﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
PREVIEW = ROOT / "app" / "ui" / "pdf_preview_widget.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not PREVIEW.exists():
    print(f"[ERROR] Not found: {PREVIEW}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

main_backup = MAIN.with_name(f"main_window.py.bak_star_whatsnew_{timestamp}")
preview_backup = PREVIEW.with_name(f"pdf_preview_widget.py.bak_remove_empty_rect_{timestamp}")

shutil.copy2(MAIN, main_backup)
shutil.copy2(PREVIEW, preview_backup)

print(f"[OK] Backup created: {main_backup}")
print(f"[OK] Backup created: {preview_backup}")

# ------------------------------------------------------------
# 1) main_window.py: add star mark to What's new
# ------------------------------------------------------------
main_text = MAIN.read_text(encoding="utf-8", errors="replace")
original_main = main_text

replacements = [
    ("What's new in 0.9.2:", "★ What's new in 0.9.2:"),
    ("What's new in 0.9.1:", "★ What's new in 0.9.1:"),
    ("What's new in 0.9.", "★ What's new in 0.9."),
]

changed = 0
for old, new in replacements:
    count = main_text.count(old)
    if count:
        main_text = main_text.replace(old, new)
        changed += count
        print(f"[OK] Welcome/notes star replace {count}: {old} -> {new}")

# Prevent double stars if script runs twice.
main_text = main_text.replace("★ ★ What's new", "★ What's new")

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 2) pdf_preview_widget.py: remove rectangle/placeholder drawing when no PDF pixmap
# ------------------------------------------------------------
preview_text = PREVIEW.read_text(encoding="utf-8", errors="replace")
original_preview = preview_text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            targets.append(node)

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno

    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

# Detect current methods/classes.
has_paint = "def paintEvent" in preview_text
has_preview_pixmap_attr = "preview_pixmap" in preview_text or "self.pixmap" in preview_text or "self._pixmap" in preview_text

print(f"[INFO] pdf_preview_widget paintEvent exists: {has_paint}")
print(f"[INFO] pixmap-related markers exist: {has_preview_pixmap_attr}")

# Try safe patch: if paintEvent exists, insert early return when no pixmap exists.
if has_paint:
    try:
        tree = ast.parse(preview_text)
        lines = preview_text.splitlines(True)

        paint_node = None
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "paintEvent":
                paint_node = node
                break

        if paint_node is None:
            raise RuntimeError("paintEvent node not found")

        start = paint_node.lineno - 1
        end = paint_node.end_lineno
        func = "".join(lines[start:end])

        if "Do not draw placeholder rectangle before a PDF is loaded" in func:
            print("[SKIP] Empty preview rectangle guard already exists")
        else:
            func_lines = func.splitlines(True)

            # Determine indent of function body.
            def_line = func_lines[0]
            body_indent = " " * (len(def_line) - len(def_line.lstrip()) + 4)

            guard = (
                f"{body_indent}# Do not draw placeholder rectangle before a PDF is loaded.\n"
                f"{body_indent}pixmap = getattr(self, 'preview_pixmap', None)\n"
                f"{body_indent}if pixmap is None:\n"
                f"{body_indent}    pixmap = getattr(self, '_pixmap', None)\n"
                f"{body_indent}if pixmap is None:\n"
                f"{body_indent}    pixmap = getattr(self, 'pixmap', None)\n"
                f"{body_indent}if pixmap is None or (hasattr(pixmap, 'isNull') and pixmap.isNull()):\n"
                f"{body_indent}    return\n\n"
            )

            # Insert after def line.
            func = func_lines[0] + guard + "".join(func_lines[1:])
            lines[start:end] = [func]
            preview_text = "".join(lines)
            print("[OK] Added empty-preview guard to paintEvent")

    except Exception as exc:
        print(f"[WARN] Could not patch paintEvent by guard: {exc}")

# Also patch common placeholder text/rectangle drawing patterns if present.
# These are conservative replacements only for no-pixmap branches.
patterns = [
    "No PDF",
    "Not selected",
    "drawRect",
    "draw_rect",
    "drawRoundedRect",
]

# If there is a clear_preview method, ensure it clears pixmap and selection but does not create a placeholder rect.
if "def clear_preview" in preview_text:
    try:
        new_clear_preview = r'''    def clear_preview(self) -> None:
        self.preview_pixmap = None

        if hasattr(self, "selection_rect"):
            self.selection_rect = QRect()

        if hasattr(self, "_selection_rect"):
            self._selection_rect = QRect()

        self.setMinimumSize(1, 1)
        self.resize(1, 1)
        self.update()
'''
        # Only replace if function references placeholder-ish painting or if simple replacement possible.
        try:
            preview_text = replace_function(preview_text, "clear_preview", new_clear_preview)
            print("[OK] clear_preview simplified to blank state")
        except Exception as exc:
            print(f"[WARN] Could not replace clear_preview: {exc}")
    except Exception as exc:
        print(f"[WARN] clear_preview patch failed: {exc}")

PREVIEW.write_text(preview_text, encoding="utf-8")

# ------------------------------------------------------------
# 3) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup in [
    (MAIN, main_backup),
    (PREVIEW, preview_backup),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_star_whatsnew_emptyrect_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 4) Verification
# ------------------------------------------------------------
main_new = MAIN.read_text(encoding="utf-8", errors="replace")
preview_new = PREVIEW.read_text(encoding="utf-8", errors="replace")

print("[INFO] Verification:")
print(f"  - star What's new exists: {'★ What' in main_new}")
print(f"  - empty preview guard exists: {'Do not draw placeholder rectangle before a PDF is loaded' in preview_new}")
print(f"  - clear_preview blank state exists: {'self.setMinimumSize(1, 1)' in preview_new}")

print("")
print("Done.")
print("- What's new now has a star mark")
print("- Empty preview placeholder rectangle should be removed before loading PDFs")
print("- Run: python main.py")
