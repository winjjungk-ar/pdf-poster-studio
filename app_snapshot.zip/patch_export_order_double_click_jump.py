﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_export_order_double_click_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Connect double click signal
# ------------------------------------------------------------
old = '''        self.export_order_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        status_layout.addWidget(self.export_order_list)
'''

new = '''        self.export_order_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.export_order_list.itemDoubleClicked.connect(self.on_export_order_item_double_clicked)
        status_layout.addWidget(self.export_order_list)
'''

if old in text and "itemDoubleClicked.connect(self.on_export_order_item_double_clicked)" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Connected Export Order double-click signal")
else:
    print("[SKIP] Double-click signal already connected or block not found")

# ------------------------------------------------------------
# 2) Add handler method before _get_export_order_entries
# ------------------------------------------------------------
method = r'''
    def on_export_order_item_double_clicked(self, item: QListWidgetItem) -> None:
        if item is None:
            return

        data = item.data(Qt.ItemDataRole.UserRole)

        if not isinstance(data, dict):
            return

        try:
            workspace_index = int(data.get("workspace_index"))
            page_index = int(data.get("page_index"))
        except Exception:
            return

        if not hasattr(self, "workspace_items") or not self.workspace_items:
            return

        if workspace_index < 0 or workspace_index >= len(self.workspace_items):
            return

        try:
            if self.current_workspace_index != workspace_index:
                self._load_workspace_index(workspace_index)

            if page_index < 0 or page_index >= self.page_count:
                return

            self._save_current_selection()
            self.current_page_index = page_index
            self._render_current_page()
            self._refresh_current_page_check_state()
            self._refresh_page_list_all_text()

            self._log(
                f"Jumped from Export Order to workspace {workspace_index + 1}, "
                f"page {page_index + 1}."
            )

        except Exception as exc:
            QMessageBox.warning(
                self,
                "Export Order",
                f"Failed to jump to selected page.\n\n{exc}"
            )
            self._log(f"Export Order jump failed: {exc}")

'''

if "def on_export_order_item_double_clicked" not in text:
    marker = "    def _get_export_order_entries(self) -> list[tuple[int, int]]:\n"
    pos = text.find(marker)

    if pos == -1:
        marker = "    def _export_workspace_to_pdf(self, output_path: str, options: ExportOptions) -> None:\n"
        pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added Export Order double-click handler")
else:
    print("[SKIP] Double-click handler already exists")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_export_order_double_click_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "itemDoubleClicked.connect(self.on_export_order_item_double_clicked)",
    "def on_export_order_item_double_clicked",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Double-click Export Order item to jump to that PDF/page preview")
