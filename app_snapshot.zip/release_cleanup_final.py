﻿from pathlib import Path
from datetime import datetime
import shutil
import sys

ROOT = Path.cwd()
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

archive_root = ROOT / "dev_archive" / f"release_cleanup_{timestamp}"
scripts_dir = archive_root / "scripts"
backups_dir = archive_root / "backups"
reports_dir = archive_root / "reports"

scripts_dir.mkdir(parents=True, exist_ok=True)
backups_dir.mkdir(parents=True, exist_ok=True)
reports_dir.mkdir(parents=True, exist_ok=True)

moved_scripts = []
moved_backups = []
moved_reports = []

# Move scripts
script_patterns = [
    "patch_*.py",
    "fix_*.py",
    "audit_*.py",
    "*check*.py",
    "extract_*.py",
    "diagnose_*.py",
    "force_*.py",
    "cleanup_*.py",
]

current_script = Path(__file__).name if "__file__" in globals() else ""

for pattern in script_patterns:
    for path in ROOT.glob(pattern):
        if path.name == current_script:
            continue
        if path.is_file():
            target = scripts_dir / path.name
            if target.exists():
                target = scripts_dir / f"{path.stem}_{timestamp}{path.suffix}"
            shutil.move(str(path), str(target))
            moved_scripts.append(path.name)

# Move reports/txt generated files
report_patterns = [
    "*report.txt",
    "*extract.txt",
    "cleanup_summary.txt",
]

for pattern in report_patterns:
    for path in ROOT.glob(pattern):
        if path.is_file():
            target = reports_dir / path.name
            if target.exists():
                target = reports_dir / f"{path.stem}_{timestamp}{path.suffix}"
            shutil.move(str(path), str(target))
            moved_reports.append(path.name)

# Move backup files under app
app_dir = ROOT / "app"
if app_dir.exists():
    for path in app_dir.rglob("*.bak_*"):
        if path.is_file():
            rel = path.relative_to(app_dir)
            target = backups_dir / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                target = target.with_name(f"{target.name}_{timestamp}")
            shutil.move(str(path), str(target))
            moved_backups.append(str(rel))

summary = archive_root / "cleanup_summary.txt"
summary.write_text(
    "\n".join([
        "# Release Cleanup Summary",
        f"timestamp: {timestamp}",
        f"root: {ROOT}",
        "",
        f"moved_scripts: {len(moved_scripts)}",
        *[f"- {x}" for x in moved_scripts],
        "",
        f"moved_reports: {len(moved_reports)}",
        *[f"- {x}" for x in moved_reports],
        "",
        f"moved_backups: {len(moved_backups)}",
        *[f"- {x}" for x in moved_backups],
        "",
        "Note: Files were moved, not deleted.",
    ]),
    encoding="utf-8"
)

print("[OK] Release cleanup complete")
print(f"- archive: {archive_root}")
print(f"- moved scripts: {len(moved_scripts)}")
print(f"- moved reports: {len(moved_reports)}")
print(f"- moved backups: {len(moved_backups)}")
print("")
print("Run the app to confirm:")
print("python main.py")
