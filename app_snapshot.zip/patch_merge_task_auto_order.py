﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_merge_task_auto_order_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

# ------------------------------------------------------------
# 1) Add helper to build Print Order from all pages
# ------------------------------------------------------------
helper = r'''
    def build_print_order_from_all_source_pages(self) -> int:
        if not hasattr(self, "workspace_items") or not self.workspace_items:
            return 0

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        total_added = 0

        for workspace_index, item in enumerate(self.workspace_items):
            page_count = int(item.get("page_count", 0) or 0)

            checked_pages = set(range(page_count))
            item["checked_pages"] = checked_pages

            for page_index in range(page_count):
                self._add_export_order_item(workspace_index, page_index)
                total_added += 1

        if self.current_workspace_index is not None:
            self._load_workspace_index(self.current_workspace_index)
        elif self.workspace_items:
            self._load_workspace_index(0)

        self._refresh_workspace_list_text()
        self._update_checked_pages_label()
        self.is_modified = True

        self._log(f"Print Order built from all source pages: {total_added} pages")
        return total_added

'''

if "def build_print_order_from_all_source_pages" not in text:
    marker = "    def task_merge_pdfs(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find task_merge_pdfs marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + helper + "\n" + text[pos:]
    print("[OK] Added build_print_order_from_all_source_pages helper")
else:
    print("[SKIP] build_print_order_from_all_source_pages already exists")

# ------------------------------------------------------------
# 2) Replace task_merge_pdfs
# ------------------------------------------------------------
new_task_merge = r'''    def task_merge_pdfs(self) -> None:
        self._set_combo_by_data_if_exists("output_area_combo", "whole_page")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self._set_combo_by_data_if_exists("batch_output_combo", "single_pdf")
        self.update_export_option_states()
        self.update_output_area_states()

        if not hasattr(self, "workspace_items") or not self.workspace_items:
            result = QMessageBox.question(
                self,
                "Merge PDFs",
                "Merge PDFs combines full pages into one PDF.\n\n"
                "No source files are open yet.\n\n"
                "Open PDFs / Images now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result == QMessageBox.StandardButton.Yes:
                self.open_pdfs()

            return

        total_added = self.build_print_order_from_all_source_pages()

        QMessageBox.information(
            self,
            "Merge PDFs",
            f"Merge setup completed.\n\n"
            f"Pages added to Print Order: {total_added}\n\n"
            "Output Area: Whole Page\n"
            "Output Files: One PDF\n"
            "Mode: Single Page PDF\n\n"
            "Click Create Single Page PDF to create the merged PDF."
        )

        if hasattr(self, "settings_tabs"):
            # Status tab is usually index 1 when Home exists.
            for index in range(self.settings_tabs.count()):
                if self.settings_tabs.tabText(index) == "Status":
                    self.settings_tabs.setCurrentIndex(index)
                    break

'''

try:
    text = replace_function(text, "task_merge_pdfs", new_task_merge)
    print("[OK] Replaced task_merge_pdfs with auto Print Order setup")
except Exception as exc:
    print(f"[ERROR] Failed to replace task_merge_pdfs: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 3) Release Notes
# ------------------------------------------------------------
if "Merge PDFs task now builds Print Order automatically" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Merge PDFs task now builds Print Order automatically</b>: All source pages are added using Whole Page mode and One PDF output.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

# ------------------------------------------------------------
# 4) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_merge_task_auto_order_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "def build_print_order_from_all_source_pages",
    "Merge setup completed",
    "Merge PDFs task now builds Print Order automatically",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Merge PDFs Home task now adds all source pages to Print Order")
print("- It sets Whole Page + One PDF + Single Page Mode")
