﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_export_order_thumbnails_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Ensure QSize import
# ------------------------------------------------------------
if "QSize" not in text:
    text = text.replace(
        "from PyQt6.QtCore import Qt, QRect, QTimer\n",
        "from PyQt6.QtCore import Qt, QRect, QTimer, QSize\n",
        1
    )
    print("[OK] Added QSize import")
else:
    print("[SKIP] QSize already imported")

# ------------------------------------------------------------
# 2) Configure export_order_list icon size
# ------------------------------------------------------------
old = '''        self.export_order_list = QListWidget()
        self.export_order_list.setMinimumHeight(150)
        self.export_order_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
'''

new = '''        self.export_order_list = QListWidget()
        self.export_order_list.setMinimumHeight(180)
        self.export_order_list.setIconSize(QSize(96, 128))
        self.export_order_list.setSpacing(6)
        self.export_order_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Configured Export Order thumbnail icon size")
else:
    print("[SKIP] Export Order list config already patched or block not found")

# ------------------------------------------------------------
# 3) Add thumbnail helper methods before _add_export_order_item
# ------------------------------------------------------------
methods = r'''
    def _create_export_order_thumbnail(self, workspace_index: int, page_index: int) -> QIcon:
        try:
            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                return QIcon()

            item = self.workspace_items[workspace_index]
            pdf_path = item.get("pdf_path", "")

            if not pdf_path:
                return QIcon()

            renderer = PdfRenderer()
            renderer.open(pdf_path)
            pixmap = renderer.render_page(page_index, zoom=0.35)

            if pixmap.isNull():
                return QIcon()

            canvas = QPixmap(96, 128)
            canvas.fill(QColor("#FFF8F0"))

            painter = QPainter(canvas)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)

            scaled = pixmap.scaled(
                86,
                118,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

            x = int((96 - scaled.width()) / 2)
            y = int((128 - scaled.height()) / 2)

            painter.setBrush(QBrush(QColor("#FFFFFF")))
            painter.setPen(QPen(QColor("#B7C9D6"), 1))
            painter.drawRoundedRect(x - 2, y - 2, scaled.width() + 4, scaled.height() + 4, 4, 4)
            painter.drawPixmap(x, y, scaled)

            # Draw selected area overlay if possible.
            selections = item.get("page_selections", {})
            rect = selections.get(page_index)

            if rect is not None and not rect.isNull() and rect.width() > 0 and rect.height() > 0:
                # Selections are stored in preview pixel coordinates.
                # Use stored current display base size if available; fallback to pixmap size.
                source_w = max(1, int(getattr(self, "current_display_base_width", pixmap.width())))
                source_h = max(1, int(getattr(self, "current_display_base_height", pixmap.height())))

                sx = scaled.width() / source_w
                sy = scaled.height() / source_h

                overlay_x = x + int(rect.x() * sx)
                overlay_y = y + int(rect.y() * sy)
                overlay_w = max(2, int(rect.width() * sx))
                overlay_h = max(2, int(rect.height() * sy))

                painter.setBrush(QBrush(QColor(255, 180, 110, 85)))
                painter.setPen(QPen(QColor("#FF9F68"), 2))
                painter.drawRoundedRect(overlay_x, overlay_y, overlay_w, overlay_h, 3, 3)

            painter.end()
            return QIcon(canvas)

        except Exception as exc:
            self._log(f"Thumbnail creation failed: workspace={workspace_index}, page={page_index + 1}, error={exc}")
            return QIcon()

'''

if "def _create_export_order_thumbnail" not in text:
    marker = "    def _add_export_order_item(self, workspace_index: int, page_index: int) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find _add_export_order_item marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + methods + "\n" + text[pos:]
    print("[OK] Added export order thumbnail helper")
else:
    print("[SKIP] Thumbnail helper already exists")

# ------------------------------------------------------------
# 4) Patch _add_export_order_item to set icon
# ------------------------------------------------------------
old = '''        pdf_path = self.workspace_items[workspace_index].get("pdf_path", "")
        list_item.setToolTip(f"{pdf_path}\\nPage {page_index + 1}")
        self.export_order_list.addItem(list_item)
'''

new = '''        pdf_path = self.workspace_items[workspace_index].get("pdf_path", "")
        list_item.setToolTip(f"{pdf_path}\\nPage {page_index + 1}")
        list_item.setIcon(self._create_export_order_thumbnail(workspace_index, page_index))
        self.export_order_list.addItem(list_item)
'''

if old in text and "setIcon(self._create_export_order_thumbnail" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Export Order items now use thumbnails")
else:
    print("[SKIP] _add_export_order_item already patched or block not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_export_order_thumbnails_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "def _create_export_order_thumbnail",
    "setIcon(self._create_export_order_thumbnail",
    "setIconSize(QSize(96, 128))",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Export Order now shows thumbnails")
print("- Selected area overlay is drawn on thumbnails when possible")
