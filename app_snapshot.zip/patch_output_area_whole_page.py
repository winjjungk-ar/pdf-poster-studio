﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_output_area_whole_page_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Version bump 0.9.4/0.9.3 -> 0.9.5
# ------------------------------------------------------------
for old in ["0.9.4", "0.9.3"]:
    if old in text:
        text = text.replace(f"Version: {old}", "Version: 0.9.5")
        text = text.replace(f'"version": "{old}"', '"version": "0.9.5"')
        text = text.replace(f"What's new in {old}", "What's new in 0.9.5")
        text = text.replace(f"Version {old}", "Version 0.9.5")

# ------------------------------------------------------------
# 2) Add Output Area combo after export_type_combo
# ------------------------------------------------------------
old = '''        self.export_type_combo = QComboBox()
        self.export_type_combo.addItem("Poster Print Mode", "a3_split")
        self.export_type_combo.addItem("Single Page Mode", "selection_only")
        self.export_type_combo.currentIndexChanged.connect(self.update_export_option_states)

        self.selection_fit_mode_combo = QComboBox()
'''

new = '''        self.export_type_combo = QComboBox()
        self.export_type_combo.addItem("Poster Print Mode", "a3_split")
        self.export_type_combo.addItem("Single Page Mode", "selection_only")
        self.export_type_combo.currentIndexChanged.connect(self.update_export_option_states)

        self.output_area_combo = QComboBox()
        self.output_area_combo.addItem("Whole Page", "whole_page")
        self.output_area_combo.addItem("Selected Area", "selected_area")
        self.output_area_combo.setCurrentIndex(0)

        self.selection_fit_mode_combo = QComboBox()
'''

if old in text and "self.output_area_combo" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Output Area combo")
else:
    print("[SKIP] Output Area combo already exists or anchor not found")

# ------------------------------------------------------------
# 3) Add Output Area UI in Export tab
# ------------------------------------------------------------
old = '''        export_layout.addWidget(QLabel("Export Type"))
        export_layout.addWidget(self.export_type_combo)
        self.export_quality_label = QLabel("Export Quality")
'''

new = '''        export_layout.addWidget(QLabel("Export Type"))
        export_layout.addWidget(self.export_type_combo)

        export_layout.addWidget(QLabel("Output Area"))
        export_layout.addWidget(self.output_area_combo)

        self.output_area_help_label = QLabel(
            "Whole Page does not require area selection.\\n"
            "Selected Area uses the area you select in the preview."
        )
        self.output_area_help_label.setWordWrap(True)
        self.output_area_help_label.setStyleSheet("color: #5F6F7A;")
        export_layout.addWidget(self.output_area_help_label)

        self.export_quality_label = QLabel("Export Quality")
'''

if old in text and "self.output_area_help_label" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Output Area UI")
else:
    print("[SKIP] Output Area UI already exists or anchor not found")

# ------------------------------------------------------------
# 4) Add helper methods before _selection_exists_for_page
# ------------------------------------------------------------
helpers = r'''
    def _is_whole_page_output_area(self) -> bool:
        return hasattr(self, "output_area_combo") and self.output_area_combo.currentData() == "whole_page"

    def _get_full_page_selection_for_pdf(self, pdf_path: str, page_index: int) -> SelectionRect:
        doc = fitz.open(str(pdf_path))
        try:
            page = doc.load_page(page_index)
            rect = page.rect
            return SelectionRect(
                x=float(rect.x0),
                y=float(rect.y0),
                width=float(rect.width),
                height=float(rect.height),
            )
        finally:
            doc.close()

    def _get_full_page_selection(self, page_index: int) -> SelectionRect:
        if not self.current_pdf_path:
            raise RuntimeError("No PDF is open.")
        return self._get_full_page_selection_for_pdf(self.current_pdf_path, page_index)

'''

if "def _is_whole_page_output_area" not in text:
    marker = "    def _selection_exists_for_page(self, page_index: int) -> bool:\n"
    pos = text.find(marker)
    if pos == -1:
        print("[ERROR] Could not find _selection_exists_for_page marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
    text = text[:pos] + helpers + "\n" + text[pos:]
    print("[OK] Added Output Area helper methods")
else:
    print("[SKIP] Output Area helper methods already exist")

# ------------------------------------------------------------
# 5) Patch _selection_exists_for_page
# ------------------------------------------------------------
pattern = re.compile(
    r"    def _selection_exists_for_page\(self, page_index: int\) -> bool:\n"
    r"        rect = self\.page_selections\.get\(page_index\)\n"
    r"        return rect is not None and not rect\.isNull\(\) and rect\.width\(\) > 0 and rect\.height\(\) > 0\n"
)

replacement = '''    def _selection_exists_for_page(self, page_index: int) -> bool:
        if self._is_whole_page_output_area():
            return self.page_count > 0 and 0 <= page_index < self.page_count

        rect = self.page_selections.get(page_index)
        return rect is not None and not rect.isNull() and rect.width() > 0 and rect.height() > 0
'''

text, count = pattern.subn(replacement, text, count=1)
print(f"[OK] Patched _selection_exists_for_page: {count}")

# ------------------------------------------------------------
# 6) Patch on_page_complete_changed no-selection warning
# ------------------------------------------------------------
old = '''        if self.page_complete_check.isChecked():
            rect = self.preview_label.get_selection_rect()
            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                self.page_complete_check.blockSignals(True)
                self.page_complete_check.setChecked(False)
                self.page_complete_check.blockSignals(False)
                QMessageBox.warning(
                    self,
                    "No Selection",
                    "Please select an area before checking this page."
                )
                return

            self._save_current_selection()
            self.checked_pages.add(self.current_page_index)
'''

new = '''        if self.page_complete_check.isChecked():
            if not self._is_whole_page_output_area():
                rect = self.preview_label.get_selection_rect()
                if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    self.page_complete_check.blockSignals(True)
                    self.page_complete_check.setChecked(False)
                    self.page_complete_check.blockSignals(False)
                    QMessageBox.warning(
                        self,
                        "No Selection",
                        "Please select an area before checking this page, or choose Output Area = Whole Page."
                    )
                    return

                self._save_current_selection()

            self.checked_pages.add(self.current_page_index)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched page checkbox for Whole Page")
else:
    print("[WARN] Could not patch on_page_complete_changed block")

# ------------------------------------------------------------
# 7) Patch _build_export_selections
# ------------------------------------------------------------
old = '''        for page_index in sorted(self.checked_pages):
            rect = self.page_selections.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            result[page_index] = self._preview_rect_to_pdf_selection(rect)
'''

new = '''        for page_index in sorted(self.checked_pages):
            if self._is_whole_page_output_area():
                result[page_index] = self._get_full_page_selection(page_index)
                continue

            rect = self.page_selections.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            result[page_index] = self._preview_rect_to_pdf_selection(rect)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched _build_export_selections for Whole Page")
else:
    print("[WARN] Could not patch _build_export_selections block")

# ------------------------------------------------------------
# 8) Patch page list item changed selection requirement
# ------------------------------------------------------------
old = '''        if item.checkState() == Qt.CheckState.Checked:
            if not self._selection_exists_for_page(page_index):
'''

new = '''        if item.checkState() == Qt.CheckState.Checked:
            if not self._selection_exists_for_page(page_index):
'''

# Requirement now handled by _selection_exists_for_page, message update only.
text = text.replace(
    f"Page {{page_index + 1}} has no selection area.",
    f"Page {{page_index + 1}} has no selection area. Choose Output Area = Whole Page to use the full page."
)

# ------------------------------------------------------------
# 9) Patch workspace export conversion blocks
# ------------------------------------------------------------
old = '''                rect = selections_qrect.get(page_index)

                if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    continue

                self.current_page_index = page_index
                self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)
                converted[page_index] = self._preview_rect_to_pdf_selection(rect)
'''

new = '''                if self._is_whole_page_output_area():
                    converted[page_index] = self._get_full_page_selection_for_pdf(pdf_path, page_index)
                    continue

                rect = selections_qrect.get(page_index)

                if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    continue

                self.current_page_index = page_index
                self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)
                converted[page_index] = self._preview_rect_to_pdf_selection(rect)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched workspace One PDF export for Whole Page")
else:
    print("[WARN] Could not patch workspace One PDF conversion block")

old = '''            rect = selections_qrect.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            # Load correct PDF/page so coordinate conversion uses correct page data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path
            self.current_page_index = page_index
            self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)

            converted = {
                page_index: self._preview_rect_to_pdf_selection(rect)
            }
'''

new = '''            # Load correct PDF/page so coordinate conversion uses correct page data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path
            self.current_page_index = page_index
            self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)

            if self._is_whole_page_output_area():
                converted = {
                    page_index: self._get_full_page_selection_for_pdf(pdf_path, page_index)
                }
            else:
                rect = selections_qrect.get(page_index)

                if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    continue

                converted = {
                    page_index: self._preview_rect_to_pdf_selection(rect)
                }
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched workspace Separate PDFs export for Whole Page")
else:
    print("[WARN] Could not patch workspace Separate conversion block")

# ------------------------------------------------------------
# 10) Save/load setting
# ------------------------------------------------------------
old = '''                "export_type": self.export_type_combo.currentData(),
                "selection_fit_mode": self.selection_fit_mode_combo.currentData(),
'''

new = '''                "export_type": self.export_type_combo.currentData(),
                "output_area": self.output_area_combo.currentData() if hasattr(self, "output_area_combo") else "whole_page",
                "selection_fit_mode": self.selection_fit_mode_combo.currentData(),
'''

if old in text and '"output_area"' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Project save includes output_area")

old = '''        self._apply_combo_data(self.export_type_combo, settings.get("export_type"))
        self._apply_combo_data(self.selection_fit_mode_combo, settings.get("selection_fit_mode"))
'''

new = '''        self._apply_combo_data(self.export_type_combo, settings.get("export_type"))
        if hasattr(self, "output_area_combo"):
            self._apply_combo_data(self.output_area_combo, settings.get("output_area", "whole_page"))
        self._apply_combo_data(self.selection_fit_mode_combo, settings.get("selection_fit_mode"))
'''

if old in text and 'settings.get("output_area"' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Project load restores output_area")

# ------------------------------------------------------------
# 11) Release Notes / Welcome
# ------------------------------------------------------------
if "Output Area option" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.5</h3>
<ul>
  <li><b>Output Area option</b>: Choose Whole Page or Selected Area.</li>
  <li>Whole Page mode allows PDF combining and full-image poster printing without area selection.</li>
  <li>Selected Area mode keeps the existing crop/area workflow.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for Output Area")

if "Output Area: Whole Page or Selected Area" not in text:
    marker = "• See Help > Release Notes for details"
    addition = "• Output Area: Whole Page or Selected Area\\n"
    if marker in text:
        text = text.replace(marker, addition + marker, 1)
        print("[OK] Welcome updated for Output Area")

# ------------------------------------------------------------
# 12) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_output_area_whole_page_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)
    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
print("[INFO] Marker check:")
for marker in [
    "Output Area",
    "Whole Page",
    "Selected Area",
    "def _is_whole_page_output_area",
    '"output_area"',
    "Output Area option",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Output Area added: Whole Page / Selected Area")
print("- Whole Page can be used without area selection")
print("- Project save/load updated")
print("- Release Notes updated")
