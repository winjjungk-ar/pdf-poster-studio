﻿from pathlib import Path
from datetime import datetime
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
OUT = ROOT / "github_ready_check_report.txt"

MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"
PREVIEW = ROOT / "app" / "ui" / "pdf_preview_widget.py"
DIST_EXE = ROOT / "dist" / "PDF Poster Studio" / "PDF Poster Studio.exe"
RELEASE_ZIP_DIR = ROOT / "release"

important_files = [
    ROOT / "main.py",
    MAIN,
    ROOT / "app" / "config.py",
    ROOT / "app" / "pdf" / "pdf_renderer.py",
    EXPORTER,
    PREVIEW,
]

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""

def run_py_compile(path: Path):
    return subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

def ast_status(text: str):
    try:
        ast.parse(text)
        return "OK"
    except SyntaxError as exc:
        return f"FAILED: {exc}"

def function_defs(text: str, name: str):
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []

    result = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            result.append((node.lineno, getattr(node, "end_lineno", node.lineno)))
    return sorted(result)

def grep_lines(text: str, terms: list[str]):
    rows = []
    for idx, line in enumerate(text.splitlines(), 1):
        if any(term.lower() in line.lower() for term in terms):
            rows.append(f"{idx:05d}: {line}")
    return rows

main_text = read(MAIN)
exporter_text = read(EXPORTER)
preview_text = read(PREVIEW)

required_main_markers = {
    "Version": [
        "Version: 0.9.",
        '"version": "0.9.',
    ],
    "Open PDFs / Images": [
        "Open PDFs / Images",
        "Open PDFs or Images",
        "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp)",
    ],
    "Output Area": [
        "Output Area",
        "Whole Page",
        "Selected Area",
        "def _is_whole_page_output_area",
    ],
    "Auto Select Page Range": [
        "Auto Select Page Range",
        "def auto_select_page_range",
        "def _parse_page_range_text",
    ],
    "Preview floating toolbar": [
        "previewFloatingToolbar",
        "def toggle_preview_floating_toolbar",
        "View ▸",
    ],
    "Zoom reset/sync": [
        "def reset_view",
        "def _sync_zoom_factor_from_current_display",
    ],
    "Poster workflow": [
        "Create Poster PDF",
        "Create Single Page PDF",
        "Tiling Preview",
        "Poster Size Preset",
        "Output Files",
        "Separate PDF per selected page",
    ],
    "Image import": [
        "def _convert_image_to_temp_pdf",
        "image_imports",
    ],
    "Multilingual guide": [
        '"English"',
        '"한국어"',
        '"日本語"',
        '"中文（简体）"',
        "language_combo",
    ],
    "Release notes": [
        "Release Notes",
    ],
}

required_exporter_markers = {
    "Vector output": [
        "show_pdf_page",
        "Keep PDF text/vector graphics sharp",
    ],
    "Poster tiling": [
        "def _export_poster_tiling",
        "def _make_poster_tiles",
        "tile_cols",
        "tile_rows",
    ],
    "Paper sizes": [
        "A4_WIDTH_PT",
        "LETTER_WIDTH_PT",
        "paper_size: str",
        "poster_scale: float",
    ],
}

old_visible_terms = [
    "A3 Split Mode",
    "Selection Only Mode",
    "Export Order",
    "PDF Workspace",
    "Collect Pages from PDFs",
    "Open Multiple PDFs",
]

report = []
report.append("# GitHub Ready Check Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- python: {sys.executable}")
report.append(f"- main_window.py lines: {len(main_text.splitlines()) if main_text else 'missing'}")
report.append(f"- poster_exporter.py lines: {len(exporter_text.splitlines()) if exporter_text else 'missing'}")
report.append(f"- pdf_preview_widget.py lines: {len(preview_text.splitlines()) if preview_text else 'missing'}")
report.append("")

# 1 files
report.append("## 1. Important files")
for path in important_files:
    report.append(f"- [{'OK' if path.exists() else 'MISSING'}] `{path.relative_to(ROOT) if path.exists() else path}`")
report.append("")

# 2 compile
report.append("## 2. py_compile")
compile_failed = False
for path in important_files:
    if not path.exists():
        report.append(f"- [SKIP] `{path}` missing")
        continue

    result = run_py_compile(path)
    if result.returncode == 0:
        report.append(f"- [OK] `{path.relative_to(ROOT)}`")
    else:
        compile_failed = True
        report.append(f"- [FAILED] `{path.relative_to(ROOT)}`")
        report.append("```text")
        report.append((result.stdout or "") + (result.stderr or ""))
        report.append("```")
report.append("")

# 3 AST
report.append("## 3. AST parse")
for path in important_files:
    if not path.exists():
        continue
    text = read(path)
    report.append(f"- [{ast_status(text)}] `{path.relative_to(ROOT)}`")
report.append("")

# 4 required main markers
report.append("## 4. Required main_window.py markers")
for group, markers in required_main_markers.items():
    missing = [m for m in markers if m not in main_text]
    if missing:
        report.append(f"- [WARN] {group}: missing")
        for m in missing:
            report.append(f"  - `{m}`")
    else:
        report.append(f"- [OK] {group}")
report.append("")

# 5 exporter markers
report.append("## 5. Required poster_exporter.py markers")
for group, markers in required_exporter_markers.items():
    missing = [m for m in markers if m not in exporter_text]
    if missing:
        report.append(f"- [WARN] {group}: missing")
        for m in missing:
            report.append(f"  - `{m}`")
    else:
        report.append(f"- [OK] {group}")
report.append("")

# 6 old terms
report.append("## 6. Old visible term counts")
for term in old_visible_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

old_rows = grep_lines(main_text, old_visible_terms)
report.append("## 7. Old visible term contexts")
if old_rows:
    report.append("```text")
    report.append("\n".join(old_rows[:200]))
    report.append("```")
else:
    report.append("- [OK] No old visible terms found.")
report.append("")

# 8 duplicates
report.append("## 8. Duplicate function checks")
for fn in [
    "_create_log_panel",
    "_create_central_ui",
    "_create_quick_toolbar",
    "open_pdfs",
    "add_pdfs_to_workspace",
    "_convert_image_to_temp_pdf",
    "show_user_guide",
    "show_release_notes",
    "auto_select_page_range",
    "export_print_pdf",
    "print_pdf",
]:
    defs = function_defs(main_text, fn)
    ok = len(defs) == 1 or (fn == "add_pdfs_to_workspace" and len(defs) in (0, 1))
    report.append(f"- [{'OK' if ok else 'WARN'}] `{fn}`: {len(defs)} definition(s)")
    for start, end in defs:
        report.append(f"  - lines {start}-{end} ({end-start+1} lines)")
report.append("")

# 9 preview
report.append("## 9. Preview empty rectangle / style check")
for marker in [
    "border: none",
    "background: transparent",
    "Do not draw placeholder rectangle before a PDF is loaded",
]:
    report.append(f"- [{'OK' if marker in preview_text else 'WARN'}] `{marker}`")
report.append("")

# 10 dist/release
report.append("## 10. Build/release package check")
report.append(f"- [{'OK' if DIST_EXE.exists() else 'WARN'}] EXE: `{DIST_EXE}`")

zip_files = sorted(RELEASE_ZIP_DIR.glob("*.zip")) if RELEASE_ZIP_DIR.exists() else []
if zip_files:
    report.append(f"- [OK] release ZIP files: {len(zip_files)}")
    for z in zip_files:
        size_mb = z.stat().st_size / (1024 * 1024)
        report.append(f"  - `{z.relative_to(ROOT)}` ({size_mb:.1f} MB)")
else:
    report.append("- [WARN] No release ZIP found.")
report.append("")

# 11 clutter
report.append("## 11. Files to avoid committing to GitHub")
patterns = [
    "patch_*.py",
    "fix_*.py",
    "force_*.py",
    "direct_*.py",
    "safe_*.py",
    "*check*.py",
    "*.bak_*",
    "__pycache__",
    "build",
    "dist",
    "release",
    "dev_archive",
]
for pattern in patterns:
    matches = list(ROOT.rglob(pattern)) if pattern in ["__pycache__", "build", "dist", "release", "dev_archive"] else list(ROOT.glob(pattern))
    report.append(f"- `{pattern}`: {len(matches)}")
report.append("")

# 12 recommended .gitignore
report.append("## 12. Recommended .gitignore")
report.append("```gitignore")
report.append("""__pycache__/
*.pyc
*.pyo
*.pyd
.venv/
venv/
build/
dist/
release/
dev_archive/
*.spec
*.bak_*
patch_*.py
fix_*.py
force_*.py
direct_*.py
safe_*.py
*_check.py
final_*_check.py
*_report.txt
data/temp_print/
data/image_imports/
exports/
projects/
""")
report.append("```")
report.append("")

# 13 manual tests
report.append("## 13. Final manual test checklist before GitHub release")
manual_tests = [
    "Run EXE from extracted ZIP in a fresh folder.",
    "Open a PDF.",
    "Open PNG/JPG image.",
    "Output Area = Whole Page, Create Single Page PDF.",
    "Output Area = Selected Area, drag selection, confirm Selected Area switch notice.",
    "Auto Select Page Range on a large PDF, e.g. 1-10.",
    "Create Poster PDF using Poster Medium.",
    "Output Files = Separate PDF per selected page.",
    "Help > User Guide language combo.",
    "Help > Release Notes.",
    "About version.",
]
for i, test in enumerate(manual_tests, 1):
    report.append(f"{i}. [ ] {test}")
report.append("")

# summary
report.append("## 14. Summary")
if compile_failed:
    report.append("- Overall: **FAILED**")
    report.append("- Fix py_compile errors before GitHub.")
else:
    report.append("- Overall: **CHECK COMPLETE**")
    report.append("- If WARN items are only build artifacts or files excluded by .gitignore, GitHub upload is OK.")
report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste github_ready_check_report.txt here.")
