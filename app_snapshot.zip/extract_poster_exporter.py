﻿from pathlib import Path
import re
import ast
import sys

ROOT = Path.cwd()
TARGET = ROOT / "app" / "pdf" / "poster_exporter.py"
OUT = ROOT / "poster_exporter_extract.txt"

if not TARGET.exists():
    print(f"[ERROR] Not found: {TARGET}")
    sys.exit(1)

text = TARGET.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines()

def line_no_from_pos(source, pos):
    return source.count("\n", 0, pos) + 1

def extract_function_block(source, func_name):
    pattern = re.compile(rf"^([ \\t]*)def {re.escape(func_name)}\\s*\\(", re.M)
    m = pattern.search(source)
    if not m:
        return None

    indent = m.group(1)
    start = m.start()
    source_lines = source.splitlines(True)

    acc = 0
    start_idx = None
    for i, line in enumerate(source_lines):
        if acc == start:
            start_idx = i
            break
        acc += len(line)

    if start_idx is None:
        return None

    base_indent_len = len(indent)
    end_idx = len(source_lines)

    for j in range(start_idx + 1, len(source_lines)):
        raw = source_lines[j]
        stripped = raw.strip()
        if not stripped:
            continue

        current_indent_len = len(raw) - len(raw.lstrip(" \\t"))

        if current_indent_len <= base_indent_len and (
            raw.lstrip().startswith("def ") or raw.lstrip().startswith("class ")
        ):
            end_idx = j
            break

    block = "".join(source_lines[start_idx:end_idx])
    start_line = line_no_from_pos(source, start)
    end_line = start_line + block.count("\\n")
    return start_line, end_line, block

patterns = [
    r"ExportOptions",
    r"SelectionRect",
    r"A4",
    r"A3",
    r"LETTER",
    r"page_width",
    r"page_height",
    r"cut",
    r"guide",
    r"line",
    r"overlap",
    r"no_cut",
    r"true_size",
    r"split",
    r"fitz",
    r"show_pdf_page",
    r"insert_pdf",
    r"draw_line",
    r"draw_rect",
    r"draw_text",
]

report = []
report.append("# poster_exporter_extract.txt")
report.append("")
report.append(f"- file: {TARGET}")
report.append(f"- lines: {len(lines)}")
report.append("")

report.append("## ast.parse")
try:
    ast.parse(text)
    report.append("- OK")
except SyntaxError as exc:
    report.append(f"- FAILED: {exc}")
report.append("")

report.append("## Keyword references")
rows = []
for idx, line in enumerate(lines, 1):
    for pat in patterns:
        if re.search(pat, line, re.I):
            rows.append(f"{idx:05d}: {line}")
            break
report.append("```text")
report.append("\\n".join(rows[:500]))
report.append("```")
report.append("")

# Extract all top-level classes and likely methods
class_names = []
for m in re.finditer(r"^class\\s+([A-Za-z0-9_]+)", text, re.M):
    class_names.append(m.group(1))

report.append("## Classes")
for name in class_names:
    report.append(f"- {name}")
report.append("")

func_names = [
    "export",
    "_export_a3_split",
    "_export_selection_only",
    "_draw_cut_guides",
    "_draw_sheet_number",
    "_create_a4_page",
    "_calculate_split",
    "_fit_rect",
    "_fill_rect",
    "_draw_guides",
]

for fn in func_names:
    block = extract_function_block(text, fn)
    report.append(f"## Function: `{fn}`")
    if block:
        s, e, code = block
        report.append(f"- lines: {s}-{e}")
        report.append("```python")
        report.append(code.rstrip())
        report.append("```")
    else:
        report.append("(not found)")
    report.append("")

OUT.write_text("\\n".join(report), encoding="utf-8")
print(f"[OK] Extracted: {OUT}")
print("Paste poster_exporter_extract.txt here.")
