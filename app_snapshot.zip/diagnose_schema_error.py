﻿from pathlib import Path
import ast
import re
import sys
from datetime import datetime

ROOT = Path.cwd()
OUT = ROOT / "schema_error_diagnose.txt"

targets = [
    ROOT / "main.py",
    ROOT / "app" / "db" / "database.py",
    ROOT / "app" / "config.py",
    ROOT / "app" / "utils" / "paths.py",
]

patterns = [
    r"schema\.sql",
    r"sqlite",
    r"connect",
    r"initialize",
    r"database",
    r"DB",
    r"DATA_DIR",
    r"Path",
    r"__file__",
    r"_MEIPASS",
    r"open\(",
    r"read_text",
    r"executescript",
]

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""

def syntax_status(source: str):
    try:
        ast.parse(source)
        return "OK"
    except SyntaxError as exc:
        return f"FAILED: {exc}"

def get_functions(source: str):
    result = []
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return result

    lines = source.splitlines()

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            start = node.lineno
            end = getattr(node, "end_lineno", node.lineno)
            code = "\n".join(lines[start - 1:end])
            result.append((node.name, start, end, code))

    return sorted(result, key=lambda x: x[1])

def grep_context(source: str, patterns: list[str], radius: int = 5):
    lines = source.splitlines()
    hits = []

    for idx, line in enumerate(lines):
        for pat in patterns:
            if re.search(pat, line, re.I):
                start = max(0, idx - radius)
                end = min(len(lines), idx + radius + 1)
                block = "\n".join(f"{i+1:05d}: {lines[i]}" for i in range(start, end))
                hits.append((idx + 1, pat, block))
                break

    return hits

report = []
report.append("# schema_error_diagnose.txt")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- python: {sys.executable}")
report.append("")

report.append("## File existence")
for path in targets:
    report.append(f"- [{'OK' if path.exists() else 'MISSING'}] `{path}`")
report.append("")

for path in targets:
    report.append(f"## File: `{path.relative_to(ROOT) if path.exists() else path}`")

    if not path.exists():
        report.append("- missing")
        report.append("")
        continue

    source = read(path)
    report.append(f"- lines: {len(source.splitlines())}")
    report.append(f"- ast: {syntax_status(source)}")
    report.append("")

    report.append("### Keyword contexts")
    hits = grep_context(source, patterns, radius=4)

    if hits:
        for line_no, pat, block in hits[:40]:
            report.append(f"#### hit line {line_no}, pattern `{pat}`")
            report.append("```text")
            report.append(block)
            report.append("```")
    else:
        report.append("(none)")
    report.append("")

    report.append("### Functions")
    funcs = get_functions(source)

    if funcs:
        for name, start, end, code in funcs:
            # Include likely relevant functions only.
            if re.search(r"init|database|schema|path|config|dir|db|connect", name, re.I):
                report.append(f"#### `{name}` lines {start}-{end}")
                report.append("```python")
                report.append(code)
                report.append("```")
    else:
        report.append("(none)")
    report.append("")

# Also check actual schema file.
schema = ROOT / "app" / "db" / "schema.sql"
report.append("## schema.sql check")
if schema.exists():
    text = schema.read_text(encoding="utf-8", errors="replace")
    report.append(f"- path: {schema}")
    report.append(f"- size: {schema.stat().st_size} bytes")
    report.append(f"- first 80 lines:")
    report.append("```sql")
    report.append("\n".join(text.splitlines()[:80]))
    report.append("```")
else:
    report.append("- schema.sql missing")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste schema_error_diagnose.txt here.")
