﻿from pathlib import Path
import ast
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
OUT = ROOT / "wholepage_rotation_diagnose.txt"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

text = MAIN.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines()

def function_block(name):
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return f"SYNTAX ERROR: {exc}"

    blocks = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            start = node.lineno
            end = node.end_lineno
            code = "\n".join(lines[start - 1:end])
            blocks.append((start, end, code))

    if not blocks:
        return "(not found)"

    result = []
    for start, end, code in sorted(blocks):
        result.append(f"lines {start}-{end}")
        result.append("```python")
        result.append(code)
        result.append("```")
    return "\n".join(result)

markers = [
    "page_rotations",
    "def _get_current_rotation_degrees",
    "def _set_current_rotation_degrees",
    "def _get_page_rotation_degrees",
    "_get_current_rotation_degrees()",
    "_is_whole_page_output_area()",
    "Whole Page export now auto-uses current page",
    "Page-specific rotation",
    "item[\"page_rotations\"]",
    "page_rotation = 0",
]

report = []
report.append("# wholepage_rotation_diagnose.txt")
report.append("")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py lines: {len(lines)}")
report.append("")

report.append("## Marker counts")
for m in markers:
    report.append(f"- `{m}`: {text.count(m)}")
report.append("")

report.append("## Relevant line contexts")
for idx, line in enumerate(lines, 1):
    if any(m in line for m in [
        "page_rotations",
        "_get_current_rotation",
        "_set_current_rotation",
        "Whole Page export",
        "Page-specific rotation",
        "angle =",
        "rotation_degrees",
        "no checked",
        "No checked",
        "checked_pages",
    ]):
        report.append(f"{idx:05d}: {line}")
report.append("")

for fn in [
    "__init__",
    "_build_export_selections",
    "_show_pixmap",
    "_render_current_page",
    "rotate_left",
    "rotate_right",
    "reset_rotation",
    "reset_view",
    "_save_current_workspace_state",
    "_load_workspace_index",
    "_serialize_workspace_items",
    "_restore_workspace_items_from_project",
    "_create_export_order_thumbnail",
]:
    report.append(f"## Function `{fn}`")
    report.append(function_block(fn))
    report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Please paste wholepage_rotation_diagnose.txt here.")
