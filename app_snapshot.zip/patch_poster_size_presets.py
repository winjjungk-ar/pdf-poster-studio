﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_poster_size_presets_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add preset combo after poster_scale_spin creation
# ------------------------------------------------------------
old = '''        self.poster_scale_spin = QSpinBox()
        self.poster_scale_spin.setRange(100, 500)
        self.poster_scale_spin.setSingleStep(25)
        self.poster_scale_spin.setSuffix("%")
        self.poster_scale_spin.setValue(100)
        self.poster_scale_spin.valueChanged.connect(self.update_poster_sheet_estimate)

        self.poster_sheet_estimate_label = QLabel("Estimated Sheets: -")
'''

new = '''        self.poster_size_preset_combo = QComboBox()
        self.poster_size_preset_combo.addItem("Manual / Custom", None)

        self.poster_size_preset_combo.addItem("A3 from A4 - 141%", 141)
        self.poster_size_preset_combo.addItem("A2 from A4 - 200%", 200)
        self.poster_size_preset_combo.addItem("A1 from A4 - 283%", 283)
        self.poster_size_preset_combo.addItem("A0 from A4 - 400%", 400)

        self.poster_size_preset_combo.addItem("ANSI B / Tabloid - 141%", 141)
        self.poster_size_preset_combo.addItem("ANSI C - 200%", 200)
        self.poster_size_preset_combo.addItem("ANSI D - 283%", 283)
        self.poster_size_preset_combo.addItem("ANSI E - 400%", 400)

        self.poster_size_preset_combo.addItem("Arch B - 152%", 152)
        self.poster_size_preset_combo.addItem("Arch C - 215%", 215)
        self.poster_size_preset_combo.addItem("Arch D - 304%", 304)
        self.poster_size_preset_combo.addItem("Arch E - 430%", 430)
        self.poster_size_preset_combo.currentIndexChanged.connect(self.on_poster_size_preset_changed)

        self.poster_scale_spin = QSpinBox()
        self.poster_scale_spin.setRange(100, 500)
        self.poster_scale_spin.setSingleStep(25)
        self.poster_scale_spin.setSuffix("%")
        self.poster_scale_spin.setValue(100)
        self.poster_scale_spin.valueChanged.connect(self.on_poster_scale_changed)

        self.poster_sheet_estimate_label = QLabel("Estimated Sheets: -")
'''

if old in text and "self.poster_size_preset_combo" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added poster size preset combo")
else:
    print("[SKIP] Preset combo already exists or target block not found")

# ------------------------------------------------------------
# 2) Add preset combo to layout
# ------------------------------------------------------------
old = '''        a3_layout.addWidget(QLabel("Output Paper Size"))
        a3_layout.addWidget(self.paper_size_combo)
        a3_layout.addWidget(QLabel("Poster Scale"))
        a3_layout.addWidget(self.poster_scale_spin)
        a3_layout.addWidget(self.poster_sheet_estimate_label)
'''

new = '''        a3_layout.addWidget(QLabel("Output Paper Size"))
        a3_layout.addWidget(self.paper_size_combo)
        a3_layout.addWidget(QLabel("Poster Size Preset"))
        a3_layout.addWidget(self.poster_size_preset_combo)
        a3_layout.addWidget(QLabel("Poster Scale"))
        a3_layout.addWidget(self.poster_scale_spin)
        a3_layout.addWidget(self.poster_sheet_estimate_label)
'''

if old in text and 'QLabel("Poster Size Preset")' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added poster size preset to layout")
else:
    print("[SKIP] Preset layout already exists or target block not found")

# ------------------------------------------------------------
# 3) Add event handlers before update_poster_sheet_estimate
# ------------------------------------------------------------
methods = r'''
    def on_poster_size_preset_changed(self) -> None:
        if not hasattr(self, "poster_size_preset_combo"):
            return

        preset_value = self.poster_size_preset_combo.currentData()

        if preset_value is None:
            self.update_poster_sheet_estimate()
            return

        if hasattr(self, "poster_scale_spin"):
            self.poster_scale_spin.blockSignals(True)
            self.poster_scale_spin.setValue(int(preset_value))
            self.poster_scale_spin.blockSignals(False)

        self.update_poster_sheet_estimate()

    def on_poster_scale_changed(self) -> None:
        if hasattr(self, "poster_size_preset_combo"):
            current_preset = self.poster_size_preset_combo.currentData()

            if current_preset is not None and int(current_preset) != int(self.poster_scale_spin.value()):
                self.poster_size_preset_combo.blockSignals(True)
                self.poster_size_preset_combo.setCurrentIndex(0)
                self.poster_size_preset_combo.blockSignals(False)

        self.update_poster_sheet_estimate()

'''

if "def on_poster_size_preset_changed" not in text:
    marker = "    def update_poster_sheet_estimate(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find update_poster_sheet_estimate marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + methods + "\n" + text[pos:]
    print("[OK] Added poster preset handlers")
else:
    print("[SKIP] Preset handlers already exist")

# ------------------------------------------------------------
# 4) Save/load preset text/value
# ------------------------------------------------------------
old = '''                "poster_scale_percent": self.poster_scale_spin.value() if hasattr(self, "poster_scale_spin") else 100,
            },
'''

new = '''                "poster_scale_percent": self.poster_scale_spin.value() if hasattr(self, "poster_scale_spin") else 100,
                "poster_size_preset_index": self.poster_size_preset_combo.currentIndex() if hasattr(self, "poster_size_preset_combo") else 0,
            },
'''

if old in text and '"poster_size_preset_index"' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Project save includes poster preset index")
else:
    print("[SKIP] Project save preset already present or anchor not found")

old = '''        if hasattr(self, "poster_scale_spin"):
            self.poster_scale_spin.setValue(int(settings.get("poster_scale_percent", 100)))

        workspace = data.get("workspace", {})
'''

new = '''        if hasattr(self, "poster_scale_spin"):
            self.poster_scale_spin.setValue(int(settings.get("poster_scale_percent", 100)))
        if hasattr(self, "poster_size_preset_combo"):
            try:
                preset_index = int(settings.get("poster_size_preset_index", 0))
                if 0 <= preset_index < self.poster_size_preset_combo.count():
                    self.poster_size_preset_combo.setCurrentIndex(preset_index)
            except Exception:
                pass

        workspace = data.get("workspace", {})
'''

if old in text and "poster_size_preset_index" not in text[text.find("def _apply_project_data"):text.find("workspace = data.get")]:
    text = text.replace(old, new, 1)
    print("[OK] Project load restores poster preset index")
else:
    print("[SKIP] Project load preset already present or anchor not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_poster_size_presets_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "self.poster_size_preset_combo",
    "A0 from A4 - 400%",
    "ANSI E - 400%",
    "Arch E - 430%",
    "def on_poster_size_preset_changed",
    "def on_poster_scale_changed",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Poster Size Preset added")
print("- Manual scale input is still supported")
print("- Selecting a preset updates Poster Scale automatically")
print("- Manual scale change resets preset to Manual / Custom")
