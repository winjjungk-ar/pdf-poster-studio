﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_auto_select_workspace_toolbar_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Import QToolBar if missing
# ------------------------------------------------------------
if "QToolBar" not in text:
    text = text.replace(
        "    QTabWidget,\n",
        "    QTabWidget,\n    QToolBar,\n",
        1
    )
    print("[OK] Added QToolBar import")
else:
    print("[SKIP] QToolBar already imported")

# ------------------------------------------------------------
# 2) Add top toolbar after menu creation
# ------------------------------------------------------------
if "def _create_quick_toolbar" not in text:
    toolbar_method = r'''
    def _create_quick_toolbar(self) -> None:
        toolbar = QToolBar("Quick Actions", self)
        toolbar.setMovable(False)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, toolbar)

        auto_current_action = QAction("Auto Select Current Page", self)
        auto_current_action.triggered.connect(self.auto_select_content)
        toolbar.addAction(auto_current_action)

        auto_all_action = QAction("Auto Select All Pages", self)
        auto_all_action.triggered.connect(self.auto_select_all_pages)
        toolbar.addAction(auto_all_action)

        toolbar.addSeparator()

        export_action = QAction("Export PDF", self)
        export_action.triggered.connect(self.export_print_pdf)
        toolbar.addAction(export_action)

'''
    marker = "    def _create_menus(self) -> None:\n"
    pos = text.find(marker)
    if pos == -1:
        print("[ERROR] Could not find _create_menus marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + toolbar_method + "\n" + text[pos:]
    print("[OK] Added _create_quick_toolbar method")
else:
    print("[SKIP] _create_quick_toolbar already exists")

old = """        self._create_menus()
        self._create_central_ui()
"""
new = """        self._create_menus()
        self._create_quick_toolbar()
        self._create_central_ui()
"""

if old in text and "self._create_quick_toolbar()" not in text[text.find("def __init__"):text.find("def _create_quick_toolbar") if "def _create_quick_toolbar" in text else text.find("def _create_menus")]:
    text = text.replace(old, new, 1)
    print("[OK] Connected toolbar creation in __init__")
elif "self._create_quick_toolbar()" in text:
    print("[SKIP] Toolbar creation already connected")
else:
    print("[WARN] Could not patch __init__ toolbar creation")

# ------------------------------------------------------------
# 3) Add workspace auto-select helper methods before auto_select_all_pages
# ------------------------------------------------------------
helper_methods = r'''
    def _auto_select_all_pages_for_current_pdf_no_prompt(self) -> int:
        if not self.current_pdf_path or self.page_count <= 0:
            return 0

        threshold = 245
        if hasattr(self, "auto_select_sensitivity_combo"):
            threshold = int(self.auto_select_sensitivity_combo.currentData())

        selected_count = 0
        original_page_index = self.current_page_index

        for page_index in range(self.page_count):
            try:
                pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)
                self.current_pixmap = pixmap
                self.preview_label.set_preview_pixmap(pixmap)

                rect = self.preview_label.auto_select_content(threshold=threshold, padding=8)

                if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    self.page_selections.pop(page_index, None)
                    self.checked_pages.discard(page_index)
                    continue

                self.page_selections[page_index] = QRect(rect)
                self.checked_pages.add(page_index)
                selected_count += 1

            except Exception as exc:
                self._log(f"Auto Select failed on page {page_index + 1}: {exc}")

        self.current_page_index = max(0, min(original_page_index, self.page_count - 1))
        self._render_current_page()
        self._refresh_page_list_all_text()
        self._refresh_current_page_check_state()
        self._update_checked_pages_label()

        return selected_count

    def auto_select_all_workspace_pages(self) -> None:
        if not hasattr(self, "workspace_items") or not self.workspace_items:
            QMessageBox.information(self, "Auto Select All Pages", "Workspace is empty.")
            return

        result = QMessageBox.question(
            self,
            "Auto Select All Workspace Pages",
            "Automatically detect content area for all pages in all workspace PDFs?\n\n"
            "Existing selections may be replaced.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if result != QMessageBox.StandardButton.Yes:
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        original_workspace_index = self.current_workspace_index
        total_selected = 0
        total_pages = 0

        for workspace_index, item in enumerate(self.workspace_items):
            try:
                self._load_workspace_index(workspace_index)
                total_pages += self.page_count

                selected_count = self._auto_select_all_pages_for_current_pdf_no_prompt()
                total_selected += selected_count

                self._save_current_workspace_state()

                self._log(
                    f"Workspace auto selected: {Path(item.get('pdf_path', '')).name}, "
                    f"selected={selected_count}/{self.page_count}"
                )

            except Exception as exc:
                self._log(f"Workspace auto select failed: {item.get('pdf_path', '')}: {exc}")

        if original_workspace_index is not None and 0 <= original_workspace_index < len(self.workspace_items):
            self._load_workspace_index(original_workspace_index)
        elif self.workspace_items:
            self._load_workspace_index(0)

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        self.is_modified = True

        QMessageBox.information(
            self,
            "Auto Select All Workspace Pages",
            f"Auto selection completed.\n\nSelected pages: {total_selected}/{total_pages}"
        )

'''

if "def auto_select_all_workspace_pages" not in text:
    marker = "    def auto_select_all_pages(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find auto_select_all_pages marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + helper_methods + "\n" + text[pos:]
    print("[OK] Added workspace auto-select helper methods")
else:
    print("[SKIP] Workspace auto-select helper methods already exist")

# ------------------------------------------------------------
# 4) Patch auto_select_all_pages to route workspace mode
# ------------------------------------------------------------
marker = "    def auto_select_all_pages(self) -> None:\n"
start = text.find(marker)

if start == -1:
    print("[ERROR] auto_select_all_pages not found")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Only patch if not already routed.
func_head_area = text[start:start + 500]
if "self.auto_select_all_workspace_pages()" not in func_head_area:
    insert_after = marker
    route = """        if hasattr(self, "workspace_items") and len(self.workspace_items) > 1:
            self.auto_select_all_workspace_pages()
            return

"""
    text = text.replace(insert_after, insert_after + route, 1)
    print("[OK] Patched auto_select_all_pages workspace route")
else:
    print("[SKIP] auto_select_all_pages already routes workspace mode")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_auto_select_workspace_toolbar_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

required = [
    "def _create_quick_toolbar",
    "self._create_quick_toolbar()",
    "def auto_select_all_workspace_pages",
    "self.auto_select_all_workspace_pages()",
]

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Top toolbar added: Auto Select Current Page / Auto Select All Pages / Export PDF")
print("- Auto Select All Pages now handles all PDFs in Workspace")
