﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_force_rename_labels_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

before_count = {
    "PDF Workspace": text.count("PDF Workspace"),
    "Export Order": text.count("Export Order"),
    "Build Export Order": text.count("Build Export Order"),
    "Refresh Order": text.count("Refresh Order"),
    "export order": text.count("export order"),
    "Export order": text.count("Export order"),
}

print("[INFO] Before counts:")
for k, v in before_count.items():
    print(f"  - {k}: {v}")

# ------------------------------------------------------------
# Direct global user-facing text replacements.
# Keep internal variable names untouched because these are phrases with spaces.
# ------------------------------------------------------------
replacements = [
    ("PDF Workspace", "Source PDFs"),
    ("Export Order", "Print Order"),
    ("Build Export Order", "Build Print Order"),
    ("Refresh Order", "Build Print Order"),
    ("export order", "print order"),
    ("Export order", "Print order"),
    ("workspace PDF", "source PDF"),
    ("workspace PDFs", "source PDFs"),
    ("Workspace PDF", "Source PDF"),
    ("Workspace PDFs", "Source PDFs"),
    ("Workspace output PDF", "Print output PDF"),
    ("Open one or more PDFs as source files, or continue an existing project.", 
     "Open one or more source PDF files, or continue an existing project."),
    ("Start a new print workspace from PDFs, or continue an existing project.",
     "Open one or more source PDF files, or continue an existing project."),
    ("Select areas, build the export order, then export.",
     "Select areas, build the print order, then export."),
    ("Create the print PDF using this page order?",
     "Create the print PDF using this page order?"),
    ("Export the selected pages in this order?",
     "Create the print PDF using this page order?"),
]

changed = 0
for old, new in replacements:
    c = text.count(old)
    if c:
        text = text.replace(old, new)
        changed += c
        print(f"[OK] {old} -> {new}: {c}")

# ------------------------------------------------------------
# Regex fallback for common PyQt widget constructors.
# ------------------------------------------------------------
regex_replacements = [
    (r'QLabel\(\s*["\']PDF Workspace["\']\s*\)', 'QLabel("Source PDFs")'),
    (r'QLabel\(\s*["\']Export Order["\']\s*\)', 'QLabel("Print Order")'),
    (r'QPushButton\(\s*["\']Build Export Order["\']\s*\)', 'QPushButton("Build Print Order")'),
    (r'QPushButton\(\s*["\']Refresh Order["\']\s*\)', 'QPushButton("Build Print Order")'),
]

for pattern, repl in regex_replacements:
    text, c = re.subn(pattern, repl, text)
    if c:
        changed += c
        print(f"[OK] regex replaced {c}: {pattern}")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_force_rename_labels_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

after_count = {
    "PDF Workspace": new_text.count("PDF Workspace"),
    "Export Order": new_text.count("Export Order"),
    "Build Export Order": new_text.count("Build Export Order"),
    "Refresh Order": new_text.count("Refresh Order"),
    "Source PDFs": new_text.count("Source PDFs"),
    "Print Order": new_text.count("Print Order"),
    "Build Print Order": new_text.count("Build Print Order"),
}

print("[INFO] After counts:")
for k, v in after_count.items():
    print(f"  - {k}: {v}")

# Show remaining old text contexts if any.
old_terms = ["PDF Workspace", "Export Order", "Build Export Order", "Refresh Order"]
remaining = []

for idx, line in enumerate(new_text.splitlines(), 1):
    if any(term in line for term in old_terms):
        remaining.append(f"{idx:05d}: {line}")

if remaining:
    print("[WARN] Some old terms still remain:")
    for line in remaining[:40]:
        print(line)
else:
    print("[OK] No old visible terms found")

print("[OK] py_compile passed")
print("")
print("Done.")
print(f"- replacements applied: {changed}")
print("- Run python main.py and check labels again.")
