﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_feedback_link_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

FEEDBACK_URL = "https://github.com/winjjungk-ar/pdf-poster-studio/issues/new"

# ------------------------------------------------------------
# 1) Ensure webbrowser import
# ------------------------------------------------------------
if "import webbrowser" not in text:
    # Add after standard imports near top
    if "import os\n" in text:
        text = text.replace("import os\n", "import os\nimport webbrowser\n", 1)
    else:
        text = "import webbrowser\n" + text
    print("[OK] Added webbrowser import")
else:
    print("[SKIP] webbrowser already imported")

# ------------------------------------------------------------
# 2) Add feedback method
# ------------------------------------------------------------
method = f'''
    def send_feedback(self) -> None:
        try:
            webbrowser.open("{FEEDBACK_URL}")
            self._log("Opened feedback page.")
        except Exception as exc:
            QMessageBox.warning(
                self,
                "Send Feedback",
                f"Failed to open feedback page.\\\\n\\\\n{{exc}}"
            )
            self._log(f"Open feedback page error: {{exc}}")

'''

if "def send_feedback(self) -> None:" not in text:
    marker = "    def show_user_guide(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        marker = "    def show_about(self) -> None:\n"
        pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find insertion point for send_feedback")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added send_feedback method")
else:
    print("[SKIP] send_feedback already exists")

# ------------------------------------------------------------
# 3) Add Help menu item
# ------------------------------------------------------------
old = '''        # Help
        help_menu.addAction("User Guide / How to Use", self.show_user_guide)
        help_menu.addAction("Release Notes", self.show_release_notes)
        help_menu.addSeparator()
        help_menu.addAction("About Program", self.show_about)
'''

new = '''        # Help
        help_menu.addAction("User Guide / How to Use", self.show_user_guide)
        help_menu.addAction("Release Notes", self.show_release_notes)
        help_menu.addAction("Send Feedback", self.send_feedback)
        help_menu.addSeparator()
        help_menu.addAction("About Program", self.show_about)
'''

if old in text and "Send Feedback" not in text[text.find("def _create_menus"):text.find("def _create_app_icon") if "def _create_app_icon" in text else text.find("def _create_quick_toolbar")]:
    text = text.replace(old, new, 1)
    print("[OK] Added Help > Send Feedback")
elif "Send Feedback" in text:
    print("[SKIP] Send Feedback already exists")
else:
    print("[WARN] Could not find Help menu block")

# ------------------------------------------------------------
# 4) Add feedback note to Welcome popup
# ------------------------------------------------------------
if "Feedback: GitHub Issues" not in text:
    old_note = '''        note = QLabel("Tip: You can also use the Home tab later to switch workflows.")
'''
    new_note = '''        note = QLabel(
            "Tip: You can also use the Home tab later to switch workflows.\\n"
            "Feedback: GitHub Issues from Help > Send Feedback."
        )
'''
    if old_note in text:
        text = text.replace(old_note, new_note, 1)
        print("[OK] Added feedback note to welcome popup")
    else:
        print("[WARN] Could not find welcome note block")
else:
    print("[SKIP] Welcome feedback note already exists")

# ------------------------------------------------------------
# 5) Add feedback link to Release Notes
# ------------------------------------------------------------
if FEEDBACK_URL not in text:
    anchor = '''<h3>Known Notes</h3>
<ul>
'''
    replacement = f'''<h3>Feedback</h3>
<p>
Please report bugs or suggestions here:<br>
<a href="{FEEDBACK_URL}">{FEEDBACK_URL}</a>
</p>

<hr>

<h3>Known Notes</h3>
<ul>
'''
    if anchor in text:
        text = text.replace(anchor, replacement, 1)
        print("[OK] Added feedback link to Release Notes")
    else:
        print("[WARN] Could not find Release Notes Known Notes anchor")
else:
    print("[SKIP] Feedback URL already present in text")

# ------------------------------------------------------------
# 6) Add feedback to About if simple marker exists
# ------------------------------------------------------------
# This is conservative: append URL into About text if Creator line is present.
if "GitHub Issues" not in text:
    text = text.replace(
        'f"PDF Poster Studio\\nVersion: 0.9.6\\nCreator: {CREATOR}"',
        f'f"PDF Poster Studio\\\\nVersion: 0.9.6\\\\nCreator: {{CREATOR}}\\\\nFeedback: {FEEDBACK_URL}"'
    )

# ------------------------------------------------------------
# 7) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_feedback_link_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "def send_feedback",
    "Send Feedback",
    FEEDBACK_URL,
    "webbrowser.open",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Help > Send Feedback added")
print("- Feedback opens GitHub Issues in browser")
print("- Welcome / Release Notes feedback references added")
