﻿from pathlib import Path
from datetime import datetime
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
OUT = ROOT / "final_093_check_report.txt"

MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"
PREVIEW = ROOT / "app" / "ui" / "pdf_preview_widget.py"

important_files = [
    ROOT / "main.py",
    MAIN,
    ROOT / "app" / "config.py",
    ROOT / "app" / "pdf" / "pdf_renderer.py",
    EXPORTER,
    PREVIEW,
]

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""

def py_compile(path: Path):
    return subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

def ast_status(text: str):
    try:
        ast.parse(text)
        return "OK"
    except SyntaxError as exc:
        return f"FAILED: {exc}"

def function_defs(text: str, name: str):
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []

    result = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            result.append((node.lineno, getattr(node, "end_lineno", node.lineno)))
    return sorted(result)

def grep_lines(text: str, terms: list[str]):
    rows = []
    for idx, line in enumerate(text.splitlines(), 1):
        if any(term.lower() in line.lower() for term in terms):
            rows.append(f"{idx:05d}: {line}")
    return rows

main_text = read(MAIN)
exporter_text = read(EXPORTER)
preview_text = read(PREVIEW)

required_main = {
    "Version 0.9.3": [
        "Version: 0.9.3",
        '"version": "0.9.3"',
    ],
    "Open PDFs / Images UI": [
        "Open PDFs / Images",
        "Open PDFs or Images",
        "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp)",
        "Image Files (*.png *.jpg *.jpeg *.bmp *.webp)",
    ],
    "Image import helpers": [
        "def _is_supported_image_path",
        "def _prepare_source_file_for_workspace",
        "def _convert_image_to_temp_pdf",
        "data/image_imports",
    ],
    "Multilingual guide": [
        '"English"',
        '"한국어"',
        '"日本語"',
        '"中文（简体）"',
        "language_combo",
    ],
    "Poster workflow": [
        "Create Poster PDF",
        "Create Single Page PDF",
        "Tiling Preview",
        "Poster Size Preset",
        "Output Files",
        "Separate PDF per selected page",
    ],
    "Release Notes": [
        "Release Notes",
        "Image import support",
    ],
}

old_terms = [
    "A3 Split Mode",
    "Selection Only Mode",
    "Export Order",
    "PDF Workspace",
    "Collect Pages from PDFs",
    "Open Multiple PDFs",
]

report = []
report.append("# Final 0.9.3 Check Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- python: {sys.executable}")
report.append(f"- main_window.py lines: {len(main_text.splitlines()) if main_text else 'missing'}")
report.append(f"- poster_exporter.py lines: {len(exporter_text.splitlines()) if exporter_text else 'missing'}")
report.append(f"- pdf_preview_widget.py lines: {len(preview_text.splitlines()) if preview_text else 'missing'}")
report.append("")

report.append("## 1. Important files")
for path in important_files:
    report.append(f"- [{'OK' if path.exists() else 'MISSING'}] `{path.relative_to(ROOT) if path.exists() else path}`")
report.append("")

report.append("## 2. py_compile")
compile_failed = False
for path in important_files:
    if not path.exists():
        report.append(f"- [SKIP] `{path}` missing")
        continue

    result = py_compile(path)
    if result.returncode == 0:
        report.append(f"- [OK] `{path.relative_to(ROOT)}`")
    else:
        compile_failed = True
        report.append(f"- [FAILED] `{path.relative_to(ROOT)}`")
        report.append("```text")
        report.append((result.stdout or "") + (result.stderr or ""))
        report.append("```")
report.append("")

report.append("## 3. AST parse")
for path in important_files:
    if not path.exists():
        continue
    text = read(path)
    report.append(f"- [{ast_status(text)}] `{path.relative_to(ROOT)}`")
report.append("")

report.append("## 4. Required 0.9.3 markers in main_window.py")
for group, markers in required_main.items():
    missing = [m for m in markers if m not in main_text]
    if missing:
        report.append(f"- [WARN] {group}: missing")
        for m in missing:
            report.append(f"  - `{m}`")
    else:
        report.append(f"- [OK] {group}")
report.append("")

report.append("## 5. Old visible term counts")
for term in old_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

old_rows = grep_lines(main_text, old_terms)
report.append("## 6. Old visible term contexts")
if old_rows:
    report.append("```text")
    report.append("\n".join(old_rows[:200]))
    report.append("```")
else:
    report.append("- [OK] No old visible terms found.")
report.append("")

report.append("## 7. Duplicate function checks")
for fn in [
    "_create_log_panel",
    "_create_central_ui",
    "_create_quick_toolbar",
    "open_pdfs",
    "add_pdfs_to_workspace",
    "_convert_image_to_temp_pdf",
    "show_user_guide",
    "show_release_notes",
    "export_print_pdf",
    "print_pdf",
]:
    defs = function_defs(main_text, fn)
    status = "OK" if len(defs) == 1 or (fn == "add_pdfs_to_workspace" and len(defs) in (0, 1)) else "WARN"
    report.append(f"- [{status}] `{fn}`: {len(defs)} definition(s)")
    for start, end in defs:
        report.append(f"  - lines {start}-{end} ({end-start+1} lines)")
report.append("")

report.append("## 8. Image dialog/filter contexts")
rows = grep_lines(main_text, [
    "Open PDFs / Images",
    "Open PDFs or Images",
    "PDF and Image Files",
    "Image Files",
    "getOpenFileNames",
    "_convert_image_to_temp_pdf",
])
report.append("```text")
report.append("\n".join(rows[:300]))
report.append("```")
report.append("")

report.append("## 9. Preview empty rectangle check")
for marker in [
    "border: none",
    "background: transparent",
    "Do not draw placeholder rectangle before a PDF is loaded",
]:
    report.append(f"- [{'OK' if marker in preview_text else 'WARN'}] `{marker}`")
report.append("")

report.append("## 10. Patch/backup clutter")
patch_scripts = sorted(ROOT.glob("patch_*.py")) + sorted(ROOT.glob("fix_*.py")) + sorted(ROOT.glob("force_*.py")) + sorted(ROOT.glob("*check*.py")) + sorted(ROOT.glob("direct_*.py")) + sorted(ROOT.glob("safe_*.py"))
backup_files = sorted((ROOT / "app").rglob("*.bak_*")) if (ROOT / "app").exists() else []

report.append(f"- root patch/fix/check scripts: {len(patch_scripts)}")
for p in patch_scripts[:80]:
    report.append(f"  - `{p.name}`")
if len(patch_scripts) > 80:
    report.append(f"  - ... and {len(patch_scripts)-80} more")

report.append(f"- app backup files: {len(backup_files)}")
for p in backup_files[:80]:
    report.append(f"  - `{p.relative_to(ROOT)}`")
if len(backup_files) > 80:
    report.append(f"  - ... and {len(backup_files)-80} more")
report.append("")

report.append("## 11. Summary")
if compile_failed:
    report.append("- Overall: **FAILED**")
else:
    report.append("- Overall: **CHECK COMPLETE**")
    report.append("- If marker warnings are none or only non-user-facing compatibility names, proceed to manual testing.")
report.append("")

report.append("## 12. Recommended manual tests")
report.append("1. Open PDFs / Images and select a PDF.")
report.append("2. Open PDFs / Images and select PNG/JPG image.")
report.append("3. Verify image appears in Source PDFs and preview.")
report.append("4. Create Poster PDF from an image.")
report.append("5. Create Single Page PDF from an image.")
report.append("6. Output Files = One PDF and Separate PDF per selected page.")
report.append("7. Check Help > User Guide language combo.")
report.append("8. Check Help > Release Notes shows image import support.")
report.append("9. Confirm About shows 0.9.3.")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste final_093_check_report.txt here.")
