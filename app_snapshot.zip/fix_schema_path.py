﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
DB = ROOT / "app" / "db" / "database.py"

if not DB.exists():
    print(f"[ERROR] Not found: {DB}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = DB.with_name(f"database.py.bak_schema_path_{timestamp}")
shutil.copy2(DB, backup)
print(f"[OK] Backup created: {backup}")

text = DB.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# Ensure sys import
# ------------------------------------------------------------
if "import sys" not in text:
    # Add after pathlib import or at top
    if "from pathlib import Path" in text:
        text = text.replace("from pathlib import Path", "from pathlib import Path\nimport sys", 1)
    else:
        text = "import sys\n" + text
    print("[OK] Added sys import")

# ------------------------------------------------------------
# Add resource path helper if missing
# ------------------------------------------------------------
helper = r'''
def _resource_path(relative_path: str) -> Path:
    """Resolve resource path both in source and PyInstaller build."""
    base_path = getattr(sys, "_MEIPASS", None)

    if base_path:
        return Path(base_path) / relative_path

    # Source tree fallback
    return Path(__file__).resolve().parents[2] / relative_path

'''

if "def _resource_path(" not in text:
    # Insert after imports
    lines = text.splitlines(True)
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith("import ") or line.startswith("from "):
            insert_at = i + 1

    text = "".join(lines[:insert_at]) + "\n" + helper + "\n" + "".join(lines[insert_at:])
    print("[OK] Added _resource_path helper")
else:
    print("[SKIP] _resource_path already exists")

# ------------------------------------------------------------
# Replace direct schema.sql path patterns
# ------------------------------------------------------------
patterns = [
    r'Path\(__file__\)\.with_name\(["\']schema\.sql["\']\)',
    r'Path\(__file__\)\.parent\s*/\s*["\']schema\.sql["\']',
]

replaced = 0
for pat in patterns:
    text, count = re.subn(pat, '_resource_path("app/db/schema.sql")', text)
    replaced += count

# If there is SCHEMA_PATH = ...
text, count = re.subn(
    r'SCHEMA_PATH\s*=\s*.*schema\.sql.*',
    'SCHEMA_PATH = _resource_path("app/db/schema.sql")',
    text
)
replaced += count

# Fallback: replace literal "schema.sql" open if common variable not patched
# Avoid changing comments only; this is conservative.
if replaced == 0:
    if '"schema.sql"' in text or "'schema.sql'" in text:
        print("[WARN] Could not detect exact schema path pattern.")
        print("       Applying conservative fallback may be needed manually.")
    else:
        print("[WARN] No schema.sql reference found.")
else:
    print(f"[OK] Replaced schema path references: {replaced}")

DB.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(DB)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = DB.with_name(f"database.py.failed_schema_path_{timestamp}")
    shutil.copy2(DB, failed)
    shutil.copy2(backup, DB)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- database.py schema path patched for PyInstaller/source")
print("- Rebuild EXE after this patch.")
