﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_wholepage_rotation_final_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)
    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

# ------------------------------------------------------------
# 1) Replace _build_export_selections with correct Whole Page logic
# ------------------------------------------------------------
new_build_export_selections = r'''    def _build_export_selections(self) -> dict[int, SelectionRect]:
        self._save_current_selection()

        if not self.checked_pages:
            if self._is_whole_page_output_area() and self.page_count > 0:
                self.checked_pages.add(self.current_page_index)
            else:
                raise RuntimeError(
                    "No checked pages exist. Please select an area and check pages for export, "
                    "or choose Output Area = Whole Page."
                )

        result = {}

        for page_index in sorted(self.checked_pages):
            if self._is_whole_page_output_area():
                result[page_index] = self._get_full_page_selection(page_index)
                continue

            rect = self.page_selections.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            result[page_index] = self._preview_rect_to_pdf_selection(rect)

        if not result:
            if self._is_whole_page_output_area():
                raise RuntimeError("No valid pages were found for Whole Page export.")

            raise RuntimeError(
                "Checked pages do not have valid selections. "
                "Select an area or choose Output Area = Whole Page."
            )

        return result
'''

try:
    text = replace_function(text, "_build_export_selections", new_build_export_selections)
    print("[OK] Replaced _build_export_selections")
except Exception as exc:
    print(f"[ERROR] Failed to replace _build_export_selections: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 2) Fix _load_workspace_index rotation order
# ------------------------------------------------------------
old = '''        self.page_rotations = {
            int(page): int(deg) % 360
            for page, deg in item.get("page_rotations", {}).items()
        }
        self.rotation_degrees = self._get_current_rotation_degrees()

        target_page = int(item.get("current_page_index", 0))
        self.current_page_index = max(0, min(target_page, self.page_count - 1))
'''

new = '''        self.page_rotations = {
            int(page): int(deg) % 360
            for page, deg in item.get("page_rotations", {}).items()
        }

        target_page = int(item.get("current_page_index", 0))
        self.current_page_index = max(0, min(target_page, self.page_count - 1))
        self.rotation_degrees = self._get_current_rotation_degrees()
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Fixed _load_workspace_index rotation order")
else:
    print("[SKIP] Rotation order block not found or already fixed")

# ------------------------------------------------------------
# 3) Ensure Whole Page workspace One PDF conversion block is patched
# ------------------------------------------------------------
old = '''                rect = selections_qrect.get(page_index)

                if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    continue

                self.current_page_index = page_index
                self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)
                converted[page_index] = self._preview_rect_to_pdf_selection(rect)
'''

new = '''                if self._is_whole_page_output_area():
                    converted[page_index] = self._get_full_page_selection_for_pdf(pdf_path, page_index)
                    continue

                rect = selections_qrect.get(page_index)

                if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    continue

                self.current_page_index = page_index
                self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)
                converted[page_index] = self._preview_rect_to_pdf_selection(rect)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched workspace One PDF Whole Page conversion")
else:
    print("[SKIP] Workspace One PDF conversion block already patched or not found")

# ------------------------------------------------------------
# 4) Ensure Whole Page workspace Separate PDF conversion block is patched
# ------------------------------------------------------------
old = '''            rect = selections_qrect.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            # Load correct PDF/page so coordinate conversion uses correct page data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path
            self.current_page_index = page_index
            self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)

            converted = {
                page_index: self._preview_rect_to_pdf_selection(rect)
            }
'''

new = '''            # Load correct PDF/page so coordinate conversion uses correct page data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path
            self.current_page_index = page_index
            self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)

            if self._is_whole_page_output_area():
                converted = {
                    page_index: self._get_full_page_selection_for_pdf(pdf_path, page_index)
                }
            else:
                rect = selections_qrect.get(page_index)

                if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    continue

                converted = {
                    page_index: self._preview_rect_to_pdf_selection(rect)
                }
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched workspace Separate PDF Whole Page conversion")
else:
    print("[SKIP] Workspace Separate conversion block already patched or not found")

# ------------------------------------------------------------
# 5) Release Notes marker
# ------------------------------------------------------------
if "Whole Page export final fix" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Whole Page export final fix</b>: Single Page and Poster export can now use full pages without requiring a selection.</li>
  <li><b>Page rotation fix</b>: Page-specific rotation is restored after switching source PDFs/pages.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

# ------------------------------------------------------------
# 6) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_wholepage_rotation_final_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "result[page_index] = self._get_full_page_selection(page_index)",
    "Whole Page export final fix",
    "self.rotation_degrees = self._get_current_rotation_degrees()",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Whole Page export no longer requires selected area")
print("- Rotation restore order fixed")
print("")
print("IMPORTANT:")
print("- If testing EXE, rebuild the EXE first.")
print("- For immediate test, run: python main.py")
