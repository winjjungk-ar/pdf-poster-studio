﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_reset_view_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def insert_before_function(source: str, func_name: str, code: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            targets.append(node)

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1

    return "".join(lines[:start]) + code + "\n" + "".join(lines[start:])

# ------------------------------------------------------------
# 1) Add reset_view method before reset_rotation
# ------------------------------------------------------------
method = r'''
    def reset_view(self) -> None:
        """Reset preview view state: rotation + zoom + fit page."""
        if self.page_count <= 0:
            return

        self._save_current_selection()

        self.rotation_degrees = 0
        self.preview_zoom_factor = 1.0
        self.fit_to_page_enabled = True

        self._render_current_page()

        if hasattr(self, "rotation_info_label"):
            self.rotation_info_label.setText("Rotation: 0°")

        if hasattr(self, "zoom_info_label"):
            self.zoom_info_label.setText("Zoom: Fit Page")

        self._log("View reset: rotation=0°, zoom=Fit Page.")

'''

if "def reset_view(self) -> None:" not in text:
    try:
        text = insert_before_function(text, "reset_rotation", method)
        print("[OK] Added reset_view method")
    except Exception as exc:
        print(f"[ERROR] Could not insert reset_view: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] reset_view already exists")

# ------------------------------------------------------------
# 2) Change View tab button: Reset Rotation -> Reset View
# ------------------------------------------------------------
old = '''        reset_rotation_button = QPushButton("Reset Rotation")
        reset_rotation_button.clicked.connect(self.reset_rotation)
'''

new = '''        reset_rotation_button = QPushButton("Reset View")
        reset_rotation_button.clicked.connect(self.reset_view)
'''

count = text.count(old)
if count:
    text = text.replace(old, new)
    print(f"[OK] Replaced View tab Reset Rotation button(s): {count}")
else:
    print("[SKIP] View tab Reset Rotation button block not found or already changed")

# ------------------------------------------------------------
# 3) Change floating toolbar Reset connection to reset_view
# ------------------------------------------------------------
old = '''        floating_reset_button = QPushButton("Reset")
        floating_reset_button.setToolTip("Reset Rotation")
        floating_reset_button.clicked.connect(self.reset_rotation)
'''

new = '''        floating_reset_button = QPushButton("Reset")
        floating_reset_button.setToolTip("Reset View: Fit Page, Zoom, and Rotation")
        floating_reset_button.clicked.connect(self.reset_view)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Floating toolbar Reset now calls reset_view")
else:
    if "floating_reset_button.clicked.connect(self.reset_view)" in text:
        print("[SKIP] Floating Reset already calls reset_view")
    else:
        print("[WARN] Floating Reset block not found")

# ------------------------------------------------------------
# 4) Optional: keep View menu Reset Rotation unchanged
# ------------------------------------------------------------
# Menu action "Reset Rotation" remains rotation-only for users who need only rotation reset.

# ------------------------------------------------------------
# 5) Release Notes update
# ------------------------------------------------------------
if "Reset View now restores Fit Page and zoom" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Reset View</b>: Reset now restores Fit Page, zoom, and rotation instead of rotation only.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for Reset View")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 6) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_reset_view_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "def reset_view",
    "clicked.connect(self.reset_view)",
    "Reset View",
    "View reset: rotation=0°, zoom=Fit Page.",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Reset View now restores Fit Page, zoom, and rotation")
print("- Floating toolbar Reset now uses Reset View")
print("- View tab button renamed to Reset View")
