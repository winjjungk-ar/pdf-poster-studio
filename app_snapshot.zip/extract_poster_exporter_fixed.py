﻿from pathlib import Path
import ast
import sys
import re

ROOT = Path.cwd()
TARGET = ROOT / "app" / "pdf" / "poster_exporter.py"
OUT = ROOT / "poster_exporter_extract.txt"

if not TARGET.exists():
    print(f"[ERROR] Not found: {TARGET}")
    sys.exit(1)

text = TARGET.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines()

def get_source_segment_by_ast(source: str, node):
    if not hasattr(node, "lineno") or not hasattr(node, "end_lineno"):
        return None

    source_lines = source.splitlines()
    start = node.lineno
    end = node.end_lineno
    code = "\n".join(source_lines[start - 1:end])
    return start, end, code

def extract_function_or_method(source: str, func_name: str):
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None

    # top-level functions
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            return get_source_segment_by_ast(source, node)

    # class methods
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            for child in node.body:
                if isinstance(child, ast.FunctionDef) and child.name == func_name:
                    return get_source_segment_by_ast(source, child)

    return None

patterns = [
    r"ExportOptions",
    r"SelectionRect",
    r"A4",
    r"A3",
    r"LETTER",
    r"page_width",
    r"page_height",
    r"cut",
    r"guide",
    r"line",
    r"overlap",
    r"no_cut",
    r"true_size",
    r"split",
    r"fitz",
    r"show_pdf_page",
    r"insert_pdf",
    r"draw_line",
    r"draw_rect",
    r"draw_text",
    r"scale",
    r"paper",
]

report = []
report.append("# poster_exporter_extract.txt")
report.append("")
report.append(f"- file: {TARGET}")
report.append(f"- lines: {len(lines)}")
report.append("")

report.append("## ast.parse")
try:
    tree = ast.parse(text)
    report.append("- OK")
except SyntaxError as exc:
    report.append(f"- FAILED: {exc}")
    OUT.write_text("\n".join(report), encoding="utf-8")
    print(f"[ERROR] Syntax error. Wrote partial report: {OUT}")
    sys.exit(1)
report.append("")

report.append("## Keyword references")
rows = []
for idx, line in enumerate(lines, 1):
    for pat in patterns:
        if re.search(pat, line, re.I):
            rows.append(f"{idx:05d}: {line}")
            break

report.append("```text")
report.append("\n".join(rows[:700]))
report.append("```")
report.append("")

report.append("## Classes")
class_names = []
for node in tree.body:
    if isinstance(node, ast.ClassDef):
        class_names.append(node.name)
        report.append(f"- line {node.lineno}: `{node.name}`")
report.append("")

report.append("## All functions/methods")
for node in tree.body:
    if isinstance(node, ast.FunctionDef):
        report.append(f"- line {node.lineno}: `{node.name}`")
    elif isinstance(node, ast.ClassDef):
        report.append(f"- class `{node.name}`")
        for child in node.body:
            if isinstance(child, ast.FunctionDef):
                report.append(f"  - line {child.lineno}: `{child.name}`")
report.append("")

func_names = [
    "export",
    "_export_a3_split",
    "_export_selection_only",
    "_draw_cut_guides",
    "_draw_sheet_number",
    "_create_a4_page",
    "_calculate_split",
    "_fit_rect",
    "_fill_rect",
    "_draw_guides",
    "_draw_cut_guide_lines",
    "_draw_page_number",
    "_export_split",
    "_export_poster",
    "_make_page",
    "__init__",
]

for fn in func_names:
    block = extract_function_or_method(text, fn)
    report.append(f"## Function/method: `{fn}`")
    if block:
        s, e, code = block
        report.append(f"- lines: {s}-{e}")
        report.append("```python")
        report.append(code.rstrip())
        report.append("```")
    else:
        report.append("(not found)")
    report.append("")

# Include dataclass/class definitions fully if short enough
for node in tree.body:
    if isinstance(node, ast.ClassDef):
        seg = get_source_segment_by_ast(text, node)
        if seg:
            s, e, code = seg
            if e - s <= 350:
                report.append(f"## Full class: `{node.name}` lines {s}-{e}")
                report.append("```python")
                report.append(code.rstrip())
                report.append("```")
                report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Extracted: {OUT}")
print("Paste poster_exporter_extract.txt here.")
