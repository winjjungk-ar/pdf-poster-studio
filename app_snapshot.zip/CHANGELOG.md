# Changelog

## 0.2.2
- Forced repair for missing PDF preview files.
- Added PyMuPDF renderer.
- Added PDF preview display.
- Added diagnostic logs.

## 0.1.0
- Initial project skeleton.