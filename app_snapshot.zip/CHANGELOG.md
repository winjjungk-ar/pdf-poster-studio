# Changelog

## 0.1.0
- Initial project skeleton.
- Added PyQt6 main window.
- Added menu structure.
- Added log panel.
- Added SQLite schema.
- Added build and release script placeholders.