# Changelog

## 0.4.6
- Fixed Selection Only Mode output visibility.
- Changed Selection Only Mode to vector-based PDF placement.
- Added selection output border.

## 0.4.5
- Added Export Type.
- Added A3 Split Mode / Selection Only Mode.
- Added cut guide line option.
- Added dotted cut/join guide lines to A3 Split Mode.

## 0.4.4
- Added mouse wheel zoom.
- Added Rotate Left.
- Added Rotate Right.
- Added Reset Rotation.
- Added rotation-aware coordinate conversion.

## 0.4.3
- Added Preview Zoom In.
- Added Preview Zoom Out.
- Added zoom ratio display.
- Added View menu zoom actions.
- Improved selection usability.

## 0.4.2
- Enlarged preview area.
- Reduced Basic Settings panel width.
- Increased preview render zoom.
- Improved output PDF quality with high-quality rendering.
- Added basic overlap area extension.

## 0.4.1
- Fixed export error caused by PyMuPDF Pixmap cropping compatibility.
- Changed split export to render each tile area directly.
- Improved export stability.

## 0.4.0
- Added A4 to A3 split-print PDF export.
- Added PDF coordinate conversion from preview selection.
- Added Left-Right and Top-Bottom split layout.
- Added No-Cut, Overlap, and True Size output modes.
- Added sheet numbering overlay.
- Added multi-page selected export.