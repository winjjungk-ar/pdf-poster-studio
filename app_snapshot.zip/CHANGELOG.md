# Changelog

## 0.6.5
- Added visible page checklist.
- Added page selected/no-selection status.
- Added current page marker.
- Added click-to-jump from page list.
- Added page checklist validation.

## 0.6.4
- Added per-page export checkbox.
- Added checked pages counter.
- Added page jump control.
- Added Batch Output option.
- Added Single PDF / Separate PDF per checked page output.

## 0.6.3
- Changed settings panel to tab UI.