# Changelog

## 0.7.2
- Added PyQt6 QPrintDialog print support.
- Replaced Windows print verb with internal PDF rendering print flow.
- Default print DPI set to 300.
- Added printer selection dialog.

## 0.7.1
- Added Undo shortcut Ctrl+Z.
- Added Redo shortcut Ctrl+Y.
- Added Redo alternative shortcut Ctrl+Shift+Z.
- Added Print shortcut Ctrl+P.
- Added direct print using Windows default print handler.