# Changelog

## 0.7.4
- Added Print Quality selector.
- Added 150 / 300 / 600 DPI print options.
- Fixed selection rectangle scaling when resizing or maximizing the window.
- Hid Log panel by default.

## 0.7.3
- Print no longer requires manual Export PDF first.
- Added temporary print PDF generation.
- Print now creates a temporary PDF from current settings and opens Print Dialog.