# Changelog

## 0.7.0
- Added Undo.
- Added Redo.
- Added last exported PDF tracking.
- Added Open Last Exported PDF.
- Improved Print workflow guidance.
- Project files now store last exported PDF path.

## 0.6.8
- Cleaned menu structure.
- Kept Undo / Redo as disabled future actions.
- Kept Print with improved guidance.
- Renamed Export Print PDF to Export PDF.
- Improved Check Menu Actions.