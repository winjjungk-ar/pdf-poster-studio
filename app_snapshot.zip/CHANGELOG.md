# Changelog

## 0.5.1
- Added Export Type dependent UI enable/disable.
- Selection Only Mode now disables A3 split options.
- A3 Split Mode now disables selection-only options.

## 0.5.0
- Added project save.
- Added project save as.
- Added project open.
- Added recent projects menu.
- Added recent projects limit 5.
- Added exit save confirmation.

## 0.4.8
- Selection Only Mode now outputs clean pages.
- Add sheet numbers is ignored in Selection Only Mode.
- Add cut guide lines is ignored in Selection Only Mode.
- Removed Selection Only border/numbering output.

## 0.4.7
- Added Selection Fit Mode.
- Added Auto / Portrait / Landscape page orientation.
- Improved Selection Only Mode margin handling.