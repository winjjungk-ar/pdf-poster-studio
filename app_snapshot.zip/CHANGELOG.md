# Changelog

## 0.4.3
- Added Preview Zoom In.
- Added Preview Zoom Out.
- Added zoom ratio display.
- Added View menu zoom actions.
- Improved selection usability.

## 0.4.2
- Enlarged preview area.
- Reduced Basic Settings panel width.
- Increased preview render zoom.
- Improved output PDF quality with high-quality rendering.
- Added basic overlap area extension.

## 0.4.1
- Fixed export error caused by PyMuPDF Pixmap cropping compatibility.
- Changed split export to render each tile area directly.
- Improved export stability.

## 0.4.0
- Added A4 to A3 split-print PDF export.
- Added PDF coordinate conversion from preview selection.
- Added Left-Right and Top-Bottom split layout.
- Added No-Cut, Overlap, and True Size output modes.
- Added sheet numbering overlay.
- Added multi-page selected export.

## 0.3.0
- Added mouse drag selection rectangle.
- Added red selection overlay.
- Added selection coordinate display.
- Added per-page selection storage.
- Added Clear Selection.
- Added Apply Selection to All Pages.

## 0.2.2
- Forced repair for missing PDF preview files.
- Added PyMuPDF renderer.
- Added PDF preview display.
- Added diagnostic logs.

## 0.1.0
- Initial project skeleton.