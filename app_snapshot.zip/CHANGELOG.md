# Changelog

## 0.6.8
- Cleaned menu structure.
- Kept Undo / Redo as disabled future actions.
- Kept Print with improved guidance.
- Renamed Export Print PDF to Export PDF.
- Removed confusing unimplemented menu items.
- Improved Check Menu Actions.

## 0.6.7
- Added Auto Select Sensitivity.
- Added Auto Select Current Page naming.
- Added Auto Select All Pages.

## 0.6.6
- Fixed selection issue after heavy Zoom Out.
- Added Auto Select Content.