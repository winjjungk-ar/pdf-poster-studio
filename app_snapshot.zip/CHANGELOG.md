# Changelog

## 0.3.0
- Added mouse drag selection rectangle.
- Added red selection overlay.
- Added selection coordinate display.
- Added per-page selection storage.
- Added Clear Selection.
- Added Apply Selection to All Pages.

## 0.2.2
- Forced repair for missing PDF preview files.
- Added PyMuPDF renderer.
- Added PDF preview display.
- Added diagnostic logs.

## 0.1.0
- Initial project skeleton.