# Changelog

## 0.6.7
- Added Auto Select Sensitivity.
- Added Auto Select Current Page naming.
- Added Auto Select All Pages.
- Added project save/load for auto select sensitivity.

## 0.6.6
- Fixed selection issue after heavy Zoom Out.
- Added Auto Select Content.
- Auto selection detects non-white content area.
- Auto selected page is automatically checked for export.

## 0.6.5
- Added visible page checklist.
- Added page selected/no-selection status.
- Added current page marker.
- Added click-to-jump from page list.
- Added page checklist validation.