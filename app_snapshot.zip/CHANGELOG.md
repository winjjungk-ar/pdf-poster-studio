# Changelog

## 0.7.1
- Added Undo shortcut Ctrl+Z.
- Added Redo shortcut Ctrl+Y.
- Added Redo alternative shortcut Ctrl+Shift+Z.
- Added Open PDF shortcut Ctrl+O.
- Added Export PDF shortcut Ctrl+E.
- Added Open Last Exported PDF shortcut Ctrl+L.
- Added Print shortcut Ctrl+P.
- Added direct print using Windows default print handler.

## 0.7.0
- Added Undo.
- Added Redo.
- Added last exported PDF tracking.
- Added Open Last Exported PDF.
- Improved Print workflow guidance.