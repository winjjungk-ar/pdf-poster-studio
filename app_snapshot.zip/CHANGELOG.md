# Changelog

## 0.6.0
- Added Export Quality selector.
- Added Standard / High / Very High quality modes.
- Added settings UI group boxes.
- Improved right panel readability.
- Saved export quality in project files.

## 0.5.1
- Added Export Type dependent UI enable/disable.
- Selection Only Mode now disables A3 split options.
- A3 Split Mode now disables selection-only options.

## 0.5.0
- Added project save.
- Added project save as.
- Added project open.
- Added recent projects menu.
- Added recent projects limit 5.
- Added exit save confirmation.