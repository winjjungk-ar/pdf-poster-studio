# Changelog

## 0.6.4
- Added per-page export checkbox.
- Added checked pages counter.
- Added page jump control.
- Added Batch Output option.
- Added Single PDF / Separate PDF per checked page output.
- Added project save/load support for checked pages.

## 0.6.3
- Changed settings panel to tab UI.

## 0.6.0
- Added Export Quality selector.
- Added settings UI group boxes.