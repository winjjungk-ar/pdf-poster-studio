﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_search_ocr_notice_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Improve Find Text "not found" message
# ------------------------------------------------------------
old = '''            QMessageBox.information(
                self,
                "Find Text",
                f"'{query}' was not found."
            )
'''

new = '''            QMessageBox.information(
                self,
                "Find Text",
                f"'{query}' was not found.\\n\\n"
                "Find Text works only with PDFs that already contain text.\\n"
                "Scanned PDFs or image-only PDFs may require OCR in another tool before searching."
            )
'''

if old in text and "Scanned PDFs or image-only PDFs may require OCR" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Improved Find Text not-found OCR notice")
else:
    print("[SKIP] Find Text OCR notice already present or anchor not found")

# ------------------------------------------------------------
# 2) Add User Guide section in English
# ------------------------------------------------------------
if "Find Text and OCR note" not in text:
    # Insert after Auto Select section in English guide if possible.
    anchor = '''<h3>8. Finding Exported Files</h3>
'''
    section = '''<h3>8. Find Text and OCR note</h3>
<p>
Find Text works only with PDFs that already contain text.
Scanned PDFs or image-only PDFs may not be searchable until they are processed with OCR in another tool.
</p>

<hr>

<h3>9. Finding Exported Files</h3>
'''
    if anchor in text:
        text = text.replace(anchor, section, 1)
        print("[OK] Added English User Guide OCR note")
    else:
        print("[WARN] Could not find English guide insertion anchor")

# Korean guide note
if "텍스트 검색과 OCR 안내" not in text:
    anchor = '''<h3>8. 출력 파일 찾기</h3>
'''
    section = '''<h3>8. 텍스트 검색과 OCR 안내</h3>
<p>
Find Text는 PDF 안에 텍스트 정보가 이미 들어 있는 경우에만 동작합니다.
스캔 PDF나 이미지로만 된 PDF는 다른 프로그램에서 OCR 처리를 해야 검색될 수 있습니다.
</p>

<hr>

<h3>9. 출력 파일 찾기</h3>
'''
    if anchor in text:
        text = text.replace(anchor, section, 1)
        print("[OK] Added Korean User Guide OCR note")

# Japanese short note
if "テキスト検索とOCR" not in text:
    anchor = '''<h3>ゲームマップ / ポスター</h3>
'''
    addition = '''<h3>テキスト検索とOCR</h3>
<p>
Find Text は、PDF 内にテキスト情報が含まれている場合のみ動作します。
スキャンPDFや画像のみのPDFは、検索前に別のツールでOCR処理が必要な場合があります。
</p>
<hr>
'''
    if anchor in text:
        text = text.replace(anchor, addition + anchor, 1)
        print("[OK] Added Japanese User Guide OCR note")

# Chinese short note
if "文本搜索和OCR" not in text:
    anchor = '''<h3>游戏地图 / 墙上海报</h3>
'''
    addition = '''<h3>文本搜索和OCR</h3>
<p>
Find Text 仅适用于已经包含文本信息的 PDF。
扫描 PDF 或纯图片 PDF 可能需要先使用其他工具进行 OCR 处理后才能搜索。
</p>
<hr>
'''
    if anchor in text:
        text = text.replace(anchor, addition + anchor, 1)
        print("[OK] Added Chinese User Guide OCR note")

# ------------------------------------------------------------
# 3) Release Notes update
# ------------------------------------------------------------
if "Find Text OCR notice" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Find Text OCR notice</b>: Search now explains that scanned/image-only PDFs may require OCR before text search works.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for OCR notice")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 4) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_search_ocr_notice_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Scanned PDFs or image-only PDFs may require OCR",
    "Find Text and OCR note",
    "텍스트 검색과 OCR 안내",
    "Find Text OCR notice",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Find Text now explains OCR limitations")
print("- User Guide updated")
print("- Release Notes updated")
