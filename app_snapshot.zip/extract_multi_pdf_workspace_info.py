﻿from pathlib import Path
import re
import ast
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
OUT = ROOT / "multi_pdf_workspace_extract.txt"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

text = MAIN.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines()

def line_no_from_pos(source, pos):
    return source.count("\n", 0, pos) + 1

def extract_function_block(source, func_name):
    pattern = re.compile(rf"^([ \t]*)def {re.escape(func_name)}\s*\(", re.M)
    m = pattern.search(source)
    if not m:
        return None

    indent = m.group(1)
    start = m.start()
    source_lines = source.splitlines(True)

    acc = 0
    start_idx = None
    for i, line in enumerate(source_lines):
        if acc == start:
            start_idx = i
            break
        acc += len(line)

    if start_idx is None:
        return None

    base_indent_len = len(indent)
    end_idx = len(source_lines)

    for j in range(start_idx + 1, len(source_lines)):
        raw = source_lines[j]
        stripped = raw.strip()
        if not stripped:
            continue
        current_indent_len = len(raw) - len(raw.lstrip(" \t"))
        if current_indent_len <= base_indent_len and (
            raw.lstrip().startswith("def ") or raw.lstrip().startswith("class ")
        ):
            end_idx = j
            break

    block = "".join(source_lines[start_idx:end_idx])
    start_line = line_no_from_pos(source, start)
    end_line = start_line + block.count("\n")
    return start_line, end_line, block

def grep(patterns):
    rows = []
    for idx, line in enumerate(lines, 1):
        for pat in patterns:
            if re.search(pat, line, re.I):
                rows.append(f"{idx:05d}: {line}")
                break
    return rows

funcs = [
    "__init__",
    "_create_menus",
    "_create_central_ui",
    "_open_pdf_path",
    "open_pdf",
    "export_print_pdf",
    "_collect_checked_page_indices",
    "_get_checked_page_indices",
    "_page_list_text",
    "_refresh_page_list",
    "_update_page_list",
    "_update_preview",
    "render_current_page",
    "show_current_page",
    "next_page",
    "previous_page",
    "on_page_jump_changed",
    "on_selection_changed",
    "on_page_complete_changed",
    "on_page_list_item_changed",
    "on_page_list_item_clicked",
    "_create_temp_print_pdf",
    "print_pdf",
    "save_project",
    "open_project",
    "_collect_project_data",
    "_apply_project_data",
]

patterns = [
    r"self\.pdf",
    r"pdf_path",
    r"current_page",
    r"page_count",
    r"selection",
    r"selected",
    r"page_selections",
    r"export",
    r"checked",
    r"page_list",
    r"QListWidget",
    r"QTableWidget",
    r"setDragDropMode",
    r"InternalMove",
    r"_open_pdf_path",
    r"fitz\.open",
    r"PdfRenderer",
    r"renderer",
    r"last_exported",
]

report = []
report.append("# multi_pdf_workspace_extract.txt")
report.append("")
report.append("## Environment")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py: {MAIN}")
report.append(f"- lines: {len(lines)}")
report.append("")

report.append("## ast.parse")
try:
    ast.parse(text)
    report.append("- OK")
except SyntaxError as exc:
    report.append(f"- FAILED: {exc}")
report.append("")

report.append("## Key references")
rows = grep(patterns)
report.append("```text")
report.append("\n".join(rows[:500]))
report.append("```")
report.append("")

for fn in funcs:
    block = extract_function_block(text, fn)
    report.append(f"## Function: `{fn}`")
    if block:
        s, e, code = block
        report.append(f"- lines: {s}-{e}")
        report.append("```python")
        report.append(code.rstrip())
        report.append("```")
    else:
        report.append("(not found)")
    report.append("")

# Also inspect export modules
for rel in [
    "app/pdf/pdf_exporter.py",
    "app/pdf/pdf_split_exporter.py",
    "app/pdf/pdf_page_collector.py",
    "app/pdf/pdf_renderer.py",
]:
    path = ROOT / rel
    report.append(f"## File: `{rel}`")
    if not path.exists():
        report.append("(not found)")
        report.append("")
        continue

    src = path.read_text(encoding="utf-8", errors="replace")
    report.append(f"- lines: {len(src.splitlines())}")
    try:
        ast.parse(src)
        report.append("- ast.parse: OK")
    except SyntaxError as exc:
        report.append(f"- ast.parse: FAILED: {exc}")

    report.append("### Keyword references")
    src_lines = src.splitlines()
    found = []
    for idx, line in enumerate(src_lines, 1):
        if re.search(r"export|selection|fitz|insert_pdf|page|split|A4|A3|checked", line, re.I):
            found.append(f"{idx:05d}: {line}")
    report.append("```text")
    report.append("\n".join(found[:300]))
    report.append("```")
    report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Extracted: {OUT}")
print("Paste multi_pdf_workspace_extract.txt here.")
