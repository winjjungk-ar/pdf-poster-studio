﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
DB = ROOT / "app" / "db" / "database.py"
CONFIG = ROOT / "app" / "config.py"

if not DB.exists():
    print(f"[ERROR] Not found: {DB}")
    sys.exit(1)

if not CONFIG.exists():
    print(f"[ERROR] Not found: {CONFIG}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

db_backup = DB.with_name(f"database.py.bak_schema_exe_fix_{timestamp}")
config_backup = CONFIG.with_name(f"config.py.bak_exe_data_dir_fix_{timestamp}")

shutil.copy2(DB, db_backup)
shutil.copy2(CONFIG, config_backup)

print(f"[OK] Backup created: {db_backup}")
print(f"[OK] Backup created: {config_backup}")

# ------------------------------------------------------------
# 1) Patch database.py schema path
# ------------------------------------------------------------
db_text = DB.read_text(encoding="utf-8", errors="replace")
original_db = db_text

old = '''def initialize_database() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    schema_path = Path(__file__).resolve().parent / "schema.sql"

    with sqlite3.connect(DB_PATH) as conn:
        schema = schema_path.read_text(encoding="utf-8")
        conn.executescript(schema)
        conn.commit()
'''

new = '''def initialize_database() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    schema_path = _resource_path("app/db/schema.sql")

    if not schema_path.exists():
        # Source-tree fallback for development or unusual packaging layouts.
        fallback = Path(__file__).resolve().parent / "schema.sql"
        if fallback.exists():
            schema_path = fallback

    if not schema_path.exists():
        raise FileNotFoundError(f"schema.sql not found: {schema_path}")

    with sqlite3.connect(DB_PATH) as conn:
        schema = schema_path.read_text(encoding="utf-8")
        conn.executescript(schema)
        conn.commit()
'''

if old in db_text:
    db_text = db_text.replace(old, new, 1)
    print("[OK] Patched initialize_database schema path")
else:
    # Minimal fallback replacement
    if 'schema_path = Path(__file__).resolve().parent / "schema.sql"' in db_text:
        db_text = db_text.replace(
            '    schema_path = Path(__file__).resolve().parent / "schema.sql"\n',
            '''    schema_path = _resource_path("app/db/schema.sql")

    if not schema_path.exists():
        fallback = Path(__file__).resolve().parent / "schema.sql"
        if fallback.exists():
            schema_path = fallback

    if not schema_path.exists():
        raise FileNotFoundError(f"schema.sql not found: {schema_path}")
''',
            1
        )
        print("[OK] Patched schema_path by fallback")
    else:
        print("[WARN] Could not find old schema_path line")

DB.write_text(db_text, encoding="utf-8")

# ------------------------------------------------------------
# 2) Patch config.py for EXE writable data folders
# ------------------------------------------------------------
config_text = CONFIG.read_text(encoding="utf-8", errors="replace")
original_config = config_text

new_config = '''from pathlib import Path
import sys


def _get_base_dir() -> Path:
    """Return app base directory for source and PyInstaller builds.

    In source mode:
        project root

    In PyInstaller one-folder mode:
        folder containing the EXE

    This keeps data, exports, and projects writable beside the EXE.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent

    return Path(__file__).resolve().parent.parent


BASE_DIR = _get_base_dir()
DATA_DIR = BASE_DIR / "data"
PROJECTS_DIR = BASE_DIR / "projects"
EXPORTS_DIR = BASE_DIR / "exports"
BACKUPS_DIR = BASE_DIR / "backups"
PATCHES_DIR = BASE_DIR / "patches"
LOGS_DIR = BASE_DIR / "logs"
DOCS_DIR = BASE_DIR / "docs"

DB_PATH = DATA_DIR / "app.db"
SETTINGS_DIR = DATA_DIR / "settings"
RECENT_PROJECTS_PATH = SETTINGS_DIR / "recent_projects.json"
'''

if "_get_base_dir" not in config_text:
    CONFIG.write_text(new_config, encoding="utf-8")
    print("[OK] Replaced config.py with EXE-safe BASE_DIR")
else:
    print("[SKIP] config.py already has _get_base_dir")

# ------------------------------------------------------------
# 3) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup in [
    (DB, db_backup),
    (CONFIG, config_backup),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_schema_exe_fix_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 4) Marker check
# ------------------------------------------------------------
db_new = DB.read_text(encoding="utf-8", errors="replace")
config_new = CONFIG.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker, source in [
    ('schema_path = _resource_path("app/db/schema.sql")', db_new),
    ('schema.sql not found', db_new),
    ('getattr(sys, "frozen", False)', config_new),
    ('Path(sys.executable).resolve().parent', config_new),
]:
    print(f"  - {marker}: {marker in source}")

print("")
print("Done.")
print("- schema.sql path fixed for PyInstaller/source")
print("- data/exports/projects folders now resolve beside EXE in frozen mode")
print("- Rebuild EXE after this patch")
