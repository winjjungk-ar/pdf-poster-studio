﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_equal_11_user_guide_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)
    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]
    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")
    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

new_user_guide = r'''    def show_user_guide(self) -> None:
        guides = {
            "English": """
<h2>PDF Poster Studio - User Guide</h2>
<p>PDF Poster Studio creates print-ready PDFs from PDF and image files. It supports merging, page extraction, poster tiling, page rotation, and selected-area output.</p>
<hr>
<h3>1. Basic Workflow</h3>
<ol>
<li>Open PDFs / Images.</li>
<li>Choose a task from Home or toolbar.</li>
<li>Choose Output Area: Whole Page or Selected Area.</li>
<li>Build Print Order.</li>
<li>Create Poster PDF or Single Page PDF.</li>
</ol>
<hr>
<h3>2. Home Task Launcher</h3>
<ul>
<li><b>Merge PDFs</b>: combine full pages into one PDF.</li>
<li><b>Extract Pages</b>: export chosen page ranges.</li>
<li><b>Make Poster</b>: tile maps, posters, images, or drawings.</li>
<li><b>Rotate Pages</b>: rotate current, checked, or all pages.</li>
<li><b>Selected Area PDF</b>: export only a selected area.</li>
</ul>
<hr>
<h3>3. Make Poster</h3>
<ol>
<li>Choose Make Poster.</li>
<li>Select Open One File or Use Current Source PDFs.</li>
<li>Choose Whole Page or Selected Area.</li>
<li>Choose A4 or US Letter.</li>
<li>Choose Poster Small/Medium/Large/Huge, A-series, ANSI, or Arch preset.</li>
<li>Check Tiling Preview.</li>
<li>Build Print Order and click Poster PDF.</li>
</ol>
<hr>
<h3>4. Whole Page vs Selected Area</h3>
<ul>
<li><b>Whole Page</b>: uses the full page or image. Good for merging, extracting, or full-map posters.</li>
<li><b>Selected Area</b>: uses only the selected region. Good for zooming into part of a map or drawing.</li>
</ul>
<p>Dragging a selection automatically switches Output Area to Selected Area.</p>
<hr>
<h3>5. Merge PDFs</h3>
<ol>
<li>Choose Merge PDFs.</li>
<li>Open PDF/image files if needed.</li>
<li>The app uses Whole Page, One PDF, and Single Page Mode.</li>
<li>All source pages are added to Print Order.</li>
<li>Click Single Page PDF.</li>
</ol>
<hr>
<h3>6. Extract Pages</h3>
<ol>
<li>Choose Extract Pages.</li>
<li>Enter a range: all, 1-10, 1,3,5, or 10-20,35.</li>
<li>The default output is Separate PDF per selected page.</li>
<li>Change Output Files to One PDF if you want one combined file.</li>
<li>Click Single Page PDF.</li>
</ol>
<hr>
<h3>7. Rotate Pages</h3>
<ol>
<li>Choose Rotate Pages.</li>
<li>Select Current Page, Checked Pages, or All Pages.</li>
<li>Choose Rotate Left, Rotate Right, or Reset Rotation.</li>
<li>Print Order is prepared automatically.</li>
<li>Click Single Page PDF to save the rotated output.</li>
</ol>
<hr>
<h3>8. Single Page PDF</h3>
<p>Single Page PDF exports full pages or selected areas without poster tiling.</p>
<ul>
<li>Fit Width</li>
<li>Fit Whole Area</li>
<li>Fill Page Crop</li>
<li>Fit Height</li>
</ul>
<hr>
<h3>9. Output Files</h3>
<ul>
<li><b>One PDF</b>: combine all Print Order items into one PDF.</li>
<li><b>Separate PDF per selected page</b>: create one PDF for each item.</li>
</ul>
<hr>
<h3>10. Auto Select / Text Search / OCR</h3>
<ul>
<li><b>Auto Current</b>: auto-select current page content.</li>
<li><b>Auto All</b>: auto-select all pages.</li>
<li><b>Auto Range</b>: auto-select a range such as 1-20.</li>
<li><b>Find Text</b>: works only with PDFs that contain text. Scanned/image-only PDFs may require OCR in another tool.</li>
</ul>
<hr>
<h3>11. Exported Files and Projects</h3>
<ul>
<li>Generated PDFs are saved to the exports folder.</li>
<li>Use Open Exports Folder to find output files.</li>
<li>Use Save Project As to save Source PDFs, selections, Print Order, and settings.</li>
</ul>
""",

            "한국어": """
<h2>PDF Poster Studio - 사용 방법</h2>
<p>PDF Poster Studio는 PDF와 이미지 파일로 출력용 PDF를 만드는 프로그램입니다. PDF 합치기, 페이지 추출, 포스터 분할, 페이지 회전, 선택 영역 출력이 가능합니다.</p>
<hr>
<h3>1. 기본 작업 순서</h3>
<ol>
<li>Open PDFs / Images로 파일을 엽니다.</li>
<li>Home 또는 툴바에서 작업을 선택합니다.</li>
<li>Output Area를 Whole Page 또는 Selected Area로 선택합니다.</li>
<li>Build Print Order를 실행합니다.</li>
<li>Poster PDF 또는 Single Page PDF를 만듭니다.</li>
</ol>
<hr>
<h3>2. Home 작업 메뉴</h3>
<ul>
<li><b>Merge PDFs</b>: 전체 페이지를 하나의 PDF로 합칩니다.</li>
<li><b>Extract Pages</b>: 원하는 페이지 범위만 추출합니다.</li>
<li><b>Make Poster</b>: 지도, 포스터, 이미지, 도면을 여러 장으로 나눕니다.</li>
<li><b>Rotate Pages</b>: 현재/체크/전체 페이지를 회전합니다.</li>
<li><b>Selected Area PDF</b>: 선택한 영역만 PDF로 출력합니다.</li>
</ul>
<hr>
<h3>3. 포스터 만들기</h3>
<ol>
<li>Make Poster를 선택합니다.</li>
<li>Open One File 또는 Use Current Source PDFs를 선택합니다.</li>
<li>Whole Page 또는 Selected Area를 선택합니다.</li>
<li>A4 또는 US Letter를 선택합니다.</li>
<li>Poster Small/Medium/Large/Huge, A-series, ANSI, Arch 프리셋을 선택합니다.</li>
<li>Tiling Preview를 확인합니다.</li>
<li>Build Print Order 후 Poster PDF를 누릅니다.</li>
</ol>
<hr>
<h3>4. Whole Page / Selected Area</h3>
<ul>
<li><b>Whole Page</b>: 전체 페이지 또는 전체 이미지를 사용합니다. PDF 합치기, 페이지 추출, 전체 지도/포스터 출력에 좋습니다.</li>
<li><b>Selected Area</b>: 선택한 영역만 사용합니다. 지도나 도면 일부 확대에 좋습니다.</li>
</ul>
<p>마우스로 영역을 선택하면 Output Area가 자동으로 Selected Area로 바뀝니다.</p>
<hr>
<h3>5. PDF 합치기</h3>
<ol>
<li>Merge PDFs를 선택합니다.</li>
<li>필요하면 PDF/이미지를 엽니다.</li>
<li>앱이 Whole Page, One PDF, Single Page Mode로 자동 설정합니다.</li>
<li>모든 Source 페이지가 Print Order에 추가됩니다.</li>
<li>Single Page PDF를 누릅니다.</li>
</ol>
<hr>
<h3>6. 페이지 추출</h3>
<ol>
<li>Extract Pages를 선택합니다.</li>
<li>all, 1-10, 1,3,5, 10-20,35 같은 범위를 입력합니다.</li>
<li>기본 출력은 Separate PDF per selected page입니다.</li>
<li>하나의 PDF로 만들려면 Output Files를 One PDF로 바꿉니다.</li>
<li>Single Page PDF를 누릅니다.</li>
</ol>
<hr>
<h3>7. 페이지 회전</h3>
<ol>
<li>Rotate Pages를 선택합니다.</li>
<li>Current Page, Checked Pages, All Pages 중 선택합니다.</li>
<li>Rotate Left, Rotate Right, Reset Rotation을 선택합니다.</li>
<li>Print Order가 자동 준비됩니다.</li>
<li>Single Page PDF를 눌러 회전된 결과를 저장합니다.</li>
</ol>
<hr>
<h3>8. Single Page PDF</h3>
<p>Single Page PDF는 포스터 분할 없이 전체 페이지나 선택 영역을 일반 PDF 페이지로 출력합니다.</p>
<ul>
<li>Fit Width</li>
<li>Fit Whole Area</li>
<li>Fill Page Crop</li>
<li>Fit Height</li>
</ul>
<hr>
<h3>9. Output Files</h3>
<ul>
<li><b>One PDF</b>: Print Order 항목을 하나의 PDF로 만듭니다.</li>
<li><b>Separate PDF per selected page</b>: 각 항목을 별도 PDF로 만듭니다.</li>
</ul>
<hr>
<h3>10. Auto Select / 텍스트 검색 / OCR</h3>
<ul>
<li><b>Auto Current</b>: 현재 페이지 내용을 자동 선택합니다.</li>
<li><b>Auto All</b>: 모든 페이지를 자동 선택합니다.</li>
<li><b>Auto Range</b>: 1-20 같은 범위만 자동 선택합니다.</li>
<li><b>Find Text</b>: 텍스트 정보가 있는 PDF에서만 동작합니다. 스캔/이미지 PDF는 OCR이 필요할 수 있습니다.</li>
</ul>
<hr>
<h3>11. 출력 파일과 프로젝트</h3>
<ul>
<li>생성된 PDF는 exports 폴더에 저장됩니다.</li>
<li>Open Exports Folder로 출력 폴더를 열 수 있습니다.</li>
<li>Save Project As로 Source PDFs, 선택 영역, Print Order, 설정을 저장할 수 있습니다.</li>
</ul>
""",

            "日本語": """
<h2>PDF Poster Studio - 使い方</h2>
<p>PDF Poster Studio は、PDF と画像ファイルから印刷用 PDF を作成するツールです。PDF結合、ページ抽出、ポスター分割、ページ回転、選択範囲出力に対応しています。</p>
<hr>
<h3>1. 基本の流れ</h3>
<ol><li>Open PDFs / Images でファイルを開きます。</li><li>Home またはツールバーから作業を選びます。</li><li>Output Area を Whole Page または Selected Area にします。</li><li>Build Print Order を実行します。</li><li>Poster PDF または Single Page PDF を作成します。</li></ol>
<hr>
<h3>2. Home タスク</h3>
<ul><li><b>Merge PDFs</b>: ページ全体を1つのPDFにまとめます。</li><li><b>Extract Pages</b>: 指定ページ範囲だけを抽出します。</li><li><b>Make Poster</b>: 地図、ポスター、画像、図面を複数枚に分割します。</li><li><b>Rotate Pages</b>: 現在/チェック/全ページを回転します。</li><li><b>Selected Area PDF</b>: 選択範囲だけを出力します。</li></ul>
<hr>
<h3>3. ポスター作成</h3>
<ol><li>Make Poster を選びます。</li><li>Open One File または Use Current Source PDFs を選びます。</li><li>Whole Page または Selected Area を選びます。</li><li>A4 または US Letter を選びます。</li><li>Poster / A-series / ANSI / Arch プリセットを選びます。</li><li>Tiling Preview を確認します。</li><li>Build Print Order 後、Poster PDF を押します。</li></ol>
<hr>
<h3>4. Whole Page / Selected Area</h3>
<ul><li><b>Whole Page</b>: ページ全体または画像全体を使います。</li><li><b>Selected Area</b>: 選択した範囲だけを使います。</li></ul><p>手動で範囲選択すると、Selected Area に自動変更されます。</p>
<hr>
<h3>5. PDF結合</h3>
<ol><li>Merge PDFs を選びます。</li><li>必要に応じてファイルを開きます。</li><li>Whole Page、One PDF、Single Page Mode に自動設定されます。</li><li>全ページが Print Order に追加されます。</li><li>Single Page PDF を押します。</li></ol>
<hr>
<h3>6. ページ抽出</h3>
<ol><li>Extract Pages を選びます。</li><li>all、1-10、1,3,5 などを入力します。</li><li>初期設定は Separate PDF per selected page です。</li><li>1つにまとめる場合は One PDF に変更します。</li><li>Single Page PDF を押します。</li></ol>
<hr>
<h3>7. ページ回転</h3>
<ol><li>Rotate Pages を選びます。</li><li>Current Page、Checked Pages、All Pages を選びます。</li><li>Rotate Left / Right または Reset を選びます。</li><li>Print Order が準備されます。</li><li>Single Page PDF で保存します。</li></ol>
<hr>
<h3>8. Single Page PDF</h3><p>ポスター分割せず、通常のPDFページとして出力します。</p><ul><li>Fit Width</li><li>Fit Whole Area</li><li>Fill Page Crop</li><li>Fit Height</li></ul>
<hr>
<h3>9. Output Files</h3><ul><li><b>One PDF</b>: 1つのPDFにまとめます。</li><li><b>Separate PDF per selected page</b>: 各項目を別PDFにします。</li></ul>
<hr>
<h3>10. Auto Select / 検索 / OCR</h3><ul><li>Auto Current</li><li>Auto All</li><li>Auto Range</li><li>Find Text はテキスト情報を含むPDFのみ検索できます。スキャンPDFはOCRが必要な場合があります。</li></ul>
<hr>
<h3>11. 出力ファイルとプロジェクト</h3><ul><li>PDFは exports フォルダに保存されます。</li><li>Open Exports Folder で開けます。</li><li>Save Project As で作業を保存できます。</li></ul>
""",

            "中文（简体）": """
<h2>PDF Poster Studio - 使用指南</h2>
<p>PDF Poster Studio 可以从 PDF 和图片文件创建可打印 PDF，支持合并、页面提取、海报分割、页面旋转和选区输出。</p>
<hr>
<h3>1. 基本流程</h3>
<ol><li>使用 Open PDFs / Images 打开文件。</li><li>从 Home 或工具栏选择任务。</li><li>选择 Output Area：Whole Page 或 Selected Area。</li><li>执行 Build Print Order。</li><li>创建 Poster PDF 或 Single Page PDF。</li></ol>
<hr>
<h3>2. Home 任务</h3>
<ul><li><b>Merge PDFs</b>：把完整页面合并为一个PDF。</li><li><b>Extract Pages</b>：只提取指定页面范围。</li><li><b>Make Poster</b>：把地图、海报、图片、图纸分割成多张纸。</li><li><b>Rotate Pages</b>：旋转当前/勾选/全部页面。</li><li><b>Selected Area PDF</b>：只输出选择区域。</li></ul>
<hr>
<h3>3. 制作海报</h3>
<ol><li>选择 Make Poster。</li><li>选择 Open One File 或 Use Current Source PDFs。</li><li>选择 Whole Page 或 Selected Area。</li><li>选择 A4 或 US Letter。</li><li>选择 Poster / A-series / ANSI / Arch 预设。</li><li>查看 Tiling Preview。</li><li>Build Print Order 后点击 Poster PDF。</li></ol>
<hr>
<h3>4. Whole Page / Selected Area</h3>
<ul><li><b>Whole Page</b>：使用整页或整张图片。</li><li><b>Selected Area</b>：只使用选择区域。</li></ul><p>手动选择区域时，会自动切换为 Selected Area。</p>
<hr>
<h3>5. 合并PDF</h3>
<ol><li>选择 Merge PDFs。</li><li>根据需要打开文件。</li><li>程序会自动设置 Whole Page、One PDF、Single Page Mode。</li><li>所有页面会加入 Print Order。</li><li>点击 Single Page PDF。</li></ol>
<hr>
<h3>6. 页面提取</h3>
<ol><li>选择 Extract Pages。</li><li>输入 all、1-10、1,3,5 等范围。</li><li>默认输出为 Separate PDF per selected page。</li><li>如需合并为一个文件，请改为 One PDF。</li><li>点击 Single Page PDF。</li></ol>
<hr>
<h3>7. 页面旋转</h3>
<ol><li>选择 Rotate Pages。</li><li>选择 Current Page、Checked Pages 或 All Pages。</li><li>选择 Rotate Left / Right 或 Reset。</li><li>程序会准备 Print Order。</li><li>点击 Single Page PDF 保存。</li></ol>
<hr>
<h3>8. Single Page PDF</h3><p>不进行海报分割，按普通PDF页面输出。</p><ul><li>Fit Width</li><li>Fit Whole Area</li><li>Fill Page Crop</li><li>Fit Height</li></ul>
<hr>
<h3>9. Output Files</h3><ul><li><b>One PDF</b>：合并为一个PDF。</li><li><b>Separate PDF per selected page</b>：每个项目生成单独PDF。</li></ul>
<hr>
<h3>10. Auto Select / 搜索 / OCR</h3><ul><li>Auto Current</li><li>Auto All</li><li>Auto Range</li><li>Find Text 只能搜索包含文本层的PDF。扫描PDF可能需要OCR。</li></ul>
<hr>
<h3>11. 输出文件和项目</h3><ul><li>生成的PDF保存在 exports 文件夹。</li><li>可用 Open Exports Folder 打开。</li><li>可用 Save Project As 保存工作。</li></ul>
"""
        }

        dialog = QDialog(self)
        dialog.setWindowTitle("User Guide / How to Use")
        dialog.setMinimumSize(820, 660)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        language_layout = QHBoxLayout()
        language_label = QLabel("Language")
        language_combo = QComboBox()
        language_combo.addItems(["English", "한국어", "日本語", "中文（简体）"])
        language_combo.setCurrentText("English")
        language_layout.addWidget(language_label)
        language_layout.addWidget(language_combo)
        language_layout.addStretch()

        guide_view = QTextEdit()
        guide_view.setReadOnly(True)
        guide_view.setHtml(guides["English"])
        guide_view.setStyleSheet("""
            QTextEdit {
                background-color: #FFFDF8;
                color: #2F4F5F;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 10px;
                font-family: Segoe UI, Arial;
                font-size: 10.5pt;
            }
        """)

        def change_language() -> None:
            guide_view.setHtml(guides.get(language_combo.currentText(), guides["English"]))

        language_combo.currentIndexChanged.connect(change_language)

        close_button = QPushButton("Close")
        close_button.clicked.connect(dialog.accept)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_button)

        layout.addLayout(language_layout)
        layout.addWidget(guide_view)
        layout.addLayout(button_layout)

        dialog.exec()
'''

try:
    text = replace_function(text, "show_user_guide", new_user_guide)
    print("[OK] Replaced show_user_guide with equal 11-section guides")
except Exception as exc:
    print(f"[ERROR] Failed to replace show_user_guide: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

if "Equal 11-section multilingual User Guide" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Equal 11-section multilingual User Guide</b>: English, Korean, Japanese, and Simplified Chinese guides now share the same 11-section structure.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_equal_11_user_guide_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
print("[INFO] Marker check:")
for marker in [
    "1. Basic Workflow",
    "1. 기본 작업 순서",
    "1. 基本の流れ",
    "1. 基本流程",
    "11. Exported Files and Projects",
    "11. 출력 파일과 프로젝트",
    "11. 出力ファイルとプロジェクト",
    "11. 输出文件和项目",
    "Equal 11-section multilingual User Guide",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- All User Guide languages now use 11 sections")
print("- Release Notes updated")
