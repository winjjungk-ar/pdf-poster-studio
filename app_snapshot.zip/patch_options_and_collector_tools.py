﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
DIALOG = ROOT / "app" / "ui" / "page_collector_dialog.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not DIALOG.exists():
    print(f"[ERROR] Not found: {DIALOG}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

main_backup = MAIN.with_name(f"main_window.py.bak_options_cleanup_{timestamp}")
dialog_backup = DIALOG.with_name(f"page_collector_dialog.py.bak_collector_tools_{timestamp}")

shutil.copy2(MAIN, main_backup)
shutil.copy2(DIALOG, dialog_backup)

print(f"[OK] Backup created: {main_backup}")
print(f"[OK] Backup created: {dialog_backup}")

# ------------------------------------------------------------
# 1) Remove Options > Basic Mode / Advanced Mode
# ------------------------------------------------------------
main_text = MAIN.read_text(encoding="utf-8", errors="replace")
original_main = main_text

old_options_block = """        # Options
        options_menu.addAction("Basic Mode", self.set_basic_mode)
        options_menu.addAction("Advanced Mode", self.set_advanced_mode)
        options_menu.addSeparator()
        preferences_action = options_menu.addAction("Preferences")
        preferences_action.setEnabled(False)
"""

new_options_block = """        # Options
        preferences_action = options_menu.addAction("Preferences")
        preferences_action.setEnabled(False)
"""

if old_options_block in main_text:
    main_text = main_text.replace(old_options_block, new_options_block, 1)
    print("[OK] Removed Basic Mode / Advanced Mode from Options menu")
else:
    before = main_text
    main_text = main_text.replace('        options_menu.addAction("Basic Mode", self.set_basic_mode)\n', '')
    main_text = main_text.replace('        options_menu.addAction("Advanced Mode", self.set_advanced_mode)\n', '')
    # Remove one separator directly after '# Options' if it became unnecessary.
    main_text = main_text.replace(
        '        # Options\n        options_menu.addSeparator()\n        preferences_action = options_menu.addAction("Preferences")\n',
        '        # Options\n        preferences_action = options_menu.addAction("Preferences")\n',
        1
    )

    if main_text != before:
        print("[OK] Removed Basic/Advanced menu lines by fallback")
    else:
        print("[SKIP] Basic/Advanced menu lines not found")

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 2) Patch PageCollectorDialog: add Move Up / Move Down / Validate
# ------------------------------------------------------------
dialog_text = DIALOG.read_text(encoding="utf-8", errors="replace")
original_dialog = dialog_text

# Add buttons in __init__
if "self.move_selected_row_up" not in dialog_text:
    # Try to insert after Remove button block.
    patterns = [
        """        remove_button = QPushButton("Remove Selected")
        remove_button.clicked.connect(self.remove_selected_rows)
""",
        """        remove_button = QPushButton("Remove Selected PDF")
        remove_button.clicked.connect(self.remove_selected_rows)
""",
        """        remove_button = QPushButton("Remove")
        remove_button.clicked.connect(self.remove_selected_rows)
""",
    ]

    inserted = False

    insert_buttons = """        move_up_button = QPushButton("Move Up")
        move_up_button.clicked.connect(self.move_selected_row_up)

        move_down_button = QPushButton("Move Down")
        move_down_button.clicked.connect(self.move_selected_row_down)

        validate_button = QPushButton("Validate Page Ranges")
        validate_button.clicked.connect(self.validate_page_ranges)
"""

    for pat in patterns:
        if pat in dialog_text:
            dialog_text = dialog_text.replace(pat, pat + "\n" + insert_buttons, 1)
            inserted = True
            print("[OK] Added Move/Validate button definitions")
            break

    if not inserted:
        # Fallback: insert after add_button.
        pat = """        add_button = QPushButton("Add PDF Files")
        add_button.clicked.connect(self.add_pdf_files)
"""
        if pat in dialog_text:
            dialog_text = dialog_text.replace(pat, pat + "\n" + insert_buttons, 1)
            inserted = True
            print("[OK] Added Move/Validate button definitions by fallback")
        else:
            print("[WARN] Could not find button definition area")

    # Add buttons to layout.
    # Try common button_layout names.
    layout_inserted = False
    layout_candidates = [
        '        button_layout.addWidget(remove_button)\n',
        '        buttons_layout.addWidget(remove_button)\n',
        '        control_layout.addWidget(remove_button)\n',
        '        top_button_layout.addWidget(remove_button)\n',
        '        file_button_layout.addWidget(remove_button)\n',
    ]

    add_to_layout = """        button_layout.addWidget(move_up_button)
        button_layout.addWidget(move_down_button)
        button_layout.addWidget(validate_button)
"""

    for cand in layout_candidates:
        if cand in dialog_text:
            if "button_layout" in cand:
                dialog_text = dialog_text.replace(cand, cand + add_to_layout, 1)
            elif "buttons_layout" in cand:
                dialog_text = dialog_text.replace(
                    cand,
                    cand + add_to_layout.replace("button_layout", "buttons_layout"),
                    1
                )
            elif "control_layout" in cand:
                dialog_text = dialog_text.replace(
                    cand,
                    cand + add_to_layout.replace("button_layout", "control_layout"),
                    1
                )
            elif "top_button_layout" in cand:
                dialog_text = dialog_text.replace(
                    cand,
                    cand + add_to_layout.replace("button_layout", "top_button_layout"),
                    1
                )
            elif "file_button_layout" in cand:
                dialog_text = dialog_text.replace(
                    cand,
                    cand + add_to_layout.replace("button_layout", "file_button_layout"),
                    1
                )

            layout_inserted = True
            print("[OK] Added Move/Validate buttons to existing layout")
            break

    if not layout_inserted:
        # Fallback: insert after add_button layout line.
        fallback_layout_candidates = [
            '        button_layout.addWidget(add_button)\n',
            '        buttons_layout.addWidget(add_button)\n',
            '        control_layout.addWidget(add_button)\n',
            '        top_button_layout.addWidget(add_button)\n',
            '        file_button_layout.addWidget(add_button)\n',
        ]

        for cand in fallback_layout_candidates:
            if cand in dialog_text:
                layout_name = cand.strip().split(".")[0]
                block = (
                    cand
                    + f"        {layout_name}.addWidget(move_up_button)\n"
                    + f"        {layout_name}.addWidget(move_down_button)\n"
                    + f"        {layout_name}.addWidget(validate_button)\n"
                )
                dialog_text = dialog_text.replace(cand, block, 1)
                layout_inserted = True
                print("[OK] Added Move/Validate buttons to layout by fallback")
                break

    if not layout_inserted:
        print("[WARN] Could not find button layout area. Methods will still be added.")

else:
    print("[SKIP] Collector move/validate button code seems already present")

# Add methods before create_collected_pdf
methods_block = r'''
    def _swap_table_rows(self, row_a: int, row_b: int) -> None:
        if row_a < 0 or row_b < 0:
            return

        if row_a >= self.table.rowCount() or row_b >= self.table.rowCount():
            return

        column_count = self.table.columnCount()
        values_a = []
        values_b = []

        for col in range(column_count):
            item_a = self.table.item(row_a, col)
            item_b = self.table.item(row_b, col)
            values_a.append("" if item_a is None else item_a.text())
            values_b.append("" if item_b is None else item_b.text())

        for col in range(column_count):
            self.table.setItem(row_a, col, QTableWidgetItem(values_b[col]))
            self.table.setItem(row_b, col, QTableWidgetItem(values_a[col]))

        self.table.selectRow(row_b)

    def move_selected_row_up(self) -> None:
        row = self.table.currentRow()

        if row <= 0:
            return

        self._swap_table_rows(row, row - 1)

    def move_selected_row_down(self) -> None:
        row = self.table.currentRow()

        if row < 0 or row >= self.table.rowCount() - 1:
            return

        self._swap_table_rows(row, row + 1)

    def validate_page_ranges(self) -> None:
        if self.table.rowCount() <= 0:
            QMessageBox.information(self, "Validate Page Ranges", "No PDF files to validate.")
            return

        errors = []

        for row in range(self.table.rowCount()):
            pdf_item = self.table.item(row, 0)
            pages_item = self.table.item(row, 1)
            count_item = self.table.item(row, 2)

            if pdf_item is None:
                errors.append(f"Row {row + 1}: PDF path is empty.")
                continue

            pdf_path = pdf_item.text().strip()
            page_ranges = "all"

            if pages_item is not None:
                page_ranges = pages_item.text().strip() or "all"

            try:
                if count_item is not None and count_item.text().strip().isdigit():
                    page_count = int(count_item.text().strip())
                else:
                    doc = fitz.open(pdf_path)
                    page_count = doc.page_count
                    doc.close()

                self.collector.parse_page_ranges(page_ranges, page_count)

            except Exception as exc:
                errors.append(f"Row {row + 1}: {exc}")

        if errors:
            QMessageBox.warning(
                self,
                "Validate Page Ranges",
                "Some page ranges are invalid:\n\n" + "\n".join(errors)
            )
            return

        QMessageBox.information(
            self,
            "Validate Page Ranges",
            "All page ranges are valid."
        )

'''

if "def move_selected_row_up" not in dialog_text:
    marker = "    def create_collected_pdf(self) -> None:\n"
    if marker in dialog_text:
        dialog_text = dialog_text.replace(marker, methods_block + "\n" + marker, 1)
        print("[OK] Added collector move/validate methods")
    else:
        print("[ERROR] Could not find create_collected_pdf marker")
        DIALOG.write_text(original_dialog, encoding="utf-8")
        MAIN.write_text(original_main, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Collector move/validate methods already present")

DIALOG.write_text(dialog_text, encoding="utf-8")

# ------------------------------------------------------------
# 3) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

files_to_compile = [MAIN, DIALOG, ROOT / "app" / "pdf" / "pdf_page_collector.py"]

for path in files_to_compile:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)

        failed_main = MAIN.with_name(f"main_window.py.failed_options_cleanup_{timestamp}")
        failed_dialog = DIALOG.with_name(f"page_collector_dialog.py.failed_collector_tools_{timestamp}")

        shutil.copy2(MAIN, failed_main)
        shutil.copy2(DIALOG, failed_dialog)

        shutil.copy2(main_backup, MAIN)
        shutil.copy2(dialog_backup, DIALOG)

        print("[RESTORED] Backups restored.")
        print(f"[INFO] Failed main saved: {failed_main}")
        print(f"[INFO] Failed dialog saved: {failed_dialog}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Options > Basic Mode / Advanced Mode removed")
print("- Page Collector: Move Up / Move Down / Validate Page Ranges added if layout patch succeeded")
print("- Existing collected PDF open prompt preserved")
