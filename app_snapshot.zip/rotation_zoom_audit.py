﻿from pathlib import Path
import ast
import sys
from datetime import datetime

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
OUT = ROOT / "rotation_zoom_audit.txt"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

text = MAIN.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines()

def get_function_source(source: str, func_name: str):
    tree = ast.parse(source)
    src_lines = source.splitlines()
    found = []

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno
            end = node.end_lineno
            code = "\n".join(src_lines[start - 1:end])
            found.append((start, end, code))

    return found

funcs = [
    "__init__",
    "_render_current_page",
    "rotate_left",
    "rotate_right",
    "reset_rotation",
    "reset_view",
    "zoom_in",
    "zoom_out",
    "fit_page",
    "actual_size",
    "_get_preview_display_size_tuple",
    "_save_current_workspace_state",
    "_load_workspace_index",
    "_serialize_workspace_items",
    "_restore_workspace_items_from_project",
    "_create_export_order_thumbnail",
]

terms = [
    "rotation_degrees",
    "preview_zoom_factor",
    "fit_to_page_enabled",
    "current_page_index",
    "page_rotations",
    "page_zooms",
    "workspace_items",
    "current_pixmap",
    "QTransform",
    "transformed",
]

report = []
report.append("# rotation_zoom_audit.txt")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py lines: {len(lines)}")
report.append("")

report.append("## Term references")
rows = []
for idx, line in enumerate(lines, 1):
    if any(term in line for term in terms):
        rows.append(f"{idx:05d}: {line}")

report.append("```text")
report.append("\n".join(rows[:800]))
report.append("```")
report.append("")

for fn in funcs:
    report.append(f"## Function `{fn}`")
    found = get_function_source(text, fn)
    if not found:
        report.append("- not found")
        report.append("")
        continue

    for start, end, code in found:
        report.append(f"- lines {start}-{end}")
        report.append("```python")
        report.append(code)
        report.append("```")
        report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste rotation_zoom_audit.txt here.")
