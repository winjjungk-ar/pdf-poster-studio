﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_tiling_preview_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add Tiling Preview labels after estimate label creation
# ------------------------------------------------------------
old = '''        self.poster_sheet_estimate_label = QLabel("Estimated Sheets: -")
        self.poster_sheet_estimate_label.setWordWrap(True)
        self.poster_sheet_estimate_label.setMinimumHeight(44)
        self.poster_sheet_estimate_label.setStyleSheet("color: #395B64;")

        self.numbering_check = QCheckBox("Show sheet numbers")
'''

new = '''        self.poster_sheet_estimate_label = QLabel("Estimated Sheets: -")
        self.poster_sheet_estimate_label.setWordWrap(True)
        self.poster_sheet_estimate_label.setMinimumHeight(44)
        self.poster_sheet_estimate_label.setStyleSheet("color: #395B64;")

        self.tiling_preview_title = QLabel("Tiling Preview")
        self.tiling_preview_title.setStyleSheet("font-weight: 700; color: #395B64;")

        self.tiling_preview_label = QLabel("-")
        self.tiling_preview_label.setWordWrap(True)
        self.tiling_preview_label.setMinimumHeight(70)
        self.tiling_preview_label.setStyleSheet("""
            QLabel {
                color: #395B64;
                background-color: #FFF8F0;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 8px;
                font-family: Consolas, 'Courier New', monospace;
            }
        """)

        self.numbering_check = QCheckBox("Show sheet numbers")
'''

if old in text and "self.tiling_preview_label" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Tiling Preview labels")
else:
    if "self.tiling_preview_label" in text:
        print("[SKIP] Tiling Preview labels already exist")
    else:
        print("[ERROR] Could not find estimate label block")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 2) Add preview widgets to Poster Print layout
# ------------------------------------------------------------
old = '''        a3_layout.addWidget(QLabel("Poster Scale"))
        a3_layout.addWidget(self.poster_scale_spin)
        a3_layout.addWidget(self.poster_sheet_estimate_label)

        a3_layout.addSpacing(8)
        a3_layout.addWidget(self.numbering_check)
'''

new = '''        a3_layout.addWidget(QLabel("Poster Scale"))
        a3_layout.addWidget(self.poster_scale_spin)
        a3_layout.addWidget(self.poster_sheet_estimate_label)
        a3_layout.addWidget(self.tiling_preview_title)
        a3_layout.addWidget(self.tiling_preview_label)

        a3_layout.addSpacing(8)
        a3_layout.addWidget(self.numbering_check)
'''

if old in text and "a3_layout.addWidget(self.tiling_preview_label)" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Tiling Preview to Poster Print layout")
else:
    if "a3_layout.addWidget(self.tiling_preview_label)" in text:
        print("[SKIP] Tiling Preview already in layout")
    else:
        print("[ERROR] Could not find Poster Print layout block")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 3) Add helper method before update_poster_sheet_estimate
# ------------------------------------------------------------
helper = r'''
    def update_tiling_preview(self, cols: int | None = None, rows: int | None = None) -> None:
        if not hasattr(self, "tiling_preview_label"):
            return

        if not cols or not rows or cols <= 0 or rows <= 0:
            self.tiling_preview_label.setText("-")
            return

        max_cells = 40
        total = cols * rows

        lines = []
        sheet_no = 1

        for row in range(rows):
            cells = []

            for col in range(cols):
                if sheet_no > max_cells:
                    cells.append(" ... ")
                else:
                    cells.append(f"{sheet_no:^5}")

                sheet_no += 1

            lines.append("[" + "][".join(cells) + "]")

            if sheet_no > max_cells and row < rows - 1:
                lines.append("...")
                break

        preview = "\\n".join(lines)
        self.tiling_preview_label.setText(
            f"{cols} x {rows} = {total} sheets\\n{preview}"
        )

'''

if "def update_tiling_preview" not in text:
    marker = "    def update_poster_sheet_estimate(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find update_poster_sheet_estimate marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + helper + "\n" + text[pos:]
    print("[OK] Added update_tiling_preview helper")
else:
    print("[SKIP] update_tiling_preview already exists")

# ------------------------------------------------------------
# 4) Patch update_poster_sheet_estimate to update preview
# ------------------------------------------------------------

# page_count <= 0 branch
text = text.replace(
    '''                self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
                return
''',
    '''                self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
                self.update_tiling_preview()
                return
''',
    1
)

# select area first branch
text = text.replace(
    '''                self.poster_sheet_estimate_label.setText("Estimated Sheets: select an area first")
                return
''',
    '''                self.poster_sheet_estimate_label.setText("Estimated Sheets: select an area first")
                self.update_tiling_preview()
                return
''',
    1
)

# classic A4/A3 branch
old = '''                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text}\\n{size_text}"
                )
                return
'''

new = '''                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text}\\n{size_text}"
                )

                if split_layout == "top_bottom":
                    self.update_tiling_preview(cols=1, rows=2)
                else:
                    self.update_tiling_preview(cols=2, rows=1)

                return
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Classic A4/A3 estimate updates tiling preview")
else:
    print("[WARN] Classic estimate branch not found")

# scalable branch
old = '''            self.poster_sheet_estimate_label.setText(
                f"Estimated Sheets: {cols} x {rows} = {total} "
                f"({paper_name}, {scale_percent}%)\\n"
                f"Approx Poster Size: {poster_w_mm:.0f} x {poster_h_mm:.0f} mm"
            )
'''

new = '''            self.poster_sheet_estimate_label.setText(
                f"Estimated Sheets: {cols} x {rows} = {total} "
                f"({paper_name}, {scale_percent}%)\\n"
                f"Approx Poster Size: {poster_w_mm:.0f} x {poster_h_mm:.0f} mm"
            )
            self.update_tiling_preview(cols=cols, rows=rows)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Scalable estimate updates tiling preview")
else:
    print("[WARN] Scalable estimate branch not found")

# exception branch
text = text.replace(
    '''            self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
            self._log(f"Poster sheet estimate error: {exc}")
''',
    '''            self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
            self.update_tiling_preview()
            self._log(f"Poster sheet estimate error: {exc}")
''',
    1
)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_tiling_preview_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "self.tiling_preview_label",
    "Tiling Preview",
    "def update_tiling_preview",
    "self.update_tiling_preview(cols=cols, rows=rows)",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Poster Print tab now shows a simple tiling preview")
print("- A3/A4 2-sheet mode shows [1][2] or stacked layout")
print("- Larger presets show grid layout with sheet numbers")
