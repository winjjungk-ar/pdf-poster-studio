﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_estimate_label_wrap_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Make estimate label wrap and reserve height
# ------------------------------------------------------------
old = '''        self.poster_sheet_estimate_label = QLabel("Estimated Sheets: -")

        self.numbering_check = QCheckBox("Add sheet numbers")
'''

new = '''        self.poster_sheet_estimate_label = QLabel("Estimated Sheets: -")
        self.poster_sheet_estimate_label.setWordWrap(True)
        self.poster_sheet_estimate_label.setMinimumHeight(44)
        self.poster_sheet_estimate_label.setStyleSheet("color: #395B64;")

        self.numbering_check = QCheckBox("Add sheet numbers")
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Estimate label now wraps and has minimum height")
else:
    if "self.poster_sheet_estimate_label.setWordWrap(True)" in text:
        print("[SKIP] Estimate label wrapping already applied")
    else:
        print("[WARN] Could not find estimate label block")

# ------------------------------------------------------------
# 2) Change estimate text to multi-line format
# ------------------------------------------------------------
old = '''                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text} | {size_text}"
                )
'''

new = '''                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text}\\n{size_text}"
                )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] A4 100% estimate text split into 2 lines")
else:
    print("[SKIP] A4 100% estimate text block not found or already changed")

old = '''            self.poster_sheet_estimate_label.setText(
                f"Estimated Sheets: {cols} x {rows} = {total} "
                f"({paper_name}, {scale_percent}%) | "
                f"Approx Poster Size: {poster_w_mm:.0f} x {poster_h_mm:.0f} mm"
            )
'''

new = '''            self.poster_sheet_estimate_label.setText(
                f"Estimated Sheets: {cols} x {rows} = {total} "
                f"({paper_name}, {scale_percent}%)\\n"
                f"Approx Poster Size: {poster_w_mm:.0f} x {poster_h_mm:.0f} mm"
            )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Scaled estimate text split into 2 lines")
else:
    print("[SKIP] Scaled estimate text block not found or already changed")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_estimate_label_wrap_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "self.poster_sheet_estimate_label.setWordWrap(True)",
    "Approx Poster Size",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Estimated Sheets label now wraps")
print("- Approx Poster Size is shown on a second line")
