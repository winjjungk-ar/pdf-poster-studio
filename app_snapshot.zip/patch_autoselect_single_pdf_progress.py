﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_autoselect_single_progress_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            targets.append(node)

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno

    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

# ------------------------------------------------------------
# 1) Version bump 0.9.3 -> 0.9.4
# ------------------------------------------------------------
for old, new in [
    ("Version: 0.9.3", "Version: 0.9.4"),
    ('"version": "0.9.3"', '"version": "0.9.4"'),
    ("What's new in 0.9.3", "What's new in 0.9.4"),
    ("Version 0.9.3", "Version 0.9.4"),
]:
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        print(f"[OK] Version replace {count}: {old} -> {new}")

# ------------------------------------------------------------
# 2) Replace auto_select_all_pages with progress-enabled version
# ------------------------------------------------------------
new_auto_select_all_pages = r'''    def auto_select_all_pages(self) -> None:
        if hasattr(self, "workspace_items") and len(self.workspace_items) > 1:
            self.auto_select_all_workspace_pages()
            return

        if not self.current_pdf_path or self.page_count <= 0:
            QMessageBox.information(
                self,
                "Auto Select All Pages",
                "Please open a PDF or image first."
            )
            return

        result = QMessageBox.question(
            self,
            "Auto Select All Pages",
            "Automatically detect content area for all pages?\n\n"
            "Existing selections may be replaced.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if result != QMessageBox.StandardButton.Yes:
            return

        progress = QProgressDialog(
            "Preparing auto selection...",
            "Cancel",
            0,
            self.page_count,
            self,
        )
        progress.setWindowTitle("Auto Select All Pages")
        progress.setWindowModality(Qt.WindowModality.ApplicationModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        progress.show()
        QApplication.processEvents()

        selected_count = 0
        canceled = False

        try:
            selected_count = self._auto_select_all_pages_for_current_pdf_no_prompt(
                progress_dialog=progress,
                progress_offset=0,
                progress_label_prefix="",
            )

            if progress.wasCanceled():
                canceled = True

            progress.setValue(self.page_count)
            QApplication.processEvents()

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Auto Select All Pages",
                f"Auto selection failed.\n\n{exc}"
            )
            self._log(f"Auto Select All Pages error: {exc}")
            return

        finally:
            progress.close()

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        self.is_modified = True

        if canceled:
            QMessageBox.information(
                self,
                "Auto Select All Pages",
                f"Auto selection was canceled.\n\nSelected pages before cancel: {selected_count}"
            )
        else:
            QMessageBox.information(
                self,
                "Auto Select All Pages",
                f"Auto selection completed.\n\nSelected pages: {selected_count}/{self.page_count}"
            )

        self._log(
            f"Auto Select All Pages completed: selected={selected_count}/{self.page_count}"
        )

'''

try:
    text = replace_function(text, "auto_select_all_pages", new_auto_select_all_pages)
    print("[OK] Replaced auto_select_all_pages with progress-enabled version")
except Exception as exc:
    print(f"[ERROR] Failed to replace auto_select_all_pages: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 3) Ensure helper has processEvents/progress support marker
# ------------------------------------------------------------
if "def _auto_select_all_pages_for_current_pdf_no_prompt" not in text:
    print("[ERROR] Helper _auto_select_all_pages_for_current_pdf_no_prompt not found.")
    print("        Cannot safely patch.")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 4) Add Release Notes 0.9.4 section
# ------------------------------------------------------------
if "Auto Select All Pages progress improvement" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.4</h3>
<ul>
  <li><b>Auto Select All Pages progress improvement</b>: Single large PDFs now show a progress dialog.</li>
  <li>Improved UI responsiveness during long auto-selection jobs.</li>
  <li>Cancel button is available during auto-selection.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for 0.9.4")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 5) Welcome What's New update
# ------------------------------------------------------------
if "Auto Select All Pages now shows progress for large PDFs" not in text:
    marker = "• See Help > Release Notes for details"
    addition = "• Auto Select All Pages now shows progress for large PDFs\\n"
    if marker in text:
        text = text.replace(marker, addition + marker, 1)
        print("[OK] Welcome What's New updated")
    else:
        print("[WARN] Welcome marker not found")

# ------------------------------------------------------------
# 6) Write and compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_autoselect_single_progress_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Version: 0.9.4",
    '"version": "0.9.4"',
    "Auto Select All Pages progress improvement",
    "progress.show()",
    "_auto_select_all_pages_for_current_pdf_no_prompt(",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Single-PDF Auto Select All Pages now shows progress")
print("- UI should remain more responsive during large PDF processing")
print("- Version bumped to 0.9.4")
