﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_print_order_auto_sync_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add auto-sync flag in __init__
# ------------------------------------------------------------
old = '''        self._updating_page_list = False

        # Multi-PDF workspace.
'''

new = '''        self._updating_page_list = False
        self._auto_sync_print_order_enabled = False

        # Multi-PDF workspace.
'''

if old in text and "_auto_sync_print_order_enabled" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added print order auto-sync flag")
else:
    print("[SKIP] Auto-sync flag already exists or anchor not found")

# ------------------------------------------------------------
# 2) Add quiet sync helper before refresh_export_order_from_checked_pages
# ------------------------------------------------------------
helper = r'''
    def sync_print_order_from_checked_pages_quiet(self) -> None:
        """Rebuild Print Order from checked pages without showing dialogs."""
        if not hasattr(self, "export_order_list"):
            return

        if not hasattr(self, "workspace_items") or not self.workspace_items:
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        self.export_order_list.clear()

        for workspace_index, item in enumerate(self.workspace_items):
            checked_pages = sorted(list(item.get("checked_pages", set())))

            for page_index in checked_pages:
                self._add_export_order_item(workspace_index, page_index)

        self._refresh_workspace_list_text()
        self._log(f"Print Order auto-synced: {self.export_order_list.count()} pages")

'''

if "def sync_print_order_from_checked_pages_quiet" not in text:
    marker = "    def refresh_export_order_from_checked_pages(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find refresh_export_order_from_checked_pages marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + helper + "\n" + text[pos:]
    print("[OK] Added quiet Print Order sync helper")
else:
    print("[SKIP] Quiet sync helper already exists")

# ------------------------------------------------------------
# 3) Enable auto-sync in Merge PDFs and Extract Pages tasks
# ------------------------------------------------------------
old = '''        total_added = self.build_print_order_from_all_source_pages()
'''

new = '''        self._auto_sync_print_order_enabled = True
        total_added = self.build_print_order_from_all_source_pages()
'''

if old in text and "_auto_sync_print_order_enabled = True" not in text[text.find("def task_merge_pdfs"):text.find("def task_extract_pages")]:
    text = text.replace(old, new, 1)
    print("[OK] Merge PDFs task enables Print Order auto-sync")
else:
    print("[SKIP] Merge task auto-sync already enabled or anchor not found")

old = '''            total_added = self.build_print_order_from_page_range(range_text)
'''

new = '''            self._auto_sync_print_order_enabled = True
            total_added = self.build_print_order_from_page_range(range_text)
'''

if old in text and "_auto_sync_print_order_enabled = True" not in text[text.find("def task_extract_pages"):text.find("def task_make_poster")]:
    text = text.replace(old, new, 1)
    print("[OK] Extract Pages task enables Print Order auto-sync")
else:
    print("[SKIP] Extract task auto-sync already enabled or anchor not found")

# ------------------------------------------------------------
# 4) Auto-sync after page checkbox changes
# ------------------------------------------------------------
old = '''        self.is_modified = True
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(self.current_page_index)
        self._update_checked_pages_label()
'''

new = '''        self.is_modified = True
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(self.current_page_index)
        self._update_checked_pages_label()

        if getattr(self, "_auto_sync_print_order_enabled", False):
            self.sync_print_order_from_checked_pages_quiet()
'''

if old in text and "sync_print_order_from_checked_pages_quiet()" not in text[text.find("def on_page_complete_changed"):text.find("def on_page_jump_changed")]:
    text = text.replace(old, new, 1)
    print("[OK] Page complete checkbox now auto-syncs Print Order")
else:
    print("[SKIP] Page complete auto-sync already present or anchor not found")

# Page list item changed
old = '''        self.is_modified = True
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(page_index)
        self._update_checked_pages_label()
'''

new = '''        self.is_modified = True
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(page_index)
        self._update_checked_pages_label()

        if getattr(self, "_auto_sync_print_order_enabled", False):
            self.sync_print_order_from_checked_pages_quiet()
'''

if old in text and "sync_print_order_from_checked_pages_quiet()" not in text[text.find("def on_page_list_item_changed"):text.find("def _save_current_selection")]:
    text = text.replace(old, new, 1)
    print("[OK] Page list checkbox now auto-syncs Print Order")
else:
    print("[SKIP] Page list auto-sync already present or anchor not found")

# ------------------------------------------------------------
# 5) Enable auto-sync when user manually builds Print Order
# ------------------------------------------------------------
old = '''        self._log(f"Print order refreshed: {self.export_order_list.count()} pages")
'''

new = '''        self._auto_sync_print_order_enabled = True
        self._log(f"Print order refreshed: {self.export_order_list.count()} pages")
'''

if old in text and "_auto_sync_print_order_enabled = True" not in text[text.find("def refresh_export_order_from_checked_pages"):text.find("def _move_export_order_row")]:
    text = text.replace(old, new, 1)
    print("[OK] Build Print Order enables auto-sync")
else:
    print("[SKIP] Build Print Order auto-sync already enabled or anchor not found")

# ------------------------------------------------------------
# 6) Disable auto-sync if user manually moves Print Order
# ------------------------------------------------------------
old = '''        item = self.export_order_list.takeItem(source_row)
        self.export_order_list.insertItem(target_row, item)
        self.export_order_list.setCurrentRow(target_row)
'''

new = '''        item = self.export_order_list.takeItem(source_row)
        self.export_order_list.insertItem(target_row, item)
        self.export_order_list.setCurrentRow(target_row)

        # User manually changed order; stop automatic rebuild to preserve custom order.
        self._auto_sync_print_order_enabled = False
'''

if old in text and "stop automatic rebuild" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Manual Move Up/Down disables auto-sync to preserve custom order")
else:
    print("[SKIP] Move row auto-sync disable already present or anchor not found")

# ------------------------------------------------------------
# 7) Release Notes
# ------------------------------------------------------------
if "Print Order auto-sync" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Print Order auto-sync</b>: Extract Pages and Merge PDFs workflows now update Print Order when checked pages change.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for Print Order auto-sync")

# ------------------------------------------------------------
# 8) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_print_order_auto_sync_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "_auto_sync_print_order_enabled",
    "def sync_print_order_from_checked_pages_quiet",
    "Print Order auto-synced",
    "Print Order auto-sync",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Extract/Merge workflows now auto-sync Print Order with checked pages")
print("- Manual Move Up/Down disables auto-sync to preserve custom order")
