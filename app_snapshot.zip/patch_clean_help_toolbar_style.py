﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_clean_help_toolbar_style_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Clean Help menu: keep About Program only
# ------------------------------------------------------------
old_help_block = '''        # Help
        help_menu.addAction("Quick Start", self.show_quick_start)
        help_menu.addAction("Diagnostics", self.run_diagnostics)
        help_menu.addSeparator()
        help_menu.addAction("About Program", self.show_about)
'''

new_help_block = '''        # Help
        help_menu.addAction("About Program", self.show_about)
'''

if old_help_block in text:
    text = text.replace(old_help_block, new_help_block, 1)
    print("[OK] Help menu cleaned: only About Program remains")
else:
    before = text
    text = text.replace('        help_menu.addAction("Quick Start", self.show_quick_start)\n', '')
    text = text.replace('        help_menu.addAction("Diagnostics", self.run_diagnostics)\n', '')
    text = text.replace('        help_menu.addAction("Check Menu Actions", self.check_menu_actions)\n', '')

    # Remove lonely separator directly before About Program
    text = text.replace(
        '        # Help\n        help_menu.addSeparator()\n        help_menu.addAction("About Program", self.show_about)\n',
        '        # Help\n        help_menu.addAction("About Program", self.show_about)\n',
        1
    )
    text = text.replace(
        '        help_menu.addSeparator()\n        help_menu.addAction("About Program", self.show_about)\n',
        '        help_menu.addAction("About Program", self.show_about)\n',
        1
    )

    if text != before:
        print("[OK] Help menu cleaned by fallback")
    else:
        print("[WARN] Help menu cleanup made no changes")

# ------------------------------------------------------------
# 2) Replace toolbar stylesheet with unified pastel style
# ------------------------------------------------------------
start_marker = '        toolbar.setStyleSheet("""\n'
start = text.find(start_marker, text.find("def _create_quick_toolbar"))

if start == -1:
    print("[WARN] Toolbar stylesheet start not found")
else:
    end = text.find('        """)\n', start)
    if end == -1:
        print("[WARN] Toolbar stylesheet end not found")
    else:
        end += len('        """)\n')

        new_style = '''        toolbar.setStyleSheet("""
            QToolBar {
                background-color: #FFF8F0;
                border-bottom: 1px solid #EADBC8;
                spacing: 6px;
                padding: 5px;
            }
            QToolButton {
                color: #395B64;
                background-color: #EAF7F7;
                border: 1px solid #BFE8E8;
                border-radius: 7px;
                padding: 6px 10px;
                font-weight: 700;
            }
            QToolButton:hover {
                background-color: #DDF3F5;
                border: 1px solid #9EDDE2;
            }
            QToolButton:pressed {
                background-color: #CDECEF;
            }
        """)
'''

        text = text[:start] + new_style + text[end:]
        print("[OK] Toolbar style unified to pastel")

# ------------------------------------------------------------
# 3) Remove object-specific Auto Select All styling usage if desired
#    Keep objectName harmless, but no separate style remains.
# ------------------------------------------------------------
# No need to remove objectName, since stylesheet no longer targets it.
print("[OK] Auto Select All Pages no longer has special blue styling")

# ------------------------------------------------------------
# 4) Diagnostics reference cleanup in check menu actions if present
# ------------------------------------------------------------
text = text.replace(
    '            ("Help > Quick Start", callable(self.show_quick_start)),\n',
    ''
)
text = text.replace(
    '            ("Help > Diagnostics", callable(self.run_diagnostics)),\n',
    ''
)
text = text.replace(
    '            ("Help > Check Menu Actions", callable(self.check_menu_actions)),\n',
    ''
)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_clean_help_toolbar_style_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

# Basic checks
if 'help_menu.addAction("Quick Start"' in new_text:
    print("[WARN] Quick Start menu action still exists")
if 'help_menu.addAction("Diagnostics"' in new_text:
    print("[WARN] Diagnostics menu action still exists")
if 'background-color: #0B63CE' in new_text:
    print("[WARN] Old blue Auto Select All style still exists")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Help menu simplified to About Program only")
print("- Toolbar buttons unified with pastel style")
print("- Auto Select All Pages blue highlight removed")
