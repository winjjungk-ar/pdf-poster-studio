﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
PREVIEW = ROOT / "app" / "ui" / "pdf_preview_widget.py"

if not PREVIEW.exists():
    print(f"[ERROR] Not found: {PREVIEW}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = PREVIEW.with_name(f"pdf_preview_widget.py.bak_remove_label_border_{timestamp}")
shutil.copy2(PREVIEW, backup)
print(f"[OK] Backup created: {backup}")

text = PREVIEW.read_text(encoding="utf-8", errors="replace")
original = text

old = '''        self.setStyleSheet(
            "QLabel { border: 1px solid #999; background: #f8f8f8; font-size: 18px; }"
        )
'''

new = '''        # Keep the preview area clean before a PDF is loaded.
        # Selection rectangles are drawn only when a preview pixmap exists.
        self.setStyleSheet(
            "QLabel { border: none; background: transparent; font-size: 18px; }"
        )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Removed empty preview QLabel border/background")
else:
    if "border: none; background: transparent" in text:
        print("[SKIP] Empty preview style already cleaned")
    else:
        print("[WARN] Exact old stylesheet not found. Applying fallback replacements.")
        text = text.replace("border: 1px solid #999;", "border: none;")
        text = text.replace("background: #f8f8f8;", "background: transparent;")

PREVIEW.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(PREVIEW)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = PREVIEW.with_name(f"pdf_preview_widget.py.failed_remove_label_border_{timestamp}")
    shutil.copy2(PREVIEW, failed)
    shutil.copy2(backup, PREVIEW)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = PREVIEW.read_text(encoding="utf-8", errors="replace")

print("[INFO] Check:")
print("  - border none:", "border: none" in new_text)
print("  - transparent background:", "background: transparent" in new_text)
print(
    "  - empty preview guard:",
    "Do not draw placeholder rectangle before a PDF is loaded" in new_text
)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Empty preview rectangle removed")
print("- Run: python main.py")
