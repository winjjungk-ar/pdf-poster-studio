﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_hobby_presets_respect_paper_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Window title broadened
# ------------------------------------------------------------
text = text.replace(
    'self.setWindowTitle("PDF Poster Studio - A4/A3 Print Workspace")',
    'self.setWindowTitle("PDF Poster Studio - Maps, Posters & Drawings")'
)

# ------------------------------------------------------------
# 2) Welcome subtitle broadened
# ------------------------------------------------------------
text = text.replace(
    "Open one or more PDFs as source files, or continue an existing project.",
    "Print large maps, posters, game boards, and engineering drawings from PDF files."
)

# ------------------------------------------------------------
# 3) Add hobby presets after Manual / Custom
#    Important: no paper_size field. They respect current Output Paper Size.
# ------------------------------------------------------------
anchor = '''        self.poster_size_preset_combo.addItem("Manual / Custom", None)

        self.poster_size_preset_combo.addItem("A3 from A4 - 141%", {"scale": 141, "paper_size": "a4"})
'''

insert = '''        self.poster_size_preset_combo.addItem("Manual / Custom", None)

        # Hobby presets respect the currently selected Output Paper Size.
        self.poster_size_preset_combo.addItem("Poster Small - 2 sheets", {"scale": 141, "sheets": 2})
        self.poster_size_preset_combo.addItem("Poster Medium - 4 sheets", {"scale": 200, "sheets": 4})
        self.poster_size_preset_combo.addItem("Poster Large - 8 sheets", {"scale": 283, "sheets": 8})
        self.poster_size_preset_combo.addItem("Poster Huge - 16 sheets", {"scale": 400, "sheets": 16})

        self.poster_size_preset_combo.addItem("A3 from A4 - 141%", {"scale": 141, "paper_size": "a4"})
'''

if anchor in text and "Poster Small - 2 sheets" not in text:
    text = text.replace(anchor, insert, 1)
    print("[OK] Added hobby poster presets")
elif "Poster Small - 2 sheets" in text:
    print("[SKIP] Hobby poster presets already exist")
else:
    print("[WARN] Could not find preset insertion anchor")

# If a previous failed patch added hobby presets with paper_size, fix them.
fixes = [
    ('{"scale": 141, "paper_size": "a4"}', '{"scale": 141, "sheets": 2}'),
    ('{"scale": 200, "paper_size": "a4"}', '{"scale": 200, "sheets": 4}'),
    ('{"scale": 283, "paper_size": "a4"}', '{"scale": 283, "sheets": 8}'),
    ('{"scale": 400, "paper_size": "a4"}', '{"scale": 400, "sheets": 16}'),
]

# Only apply to Poster Small/Medium/Large/Huge lines, not A-series.
lines = text.splitlines()
for i, line in enumerate(lines):
    if any(name in line for name in ["Poster Small", "Poster Medium", "Poster Large", "Poster Huge"]):
        for old, new in fixes:
            if old in line:
                line = line.replace(old, new)
        lines[i] = line
text = "\n".join(lines) + ("\n" if text.endswith("\n") else "")

# ------------------------------------------------------------
# 4) Replace fixed grid helper to include hobby presets and respect paper size
# ------------------------------------------------------------
def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

new_helper = r'''    def _get_fixed_a_series_tile_grid(self) -> tuple[int | None, int | None]:
        """Return fixed tile grid for known poster size presets.

        User expectation:
        - Poster Small / A3 / ANSI B / Arch B -> 2 sheets
        - Poster Medium / A2 / ANSI C / Arch C -> 4 sheets
        - Poster Large / A1 / ANSI D / Arch D -> 8 sheets
        - Poster Huge / A0 / ANSI E / Arch E -> 16 sheets

        Hobby presets respect the currently selected Output Paper Size.
        A-series presets set A4. ANSI/Arch presets set US Letter.
        """
        if not hasattr(self, "poster_size_preset_combo"):
            return None, None

        preset_text = self.poster_size_preset_combo.currentText()
        split_layout = self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else "left_right"

        if not preset_text or "Manual" in preset_text or "Custom" in preset_text:
            return None, None

        # 2 sheets
        if (
            preset_text.startswith("Poster Small")
            or preset_text.startswith("A3 ")
            or preset_text.startswith("ANSI B")
            or preset_text.startswith("Arch B")
        ):
            return (1, 2) if split_layout == "top_bottom" else (2, 1)

        # 4 sheets
        if (
            preset_text.startswith("Poster Medium")
            or preset_text.startswith("A2 ")
            or preset_text.startswith("ANSI C")
            or preset_text.startswith("Arch C")
        ):
            return 2, 2

        # 8 sheets
        if (
            preset_text.startswith("Poster Large")
            or preset_text.startswith("A1 ")
            or preset_text.startswith("ANSI D")
            or preset_text.startswith("Arch D")
        ):
            return (2, 4) if split_layout == "top_bottom" else (4, 2)

        # 16 sheets
        if (
            preset_text.startswith("Poster Huge")
            or preset_text.startswith("A0 ")
            or preset_text.startswith("ANSI E")
            or preset_text.startswith("Arch E")
        ):
            return 4, 4

        return None, None

'''

try:
    text = replace_function(text, "_get_fixed_a_series_tile_grid", new_helper)
    print("[OK] Fixed grid helper updated for hobby presets")
except Exception as exc:
    print(f"[ERROR] Could not update fixed grid helper: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 5) Update on_poster_size_preset_changed
#    If preset_value has paper_size -> change paper size.
#    If not -> keep current paper size.
# ------------------------------------------------------------
new_preset_changed = r'''    def on_poster_size_preset_changed(self) -> None:
        if not hasattr(self, "poster_size_preset_combo"):
            return

        preset_value = self.poster_size_preset_combo.currentData()

        if preset_value is None:
            self.update_poster_sheet_estimate()
            return

        # Backward compatibility: old preset data was just an integer scale.
        if isinstance(preset_value, dict):
            scale_value = int(preset_value.get("scale", 100))
            paper_size = preset_value.get("paper_size")
        else:
            scale_value = int(preset_value)
            paper_size = None

        # A-series / ANSI / Arch presets may define paper_size.
        # Hobby presets intentionally do not define paper_size and keep the current Output Paper Size.
        if paper_size and hasattr(self, "paper_size_combo"):
            self.paper_size_combo.blockSignals(True)
            self._apply_combo_data(self.paper_size_combo, paper_size)
            self.paper_size_combo.blockSignals(False)

        if hasattr(self, "poster_scale_spin"):
            self.poster_scale_spin.blockSignals(True)
            self.poster_scale_spin.setValue(scale_value)
            self.poster_scale_spin.blockSignals(False)

        self.update_poster_sheet_estimate()

'''

try:
    text = replace_function(text, "on_poster_size_preset_changed", new_preset_changed)
    print("[OK] Preset change handler keeps paper size for hobby presets")
except Exception as exc:
    print(f"[ERROR] Could not update preset change handler: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 6) Estimate text for hobby presets
# ------------------------------------------------------------
old = '''                if "ANSI" in preset_text:
'''

new = '''                if preset_text.startswith("Poster "):
                    current_paper = self.paper_size_combo.currentText() if hasattr(self, "paper_size_combo") else "current paper"
                    if total == 2:
                        size_text = f"Approx Poster Size: Small Poster on {current_paper}"
                    elif total == 4:
                        size_text = f"Approx Poster Size: Medium Poster on {current_paper}"
                    elif total == 8:
                        size_text = f"Approx Poster Size: Large Poster on {current_paper}"
                    elif total == 16:
                        size_text = f"Approx Poster Size: Huge Poster on {current_paper}"
                    else:
                        size_text = f"Approx Poster Size: Poster preset on {current_paper}"
                elif "ANSI" in preset_text:
'''

if old in text and "Small Poster on" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Estimate text updated for hobby presets")
else:
    print("[SKIP] Hobby estimate text already exists or anchor missing")

# ------------------------------------------------------------
# 7) User Guide: add game map / wall poster section
# ------------------------------------------------------------
guide_anchor = '''<h3>2. How to Create a Poster PDF</h3>
'''

guide_insert = '''<h3>2. How to Print a Game Map or Wall Poster</h3>
<p>
You can use PDF Poster Studio to print game maps, TRPG battle maps, board game maps,
fan posters, event posters, and wall maps across normal printer paper.
</p>

<ol>
  <li>Click <b>Open PDFs</b> and open your map or poster PDF.</li>
  <li>Select the map/poster area in the preview.</li>
  <li>Open the <b>Poster Print</b> tab.</li>
  <li>Choose <b>Output Paper Size</b>: A4 or US Letter.</li>
  <li>Choose <b>Poster Small</b>, <b>Poster Medium</b>, <b>Poster Large</b>, or <b>Poster Huge</b>.</li>
  <li>Check <b>Tiling Preview</b> to see how many sheets will be printed.</li>
  <li>Choose <b>Output Files</b>: One PDF or Separate PDF per selected page.</li>
  <li>Click <b>Create Poster PDF</b>.</li>
</ol>

<p>
The hobby poster presets use the currently selected Output Paper Size.
For example, Poster Medium creates 4 sheets using either A4 or US Letter.
</p>

<hr>

<h3>3. How to Create a Poster PDF for Drawings</h3>
'''

if guide_anchor in text and "How to Print a Game Map or Wall Poster" not in text:
    text = text.replace(guide_anchor, guide_insert, 1)
    print("[OK] User Guide expanded for game maps/wall posters")
elif "How to Print a Game Map or Wall Poster" in text:
    print("[SKIP] User Guide already has game map section")
else:
    print("[WARN] Could not find User Guide poster section anchor")

# Basic renumbering if section was inserted.
text = text.replace("<h3>3. How to Create a Single Page PDF</h3>", "<h3>4. How to Create a Single Page PDF</h3>")
text = text.replace("<h3>4. One PDF vs Separate PDFs</h3>", "<h3>5. One PDF vs Separate PDFs</h3>")
text = text.replace("<h3>5. How to Combine PDFs into One Output PDF</h3>", "<h3>6. How to Combine PDFs into One Output PDF</h3>")
text = text.replace("<h3>6. Source PDFs and Print Order</h3>", "<h3>7. Source PDFs and Print Order</h3>")
text = text.replace("<h3>7. Auto Select</h3>", "<h3>8. Auto Select</h3>")
text = text.replace("<h3>8. Poster Print Options</h3>", "<h3>9. Poster Print Options</h3>")
text = text.replace("<h3>9. Finding Exported Files</h3>", "<h3>10. Finding Exported Files</h3>")
text = text.replace("<h3>10. Saving Projects</h3>", "<h3>11. Saving Projects</h3>")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 8) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_hobby_presets_respect_paper_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "Poster Small - 2 sheets",
    '"sheets": 2',
    "Hobby presets respect the currently selected Output Paper Size",
    "How to Print a Game Map or Wall Poster",
    "PDF Poster Studio - Maps, Posters & Drawings",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Hobby presets added")
print("- Hobby presets keep current Output Paper Size")
print("- A-series presets still set A4")
print("- ANSI/Arch presets still set US Letter")
print("- User Guide expanded for game maps and wall posters")
