﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_preset_sets_paper_size_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Replace preset data values: int -> dict(scale, paper_size)
# ------------------------------------------------------------
replacements = [
    ('self.poster_size_preset_combo.addItem("A3 from A4 - 141%", 141)',
     'self.poster_size_preset_combo.addItem("A3 from A4 - 141%", {"scale": 141, "paper_size": "a4"})'),
    ('self.poster_size_preset_combo.addItem("A2 from A4 - 200%", 200)',
     'self.poster_size_preset_combo.addItem("A2 from A4 - 200%", {"scale": 200, "paper_size": "a4"})'),
    ('self.poster_size_preset_combo.addItem("A1 from A4 - 283%", 283)',
     'self.poster_size_preset_combo.addItem("A1 from A4 - 283%", {"scale": 283, "paper_size": "a4"})'),
    ('self.poster_size_preset_combo.addItem("A0 from A4 - 400%", 400)',
     'self.poster_size_preset_combo.addItem("A0 from A4 - 400%", {"scale": 400, "paper_size": "a4"})'),

    ('self.poster_size_preset_combo.addItem("ANSI B / Tabloid - 141%", 141)',
     'self.poster_size_preset_combo.addItem("ANSI B / Tabloid - 141%", {"scale": 141, "paper_size": "letter"})'),
    ('self.poster_size_preset_combo.addItem("ANSI C - 200%", 200)',
     'self.poster_size_preset_combo.addItem("ANSI C - 200%", {"scale": 200, "paper_size": "letter"})'),
    ('self.poster_size_preset_combo.addItem("ANSI D - 283%", 283)',
     'self.poster_size_preset_combo.addItem("ANSI D - 283%", {"scale": 283, "paper_size": "letter"})'),
    ('self.poster_size_preset_combo.addItem("ANSI E - 400%", 400)',
     'self.poster_size_preset_combo.addItem("ANSI E - 400%", {"scale": 400, "paper_size": "letter"})'),

    ('self.poster_size_preset_combo.addItem("Arch B - 152%", 152)',
     'self.poster_size_preset_combo.addItem("Arch B - 152%", {"scale": 152, "paper_size": "letter"})'),
    ('self.poster_size_preset_combo.addItem("Arch C - 215%", 215)',
     'self.poster_size_preset_combo.addItem("Arch C - 215%", {"scale": 215, "paper_size": "letter"})'),
    ('self.poster_size_preset_combo.addItem("Arch D - 304%", 304)',
     'self.poster_size_preset_combo.addItem("Arch D - 304%", {"scale": 304, "paper_size": "letter"})'),
    ('self.poster_size_preset_combo.addItem("Arch E - 430%", 430)',
     'self.poster_size_preset_combo.addItem("Arch E - 430%", {"scale": 430, "paper_size": "letter"})'),
]

changed = 0
for old, new in replacements:
    if old in text:
        text = text.replace(old, new, 1)
        changed += 1

print(f"[OK] Preset item data replacements applied: {changed}")

# ------------------------------------------------------------
# 2) Replace on_poster_size_preset_changed
# ------------------------------------------------------------
pattern = re.compile(
    r"^    def on_poster_size_preset_changed\(self\) -> None:\n.*?(?=^    def )",
    re.M | re.S
)

new_func = r'''    def on_poster_size_preset_changed(self) -> None:
        if not hasattr(self, "poster_size_preset_combo"):
            return

        preset_value = self.poster_size_preset_combo.currentData()

        if preset_value is None:
            self.update_poster_sheet_estimate()
            return

        # Backward compatibility: old preset data was just an integer scale.
        if isinstance(preset_value, dict):
            scale_value = int(preset_value.get("scale", 100))
            paper_size = preset_value.get("paper_size")
        else:
            scale_value = int(preset_value)
            paper_size = None

        if paper_size and hasattr(self, "paper_size_combo"):
            self.paper_size_combo.blockSignals(True)
            self._apply_combo_data(self.paper_size_combo, paper_size)
            self.paper_size_combo.blockSignals(False)

        if hasattr(self, "poster_scale_spin"):
            self.poster_scale_spin.blockSignals(True)
            self.poster_scale_spin.setValue(scale_value)
            self.poster_scale_spin.blockSignals(False)

        self.update_poster_sheet_estimate()

'''

if pattern.search(text):
    text = pattern.sub(new_func, text, count=1)
    print("[OK] Replaced on_poster_size_preset_changed")
else:
    print("[ERROR] Could not find on_poster_size_preset_changed")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 3) Replace on_poster_scale_changed to handle dict preset values
# ------------------------------------------------------------
pattern = re.compile(
    r"^    def on_poster_scale_changed\(self\) -> None:\n.*?(?=^    def )",
    re.M | re.S
)

new_func = r'''    def on_poster_scale_changed(self) -> None:
        if hasattr(self, "poster_size_preset_combo"):
            current_preset = self.poster_size_preset_combo.currentData()

            preset_scale = None

            if isinstance(current_preset, dict):
                try:
                    preset_scale = int(current_preset.get("scale"))
                except Exception:
                    preset_scale = None
            elif current_preset is not None:
                try:
                    preset_scale = int(current_preset)
                except Exception:
                    preset_scale = None

            if preset_scale is not None and preset_scale != int(self.poster_scale_spin.value()):
                self.poster_size_preset_combo.blockSignals(True)
                self.poster_size_preset_combo.setCurrentIndex(0)
                self.poster_size_preset_combo.blockSignals(False)

        self.update_poster_sheet_estimate()

'''

if pattern.search(text):
    text = pattern.sub(new_func, text, count=1)
    print("[OK] Replaced on_poster_scale_changed")
else:
    print("[ERROR] Could not find on_poster_scale_changed")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_preset_sets_paper_size_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    '{"scale": 152, "paper_size": "letter"}',
    '{"scale": 400, "paper_size": "a4"}',
    "paper_size = preset_value.get",
    "_apply_combo_data(self.paper_size_combo, paper_size)",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- A-series presets set Output Paper Size to A4")
print("- ANSI/Arch presets set Output Paper Size to US Letter")
print("- Manual / Custom keeps the current paper size")
