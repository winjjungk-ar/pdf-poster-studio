﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

main_backup = MAIN.with_name(f"main_window.py.bak_export_rotation_{timestamp}")
exporter_backup = EXPORTER.with_name(f"poster_exporter.py.bak_export_rotation_{timestamp}")

shutil.copy2(MAIN, main_backup)
shutil.copy2(EXPORTER, exporter_backup)

print(f"[OK] Backup created: {main_backup}")
print(f"[OK] Backup created: {exporter_backup}")

main_text = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace")

# ------------------------------------------------------------
# 1) poster_exporter.py: add page_rotations to ExportOptions
# ------------------------------------------------------------
if "page_rotations: dict[int, int] | None" not in exporter_text:
    old = '''    tile_cols: int | None = None
    tile_rows: int | None = None
    add_numbers: bool = True
'''
    new = '''    tile_cols: int | None = None
    tile_rows: int | None = None
    page_rotations: dict[int, int] | None = None
    add_numbers: bool = True
'''
    if old in exporter_text:
        exporter_text = exporter_text.replace(old, new, 1)
        print("[OK] Added page_rotations to ExportOptions")
    else:
        print("[ERROR] Could not add page_rotations to ExportOptions")
        sys.exit(1)
else:
    print("[SKIP] ExportOptions already has page_rotations")

# ------------------------------------------------------------
# 2) poster_exporter.py: add helper to read page rotation
# ------------------------------------------------------------
if "def _get_page_rotation" not in exporter_text:
    marker = "    def _selection_to_rect(self, selection: SelectionRect) -> fitz.Rect:\n"
    helper = r'''    def _get_page_rotation(self, page_index: int, options: ExportOptions) -> int:
        try:
            rotations = getattr(options, "page_rotations", None) or {}
            return int(rotations.get(page_index, 0)) % 360
        except Exception:
            return 0

'''
    if marker in exporter_text:
        exporter_text = exporter_text.replace(marker, helper + marker, 1)
        print("[OK] Added _get_page_rotation helper")
    else:
        print("[ERROR] Could not find _selection_to_rect marker")
        sys.exit(1)
else:
    print("[SKIP] _get_page_rotation already exists")

# ------------------------------------------------------------
# 3) poster_exporter.py: apply rotate=... to show_pdf_page calls
# ------------------------------------------------------------

# Legacy 2-sheet poster print show_pdf_page
old = '''                page.show_pdf_page(
                    target_rect,
                    src_doc,
                    page_index,
                    clip=tile_clip,
                    keep_proportion=False,
                )
'''
new = '''                page.show_pdf_page(
                    target_rect,
                    src_doc,
                    page_index,
                    clip=tile_clip,
                    rotate=self._get_page_rotation(page_index, options),
                    keep_proportion=False,
                )
'''
if old in exporter_text:
    exporter_text = exporter_text.replace(old, new, 1)
    print("[OK] Applied rotation to legacy poster split export")
else:
    print("[SKIP] Legacy poster show_pdf_page block already patched or not found")

# Single Page export show_pdf_page
old = '''            page.show_pdf_page(
                target_rect,
                src_doc,
                page_index,
                clip=source_clip,
                keep_proportion=True,
            )
'''
new = '''            page.show_pdf_page(
                target_rect,
                src_doc,
                page_index,
                clip=source_clip,
                rotate=self._get_page_rotation(page_index, options),
                keep_proportion=True,
            )
'''
if old in exporter_text:
    exporter_text = exporter_text.replace(old, new, 1)
    print("[OK] Applied rotation to Single Page export")
else:
    print("[SKIP] Single Page show_pdf_page block already patched or not found")

# Poster tiling export show_pdf_page
old = '''            page.show_pdf_page(
                tile["target_rect"],
                src_doc,
                page_index,
                clip=tile["clip"],
                keep_proportion=False,
            )
'''
new = '''            page.show_pdf_page(
                tile["target_rect"],
                src_doc,
                page_index,
                clip=tile["clip"],
                rotate=self._get_page_rotation(page_index, options),
                keep_proportion=False,
            )
'''
if old in exporter_text:
    exporter_text = exporter_text.replace(old, new, 1)
    print("[OK] Applied rotation to poster tiling export")
else:
    print("[SKIP] Poster tiling show_pdf_page block already patched or not found")

EXPORTER.write_text(exporter_text, encoding="utf-8")

# ------------------------------------------------------------
# 4) main_window.py: pass page_rotations into ExportOptions
# ------------------------------------------------------------
old = '''            tile_cols=self._get_fixed_a_series_tile_grid()[0] if hasattr(self, "_get_fixed_a_series_tile_grid") else None,
            tile_rows=self._get_fixed_a_series_tile_grid()[1] if hasattr(self, "_get_fixed_a_series_tile_grid") else None,
        )
'''
new = '''            tile_cols=self._get_fixed_a_series_tile_grid()[0] if hasattr(self, "_get_fixed_a_series_tile_grid") else None,
            tile_rows=self._get_fixed_a_series_tile_grid()[1] if hasattr(self, "_get_fixed_a_series_tile_grid") else None,
            page_rotations=dict(getattr(self, "page_rotations", {})),
        )
'''

count = main_text.count(old)
if count:
    main_text = main_text.replace(old, new)
    print(f"[OK] Added page_rotations to ExportOptions in {count} place(s)")
else:
    if "page_rotations=dict(getattr(self, \"page_rotations\", {}))" in main_text:
        print("[SKIP] main_window ExportOptions already passes page_rotations")
    else:
        print("[WARN] Could not find ExportOptions block in main_window.py")

# ------------------------------------------------------------
# 5) main_window.py: workspace exports must use each source item's rotations
# ------------------------------------------------------------
# Before each exporter.export inside workspace loops, set options.page_rotations to item rotations.
old = '''            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(page_output),
                selections=converted,
                options=options,
            )
'''
new = '''            options.page_rotations = dict(item.get("page_rotations", {}))

            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(page_output),
                selections=converted,
                options=options,
            )
'''
if old in main_text and "options.page_rotations = dict(item.get(\"page_rotations\", {}))" not in main_text:
    main_text = main_text.replace(old, new, 1)
    print("[OK] Workspace separate export now applies item page rotations")
else:
    print("[SKIP] Workspace separate export rotation already patched or block not found")

old = '''            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(part_path),
                selections=converted,
                options=options,
            )
'''
new = '''            options.page_rotations = dict(item.get("page_rotations", {}))

            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(part_path),
                selections=converted,
                options=options,
            )
'''
if old in main_text:
    main_text = main_text.replace(old, new, 1)
    print("[OK] Workspace one-PDF temporary export now applies item page rotations")
else:
    print("[SKIP] Workspace one-PDF export rotation block not found or already patched")

# ------------------------------------------------------------
# 6) Release notes
# ------------------------------------------------------------
if "Export respects page rotation" not in main_text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Export respects page rotation</b>: Rotated pages are now exported with the same rotation shown in Preview and Print Order.</li>
</ul>
<hr>
"""
    if anchor in main_text:
        main_text = main_text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 7) Compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup in [
    (MAIN, main_backup),
    (EXPORTER, exporter_backup),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_export_rotation_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 8) Verify markers
# ------------------------------------------------------------
main_new = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_new = EXPORTER.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker, source in [
    ("page_rotations: dict[int, int] | None", exporter_new),
    ("def _get_page_rotation", exporter_new),
    ("rotate=self._get_page_rotation(page_index, options)", exporter_new),
    ("page_rotations=dict(getattr(self, \"page_rotations\", {}))", main_new),
    ("Export respects page rotation", main_new),
]:
    print(f"  - {marker}: {marker in source}")

print("")
print("Done.")
print("- Export now applies page-specific rotation")
print("- Rotated Preview / Print Order should match exported PDF")
print("- If testing EXE, rebuild EXE first")
