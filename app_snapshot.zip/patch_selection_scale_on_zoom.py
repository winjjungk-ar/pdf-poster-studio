﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_selection_scale_fix_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            targets.append(node)

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno

    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

def insert_before_function(source: str, func_name: str, code: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            targets.append(node)

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1

    return "".join(lines[:start]) + code + "\n" + "".join(lines[start:])

# ------------------------------------------------------------
# 1) Add selection display size state in __init__
# ------------------------------------------------------------
old = '''        self.page_selections: dict[int, QRect] = {}
        self.checked_pages: set[int] = set()
        self._updating_page_list = False
'''

new = '''        self.page_selections: dict[int, QRect] = {}
        # Stores the preview display size used when each selection QRect was saved.
        # This keeps selections stable when zoom changes.
        self.page_selection_display_sizes: dict[int, tuple[int, int]] = {}
        self.checked_pages: set[int] = set()
        self._updating_page_list = False
'''

if old in text and "page_selection_display_sizes" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added page_selection_display_sizes state")
elif "page_selection_display_sizes" in text:
    print("[SKIP] page_selection_display_sizes already exists")
else:
    print("[WARN] Could not find page_selections init block")

# ------------------------------------------------------------
# 2) Add helpers before _save_current_selection
# ------------------------------------------------------------
helpers = r'''
    def _get_preview_display_size_tuple(self) -> tuple[int, int]:
        pixmap = None

        try:
            pixmap = getattr(self.preview_label, "preview_pixmap", None)
        except Exception:
            pixmap = None

        if pixmap is None:
            try:
                pixmap = self.preview_label.pixmap()
            except Exception:
                pixmap = None

        if pixmap is not None and hasattr(pixmap, "isNull") and not pixmap.isNull():
            return max(1, pixmap.width()), max(1, pixmap.height())

        return (
            max(1, int(getattr(self, "current_display_base_width", 1))),
            max(1, int(getattr(self, "current_display_base_height", 1))),
        )

    def _remember_selection_display_size(self, page_index: int) -> None:
        if page_index < 0:
            return

        self.page_selection_display_sizes[page_index] = self._get_preview_display_size_tuple()

    def _scale_selection_rect_to_current_display(self, page_index: int, rect: QRect) -> QRect:
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            return QRect()

        old_size = self.page_selection_display_sizes.get(page_index)

        if not old_size:
            return QRect(rect)

        old_w, old_h = old_size
        new_w, new_h = self._get_preview_display_size_tuple()

        old_w = max(1, int(old_w))
        old_h = max(1, int(old_h))
        new_w = max(1, int(new_w))
        new_h = max(1, int(new_h))

        if old_w == new_w and old_h == new_h:
            return QRect(rect)

        sx = new_w / old_w
        sy = new_h / old_h

        return QRect(
            int(round(rect.x() * sx)),
            int(round(rect.y() * sy)),
            max(1, int(round(rect.width() * sx))),
            max(1, int(round(rect.height() * sy))),
        )

'''

if "def _get_preview_display_size_tuple" not in text:
    try:
        text = insert_before_function(text, "_save_current_selection", helpers)
        print("[OK] Added selection scaling helpers")
    except Exception as exc:
        print(f"[ERROR] Could not insert selection helpers: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Selection scaling helpers already exist")

# ------------------------------------------------------------
# 3) Replace _save_current_selection
# ------------------------------------------------------------
new_save_current_selection = r'''    def _save_current_selection(self) -> None:
        if self.page_count <= 0:
            return

        rect = self.preview_label.get_selection_rect()

        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            self.page_selections.pop(self.current_page_index, None)
            self.page_selection_display_sizes.pop(self.current_page_index, None)
            return

        self.page_selections[self.current_page_index] = QRect(rect)
        self._remember_selection_display_size(self.current_page_index)
'''

try:
    text = replace_function(text, "_save_current_selection", new_save_current_selection)
    print("[OK] Replaced _save_current_selection")
except Exception as exc:
    print(f"[ERROR] Could not replace _save_current_selection: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 4) Replace _restore_current_selection
# ------------------------------------------------------------
new_restore_current_selection = r'''    def _restore_current_selection(self) -> None:
        rect = self.page_selections.get(self.current_page_index, QRect())
        scaled_rect = self._scale_selection_rect_to_current_display(self.current_page_index, rect)

        # After scaling, update the stored rect and its display size to the current preview.
        if not scaled_rect.isNull() and scaled_rect.width() > 0 and scaled_rect.height() > 0:
            self.page_selections[self.current_page_index] = QRect(scaled_rect)
            self._remember_selection_display_size(self.current_page_index)

        self.preview_label.set_selection_rect(scaled_rect)
        self._update_selection_info(scaled_rect)
'''

try:
    text = replace_function(text, "_restore_current_selection", new_restore_current_selection)
    print("[OK] Replaced _restore_current_selection")
except Exception as exc:
    print(f"[ERROR] Could not replace _restore_current_selection: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 5) Clear display sizes where selections are cleared
# ------------------------------------------------------------
text = text.replace(
    "self.page_selections.clear()\n        self.checked_pages.clear()",
    "self.page_selections.clear()\n        self.page_selection_display_sizes.clear()\n        self.checked_pages.clear()"
)

text = text.replace(
    "self.page_selections.clear()\n            self.checked_pages.clear()",
    "self.page_selections.clear()\n            self.page_selection_display_sizes.clear()\n            self.checked_pages.clear()"
)

# Selection pop should also remove display size where practical.
text = text.replace(
    "self.page_selections.pop(self.current_page_index, None)\n                self.checked_pages.discard(self.current_page_index)",
    "self.page_selections.pop(self.current_page_index, None)\n                self.page_selection_display_sizes.pop(self.current_page_index, None)\n                self.checked_pages.discard(self.current_page_index)"
)

text = text.replace(
    "self.page_selections.pop(self.current_page_index, None)\n            self.checked_pages.discard(self.current_page_index)",
    "self.page_selections.pop(self.current_page_index, None)\n            self.page_selection_display_sizes.pop(self.current_page_index, None)\n            self.checked_pages.discard(self.current_page_index)"
)

text = text.replace(
    "self.page_selections.pop(page_index, None)\n                    self.checked_pages.discard(page_index)",
    "self.page_selections.pop(page_index, None)\n                    self.page_selection_display_sizes.pop(page_index, None)\n                    self.checked_pages.discard(page_index)"
)

# ------------------------------------------------------------
# 6) Remember display size after direct assignments of page_selections
# ------------------------------------------------------------
# Current page assignment
text = text.replace(
    "self.page_selections[self.current_page_index] = QRect(rect)\n                self.checked_pages.add(self.current_page_index)",
    "self.page_selections[self.current_page_index] = QRect(rect)\n                self._remember_selection_display_size(self.current_page_index)\n                self.checked_pages.add(self.current_page_index)"
)

# Generic page_index assignment
text = text.replace(
    "self.page_selections[page_index] = QRect(rect)\n                self.checked_pages.add(page_index)",
    "self.page_selections[page_index] = QRect(rect)\n                self._remember_selection_display_size(page_index)\n                self.checked_pages.add(page_index)"
)

text = text.replace(
    "self.page_selections[page_index] = QRect(rect)\n            self.checked_pages.add(page_index)",
    "self.page_selections[page_index] = QRect(rect)\n            self._remember_selection_display_size(page_index)\n            self.checked_pages.add(page_index)"
)

# apply_selection_to_all_pages: same current display rect applied to all pages.
text = text.replace(
    "self.page_selections[page_index] = QRect(rect)\n            self.checked_pages.add(page_index)",
    "self.page_selections[page_index] = QRect(rect)\n            self._remember_selection_display_size(page_index)\n            self.checked_pages.add(page_index)"
)

# ------------------------------------------------------------
# 7) Project load: initialize display sizes for restored selections to current display after render
#    This is a best-effort fallback.
# ------------------------------------------------------------
# No project schema change for now.

# ------------------------------------------------------------
# 8) Release Notes update
# ------------------------------------------------------------
if "Selection scaling on zoom" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Selection scaling on zoom</b>: Selected areas now stay aligned when preview zoom changes.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for selection scaling")

# ------------------------------------------------------------
# 9) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_selection_scale_fix_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "page_selection_display_sizes",
    "def _scale_selection_rect_to_current_display",
    "Selection scaling on zoom",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Selection rectangles are now scaled when preview zoom/display size changes")
print("- Auto-selected areas should stay aligned after mouse wheel zoom")
