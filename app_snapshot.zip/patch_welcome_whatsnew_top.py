﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_welcome_whatsnew_top_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

try:
    tree = ast.parse(text)
except SyntaxError as exc:
    print(f"[ERROR] Syntax error before patch: {exc}")
    sys.exit(1)

lines = text.splitlines(True)

target = None
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef) and node.name == "_show_welcome_dialog":
        target = node
        break

if target is None:
    print("[ERROR] _show_welcome_dialog not found")
    sys.exit(1)

start = target.lineno - 1
end = target.end_lineno
func_text = "".join(lines[start:end])

old_steps = '''        steps = QLabel(
            "New work:\\n"
            "1. Open one or more source PDF files.\\n"
            "2. Select an area manually or use Auto Select.\\n"
            "3. Build Print Order and choose Output Files.\\n"
            "4. Create Poster PDF for tiled prints, or Single Page PDF for clean page output.\\n\\n"
            "Examples:\\n"
            "• Game maps and wall posters\\n"
            "• TRPG / board game maps\\n"
            "• Engineering drawings and field work packages\\n\\n"
            "What's new in 0.9.1:\\n"
            "• Poster presets for A-series, ANSI, Arch, and hobby posters\\n"
            "• Tiling Preview for poster layouts\\n"
            "• One PDF or Separate PDF output modes\\n\\n"
            "Existing work:\\n"
            "• Open Project to continue a saved workspace."
        )
'''

new_steps = '''        steps = QLabel(
            "What's new in 0.9.1:\\n"
            "• Poster presets for A-series, ANSI, Arch, and hobby posters\\n"
            "• Tiling Preview for poster layouts\\n"
            "• One PDF or Separate PDF output modes\\n\\n"
            "New work:\\n"
            "1. Open one or more source PDF files.\\n"
            "2. Select an area manually or use Auto Select.\\n"
            "3. Build Print Order and choose Output Files.\\n"
            "4. Create Poster PDF for tiled prints, or Single Page PDF for clean page output.\\n\\n"
            "Examples:\\n"
            "• Game maps and wall posters\\n"
            "• TRPG / board game maps\\n"
            "• Engineering drawings and field work packages\\n\\n"
            "Existing work:\\n"
            "• Open Project to continue a saved workspace."
        )
'''

if old_steps in func_text:
    func_text = func_text.replace(old_steps, new_steps, 1)
    lines[start:end] = [func_text]
    text = "".join(lines)
    MAIN.write_text(text, encoding="utf-8")
    print("[OK] Moved What's new section to top of welcome popup")
else:
    print("[WARN] Exact welcome steps block not found. Trying fallback text rearrange.")

    # fallback: if both blocks exist, rebuild by string operations inside function
    if "What's new in 0.9.1:" in func_text and "New work:" in func_text:
        # Avoid risky partial parse; just report.
        print("[WARN] Could not safely rearrange fallback. Please paste _show_welcome_dialog block if needed.")
    else:
        print("[WARN] What's new or New work text not found in welcome function")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_welcome_whatsnew_top_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- What's new in 0.9.1 is now shown first in the welcome popup")
