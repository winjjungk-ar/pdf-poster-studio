﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_welcome_newlines_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

try:
    tree = ast.parse(text)
except SyntaxError as exc:
    print(f"[ERROR] Syntax error before patch: {exc}")
    sys.exit(1)

lines = text.splitlines(True)

target = None
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef) and node.name == "_show_welcome_dialog":
        target = node
        break

if target is None:
    print("[ERROR] _show_welcome_dialog not found")
    sys.exit(1)

start = target.lineno - 1
end = target.end_lineno

func_text = "".join(lines[start:end])

before_count = func_text.count("\\\\n")
print(f"[INFO] Literal \\\\n count in _show_welcome_dialog: {before_count}")

if before_count == 0:
    print("[SKIP] No literal \\\\n found in welcome dialog")
else:
    # In Python source:
    # "\\\\n" means two backslashes + n in the source, which displays as literal \n.
    # "\\n" means newline escape in the string, which displays as actual line break.
    func_text = func_text.replace("\\\\n", "\\n")
    lines[start:end] = [func_text]
    text = "".join(lines)

    MAIN.write_text(text, encoding="utf-8")
    print("[OK] Fixed welcome dialog newline escapes")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_welcome_newlines_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

try:
    ast.parse(new_text)
except SyntaxError as exc:
    print(f"[ERROR] AST failed after patch: {exc}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Welcome popup line breaks fixed")
print("- Run: python main.py")
