﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_export_order_methods_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

methods = r'''
    def _export_order_item_text(self, workspace_index: int, page_index: int) -> str:
        item = self.workspace_items[workspace_index]
        pdf_name = Path(item.get("pdf_path", "")).name
        return f"{pdf_name}  -  Page {page_index + 1}"

    def _add_export_order_item(self, workspace_index: int, page_index: int) -> None:
        if not hasattr(self, "export_order_list"):
            return

        list_item = QListWidgetItem(self._export_order_item_text(workspace_index, page_index))
        list_item.setData(
            Qt.ItemDataRole.UserRole,
            {
                "workspace_index": workspace_index,
                "page_index": page_index,
            }
        )

        pdf_path = self.workspace_items[workspace_index].get("pdf_path", "")
        list_item.setToolTip(f"{pdf_path}\nPage {page_index + 1}")
        self.export_order_list.addItem(list_item)

    def refresh_export_order_from_checked_pages(self) -> None:
        if not hasattr(self, "export_order_list"):
            return

        if not hasattr(self, "workspace_items") or not self.workspace_items:
            QMessageBox.information(self, "Export Order", "Workspace is empty.")
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        self.export_order_list.clear()

        for workspace_index, item in enumerate(self.workspace_items):
            checked_pages = sorted(list(item.get("checked_pages", set())))

            for page_index in checked_pages:
                self._add_export_order_item(workspace_index, page_index)

        if self.export_order_list.count() <= 0:
            QMessageBox.information(
                self,
                "Export Order",
                "No checked pages found.\n\nSelect areas on pages first."
            )
            return

        self._log(f"Export order refreshed: {self.export_order_list.count()} pages")

    def _move_export_order_row(self, source_row: int, target_row: int) -> None:
        if not hasattr(self, "export_order_list"):
            return

        count = self.export_order_list.count()

        if source_row < 0 or source_row >= count:
            return

        if target_row < 0 or target_row >= count:
            return

        item = self.export_order_list.takeItem(source_row)
        self.export_order_list.insertItem(target_row, item)
        self.export_order_list.setCurrentRow(target_row)

    def move_export_order_item_up(self) -> None:
        if not hasattr(self, "export_order_list"):
            return

        row = self.export_order_list.currentRow()

        if row <= 0:
            return

        self._move_export_order_row(row, row - 1)

    def move_export_order_item_down(self) -> None:
        if not hasattr(self, "export_order_list"):
            return

        row = self.export_order_list.currentRow()

        if row < 0 or row >= self.export_order_list.count() - 1:
            return

        self._move_export_order_row(row, row + 1)

    def _get_export_order_entries(self) -> list[tuple[int, int]]:
        entries: list[tuple[int, int]] = []

        if not hasattr(self, "export_order_list"):
            return entries

        for row in range(self.export_order_list.count()):
            item = self.export_order_list.item(row)
            data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(data, dict):
                continue

            try:
                workspace_index = int(data.get("workspace_index"))
                page_index = int(data.get("page_index"))
            except Exception:
                continue

            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                continue

            entries.append((workspace_index, page_index))

        return entries

'''

if "def refresh_export_order_from_checked_pages" in text:
    print("[SKIP] Export Order methods already exist")
else:
    # Put methods before workspace export method if present, otherwise before _open_pdf_path.
    markers = [
        "    def _export_workspace_to_pdf(self, output_path: str, options: ExportOptions) -> None:\n",
        "    def _open_pdf_path(self, file_path: str, clear_selections: bool = True) -> None:\n",
    ]

    inserted = False

    for marker in markers:
        pos = text.find(marker)
        if pos != -1:
            text = text[:pos] + methods + "\n" + text[pos:]
            inserted = True
            print(f"[OK] Inserted Export Order methods before: {marker.strip()}")
            break

    if not inserted:
        print("[ERROR] Could not find insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_export_order_methods_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

# Runtime attribute smoke check without launching full QApplication is hard for QWidget,
# so do a source-level method check.
new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "def refresh_export_order_from_checked_pages",
    "def move_export_order_item_up",
    "def move_export_order_item_down",
    "def _get_export_order_entries",
]

missing = [name for name in required if name not in new_text]

if missing:
    print("[ERROR] Missing methods after patch:")
    for name in missing:
        print(f"  - {name}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("[OK] Export Order methods exist")
print("")
print("Done. Now run: python main.py")
