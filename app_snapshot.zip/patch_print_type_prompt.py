﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_print_type_prompt_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# Patch print_pdf to ask export/print mode
# ------------------------------------------------------------
old = '''    def print_pdf(self) -> None:
        self._log("Print selected.")

        if not self.current_pdf_path:
            QMessageBox.information(
                self,
                "Print",
                "Please open a PDF first."
            )
            return

        try:
'''

new = '''    def print_pdf(self) -> None:
        self._log("Print selected.")

        if not self.current_pdf_path:
            QMessageBox.information(
                self,
                "Print",
                "Please open a PDF first."
            )
            return

        if not self._prompt_export_type():
            return

        try:
'''

if old in text and "if not self._prompt_export_type():" not in text[text.find("def print_pdf"):]:
    text = text.replace(old, new, 1)
    print("[OK] Added print mode prompt")
else:
    print("[SKIP] Print mode prompt already present or target block not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_print_type_prompt_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Print now asks A3 Split Mode / Selection Only Mode before creating temporary print PDF")
