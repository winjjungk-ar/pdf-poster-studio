﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_auto_select_page_range_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Import QInputDialog
# ------------------------------------------------------------
if "QInputDialog" not in text:
    if "    QProgressDialog,\n" in text:
        text = text.replace(
            "    QProgressDialog,\n",
            "    QProgressDialog,\n    QInputDialog,\n",
            1
        )
        print("[OK] Added QInputDialog import")
    elif "    QMessageBox,\n" in text:
        text = text.replace(
            "    QMessageBox,\n",
            "    QMessageBox,\n    QInputDialog,\n",
            1
        )
        print("[OK] Added QInputDialog import by fallback")
    else:
        print("[WARN] Could not find import anchor for QInputDialog")
else:
    print("[SKIP] QInputDialog already imported")

# ------------------------------------------------------------
# Helper functions
# ------------------------------------------------------------
def insert_before_function(source: str, func_name: str, code: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    return "".join(lines[:start]) + code + "\n" + "".join(lines[start:])

# ------------------------------------------------------------
# 2) Add toolbar action after Auto Select All Pages
# ------------------------------------------------------------
old = '''        self.auto_all_action = QAction("Auto Select All Pages", self)
        self.auto_all_action.triggered.connect(self.auto_select_all_pages)
        self.auto_all_action.setObjectName("autoSelectAllPagesAction")
        toolbar.addAction(self.auto_all_action)

        auto_all_button = toolbar.widgetForAction(self.auto_all_action)
'''

new = '''        self.auto_all_action = QAction("Auto Select All Pages", self)
        self.auto_all_action.triggered.connect(self.auto_select_all_pages)
        self.auto_all_action.setObjectName("autoSelectAllPagesAction")
        toolbar.addAction(self.auto_all_action)

        self.auto_range_action = QAction("Auto Select Page Range", self)
        self.auto_range_action.triggered.connect(self.auto_select_page_range)
        toolbar.addAction(self.auto_range_action)

        auto_all_button = toolbar.widgetForAction(self.auto_all_action)
'''

if old in text and "self.auto_range_action" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Auto Select Page Range toolbar action")
elif "self.auto_range_action" in text:
    print("[SKIP] Auto Select Page Range action already exists")
else:
    print("[WARN] Could not find toolbar Auto Select All block")

# ------------------------------------------------------------
# 3) Add parse + range auto select methods
# ------------------------------------------------------------
methods = r'''
    def _parse_page_range_text(self, range_text: str, page_count: int) -> list[int]:
        text = (range_text or "").strip().lower()

        if text in ("", "all", "*"):
            return list(range(page_count))

        result: list[int] = []

        for part in text.split(","):
            part = part.strip()

            if not part:
                continue

            if "-" in part:
                start_text, end_text = part.split("-", 1)
                start_page = int(start_text.strip())
                end_page = int(end_text.strip())

                if start_page <= 0 or end_page <= 0:
                    raise ValueError("Page numbers must be greater than zero.")

                if start_page > end_page:
                    raise ValueError(f"Invalid page range: {part}")

                for page_no in range(start_page, end_page + 1):
                    if page_no > page_count:
                        raise ValueError(f"Page {page_no} is out of range. Total pages: {page_count}")
                    page_index = page_no - 1
                    if page_index not in result:
                        result.append(page_index)
            else:
                page_no = int(part)

                if page_no <= 0:
                    raise ValueError("Page numbers must be greater than zero.")

                if page_no > page_count:
                    raise ValueError(f"Page {page_no} is out of range. Total pages: {page_count}")

                page_index = page_no - 1
                if page_index not in result:
                    result.append(page_index)

        if not result:
            raise ValueError("No valid pages were specified.")

        return result

    def auto_select_page_range(self) -> None:
        if self._is_whole_page_output_area():
            QMessageBox.information(
                self,
                "Auto Select Page Range",
                "Auto Select is only needed when Output Area is Selected Area."
            )
            return

        if not self.current_pdf_path or self.page_count <= 0:
            QMessageBox.information(
                self,
                "Auto Select Page Range",
                "Please open a PDF or image first."
            )
            return

        range_text, ok = QInputDialog.getText(
            self,
            "Auto Select Page Range",
            "Enter page range to auto select:\n"
            "Examples: all, 1-50, 1,3,5, 10-20,35",
            text="1-50" if self.page_count >= 50 else "all",
        )

        if not ok:
            return

        try:
            page_indices = self._parse_page_range_text(range_text, self.page_count)
        except Exception as exc:
            QMessageBox.warning(
                self,
                "Invalid Page Range",
                str(exc)
            )
            return

        if not page_indices:
            return

        if len(page_indices) >= 200:
            result = QMessageBox.question(
                self,
                "Large Page Range",
                f"You selected {len(page_indices)} pages.\n\n"
                "Auto Select may take several minutes.\n"
                "You can cancel during processing.\n\n"
                "Continue?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result != QMessageBox.StandardButton.Yes:
                return

        threshold = self._get_auto_select_threshold()
        selected_count = 0
        original_page_index = self.current_page_index

        progress = QProgressDialog(
            "Preparing auto selection...",
            "Cancel",
            0,
            len(page_indices),
            self,
        )
        progress.setWindowTitle("Auto Select Page Range")
        progress.setWindowModality(Qt.WindowModality.ApplicationModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        progress.show()
        QApplication.processEvents()

        try:
            for position, page_index in enumerate(page_indices):
                progress.setValue(position)
                progress.setLabelText(
                    f"Auto selecting page {page_index + 1} / {self.page_count}"
                )
                QApplication.processEvents()

                if progress.wasCanceled():
                    break

                try:
                    self.current_page_index = page_index
                    self._render_current_page()
                    QApplication.processEvents()

                    rect = self.preview_label.auto_select_content(threshold=threshold, padding=8)

                    if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                        self.page_selections.pop(page_index, None)
                        self.checked_pages.discard(page_index)
                        continue

                    self.page_selections[page_index] = QRect(rect)
                    self.checked_pages.add(page_index)
                    selected_count += 1

                except Exception as exc:
                    self._log(f"Auto Select Page Range failed on page {page_index + 1}: {exc}")

            progress.setValue(len(page_indices))
            QApplication.processEvents()

        finally:
            progress.close()

            self.current_page_index = max(0, min(original_page_index, self.page_count - 1))
            self._render_current_page()
            self._refresh_page_list_all_text()
            self._refresh_current_page_check_state()
            self._update_checked_pages_label()

            if hasattr(self, "export_order_list"):
                self.export_order_list.clear()

        self.is_modified = True

        QMessageBox.information(
            self,
            "Auto Select Page Range",
            f"Auto selection completed.\n\n"
            f"Selected pages: {selected_count}/{len(page_indices)}"
        )

        self._log(
            f"Auto Select Page Range completed: selected={selected_count}/{len(page_indices)}, "
            f"range={range_text}"
        )

'''

if "def auto_select_page_range" not in text:
    try:
        text = insert_before_function(text, "auto_select_all_pages", methods)
        print("[OK] Added Auto Select Page Range methods")
    except Exception as exc:
        print(f"[ERROR] Could not insert Auto Select Page Range methods: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Auto Select Page Range methods already exist")

# ------------------------------------------------------------
# 4) Update output area state function to enable/disable range action
# ------------------------------------------------------------
old = '''        if hasattr(self, "auto_all_action"):
            self.auto_all_action.setEnabled(is_selected_area)
            self.auto_all_action.setToolTip(enabled_tip_all if is_selected_area else disabled_tip)
'''

new = '''        if hasattr(self, "auto_all_action"):
            self.auto_all_action.setEnabled(is_selected_area)
            self.auto_all_action.setToolTip(enabled_tip_all if is_selected_area else disabled_tip)

        if hasattr(self, "auto_range_action"):
            self.auto_range_action.setEnabled(is_selected_area)
            self.auto_range_action.setToolTip(
                "Automatically detect content areas for a specific page range."
                if is_selected_area else disabled_tip
            )
'''

if old in text and "auto_range_action" not in text[text.find("def update_output_area_states"):text.find("def update_export_option_states")]:
    text = text.replace(old, new, 1)
    print("[OK] update_output_area_states now controls Auto Select Page Range")
else:
    print("[SKIP] update_output_area_states already handles range action or anchor not found")

# ------------------------------------------------------------
# 5) Release Notes / Welcome
# ------------------------------------------------------------
if "Auto Select Page Range" not in text[text.find("<h2>PDF Poster Studio - Release Notes</h2>"):]:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Auto Select Page Range</b>: Auto-select only a specific range of pages, such as 1-50 or 10-20,35.</li>
  <li>Useful for very large PDFs where processing all pages would take too long.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for Auto Select Page Range")

# Version bump to 0.9.6
for old_version in ["0.9.5", "0.9.4", "0.9.3"]:
    text = text.replace(f"Version: {old_version}", "Version: 0.9.6")
    text = text.replace(f'"version": "{old_version}"', '"version": "0.9.6"')
    text = text.replace(f"What's new in {old_version}", "What's new in 0.9.6")
    text = text.replace(f"Version {old_version}", "Version 0.9.6")

if "Auto Select Page Range for large PDFs" not in text:
    marker = "• See Help > Release Notes for details"
    addition = "• Auto Select Page Range for large PDFs\\n"
    if marker in text:
        text = text.replace(marker, addition + marker, 1)

# ------------------------------------------------------------
# 6) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_auto_select_page_range_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Auto Select Page Range",
    "def _parse_page_range_text",
    "def auto_select_page_range",
    "self.auto_range_action",
    "Version: 0.9.6",
    '"version": "0.9.6"',
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Auto Select Page Range added")
print("- Useful for very large PDFs")
print("- Version bumped to 0.9.6")
