﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_task_launcher_welcome_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

new_welcome = r'''    def _show_welcome_dialog(self) -> None:
        if hasattr(self, "workspace_items") and self.workspace_items:
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Welcome to PDF Poster Studio")
        dialog.setModal(True)
        dialog.setMinimumWidth(720)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(26, 24, 26, 24)
        layout.setSpacing(14)

        dialog.setStyleSheet("""
            QDialog {
                background-color: #FFF8F0;
            }
            QLabel#welcomeTitle {
                color: #395B64;
                font-size: 24px;
                font-weight: 900;
            }
            QLabel#welcomeSubtitle {
                color: #4F6F8F;
                font-size: 13px;
            }
            QPushButton.taskCard {
                color: #395B64;
                background-color: #EAF7F7;
                border: 1px solid #BFE8E8;
                border-radius: 12px;
                padding: 14px 12px;
                font-size: 15px;
                font-weight: 800;
                text-align: left;
                min-height: 70px;
            }
            QPushButton.taskCard:hover {
                background-color: #DDF3F5;
                border: 1px solid #9EDDE2;
            }
            QPushButton.taskCard:pressed {
                background-color: #CDECEF;
            }
            QPushButton.bottomButton {
                color: #395B64;
                background-color: #F6E7CB;
                border: 1px solid #E4CFA8;
                border-radius: 8px;
                padding: 9px 16px;
                font-weight: 700;
            }
            QPushButton.bottomButton:hover {
                background-color: #EFDDBA;
            }
        """)

        title = QLabel("PDF Poster Studio")
        title.setObjectName("welcomeTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel(
            "Print large maps, posters, game boards, and engineering drawings from PDF or image files."
        )
        subtitle.setObjectName("welcomeSubtitle")
        subtitle.setWordWrap(True)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        prompt = QLabel("What do you want to do?")
        prompt.setStyleSheet("font-size: 16px; font-weight: 800; color: #395B64;")
        prompt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(prompt)

        grid = QGridLayout()
        grid.setSpacing(10)

        def add_task_button(row: int, col: int, text: str, callback) -> None:
            button = QPushButton(text)
            button.setProperty("class", "taskCard")
            button.clicked.connect(lambda: run_task(callback))
            grid.addWidget(button, row, col)

        def run_task(callback) -> None:
            dialog.accept()
            callback()

        add_task_button(
            0,
            0,
            "🖼  Make Poster\nTile maps, posters, images, or drawings",
            self.task_make_poster,
        )
        add_task_button(
            0,
            1,
            "🧩  Merge PDFs\nCombine full pages into one PDF",
            self.task_merge_pdfs,
        )
        add_task_button(
            1,
            0,
            "📄  Extract Pages\nPick page ranges and export them",
            self.task_extract_pages,
        )
        add_task_button(
            1,
            1,
            "✂  Selected Area PDF\nExport only the area you select",
            self.task_selected_area_pdf,
        )
        add_task_button(
            2,
            0,
            "🔄  Rotate Pages\nRotate pages and save a new PDF",
            self.task_rotate_pages,
        )
        add_task_button(
            2,
            1,
            "📂  Open Project\nContinue a saved workspace",
            self.open_project,
        )

        layout.addLayout(grid)

        bottom_layout = QHBoxLayout()
        bottom_layout.addStretch()

        open_files_button = QPushButton("Open PDFs / Images")
        open_files_button.setProperty("class", "bottomButton")
        open_files_button.clicked.connect(lambda: run_task(self.open_pdfs))

        continue_button = QPushButton("Continue")
        continue_button.setProperty("class", "bottomButton")
        continue_button.clicked.connect(dialog.reject)

        bottom_layout.addWidget(open_files_button)
        bottom_layout.addWidget(continue_button)
        bottom_layout.addStretch()

        layout.addLayout(bottom_layout)

        note = QLabel("Tip: You can also use the Home tab later to switch workflows.")
        note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        note.setStyleSheet("color: #7A8D96; font-size: 12px;")
        layout.addWidget(note)

        dialog.exec()

'''

try:
    text = replace_function(text, "_show_welcome_dialog", new_welcome)
    print("[OK] Replaced welcome popup with task launcher")
except Exception as exc:
    print(f"[ERROR] Failed to replace _show_welcome_dialog: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Release Notes
if "Task Launcher welcome screen" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Task Launcher welcome screen</b>: The startup popup now shows large workflow cards for Make Poster, Merge PDFs, Extract Pages, Rotate Pages, Selected Area PDF, and Open Project.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_task_launcher_welcome_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "What do you want to do?",
    "Make Poster",
    "Merge PDFs",
    "Extract Pages",
    "Selected Area PDF",
    "Rotate Pages",
    "Open Project",
    "Task Launcher welcome screen",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Startup popup is now a task launcher")
print("- Large workflow cards added")
print("- Home tab remains available inside the app")
