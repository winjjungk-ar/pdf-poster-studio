﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_direct_image_filter_safe_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add image helper methods before open_pdfs if missing
# ------------------------------------------------------------
helpers = r'''
    def _is_supported_image_path(self, file_path: str) -> bool:
        suffix = Path(file_path).suffix.lower()
        return suffix in {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

    def _prepare_source_file_for_workspace(self, file_path: str) -> str:
        suffix = Path(file_path).suffix.lower()

        if suffix == ".pdf":
            return file_path

        if self._is_supported_image_path(file_path):
            return self._convert_image_to_temp_pdf(file_path)

        raise RuntimeError(f"Unsupported file type: {file_path}")

    def _convert_image_to_temp_pdf(self, image_path: str) -> str:
        image_file = Path(image_path)

        if not image_file.exists():
            raise RuntimeError(f"Image file not found: {image_path}")

        temp_dir = DATA_DIR / "image_imports"
        temp_dir.mkdir(parents=True, exist_ok=True)

        safe_stem = "".join(ch if ch not in '<>:"/\\\\|?*' else "_" for ch in image_file.stem)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        output_pdf = temp_dir / f"{safe_stem}_{timestamp}.pdf"

        doc = fitz.open()
        img_doc = None

        try:
            img_doc = fitz.open(str(image_file))
            rect = img_doc[0].rect

            if rect.width <= 0 or rect.height <= 0:
                raise RuntimeError("Invalid image size.")

            page = doc.new_page(width=rect.width, height=rect.height)
            page.insert_image(page.rect, filename=str(image_file))
            doc.save(str(output_pdf), garbage=4, deflate=True)

        finally:
            doc.close()
            if img_doc is not None:
                img_doc.close()

        self._log(f"Image converted to temporary PDF: {image_file} -> {output_pdf}")
        return str(output_pdf)

'''

if "def _convert_image_to_temp_pdf" not in text:
    marker = "    def open_pdfs(self) -> None:\n"
    if marker not in text:
        print("[ERROR] Could not find open_pdfs marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text.replace(marker, helpers + "\n" + marker, 1)
    print("[OK] Added image helper methods")
else:
    print("[SKIP] Image helper methods already exist")

# ------------------------------------------------------------
# 2) Replace Open PDFs file dialog block
# ------------------------------------------------------------
old_open_dialog = '''        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Open PDFs",
            "",
            "PDF Files (*.pdf)"
        )
'''

new_open_dialog = '''        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Open PDFs or Images",
            "",
            "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp);;"
            "PDF Files (*.pdf);;"
            "Image Files (*.png *.jpg *.jpeg *.bmp *.webp);;"
            "All Files (*)"
        )
'''

if old_open_dialog in text:
    text = text.replace(old_open_dialog, new_open_dialog, 1)
    print("[OK] Replaced open_pdfs file dialog filter")
else:
    print("[WARN] open_pdfs exact file dialog block not found")

# ------------------------------------------------------------
# 3) Replace Add PDFs file dialog block
# ------------------------------------------------------------
old_add_dialog = '''        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Add PDFs to Workspace",
            "",
            "PDF Files (*.pdf)"
        )
'''

new_add_dialog = '''        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Add PDFs or Images to Source PDFs",
            "",
            "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp);;"
            "PDF Files (*.pdf);;"
            "Image Files (*.png *.jpg *.jpeg *.bmp *.webp);;"
            "All Files (*)"
        )
'''

if old_add_dialog in text:
    text = text.replace(old_add_dialog, new_add_dialog, 1)
    print("[OK] Replaced add_pdfs_to_workspace file dialog filter")
else:
    print("[WARN] add_pdfs_to_workspace exact file dialog block not found")

# ------------------------------------------------------------
# 4) Patch open_pdfs loop
# ------------------------------------------------------------
old_loop_1 = '''            for pdf_path in file_paths:
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

new_loop_1 = '''            for source_path in file_paths:
                pdf_path = self._prepare_source_file_for_workspace(source_path)
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

if old_loop_1 in text:
    text = text.replace(old_loop_1, new_loop_1, 1)
    print("[OK] Patched open_pdfs load loop")
else:
    print("[SKIP] open_pdfs loop already patched or not found")

# ------------------------------------------------------------
# 5) Patch add_pdfs_to_workspace loop
# ------------------------------------------------------------
old_loop_2 = '''        for pdf_path in file_paths:
            if pdf_path not in existing:
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

new_loop_2 = '''        for source_path in file_paths:
            pdf_path = self._prepare_source_file_for_workspace(source_path)

            if pdf_path not in existing:
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

if old_loop_2 in text:
    text = text.replace(old_loop_2, new_loop_2, 1)
    print("[OK] Patched add_pdfs_to_workspace load loop")
else:
    print("[SKIP] add_pdfs_to_workspace loop already patched or not found")

# ------------------------------------------------------------
# 6) Version only, no risky multiline Welcome edit
# ------------------------------------------------------------
text = text.replace("Version: 0.9.2", "Version: 0.9.3")
text = text.replace('"version": "0.9.2"', '"version": "0.9.3"')
text = text.replace("What's new in 0.9.2", "What's new in 0.9.3")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 7) Compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_direct_image_filter_safe_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
markers = [
    "Open PDFs or Images",
    "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp)",
    "Image Files (*.png *.jpg *.jpeg *.bmp *.webp)",
    "def _convert_image_to_temp_pdf",
    "_prepare_source_file_for_workspace(source_path)",
]
for marker in markers:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Open PDFs dialog should now show image formats")
print("- Supported: PNG, JPG, JPEG, BMP, WEBP")
