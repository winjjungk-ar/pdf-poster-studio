﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_separate_export_open_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# Helper: replace function by AST
# ------------------------------------------------------------
def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    candidates = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            candidates.append(node)

    if not candidates:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(candidates, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno
    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

# ------------------------------------------------------------
# 1) Add common open helper if missing
# ------------------------------------------------------------
open_helper = r'''    def _open_file_with_default_app(self, file_path: str) -> None:
        try:
            path = Path(file_path).resolve()

            if not path.exists():
                self._log(f"Open file skipped, not found: {path}")
                return

            os.startfile(str(path))
            self._log(f"Opened file with default app: {path}")

        except Exception as exc:
            self._log(f"Open file with default app failed: {exc}")

'''

if "def _open_file_with_default_app" not in text:
    marker = "    def open_exports_folder(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        marker = "    def export_print_pdf(self) -> None:\n"
        pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find insertion point for _open_file_with_default_app")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + open_helper + "\n" + text[pos:]
    print("[OK] Added _open_file_with_default_app")
else:
    print("[SKIP] _open_file_with_default_app already exists")

# ------------------------------------------------------------
# 2) Replace workspace separate export with robust version
# ------------------------------------------------------------
new_workspace_separate = r'''    def _export_workspace_to_separate_pdfs(self, output_path: str, options: ExportOptions) -> list[str]:
        if not self.workspace_items:
            raise RuntimeError("Workspace is empty.")

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        export_order_entries = self._get_export_order_entries()

        if not export_order_entries:
            for workspace_index, item in enumerate(self.workspace_items):
                checked_pages = sorted(list(item.get("checked_pages", set())))
                for page_index in checked_pages:
                    export_order_entries.append((workspace_index, page_index))

        if not export_order_entries:
            raise RuntimeError("No pages are checked for export.")

        base_path = Path(output_path)
        output_files: list[str] = []
        exporter = PosterExporter()

        self._log(
            f"Separate export started. "
            f"mode={options.export_type}, paper={getattr(options, 'paper_size', 'a4')}, "
            f"scale={getattr(options, 'poster_scale', 1.0)}"
        )

        for order_index, entry in enumerate(export_order_entries, 1):
            workspace_index, page_index = entry

            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                continue

            item = self.workspace_items[workspace_index]
            pdf_path = item.get("pdf_path")
            selections_qrect = item.get("page_selections", {})
            checked_pages = set(item.get("checked_pages", set()))

            if not pdf_path:
                continue

            if page_index not in checked_pages:
                continue

            rect = selections_qrect.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            # Load correct PDF/page so coordinate conversion uses correct page data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path
            self.current_page_index = page_index
            self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)

            converted = {
                page_index: self._preview_rect_to_pdf_selection(rect)
            }

            source_stem = Path(pdf_path).stem
            safe_source_stem = "".join(ch if ch not in '<>:"/\\\\|?*' else "_" for ch in source_stem)

            page_output = base_path.with_name(
                f"{base_path.stem}_{order_index:03d}_{safe_source_stem}_page_{page_index + 1:03d}{base_path.suffix}"
            )

            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(page_output),
                selections=converted,
                options=options,
            )

            output_files.append(str(page_output))
            self._log(f"Separate PDF created: {page_output}")

        if not output_files:
            raise RuntimeError("No valid selected pages were found for export.")

        self.last_exported_pdf_path = output_files[0]
        self._log(f"Separate export completed. Files created: {len(output_files)}")

        return output_files

'''

if "def _export_workspace_to_separate_pdfs" in text:
    text = replace_function(text, "_export_workspace_to_separate_pdfs", new_workspace_separate)
    print("[OK] Replaced _export_workspace_to_separate_pdfs")
else:
    marker = "    def _export_workspace_to_pdf(self, output_path: str, options: ExportOptions) -> None:\n"
    pos = text.find(marker)
    if pos == -1:
        print("[ERROR] Could not find _export_workspace_to_pdf marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
    text = text[:pos] + new_workspace_separate + "\n" + text[pos:]
    print("[OK] Added _export_workspace_to_separate_pdfs")

# ------------------------------------------------------------
# 3) Ensure workspace branch supports separate PDFs and opens first file
# ------------------------------------------------------------
if "_export_workspace_to_separate_pdfs(output_path, options)" not in text:
    old = '''            if workspace_mode:
                self._export_workspace_to_pdf(output_path, options)
'''
    new = '''            if workspace_mode:
                if self.batch_output_combo.currentData() == "separate_pdf_per_page":
                    output_files = self._export_workspace_to_separate_pdfs(output_path, options)

                    QMessageBox.information(
                        self,
                        "Export Complete",
                        "Separate PDF files were created:\\n\\n" + "\\n".join(output_files[:10])
                    )

                    if output_files:
                        self._open_file_with_default_app(output_files[0])

                    return

                self._export_workspace_to_pdf(output_path, options)
'''
    if old in text:
        text = text.replace(old, new, 1)
        print("[OK] Added workspace separate branch")
    else:
        print("[WARN] Could not find simple workspace branch to patch")
else:
    print("[SKIP] Workspace separate branch already present")

# ------------------------------------------------------------
# 4) Normalize auto-open calls after successful exports
# ------------------------------------------------------------
# Replace os.startfile(output_path) with helper where possible.
text = text.replace(
    "os.startfile(output_path)",
    "self._open_file_with_default_app(output_path)"
)
text = text.replace(
    "os.startfile(output_files[0])",
    "self._open_file_with_default_app(output_files[0])"
)

# If helper replacement created duplicated log lines, it's okay; helper logs too.

# ------------------------------------------------------------
# 5) Ensure normal single-PDF separate branch opens first file
# ------------------------------------------------------------
normal_sep_block = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    "Separate PDF files were created:\\n\\n" + "\\n".join(output_files[:10])
                )
'''

normal_sep_open = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    "Separate PDF files were created:\\n\\n" + "\\n".join(output_files[:10])
                )
                if output_files:
                    self._open_file_with_default_app(output_files[0])
'''

# Add only if this exact message block is in non-workspace branch and no immediate helper after it.
idx = text.find(normal_sep_block)
if idx != -1:
    lookahead = text[idx:idx + 500]
    if "_open_file_with_default_app(output_files[0])" not in lookahead:
        text = text.replace(normal_sep_block, normal_sep_open, 1)
        print("[OK] Added auto-open to normal separate export branch")
else:
    print("[SKIP] Normal separate export message block not found")

# ------------------------------------------------------------
# 6) Add mode warning text to separate export completion if needed
# ------------------------------------------------------------
# No functional change, logs already show mode.

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 7) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_separate_export_open_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "def _open_file_with_default_app",
    "def _export_workspace_to_separate_pdfs",
    "_export_workspace_to_separate_pdfs(output_path, options)",
    "_open_file_with_default_app(output_files[0])",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Separate PDF export branch reinforced")
print("- Successful exports now use common default-app opener")
print("- First separate PDF should open automatically")
print("")
print("IMPORTANT TEST:")
print("1. Export PDF")
print("2. Choose Poster Print Mode, not Single Page Mode")
print("3. Output Files = Separate PDF per selected page")
print("4. A4 + 100% should create separate files, each with 2 pages for Poster Print")
