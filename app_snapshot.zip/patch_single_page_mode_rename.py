﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_single_page_mode_rename_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")

replacements = [
    ("Selection Only Mode", "Single Page Mode"),
    ("Selection-only", "Single Page"),
    ("selection-only", "single-page"),
    ("Selection Only", "Single Page"),
    ("selection only", "single page"),
    ("selection_only_A4", "single_page"),
]

changed = 0

for old, new in replacements:
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        changed += count
        print(f"[OK] Replaced {count}: {old} -> {new}")

# Keep internal data key "selection_only" unchanged.
# If any accidental internal value replacement happened, restore it.
text = text.replace('"single_page"', '"selection_only"')
text = text.replace("'single_page'", "'selection_only'")

# But filenames can stay single_page.
text = text.replace("_selection_only", "_single_page")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_single_page_mode_rename_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "Single Page Mode",
    '"selection_only"',
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print(f"- User-facing mode name changed to Single Page Mode")
print(f"- Internal value selection_only preserved")
print(f"- replacements applied: {changed}")
