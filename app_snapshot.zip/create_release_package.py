﻿from pathlib import Path
from datetime import datetime
import shutil
import zipfile
import sys

ROOT = Path.cwd()
VERSION = "0.9.3"
APP_NAME = "PDF Poster Studio"

DIST_APP_DIR = ROOT / "dist" / APP_NAME
EXE_PATH = DIST_APP_DIR / f"{APP_NAME}.exe"
RELEASE_DIR = ROOT / "release"
ZIP_PATH = RELEASE_DIR / f"PDF_Poster_Studio_v{VERSION}_Windows.zip"

if not DIST_APP_DIR.exists():
    print(f"[ERROR] Dist app folder not found: {DIST_APP_DIR}")
    print("Please build EXE first.")
    sys.exit(1)

if not EXE_PATH.exists():
    print(f"[ERROR] EXE not found: {EXE_PATH}")
    print("Please build EXE first.")
    sys.exit(1)

RELEASE_DIR.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# README
# ------------------------------------------------------------
readme = f"""PDF Poster Studio v{VERSION}
================================

PDF Poster Studio is a Windows desktop tool for creating print-ready PDFs from
PDF files and image files.

Main use cases:
- Print large maps across A4 or US Letter sheets
- Print game maps, TRPG maps, and wall posters
- Print engineering drawings, P&ID sections, loop sheets, and pipe drawings
- Select areas from multiple PDFs/images and arrange them in a custom print order
- Create one combined PDF or separate PDF files per selected page

Supported input files:
- PDF
- PNG
- JPG / JPEG
- BMP
- WEBP

Main features:
- Open PDFs / Images
- Auto Select Current Page
- Auto Select All Pages
- Source PDFs list
- Print Order list
- Create Poster PDF
- Create Single Page PDF
- Output Files:
  - One PDF
  - Separate PDF per selected page
- A4 and US Letter output
- A-series presets: A3, A2, A1, A0
- ANSI presets
- Arch presets
- Hobby poster presets:
  - Poster Small - 2 sheets
  - Poster Medium - 4 sheets
  - Poster Large - 8 sheets
  - Poster Huge - 16 sheets
- Tiling Preview
- Project save/load
- Multilingual User Guide:
  - English
  - Korean
  - Japanese
  - Simplified Chinese

How to start:
1. Run "{APP_NAME}.exe"
2. Click "Open PDFs / Images"
3. Select a PDF or image file
4. Select an area or use Auto Select
5. Click "Build Print Order"
6. Choose Output Files mode
7. Click "Create Poster PDF" or "Create Single Page PDF"

Output files:
- Generated PDFs are saved to the exports folder.
- You can click "Open Exports Folder" in the toolbar.

Notes:
- This is a pre-1.0 release.
- For best quality with drawings and text, use vector PDF sources.
- Image files are converted internally to temporary PDF pages.
- The program does not modify original PDF or image files.

Creator:
JI JEONG GEUN
"""

# ------------------------------------------------------------
# QUICK START
# ------------------------------------------------------------
quick_start = f"""QUICK START - PDF Poster Studio v{VERSION}
=========================================

A. Create a large poster from a PDF or image
-------------------------------------------
1. Click "Open PDFs / Images".
2. Open your PDF, map, poster image, or drawing.
3. Select the area in the preview.
4. Go to the Poster Print tab.
5. Choose:
   - Output Paper Size: A4 or US Letter
   - Poster Size Preset: Poster Small / Medium / Large / Huge, A-series, ANSI, or Arch
6. Check Tiling Preview.
7. Click "Build Print Order".
8. Click "Create Poster PDF".

B. Create a clean single-page PDF
---------------------------------
1. Open your PDF or image.
2. Select an area.
3. Go to the Single Page tab.
4. Choose Single Page Fit Mode and Page Orientation.
5. Click "Build Print Order".
6. Click "Create Single Page PDF".

C. Combine selected areas into one PDF
--------------------------------------
1. Open multiple PDFs/images.
2. Select the pages or areas you need.
3. Click "Build Print Order".
4. Arrange items using Move Up / Move Down.
5. Set Output Files to "One PDF".
6. Create Poster PDF or Single Page PDF.

D. Create separate PDF files
----------------------------
1. Build Print Order.
2. Set Output Files to "Separate PDF per selected page".
3. Create Poster PDF or Single Page PDF.
4. Each selected page/area will be exported as a separate PDF.

E. Find exported files
----------------------
- Click "Open Exports Folder".
- Exported PDFs are saved in the exports folder.

F. Help
-------
Open Help > User Guide / How to Use for detailed instructions.
"""

# ------------------------------------------------------------
# VERSION
# ------------------------------------------------------------
version_txt = f"""PDF Poster Studio
Version: {VERSION}
Build date: {datetime.now().isoformat(timespec='seconds')}
Platform: Windows
Creator: JI JEONG GEUN

Release highlights:
- PDF and image input support
- Poster Print and Single Page output
- One PDF / Separate PDF output modes
- Tiling Preview
- A4 / US Letter
- A-series / ANSI / Arch / Hobby poster presets
- Multilingual User Guide
"""

(DIST_APP_DIR / "README.txt").write_text(readme, encoding="utf-8")
(DIST_APP_DIR / "QUICK_START.txt").write_text(quick_start, encoding="utf-8")
(DIST_APP_DIR / "VERSION.txt").write_text(version_txt, encoding="utf-8")

print("[OK] README.txt created")
print("[OK] QUICK_START.txt created")
print("[OK] VERSION.txt created")

# Runtime folders
for name in ["data", "exports", "projects"]:
    folder = DIST_APP_DIR / name
    folder.mkdir(parents=True, exist_ok=True)
    print(f"[OK] Runtime folder ready: {folder}")

# ------------------------------------------------------------
# ZIP
# ------------------------------------------------------------
if ZIP_PATH.exists():
    ZIP_PATH.unlink()

print(f"[INFO] Creating ZIP: {ZIP_PATH}")

with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for path in DIST_APP_DIR.rglob("*"):
        if path.is_file():
            arcname = Path(APP_NAME) / path.relative_to(DIST_APP_DIR)
            zf.write(path, arcname)

print("[OK] ZIP created")
print("")
print(f"Release package: {ZIP_PATH}")
print("")
print("Recommended final test:")
print(f"1. Extract {ZIP_PATH.name} to a new folder")
print(f"2. Run {APP_NAME}.exe")
print("3. Open a PDF and an image")
print("4. Create Poster PDF")
