﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_remove_print_order_overlay_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

new_thumbnail_func = r'''    def _create_export_order_thumbnail(self, workspace_index: int, page_index: int) -> QIcon:
        try:
            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                return QIcon()

            item = self.workspace_items[workspace_index]
            pdf_path = item.get("pdf_path", "")

            if not pdf_path:
                return QIcon()

            renderer = PdfRenderer()
            renderer.open(pdf_path)
            pixmap = renderer.render_page(page_index, zoom=0.35)

            if pixmap.isNull():
                return QIcon()

            canvas = QPixmap(96, 128)
            canvas.fill(QColor("#FFF8F0"))

            painter = QPainter(canvas)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)

            scaled = pixmap.scaled(
                86,
                118,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

            x = int((96 - scaled.width()) / 2)
            y = int((128 - scaled.height()) / 2)

            painter.setBrush(QBrush(QColor("#FFFFFF")))
            painter.setPen(QPen(QColor("#B7C9D6"), 1))
            painter.drawRoundedRect(x - 2, y - 2, scaled.width() + 4, scaled.height() + 4, 4, 4)
            painter.drawPixmap(x, y, scaled)

            # Do not draw selection overlay here.
            # The selection rectangle is based on preview display coordinates and can be misleading
            # after thumbnail scaling. Double-click the item to review the exact selection in Preview.

            painter.end()
            return QIcon(canvas)

        except Exception as exc:
            self._log(f"Thumbnail creation failed: workspace={workspace_index}, page={page_index + 1}, error={exc}")
            return QIcon()

'''

try:
    text = replace_function(text, "_create_export_order_thumbnail", new_thumbnail_func)
    print("[OK] Removed misleading selection overlay from Print Order thumbnails")
except Exception as exc:
    print(f"[ERROR] Failed to replace _create_export_order_thumbnail: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Add/adjust help label under Print Order if possible.
old = '''        status_layout.addWidget(QLabel("Print Order"))

        self.export_order_list = QListWidget()
'''

new = '''        status_layout.addWidget(QLabel("Print Order"))

        self.print_order_help_label = QLabel(
            "Thumbnails show source pages. Double-click an item to review the exact selected area."
        )
        self.print_order_help_label.setWordWrap(True)
        self.print_order_help_label.setStyleSheet("color: #5F6F7A;")
        status_layout.addWidget(self.print_order_help_label)

        self.export_order_list = QListWidget()
'''

if old in text and "self.print_order_help_label" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Print Order help label")
else:
    if "self.print_order_help_label" in text:
        print("[SKIP] Print Order help label already exists")
    else:
        print("[WARN] Could not insert Print Order help label")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_remove_print_order_overlay_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "Do not draw selection overlay here",
    "Double-click an item to review the exact selected area",
]

missing = [x for x in required if x not in new_text]
if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Print Order thumbnail no longer draws inaccurate selection overlay")
print("- Help text added below Print Order")
print("- Double-click item to verify exact selection in Preview")
