﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_unify_open_pdfs_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add unified Open PDFs method
# ------------------------------------------------------------
method = r'''
    def open_pdfs(self) -> None:
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Open PDFs",
            "",
            "PDF Files (*.pdf)"
        )

        if not file_paths:
            return

        try:
            self.workspace_items = []
            self.current_workspace_index = None

            if hasattr(self, "workspace_pdf_list"):
                self.workspace_pdf_list.clear()
            if hasattr(self, "export_order_list"):
                self.export_order_list.clear()

            for pdf_path in file_paths:
                self.workspace_items.append(self._make_workspace_item(pdf_path))

            self._refresh_workspace_list_text()

            if self.workspace_items:
                self._load_workspace_index(0)

            self.is_modified = True
            self._log(f"Open PDFs: {len(self.workspace_items)} file(s) loaded.")

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open PDFs Error",
                f"Failed to open PDFs.\n\n{exc}"
            )
            self._log(f"Open PDFs error: {exc}")

'''

if "def open_pdfs(self) -> None:" not in text:
    marker = "    def open_multiple_pdfs_workspace(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        marker = "    def open_pdf(self) -> None:\n"
        pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find insertion point for open_pdfs")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added open_pdfs method")
else:
    print("[SKIP] open_pdfs already exists")

# ------------------------------------------------------------
# 2) Replace File menu PDF open actions
# ------------------------------------------------------------
old_block = '''        open_pdf_action = self.file_menu.addAction("Open PDF", self.open_pdf)
        open_pdf_action.setShortcut(QKeySequence("Ctrl+O"))

        open_workspace_action = self.file_menu.addAction("Open Multiple PDFs as Workspace", self.open_multiple_pdfs_workspace)
        open_workspace_action.setShortcut(QKeySequence("Ctrl+M"))

        self.file_menu.addAction("Collect Pages from PDFs", self.open_page_collector_dialog)
'''

new_block = '''        open_pdfs_action = self.file_menu.addAction("Open PDFs", self.open_pdfs)
        open_pdfs_action.setShortcut(QKeySequence("Ctrl+O"))
'''

if old_block in text:
    text = text.replace(old_block, new_block, 1)
    print("[OK] Replaced File menu PDF actions with Open PDFs")
else:
    # fallback removals/additions
    before = text

    text = text.replace(
        '        open_pdf_action = self.file_menu.addAction("Open PDF", self.open_pdf)\n'
        '        open_pdf_action.setShortcut(QKeySequence("Ctrl+O"))\n\n',
        '',
        1
    )
    text = text.replace(
        '        open_workspace_action = self.file_menu.addAction("Open Multiple PDFs as Workspace", self.open_multiple_pdfs_workspace)\n'
        '        open_workspace_action.setShortcut(QKeySequence("Ctrl+M"))\n\n',
        '',
        1
    )
    text = text.replace(
        '        self.file_menu.addAction("Collect Pages from PDFs", self.open_page_collector_dialog)\n\n',
        '',
        1
    )

    marker = '        self.recent_projects_menu = self.file_menu.addMenu("Recent Projects")\n        self.file_menu.addSeparator()\n\n'
    insert = marker + '        open_pdfs_action = self.file_menu.addAction("Open PDFs", self.open_pdfs)\n        open_pdfs_action.setShortcut(QKeySequence("Ctrl+O"))\n\n'

    if marker in text and 'self.file_menu.addAction("Open PDFs", self.open_pdfs)' not in text:
        text = text.replace(marker, insert, 1)
        print("[OK] Added Open PDFs menu action by fallback")

    if text != before:
        print("[OK] Removed old PDF open/collect menu actions by fallback")
    else:
        print("[WARN] Could not fully replace File menu actions")

# ------------------------------------------------------------
# 3) Change View tab button text/connection: Open PDF -> Open PDFs
# ------------------------------------------------------------
text = text.replace(
    '        open_pdf_button = QPushButton("Open PDF")\n        open_pdf_button.clicked.connect(self.open_pdf)\n',
    '        open_pdf_button = QPushButton("Open PDFs")\n        open_pdf_button.clicked.connect(self.open_pdfs)\n',
    1
)

# There may be duplicated dead code later; patch first practical occurrence only above.
print("[OK] Updated View tab Open button if found")

# ------------------------------------------------------------
# 4) Add Open PDFs to quick toolbar and emphasize Auto Select All Pages
# ------------------------------------------------------------
old_toolbar = '''    def _create_quick_toolbar(self) -> None:
        toolbar = QToolBar("Quick Actions", self)
        toolbar.setMovable(False)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, toolbar)

        auto_current_action = QAction("Auto Select Current Page", self)
        auto_current_action.triggered.connect(self.auto_select_content)
        toolbar.addAction(auto_current_action)

        auto_all_action = QAction("Auto Select All Pages", self)
        auto_all_action.triggered.connect(self.auto_select_all_pages)
        toolbar.addAction(auto_all_action)

        toolbar.addSeparator()

        export_action = QAction("Export PDF", self)
        export_action.triggered.connect(self.export_print_pdf)
        toolbar.addAction(export_action)
'''

new_toolbar = '''    def _create_quick_toolbar(self) -> None:
        toolbar = QToolBar("Quick Actions", self)
        toolbar.setMovable(False)
        toolbar.setStyleSheet("""
            QToolButton {
                padding: 5px 8px;
                font-weight: 600;
            }
            QToolButton[objectName="autoSelectAllPagesButton"] {
                color: white;
                background-color: #0B63CE;
                border: 1px solid #084A9B;
                border-radius: 4px;
            }
            QToolButton[objectName="autoSelectAllPagesButton"]:hover {
                background-color: #0A56B3;
            }
        """)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, toolbar)

        open_pdfs_action = QAction("Open PDFs", self)
        open_pdfs_action.triggered.connect(self.open_pdfs)
        toolbar.addAction(open_pdfs_action)

        toolbar.addSeparator()

        auto_current_action = QAction("Auto Select Current Page", self)
        auto_current_action.triggered.connect(self.auto_select_content)
        toolbar.addAction(auto_current_action)

        auto_all_action = QAction("Auto Select All Pages", self)
        auto_all_action.triggered.connect(self.auto_select_all_pages)
        auto_all_action.setObjectName("autoSelectAllPagesAction")
        toolbar.addAction(auto_all_action)

        auto_all_button = toolbar.widgetForAction(auto_all_action)
        if auto_all_button is not None:
            auto_all_button.setObjectName("autoSelectAllPagesButton")

        toolbar.addSeparator()

        export_action = QAction("Export PDF", self)
        export_action.triggered.connect(self.export_print_pdf)
        toolbar.addAction(export_action)
'''

if old_toolbar in text:
    text = text.replace(old_toolbar, new_toolbar, 1)
    print("[OK] Replaced quick toolbar with styled version")
else:
    if 'autoSelectAllPagesButton' in text:
        print("[SKIP] Styled toolbar already present")
    else:
        print("[WARN] Could not replace quick toolbar exactly")

# ------------------------------------------------------------
# 5) Rename diagnostics menu labels if present
# ------------------------------------------------------------
text = text.replace(
    '("File > Open PDF", callable(self.open_pdf)),',
    '("File > Open PDFs", callable(self.open_pdfs)),'
)
text = text.replace(
    '("File > Collect Pages from PDFs", callable(self.open_page_collector_dialog)),\n',
    ''
)

# ------------------------------------------------------------
# 6) py_compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_unify_open_pdfs_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "def open_pdfs",
    'addAction("Open PDFs", self.open_pdfs)',
    "autoSelectAllPagesButton",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- File menu unified to Open PDFs")
print("- Open PDF / Open Multiple PDFs / Collect Pages menu entries removed")
print("- Toolbar now includes Open PDFs")
print("- Auto Select All Pages button is highlighted")
