﻿from pathlib import Path
import ast
import re
import sys
from datetime import datetime

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"
OUT = ROOT / "ui_cleanup_audit_report.txt"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

def read(path):
    return path.read_text(encoding="utf-8", errors="replace")

def ast_functions(source):
    result = []
    try:
        tree = ast.parse(source)
    except Exception:
        return result

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            result.append((node.name, node.lineno, getattr(node, "end_lineno", node.lineno)))
    return sorted(result, key=lambda x: x[1])

def extract_function(source, func_name):
    try:
        tree = ast.parse(source)
    except Exception:
        return None

    lines = source.splitlines()

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno
            end = getattr(node, "end_lineno", node.lineno)
            return start, end, "\n".join(lines[start - 1:end])

    return None

def grep_lines(source, patterns, flags=re.I):
    rows = []
    for idx, line in enumerate(source.splitlines(), 1):
        for pat in patterns:
            if re.search(pat, line, flags):
                rows.append(f"{idx:05d}: {line}")
                break
    return rows

main_text = read(MAIN)
exporter_text = read(EXPORTER) if EXPORTER.exists() else ""

old_terms = [
    "A3 Split",
    "A3 Split Mode",
    "Export Order",
    "PDF Workspace",
    "Collect Pages",
    "Open Multiple PDFs",
    "Open PDF",
    "A4 to A3",
]

desired_terms = [
    "Poster Print",
    "Print Order",
    "Source PDFs",
    "Open PDFs",
    "Build Print Order",
    "Poster Scale",
    "Output Paper Size",
    "Poster Size Preset",
]

ui_patterns = [
    r"QLabel\(",
    r"QPushButton\(",
    r"addAction\(",
    r"addTab\(",
    r"\.addItem\(",
    r"setWindowTitle\(",
    r"QAction\(",
]

duplicate_patterns = [
    r"open_pdf_button",
    r"export_button",
    r"settings_tabs",
    r"status_tab",
    r"view_tab",
    r"export_tab",
    r"a3_split_group",
    r"selection_only_group",
]

report = []
report.append("# UI Cleanup Audit Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py lines: {len(main_text.splitlines())}")
report.append(f"- poster_exporter.py lines: {len(exporter_text.splitlines()) if exporter_text else 'missing'}")
report.append("")

# Syntax
report.append("## 1. Syntax")
for path, source in [(MAIN, main_text), (EXPORTER, exporter_text)]:
    if not source:
        report.append(f"- [MISSING] `{path}`")
        continue
    try:
        ast.parse(source)
        report.append(f"- [OK] `{path.relative_to(ROOT)}`")
    except SyntaxError as exc:
        report.append(f"- [FAILED] `{path.relative_to(ROOT)}`: {exc}")
report.append("")

# Term counts
report.append("## 2. Old term counts in main_window.py")
for term in old_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

report.append("## 3. Desired term counts in main_window.py")
for term in desired_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

# Old term contexts
report.append("## 4. Old term contexts in main_window.py")
old_contexts = grep_lines(main_text, [re.escape(t) for t in old_terms])
if old_contexts:
    report.append("```text")
    report.append("\n".join(old_contexts[:300]))
    report.append("```")
else:
    report.append("- [OK] No old terms found.")
report.append("")

# UI lines
report.append("## 5. User-facing UI lines in main_window.py")
ui_lines = grep_lines(main_text, ui_patterns, flags=0)
report.append("```text")
report.append("\n".join(ui_lines[:700]))
report.append("```")
report.append("")

# Duplicate indicators
report.append("## 6. Duplicate UI indicator counts")
for pat in duplicate_patterns:
    count = len(re.findall(pat, main_text))
    report.append(f"- `{pat}`: {count}")
report.append("")

report.append("## 7. Duplicate UI indicator contexts")
dup_lines = grep_lines(main_text, duplicate_patterns)
report.append("```text")
report.append("\n".join(dup_lines[:500]))
report.append("```")
report.append("")

# Function summary
report.append("## 8. main_window.py function summary")
funcs = ast_functions(main_text)
for name, start, end in funcs:
    length = end - start + 1
    if length >= 80 or name in [
        "_create_central_ui",
        "_create_log_panel",
        "export_print_pdf",
        "_apply_project_data",
        "_collect_project_data",
        "_create_quick_toolbar",
        "_show_welcome_dialog",
    ]:
        report.append(f"- `{name}` lines {start}-{end} ({length} lines)")
report.append("")

# Specific suspicious _create_log_panel
report.append("## 9. _create_log_panel inspection")
block = extract_function(main_text, "_create_log_panel")
if not block:
    report.append("- `_create_log_panel` not found")
else:
    start, end, code = block
    report.append(f"- lines: {start}-{end}")
    suspicious = []
    for idx, line in enumerate(code.splitlines(), start):
        if any(x in line for x in [
            "QPushButton(",
            "QComboBox(",
            "QTabWidget(",
            "settings_tabs",
            "root_layout",
            "settings_area",
            "preview_area",
            "open_pdf_button",
            "export_button",
        ]):
            suspicious.append(f"{idx:05d}: {line}")

    if suspicious:
        report.append("- [WARN] Suspicious UI construction found inside `_create_log_panel`:")
        report.append("```text")
        report.append("\n".join(suspicious[:300]))
        report.append("```")
    else:
        report.append("- [OK] No suspicious central UI construction found inside `_create_log_panel`.")
report.append("")

# Exporter term counts
report.append("## 10. poster_exporter.py term counts")
if exporter_text:
    for term in old_terms + ["A4_WIDTH_PT", "A3_WIDTH_PT", "LETTER_WIDTH_PT", "poster_scale", "paper_size"]:
        report.append(f"- `{term}`: {exporter_text.count(term)}")
else:
    report.append("- poster_exporter.py missing")
report.append("")

report.append("## 11. poster_exporter.py relevant lines")
if exporter_text:
    rows = grep_lines(
        exporter_text,
        [
            r"A3",
            r"A4",
            r"LETTER",
            r"poster_scale",
            r"paper_size",
            r"_export_a3_split",
            r"_export_poster_tiling",
            r"draw.*number",
            r"Sheet",
            r"cut",
            r"guide",
            r"show_pdf_page",
            r"insert_image",
        ],
    )
    report.append("```text")
    report.append("\n".join(rows[:500]))
    report.append("```")
else:
    report.append("(missing)")
report.append("")

# Recommendations
report.append("## 12. Suggested next cleanup")
report.append("- If `_create_log_panel` contains central UI construction, clean it first.")
report.append("- User-facing old terms should be removed unless they are only internal compatibility names.")
report.append("- Internal names like `a3_split_group`, `_export_a3_split`, and `split_layout` may remain temporarily for compatibility.")
report.append("- `A3_WIDTH_PT` may remain if legacy A4 100% base mode still uses A3-like sizing.")
report.append("- `insert_image` should ideally not be used for PDF/vector text output paths.")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Audit report written: {OUT}")
print("Paste ui_cleanup_audit_report.txt here.")
