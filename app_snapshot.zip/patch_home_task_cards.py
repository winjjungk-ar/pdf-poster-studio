﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_home_task_cards_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add Home task methods before update_output_area_states
# ------------------------------------------------------------
methods = r'''
    def _set_combo_by_data_if_exists(self, combo_name: str, data) -> None:
        combo = getattr(self, combo_name, None)
        if combo is not None:
            self._apply_combo_data(combo, data)

    def task_merge_pdfs(self) -> None:
        self._set_combo_by_data_if_exists("output_area_combo", "whole_page")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self._set_combo_by_data_if_exists("batch_output_combo", "single_pdf")
        self.update_export_option_states()
        self.update_output_area_states()

        QMessageBox.information(
            self,
            "Merge PDFs",
            "Merge PDFs uses full pages and creates one PDF.\\n\\n"
            "1. Open PDFs / Images.\\n"
            "2. Check the pages you want, or use the current page.\\n"
            "3. Click Build Print Order.\\n"
            "4. Click Create Single Page PDF."
        )

        if hasattr(self, "settings_tabs"):
            self.settings_tabs.setCurrentWidget(self.settings_tabs.widget(0))

    def task_extract_pages(self) -> None:
        self._set_combo_by_data_if_exists("output_area_combo", "whole_page")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self.update_export_option_states()
        self.update_output_area_states()

        QMessageBox.information(
            self,
            "Extract Pages",
            "Extract Pages uses full pages.\\n\\n"
            "Use the page list to check pages, or use Go Page / page range workflows.\\n"
            "Then choose Output Files and click Create Single Page PDF."
        )

    def task_make_poster(self) -> None:
        self._set_combo_by_data_if_exists("export_type_combo", "a3_split")
        self.update_export_option_states()
        self.update_output_area_states()

        QMessageBox.information(
            self,
            "Make Poster",
            "Make Poster creates tiled poster output.\\n\\n"
            "Choose Output Area:\\n"
            "- Whole Page for full maps/images/pages\\n"
            "- Selected Area for only part of a page\\n\\n"
            "Then choose Poster Size Preset and click Create Poster PDF."
        )

        if hasattr(self, "settings_tabs") and hasattr(self, "a3_split_group"):
            self.settings_tabs.setCurrentWidget(self.a3_split_group)

    def task_rotate_pages(self) -> None:
        QMessageBox.information(
            self,
            "Rotate Pages",
            "Use the floating View toolbar on the preview to rotate pages.\\n\\n"
            "Rotation is page-specific. After rotating, create a PDF to save the rotated output."
        )

    def task_selected_area_pdf(self) -> None:
        self._set_combo_by_data_if_exists("output_area_combo", "selected_area")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self.update_export_option_states()
        self.update_output_area_states()

        QMessageBox.information(
            self,
            "Selected Area PDF",
            "Selected Area PDF exports only the area you select.\\n\\n"
            "1. Drag to select an area or use Auto Select.\\n"
            "2. Click Build Print Order.\\n"
            "3. Click Create Single Page PDF."
        )

        if hasattr(self, "settings_tabs") and hasattr(self, "selection_only_group"):
            self.settings_tabs.setCurrentWidget(self.selection_only_group)

'''

if "def task_merge_pdfs" not in text:
    marker = "    def update_output_area_states(self) -> None:\n"
    pos = text.find(marker)
    if pos == -1:
        print("[ERROR] Could not find update_output_area_states marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + methods + "\n" + text[pos:]
    print("[OK] Added Home task methods")
else:
    print("[SKIP] Home task methods already exist")

# ------------------------------------------------------------
# 2) Add Home tab UI before status_tab
# ------------------------------------------------------------
anchor = '''        status_tab = QWidget()
        status_layout = QVBoxLayout(status_tab)
'''

home_ui = '''        home_tab = QWidget()
        home_layout = QVBoxLayout(home_tab)
        home_layout.setSpacing(10)

        home_title = QLabel("What do you want to do?")
        home_title.setStyleSheet("font-size: 16px; font-weight: 800; color: #395B64;")
        home_layout.addWidget(home_title)

        home_help = QLabel(
            "Choose a task below. The app will set the main options for that workflow."
        )
        home_help.setWordWrap(True)
        home_help.setStyleSheet("color: #5F6F7A;")
        home_layout.addWidget(home_help)

        def add_task_card(title_text: str, description: str, callback) -> None:
            card = QWidget()
            card.setStyleSheet("""
                QWidget {
                    background-color: #FFF8F0;
                    border: 1px solid #EADBC8;
                    border-radius: 10px;
                }
                QLabel {
                    border: none;
                    background: transparent;
                }
                QPushButton {
                    color: #395B64;
                    background-color: #EAF7F7;
                    border: 1px solid #BFE8E8;
                    border-radius: 7px;
                    padding: 7px 10px;
                    font-weight: 800;
                    text-align: left;
                }
                QPushButton:hover {
                    background-color: #DDF3F5;
                    border: 1px solid #9EDDE2;
                }
            """)

            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(10, 8, 10, 8)
            card_layout.setSpacing(5)

            button = QPushButton(title_text)
            button.clicked.connect(callback)

            desc_label = QLabel(description)
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #5F6F7A;")

            card_layout.addWidget(button)
            card_layout.addWidget(desc_label)
            home_layout.addWidget(card)

        add_task_card(
            "Merge PDFs",
            "Combine full pages from multiple PDFs/images into one PDF.",
            self.task_merge_pdfs,
        )

        add_task_card(
            "Extract Pages",
            "Use full pages and export only the pages you choose.",
            self.task_extract_pages,
        )

        add_task_card(
            "Make Poster",
            "Tile a map, poster, image, or drawing across A4/US Letter sheets.",
            self.task_make_poster,
        )

        add_task_card(
            "Rotate Pages",
            "Rotate pages in preview and save the rotated result as a new PDF.",
            self.task_rotate_pages,
        )

        add_task_card(
            "Selected Area PDF",
            "Select part of a PDF/image and export only that area.",
            self.task_selected_area_pdf,
        )

        home_layout.addStretch()

        status_tab = QWidget()
        status_layout = QVBoxLayout(status_tab)
'''

if anchor in text and "What do you want to do?" not in text:
    text = text.replace(anchor, home_ui, 1)
    print("[OK] Added Home tab UI")
else:
    if "What do you want to do?" in text:
        print("[SKIP] Home tab UI already exists")
    else:
        print("[ERROR] Could not find status_tab anchor")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 3) Add Home tab to settings_tabs before Status
# ------------------------------------------------------------
old = '''        self.settings_tabs = QTabWidget()
        self.settings_tabs.addTab(status_tab, "Status")
'''

new = '''        self.settings_tabs = QTabWidget()
        self.settings_tabs.addTab(home_tab, "Home")
        self.settings_tabs.addTab(status_tab, "Status")
'''

if old in text and 'addTab(home_tab, "Home")' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Home tab to settings_tabs")
else:
    print("[SKIP] Home tab already added or anchor not found")

# ------------------------------------------------------------
# 4) Welcome popup mention Home
# ------------------------------------------------------------
if "Use the Home tab for guided workflows" not in text:
    marker = "• See Help > Release Notes for details"
    addition = "• Use the Home tab for guided workflows\\n"
    if marker in text:
        text = text.replace(marker, addition + marker, 1)
        print("[OK] Welcome updated with Home tab note")

# ------------------------------------------------------------
# 5) Release Notes
# ------------------------------------------------------------
if "Home task cards" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Home task cards</b>: Added guided task cards for Merge PDFs, Extract Pages, Make Poster, Rotate Pages, and Selected Area PDF.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for Home task cards")

# ------------------------------------------------------------
# 6) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_home_task_cards_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "What do you want to do?",
    "def task_merge_pdfs",
    'addTab(home_tab, "Home")',
    "Home task cards",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Home tab added")
print("- Guided task cards added")
print("- Release Notes updated")
