﻿from pathlib import Path
from datetime import datetime
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
OUT = ROOT / "final_093_full_check_report.txt"

MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"
PREVIEW = ROOT / "app" / "ui" / "pdf_preview_widget.py"

important_files = [
    ROOT / "main.py",
    MAIN,
    ROOT / "app" / "config.py",
    ROOT / "app" / "pdf" / "pdf_renderer.py",
    EXPORTER,
    PREVIEW,
]

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""

def run_py_compile(path: Path):
    return subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

def ast_parse_status(text: str):
    try:
        ast.parse(text)
        return "OK"
    except SyntaxError as exc:
        return f"FAILED: {exc}"

def function_defs(text: str, name: str):
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []

    result = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            result.append((node.lineno, getattr(node, "end_lineno", node.lineno)))
    return sorted(result)

def grep_lines(text: str, terms: list[str]):
    rows = []
    for idx, line in enumerate(text.splitlines(), 1):
        if any(term.lower() in line.lower() for term in terms):
            rows.append(f"{idx:05d}: {line}")
    return rows

main_text = read(MAIN)
exporter_text = read(EXPORTER)
preview_text = read(PREVIEW)

required_main_markers = {
    "Version 0.9.3": [
        "Version: 0.9.3",
        '"version": "0.9.3"',
    ],
    "Open PDFs / Images": [
        "Open PDFs / Images",
        "Open PDFs or Images",
        "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp)",
        "Image Files (*.png *.jpg *.jpeg *.bmp *.webp)",
    ],
    "Image import": [
        "def _is_supported_image_path",
        "def _prepare_source_file_for_workspace",
        "def _convert_image_to_temp_pdf",
        "image_imports",
    ],
    "Toolbar actions": [
        'QAction("Open PDFs / Images", self)',
        'QAction("Create Poster PDF", self)',
        'QAction("Create Single Page PDF", self)',
        'QAction("Open Exports Folder", self)',
    ],
    "Source PDFs / Print Order": [
        "Source PDFs",
        "Print Order",
        "Build Print Order",
        "def refresh_export_order_from_checked_pages",
        "def on_export_order_item_double_clicked",
    ],
    "Output modes": [
        "Output Files",
        "One PDF",
        "Separate PDF per selected page",
        "def _export_workspace_to_separate_pdfs",
    ],
    "Poster Print": [
        "Poster Print Mode",
        "Poster Size Preset",
        "Output Paper Size",
        "Poster Scale",
        "Tiling Preview",
        "Poster Small - 2 sheets",
        "Poster Huge - 16 sheets",
        "def update_tiling_preview",
    ],
    "Single Page": [
        "Single Page Mode",
        "Single Page Fit Mode",
        "Create Single Page PDF",
    ],
    "Multilingual guide": [
        '"English"',
        '"한국어"',
        '"日本語"',
        '"中文（简体）"',
        "language_combo",
    ],
    "Release notes": [
        "Release Notes",
        "Image import support",
        "English User Guide",
    ],
    "Project save/load": [
        "def _serialize_workspace_items",
        "def _restore_workspace_items_from_project",
        "def _serialize_export_order",
        "def _restore_export_order_from_project",
        '"workspace":',
        '"export_order": export_order',
        "poster_size_preset_index",
    ],
}

required_exporter_markers = {
    "Vector output": [
        "show_pdf_page",
        "Keep PDF text/vector graphics sharp",
    ],
    "Tiling core": [
        "def _export_poster_tiling",
        "def _make_poster_tiles",
        "tile_cols",
        "tile_rows",
        "def _draw_poster_tiling_cut_guides",
    ],
    "Paper sizes": [
        "A4_WIDTH_PT",
        "LETTER_WIDTH_PT",
        "paper_size: str",
        "poster_scale: float",
    ],
    "Short sheet numbers": [
        'text = f"{sheet_no}/{sheet_total}"',
        "Minimal and consistent sheet label",
    ],
}

old_visible_terms = [
    "A3 Split Mode",
    "Selection Only Mode",
    "Export Order",
    "PDF Workspace",
    "Collect Pages from PDFs",
    "Open Multiple PDFs",
]

report = []
report.append("# Final 0.9.3 Full Check Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- python: {sys.executable}")
report.append(f"- main_window.py lines: {len(main_text.splitlines()) if main_text else 'missing'}")
report.append(f"- poster_exporter.py lines: {len(exporter_text.splitlines()) if exporter_text else 'missing'}")
report.append(f"- pdf_preview_widget.py lines: {len(preview_text.splitlines()) if preview_text else 'missing'}")
report.append("")

# 1 files
report.append("## 1. Important files")
for path in important_files:
    report.append(f"- [{'OK' if path.exists() else 'MISSING'}] `{path.relative_to(ROOT) if path.exists() else path}`")
report.append("")

# 2 compile
report.append("## 2. py_compile")
compile_failed = False
for path in important_files:
    if not path.exists():
        report.append(f"- [SKIP] `{path}` missing")
        continue

    result = run_py_compile(path)
    if result.returncode == 0:
        report.append(f"- [OK] `{path.relative_to(ROOT)}`")
    else:
        compile_failed = True
        report.append(f"- [FAILED] `{path.relative_to(ROOT)}`")
        report.append("```text")
        report.append((result.stdout or "") + (result.stderr or ""))
        report.append("```")
report.append("")

# 3 ast
report.append("## 3. AST parse")
for path in important_files:
    if not path.exists():
        continue
    text = read(path)
    report.append(f"- [{ast_parse_status(text)}] `{path.relative_to(ROOT)}`")
report.append("")

# 4 main markers
report.append("## 4. Required main_window.py markers")
for group, markers in required_main_markers.items():
    missing = [m for m in markers if m not in main_text]
    if missing:
        report.append(f"- [WARN] {group}: missing")
        for m in missing:
            report.append(f"  - `{m}`")
    else:
        report.append(f"- [OK] {group}")
report.append("")

# 5 exporter markers
report.append("## 5. Required poster_exporter.py markers")
for group, markers in required_exporter_markers.items():
    missing = [m for m in markers if m not in exporter_text]
    if missing:
        report.append(f"- [WARN] {group}: missing")
        for m in missing:
            report.append(f"  - `{m}`")
    else:
        report.append(f"- [OK] {group}")
report.append("")

# 6 old terms
report.append("## 6. Old visible term counts")
for term in old_visible_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

old_rows = grep_lines(main_text, old_visible_terms)
report.append("## 7. Old visible term contexts")
if old_rows:
    report.append("```text")
    report.append("\n".join(old_rows[:200]))
    report.append("```")
else:
    report.append("- [OK] No old visible terms found.")
report.append("")

# 8 duplicates
report.append("## 8. Duplicate function checks")
for fn in [
    "_create_log_panel",
    "_create_central_ui",
    "_create_quick_toolbar",
    "open_pdfs",
    "add_pdfs_to_workspace",
    "_convert_image_to_temp_pdf",
    "show_user_guide",
    "show_release_notes",
    "update_tiling_preview",
    "export_print_pdf",
    "print_pdf",
]:
    defs = function_defs(main_text, fn)
    expected_ok = len(defs) == 1 or (fn == "add_pdfs_to_workspace" and len(defs) in (0, 1))
    report.append(f"- [{'OK' if expected_ok else 'WARN'}] `{fn}`: {len(defs)} definition(s)")
    for start, end in defs:
        report.append(f"  - lines {start}-{end} ({end-start+1} lines)")
report.append("")

# 9 image contexts
report.append("## 9. Image support contexts")
rows = grep_lines(main_text, [
    "Open PDFs / Images",
    "Open PDFs or Images",
    "PDF and Image Files",
    "Image Files",
    "_prepare_source_file_for_workspace",
    "_convert_image_to_temp_pdf",
    "image_imports",
])
report.append("```text")
report.append("\n".join(rows[:300]))
report.append("```")
report.append("")

# 10 preview empty rect
report.append("## 10. Empty preview rectangle check")
for marker in [
    "border: none",
    "background: transparent",
    "Do not draw placeholder rectangle before a PDF is loaded",
]:
    report.append(f"- [{'OK' if marker in preview_text else 'WARN'}] `{marker}`")
report.append("")

# 11 manual test checklist
report.append("## 11. Manual test checklist")
tests = [
    "Open PDFs / Images: select a PDF.",
    "Open PDFs / Images: select PNG/JPG image.",
    "Image appears in Source PDFs and Preview.",
    "Auto Select Current Page works on imported image.",
    "Create Poster PDF from imported image.",
    "Create Single Page PDF from imported image.",
    "Output Files = One PDF.",
    "Output Files = Separate PDF per selected page.",
    "Poster presets: Poster Small/Medium/Large/Huge.",
    "A-series presets: A3/A2/A1/A0 expected sheet counts.",
    "User Guide language combo shows English / 한국어 / 日本語 / 中文（简体）.",
    "Release Notes includes image import support.",
    "About shows Version 0.9.3.",
]
for i, test in enumerate(tests, 1):
    report.append(f"{i}. [ ] {test}")
report.append("")

# 12 clutter
report.append("## 12. Patch/backup clutter")
patch_scripts = (
    sorted(ROOT.glob("patch_*.py"))
    + sorted(ROOT.glob("fix_*.py"))
    + sorted(ROOT.glob("force_*.py"))
    + sorted(ROOT.glob("direct_*.py"))
    + sorted(ROOT.glob("safe_*.py"))
    + sorted(ROOT.glob("*check*.py"))
)
backup_files = sorted((ROOT / "app").rglob("*.bak_*")) if (ROOT / "app").exists() else []

report.append(f"- root patch/fix/check scripts: {len(patch_scripts)}")
for p in patch_scripts[:100]:
    report.append(f"  - `{p.name}`")
if len(patch_scripts) > 100:
    report.append(f"  - ... and {len(patch_scripts)-100} more")

report.append(f"- app backup files: {len(backup_files)}")
for p in backup_files[:100]:
    report.append(f"  - `{p.relative_to(ROOT)}`")
if len(backup_files) > 100:
    report.append(f"  - ... and {len(backup_files)-100} more")
report.append("")

# 13 summary
report.append("## 13. Summary")
if compile_failed:
    report.append("- Overall: **FAILED**")
    report.append("- Reason: py_compile failed.")
else:
    report.append("- Overall: **CHECK COMPLETE**")
    report.append("- Review WARN items. If none are critical, proceed to manual tests.")
report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste final_093_full_check_report.txt here.")
