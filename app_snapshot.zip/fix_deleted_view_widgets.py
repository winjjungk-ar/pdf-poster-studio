﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_deleted_view_widgets_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# The View tab was removed from settings_tabs, but widgets inside it still exist as self members.
# Keep the view_tab Python/Qt object alive so child widgets such as auto_select_sensitivity_combo
# are not deleted by Qt/Python garbage collection.
anchor = '''        view_layout.addStretch()

        export_tab = QWidget()
'''

replacement = '''        view_layout.addStretch()

        # Keep this hidden View tab alive.
        # It is not shown in settings_tabs because view controls moved to the preview floating toolbar,
        # but it owns widgets still used internally, such as auto_select_sensitivity_combo.
        self._hidden_view_tab = view_tab

        export_tab = QWidget()
'''

if anchor in text and "self._hidden_view_tab = view_tab" not in text:
    text = text.replace(anchor, replacement, 1)
    print("[OK] Hidden View tab is now kept alive")
elif "self._hidden_view_tab = view_tab" in text:
    print("[SKIP] Hidden View tab keep-alive already exists")
else:
    print("[ERROR] Could not find view_layout.addStretch anchor")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_deleted_view_widgets_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Hidden View tab widgets are kept alive")
print("- This should fix QComboBox has been deleted")
print("")
print("IMPORTANT:")
print("Rebuild EXE after this patch.")
