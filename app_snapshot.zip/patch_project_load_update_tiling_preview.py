﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_project_load_update_tiling_preview_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

old = '''        self._refresh_workspace_list_text()
        self._refresh_current_page_check_state()
        self._refresh_page_list_all_text()
        self._update_checked_pages_label()

        self.is_modified = False
'''

new = '''        self._refresh_workspace_list_text()
        self._refresh_current_page_check_state()
        self._refresh_page_list_all_text()
        self._update_checked_pages_label()

        if hasattr(self, "update_poster_sheet_estimate"):
            self.update_poster_sheet_estimate()

        self.is_modified = False
'''

if old in text and "self.update_poster_sheet_estimate()" not in text[text.find("def _apply_project_data"):text.find("self.is_modified = False", text.find("def _apply_project_data")) + 100]:
    text = text.replace(old, new, 1)
    print("[OK] Project load now updates Estimated Sheets / Tiling Preview")
else:
    if "self.update_poster_sheet_estimate()" in text[text.find("def _apply_project_data"):text.find("def _confirm_discard_changes") if "def _confirm_discard_changes" in text else text.find("def _create_central_ui")]:
        print("[SKIP] Project load already updates poster estimate")
    else:
        print("[WARN] Could not find _apply_project_data final refresh block")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_project_load_update_tiling_preview_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Project load now refreshes Estimated Sheets and Tiling Preview")
