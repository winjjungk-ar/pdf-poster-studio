﻿from pathlib import Path
import sys
import ast
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
ENTRY = ROOT / "main.py"

print("ROOT:", ROOT)
print("PYTHON:", sys.executable)
print("main.py exists:", ENTRY.exists())
print("app/main_window.py exists:", MAIN.exists())

if ENTRY.exists():
    print("\n--- main.py first 80 lines ---")
    lines = ENTRY.read_text(encoding="utf-8", errors="replace").splitlines()
    for i, line in enumerate(lines[:80], 1):
        print(f"{i:04d}: {line}")

if MAIN.exists():
    text = MAIN.read_text(encoding="utf-8", errors="replace")
    print("\n--- main_window.py info ---")
    print("chars:", len(text))
    print("lines:", len(text.splitlines()))

    try:
        ast.parse(text)
        print("ast: OK")
    except Exception as exc:
        print("ast: FAILED", exc)

    terms = [
        "PDF Workspace",
        "Source PDFs",
        "Export Order",
        "Print Order",
        "Build Export Order",
        "Build Print Order",
        "export_order_list",
        "workspace_pdf_list",
        "QLabel(",
        "QPushButton(",
        "QTabWidget",
        "settings_tabs",
    ]

    print("\n--- term counts ---")
    for term in terms:
        print(f"{term}: {text.count(term)}")

    print("\n--- likely UI label/button lines ---")
    for idx, line in enumerate(text.splitlines(), 1):
        if (
            "QLabel(" in line
            or "QPushButton(" in line
            or "addTab(" in line
            or "addAction(" in line
        ):
            if any(k in line for k in [
                "Workspace", "Source", "Export", "Print", "Order",
                "PDF", "Open", "Build", "Refresh"
            ]):
                print(f"{idx:05d}: {line}")

    print("\n--- MainWindow class check ---")
    print("class MainWindow:", "class MainWindow" in text)
    print("def __init__:", "def __init__" in text)
    print("def _create_central_ui:", "def _create_central_ui" in text)
    print("def _show_welcome_dialog:", "def _show_welcome_dialog" in text)
