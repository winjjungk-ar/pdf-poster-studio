from PyQt6.QtCore import Qt, QRect, QPoint, pyqtSignal
from PyQt6.QtGui import QPainter, QPen, QColor, QPixmap
from PyQt6.QtWidgets import QLabel


class PdfPreviewWidget(QLabel):
    selection_changed = pyqtSignal(QRect)
    zoom_requested = pyqtSignal(int)

    def __init__(self) -> None:
        super().__init__()

        self._pixmap: QPixmap | None = None
        self._selection_rect = QRect()
        self._drag_start = QPoint()
        self._dragging = False

        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumSize(600, 700)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setStyleSheet(
            "QLabel { border: 1px solid #999; background: #f8f8f8; font-size: 18px; }"
        )

    def set_preview_pixmap(self, pixmap: QPixmap) -> None:
        self._pixmap = pixmap
        self.setPixmap(pixmap)
        self.resize(pixmap.size())
        self.update()

    def clear_preview(self) -> None:
        self._pixmap = None
        self._selection_rect = QRect()
        self.clear()
        self.setText("PDF Preview Area\n\nOpen a PDF to begin.")
        self.update()

    def set_selection_rect(self, rect: QRect) -> None:
        self._selection_rect = rect.normalized()
        self.update()

    def get_selection_rect(self) -> QRect:
        return self._selection_rect.normalized()

    def clear_selection(self) -> None:
        self._selection_rect = QRect()
        self.selection_changed.emit(self._selection_rect)
        self.update()

    def mousePressEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            return

        if self._pixmap is None:
            return

        self._dragging = True
        self._drag_start = event.position().toPoint()
        self._selection_rect = QRect(self._drag_start, self._drag_start)
        self.update()

    def mouseMoveEvent(self, event) -> None:
        if not self._dragging:
            return

        current_pos = event.position().toPoint()
        self._selection_rect = QRect(self._drag_start, current_pos).normalized()
        self.update()

    def mouseReleaseEvent(self, event) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            return

        if not self._dragging:
            return

        self._dragging = False
        current_pos = event.position().toPoint()
        self._selection_rect = QRect(self._drag_start, current_pos).normalized()
        self._selection_rect = self._clamp_rect_to_pixmap(self._selection_rect)

        self.selection_changed.emit(self._selection_rect)
        self.update()

    def wheelEvent(self, event) -> None:
        if self._pixmap is None:
            return

        delta = event.angleDelta().y()

        if delta > 0:
            self.zoom_requested.emit(1)
        elif delta < 0:
            self.zoom_requested.emit(-1)

        event.accept()

    def paintEvent(self, event) -> None:
        super().paintEvent(event)

        if self._selection_rect.isNull() or self._selection_rect.width() <= 0 or self._selection_rect.height() <= 0:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        fill_color = QColor(255, 0, 0, 35)
        border_pen = QPen(QColor(220, 0, 0), 2, Qt.PenStyle.SolidLine)

        painter.fillRect(self._selection_rect, fill_color)
        painter.setPen(border_pen)
        painter.drawRect(self._selection_rect)

        painter.end()

    def _clamp_rect_to_pixmap(self, rect: QRect) -> QRect:
        if self._pixmap is None:
            return rect.normalized()

        bounds = QRect(0, 0, self._pixmap.width(), self._pixmap.height())
        return rect.normalized().intersected(bounds)