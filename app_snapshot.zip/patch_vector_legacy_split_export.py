﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = EXPORTER.with_name(f"poster_exporter.py.bak_vector_legacy_split_{timestamp}")
shutil.copy2(EXPORTER, backup)
print(f"[OK] Backup created: {backup}")

text = EXPORTER.read_text(encoding="utf-8", errors="replace")
original = text

old_block = '''                tile_pix = self._render_tile_to_a4(
                    src_page=src_page,
                    full_clip=full_clip,
                    tile_clip=tile_clip,
                    options=options,
                )

                target_rect = self._get_target_rect(
                    options=options,
                    page_width=A4_WIDTH_PT,
                    page_height=A4_HEIGHT_PT,
                )
                page.insert_image(target_rect, pixmap=tile_pix)
'''

new_block = '''                target_rect = self._get_target_rect(
                    options=options,
                    page_width=A4_WIDTH_PT,
                    page_height=A4_HEIGHT_PT,
                )

                # Keep PDF text/vector graphics sharp by placing the original PDF region
                # directly instead of rasterizing it to an image.
                page.show_pdf_page(
                    target_rect,
                    src_doc,
                    page_index,
                    clip=tile_clip,
                    keep_proportion=False,
                )
'''

if old_block in text:
    text = text.replace(old_block, new_block, 1)
    print("[OK] Replaced legacy split raster insert with vector PDF placement")
else:
    if "Keep PDF text/vector graphics sharp" in text:
        print("[SKIP] Legacy split already uses vector PDF placement")
    else:
        print("[ERROR] Target raster block not found")
        print("        This may mean poster_exporter.py changed. No patch applied.")
        EXPORTER.write_text(original, encoding="utf-8")
        sys.exit(1)

EXPORTER.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(EXPORTER)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = EXPORTER.with_name(f"poster_exporter.py.failed_vector_legacy_split_{timestamp}")
    shutil.copy2(EXPORTER, failed)
    shutil.copy2(backup, EXPORTER)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = EXPORTER.read_text(encoding="utf-8", errors="replace")

required = [
    "Keep PDF text/vector graphics sharp",
    "page.show_pdf_page(",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, EXPORTER)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Classic A4 100% / 2-sheet Poster Print now preserves PDF vector quality")
print("- Text and line art should stay sharp when zoomed")
print("- _render_tile_to_a4 remains in file but is no longer used by this path")
