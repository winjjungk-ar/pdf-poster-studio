﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# ------------------------------------------------------------
# 1) Patch main_window.py small cleanup
# ------------------------------------------------------------
backup = MAIN.with_name(f"main_window.py.bak_release_cleanup_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# About version cleanup
text = text.replace(
    'f"{APP_NAME}\\nVersion: 0.4.0\\nCreator: {CREATOR}"',
    'f"PDF Poster Studio\\nVersion: 0.9.0-workspace\\nCreator: {CREATOR}"'
)

# Old workspace action text cleanup.
# Keep method if still referenced internally, but remove user-facing old label.
text = text.replace(
    '"Open Multiple PDFs as Workspace"',
    '"Open PDFs"'
)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_release_cleanup_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] main_window.py cleanup py_compile passed")

# ------------------------------------------------------------
# 2) Move patch/fix/extract scripts and backup files to dev_archive
# ------------------------------------------------------------
archive_root = ROOT / "dev_archive" / f"cleanup_{timestamp}"
scripts_dir = archive_root / "scripts"
backups_dir = archive_root / "backups"
reports_dir = archive_root / "reports"

scripts_dir.mkdir(parents=True, exist_ok=True)
backups_dir.mkdir(parents=True, exist_ok=True)
reports_dir.mkdir(parents=True, exist_ok=True)

# Move patch/fix/extract scripts
script_patterns = ["patch_*.py", "fix_*.py", "extract_*.py"]
moved_scripts = []

for pattern in script_patterns:
    for path in ROOT.glob(pattern):
        if path.name == Path(__file__).name:
            continue

        target = scripts_dir / path.name
        shutil.move(str(path), str(target))
        moved_scripts.append(path.name)

# Move report/extract txt files except maybe keep release_check_report? Archive it too.
text_patterns = [
    "handover_extract.txt",
    "pdf_collector_extract.txt",
    "multi_pdf_workspace_extract.txt",
    "release_check_report.txt",
]

moved_reports = []

for name in text_patterns:
    path = ROOT / name
    if path.exists():
        target = reports_dir / path.name
        shutil.move(str(path), str(target))
        moved_reports.append(path.name)

# Move backup files under app
moved_backups = []

for path in (ROOT / "app").rglob("*.bak_*"):
    rel = path.relative_to(ROOT / "app")
    target = backups_dir / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(path), str(target))
    moved_backups.append(str(rel))

# This cleanup script itself remains, so user can see what was done.
summary = archive_root / "cleanup_summary.txt"
summary.write_text(
    "\n".join([
        "# Cleanup Summary",
        f"timestamp: {timestamp}",
        "",
        "## moved scripts",
        *[f"- {name}" for name in moved_scripts],
        "",
        "## moved reports",
        *[f"- {name}" for name in moved_reports],
        "",
        "## moved backups",
        *[f"- {name}" for name in moved_backups],
        "",
        "## note",
        "Files were moved, not deleted.",
    ]),
    encoding="utf-8"
)

print("")
print("[OK] Cleanup complete")
print(f"- archive: {archive_root}")
print(f"- moved scripts: {len(moved_scripts)}")
print(f"- moved reports: {len(moved_reports)}")
print(f"- moved backups: {len(moved_backups)}")
print("")
print("Done. Recommended: run release_check.py again only if you keep a copy, or run python main.py.")
