﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

main_backup = MAIN.with_name(f"main_window.py.bak_fix_poster_estimate_open_{timestamp}")
exporter_backup = EXPORTER.with_name(f"poster_exporter.py.bak_fix_poster_estimate_open_{timestamp}")

shutil.copy2(MAIN, main_backup)
shutil.copy2(EXPORTER, exporter_backup)

print(f"[OK] Backup created: {main_backup}")
print(f"[OK] Backup created: {exporter_backup}")

# ------------------------------------------------------------
# 1) poster_exporter.py
#    A4 + 100% keeps legacy 2-sheet Poster Print.
#    Others use scalable tiling.
# ------------------------------------------------------------
exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace")
original_exporter = exporter_text

old = '''        # Poster Print mode now always uses the scalable tiling engine.
        # This keeps Estimated Sheets and actual exported pages consistent.
        self._export_poster_tiling(src_doc, out_doc, selections, options)
        return

        sheet_total = len(selections) * 2
'''

new = '''        # A4 + 100% is the classic Poster Print base: A3-sized output split into 2 A4 sheets.
        # Other paper sizes or scales use the scalable tiling engine.
        paper_size = str(getattr(options, "paper_size", "a4") or "a4").lower()
        poster_scale = float(getattr(options, "poster_scale", 1.0) or 1.0)

        if not (paper_size == "a4" and abs(poster_scale - 1.0) <= 0.000001):
            self._export_poster_tiling(src_doc, out_doc, selections, options)
            return

        sheet_total = len(selections) * 2
'''

if old in exporter_text:
    exporter_text = exporter_text.replace(old, new, 1)
    print("[OK] Restored A4 100% as 2-sheet legacy Poster Print")
else:
    print("[WARN] Exact exporter route block not found. Checking if already patched.")
    if "classic Poster Print base" in exporter_text:
        print("[SKIP] Exporter route already patched")
    else:
        print("[ERROR] Could not patch exporter route")
        EXPORTER.write_text(original_exporter, encoding="utf-8")
        sys.exit(1)

# Move poster tiling numbering to a more visible top area.
old_rect = '''        # Place sheet number in the top margin, outside the main printable content.
        rect = fitz.Rect(
            8 * MM_TO_PT,
            1.5 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            5.0 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=7,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
            align=fitz.TEXT_ALIGN_RIGHT,
        )
'''

new_rect = '''        # Place sheet number near the top, outside the main printable content but still visible.
        rect = fitz.Rect(
            8 * MM_TO_PT,
            5 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            11 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=8,
            fontname="helv",
            color=(0.15, 0.15, 0.15),
            align=fitz.TEXT_ALIGN_RIGHT,
        )
'''

if old_rect in exporter_text:
    exporter_text = exporter_text.replace(old_rect, new_rect, 1)
    print("[OK] Made poster tiling sheet number more visible")
else:
    print("[SKIP] Poster tiling numbering rect block not found or already changed")

EXPORTER.write_text(exporter_text, encoding="utf-8")

# ------------------------------------------------------------
# 2) main_window.py
#    Replace update_poster_sheet_estimate with corrected logic.
# ------------------------------------------------------------
main_text = MAIN.read_text(encoding="utf-8", errors="replace")
original_main = main_text

start_marker = "    def update_poster_sheet_estimate(self) -> None:\n"
start = main_text.find(start_marker)

if start == -1:
    print("[ERROR] update_poster_sheet_estimate not found")
    MAIN.write_text(original_main, encoding="utf-8")
    EXPORTER.write_text(original_exporter, encoding="utf-8")
    sys.exit(1)

next_def = main_text.find("\n    def ", start + len(start_marker))
if next_def == -1:
    print("[ERROR] Could not find end of update_poster_sheet_estimate")
    MAIN.write_text(original_main, encoding="utf-8")
    EXPORTER.write_text(original_exporter, encoding="utf-8")
    sys.exit(1)

new_estimate_func = r'''    def update_poster_sheet_estimate(self) -> None:
        if not hasattr(self, "poster_sheet_estimate_label"):
            return

        try:
            if self.page_count <= 0:
                self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
                return

            paper = self.paper_size_combo.currentData() if hasattr(self, "paper_size_combo") else "a4"
            scale_percent = self.poster_scale_spin.value() if hasattr(self, "poster_scale_spin") else 100
            scale = max(scale_percent / 100.0, 0.1)

            # Classic base behavior:
            # A4 + 100% Poster Print means A3-sized poster output split into 2 A4 sheets.
            if paper == "a4" and scale_percent == 100:
                split_layout = self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else "left_right"

                if split_layout == "top_bottom":
                    layout_text = "1 x 2 = 2"
                    size_text = "Approx Poster Size: A3-like, 210 x 420 mm"
                else:
                    layout_text = "2 x 1 = 2"
                    size_text = "Approx Poster Size: A3, 420 x 297 mm"

                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text} | {size_text}"
                )
                return

            rect = self.preview_label.get_selection_rect()

            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                rect = self.page_selections.get(self.current_page_index, QRect())

            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                self.poster_sheet_estimate_label.setText("Estimated Sheets: select an area first")
                return

            selection = self._preview_rect_to_pdf_selection(rect)

            if paper == "letter":
                page_w = 8.5 * 72
                page_h = 11 * 72
                paper_name = "US Letter"
            else:
                page_w = 210 * 72 / 25.4
                page_h = 297 * 72 / 25.4
                paper_name = "A4"

            margin = 5 * 72 / 25.4
            printable_w = max(page_w - margin * 2, 1)
            printable_h = max(page_h - margin * 2, 1)

            poster_w_pt = selection.width * scale
            poster_h_pt = selection.height * scale

            import math
            cols = max(1, math.ceil(poster_w_pt / printable_w))
            rows = max(1, math.ceil(poster_h_pt / printable_h))
            total = cols * rows

            poster_w_mm = poster_w_pt * 25.4 / 72
            poster_h_mm = poster_h_pt * 25.4 / 72

            self.poster_sheet_estimate_label.setText(
                f"Estimated Sheets: {cols} x {rows} = {total} "
                f"({paper_name}, {scale_percent}%) | "
                f"Approx Poster Size: {poster_w_mm:.0f} x {poster_h_mm:.0f} mm"
            )

        except Exception as exc:
            self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
            self._log(f"Poster sheet estimate error: {exc}")

'''

main_text = main_text[:start] + new_estimate_func + main_text[next_def:]
print("[OK] Replaced poster sheet estimate logic")

# Update estimate when split layout changes too.
if "self.split_layout_combo.currentIndexChanged.connect(self.update_poster_sheet_estimate)" not in main_text:
    old = '''        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")
'''
    new = '''        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")
        self.split_layout_combo.currentIndexChanged.connect(self.update_poster_sheet_estimate)
'''
    if old in main_text:
        main_text = main_text.replace(old, new, 1)
        print("[OK] Estimate updates when split layout changes")
    else:
        print("[WARN] Could not connect split layout estimate update")

# ------------------------------------------------------------
# 3) Auto-open exported PDF after successful export.
# ------------------------------------------------------------
# Workspace branch
old = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Workspace output PDF was created:\\n\\n{output_path}"
                )
                return
'''

new = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Print output PDF was created:\\n\\n{output_path}"
                )
                try:
                    os.startfile(output_path)
                    self._log(f"Opened exported PDF: {output_path}")
                except Exception as exc:
                    self._log(f"Open exported PDF failed: {exc}")
                return
'''

if old in main_text:
    main_text = main_text.replace(old, new, 1)
    print("[OK] Auto-open added for workspace export")
else:
    print("[SKIP] Workspace export completion block not found or already changed")

# Normal single PDF branch
old = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Output PDF was created:\\n\\n{output_path}"
                )
'''

new = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Output PDF was created:\\n\\n{output_path}"
                )
                try:
                    os.startfile(output_path)
                    self._log(f"Opened exported PDF: {output_path}")
                except Exception as exc:
                    self._log(f"Open exported PDF failed: {exc}")
'''

if old in main_text and "Opened exported PDF" not in main_text[main_text.find(old):main_text.find(old)+500]:
    main_text = main_text.replace(old, new, 1)
    print("[OK] Auto-open added for normal export")
else:
    print("[SKIP] Normal export auto-open already present or block not found")

# Separate PDF per page branch: open first exported file.
old = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    "Separate PDF files were created:\\n\\n" + "\\n".join(output_files[:10])
                )
'''
new = '''                QMessageBox.information(
                    self,
                    "Export Complete",
                    "Separate PDF files were created:\\n\\n" + "\\n".join(output_files[:10])
                )
                try:
                    if output_files:
                        os.startfile(output_files[0])
                        self._log(f"Opened first exported PDF: {output_files[0]}")
                except Exception as exc:
                    self._log(f"Open exported PDF failed: {exc}")
'''

if old in main_text and "Opened first exported PDF" not in main_text:
    main_text = main_text.replace(old, new, 1)
    print("[OK] Auto-open added for separate export")
else:
    print("[SKIP] Separate export auto-open already present or block not found")

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 4) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup in [
    (MAIN, main_backup),
    (EXPORTER, exporter_backup),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_fix_poster_estimate_open_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 5) Verify expected markers.
# ------------------------------------------------------------
main_new = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_new = EXPORTER.read_text(encoding="utf-8", errors="replace")

required = [
    ("main", "Approx Poster Size", "Approx Poster Size" in main_new),
    ("main", "os.startfile(output_path)", "os.startfile(output_path)" in main_new),
    ("exporter", "classic Poster Print base", "classic Poster Print base" in exporter_new),
]

missing = [name for scope, name, ok in required if not ok]

if missing:
    print("[WARN] Some expected markers missing:")
    for name in missing:
        print(f"  - {name}")
else:
    print("[OK] Verification markers found")

print("")
print("Done.")
print("- A4 + 100% estimate now shows 2 sheets")
print("- A4 + 100% export uses classic 2-sheet Poster Print")
print("- Estimated label now includes approximate poster size")
print("- Sheet number moved lower in top margin for visibility")
print("- Exported PDF opens automatically with Windows default PDF app")
