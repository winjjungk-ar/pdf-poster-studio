﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_user_guide_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add User Guide menu action before About Program
# ------------------------------------------------------------
old = '''        # Help
        help_menu.addAction("About Program", self.show_about)
'''

new = '''        # Help
        help_menu.addAction("User Guide / How to Use", self.show_user_guide)
        help_menu.addSeparator()
        help_menu.addAction("About Program", self.show_about)
'''

if old in text and "User Guide / How to Use" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Help > User Guide / How to Use")
elif "User Guide / How to Use" in text:
    print("[SKIP] User Guide menu already exists")
else:
    print("[ERROR] Could not find Help menu block")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 2) Add show_user_guide method before show_about
# ------------------------------------------------------------
method = r'''
    def show_user_guide(self) -> None:
        guide = """
<h2>PDF Poster Studio - User Guide</h2>

<p>
PDF Poster Studio helps you open one or more PDF files, select the area you need,
arrange the output order, and create print-ready PDF files.
</p>

<hr>

<h3>1. Basic Workflow</h3>
<ol>
  <li><b>Open PDFs</b>: Open one or more source PDF files.</li>
  <li><b>Select Area</b>: Drag on the preview, or use Auto Select.</li>
  <li><b>Build Print Order</b>: Create the ordered list of selected pages.</li>
  <li><b>Choose Output Files</b>: Select One PDF or Separate PDF per selected page.</li>
  <li><b>Create Poster PDF</b> or <b>Create Single Page PDF</b>.</li>
</ol>

<hr>

<h3>2. How to Create a Poster PDF</h3>
<p>
Use <b>Create Poster PDF</b> when you want to split a large selected area across
multiple sheets such as A4 or US Letter.
</p>

<ol>
  <li>Click <b>Open PDFs</b> and choose your PDF files.</li>
  <li>Select the area you want to print as a poster.</li>
  <li>For many pages, use <b>Auto Select All Pages</b>.</li>
  <li>Open the <b>Poster Print</b> tab.</li>
  <li>Choose <b>Output Paper Size</b>: A4 or US Letter.</li>
  <li>Choose a <b>Poster Size Preset</b>, such as A3, A2, A1, A0, ANSI, or Arch.</li>
  <li>Or manually enter <b>Poster Scale</b>.</li>
  <li>Check <b>Estimated Sheets</b> and <b>Tiling Preview</b>.</li>
  <li>Click <b>Build Print Order</b>.</li>
  <li>Click <b>Create Poster PDF</b>.</li>
</ol>

<p>
Example:
</p>
<ul>
  <li><b>A3 from A4</b>: 2 sheets</li>
  <li><b>A2 from A4</b>: 4 sheets</li>
  <li><b>A1 from A4</b>: 8 sheets</li>
  <li><b>A0 from A4</b>: 16 sheets</li>
</ul>

<hr>

<h3>3. How to Create a Single Page PDF</h3>
<p>
Use <b>Create Single Page PDF</b> when you want the selected area exported as
clean single-page output instead of a tiled poster.
</p>

<ol>
  <li>Open PDFs.</li>
  <li>Select an area on one or more pages.</li>
  <li>Open the <b>Single Page</b> tab.</li>
  <li>Choose <b>Single Page Fit Mode</b>.</li>
  <li>Choose <b>Page Orientation</b>: Auto, Portrait, or Landscape.</li>
  <li>Click <b>Build Print Order</b>.</li>
  <li>Click <b>Create Single Page PDF</b>.</li>
</ol>

<p>
Single Page modes:
</p>
<ul>
  <li><b>Fit Width</b>: Fit the selected area to page width.</li>
  <li><b>Fit Whole Area</b>: Fit the whole selected area without cropping.</li>
  <li><b>Fill Page Crop</b>: Fill the page; some edges may be cropped.</li>
  <li><b>Fit Height</b>: Fit the selected area to page height.</li>
</ul>

<hr>

<h3>4. One PDF vs Separate PDFs</h3>
<p>
In the <b>Export</b> tab, use <b>Output Files</b> to choose how files are created.
</p>

<ul>
  <li>
    <b>One PDF</b>: Combines all selected pages in <b>Print Order</b> into one PDF file.
    This can be used like a PDF combining feature, but with selected areas and poster/single-page processing.
  </li>
  <li>
    <b>Separate PDF per selected page</b>: Creates one PDF file for each selected page.
    In Poster mode, each file may contain multiple tiled sheets.
    In Single Page mode, each file is usually one page.
  </li>
</ul>

<hr>

<h3>5. How to Combine PDFs into One Output PDF</h3>
<p>
This program is not a simple PDF merger, but you can create one combined output PDF
from multiple source PDFs.
</p>

<ol>
  <li>Click <b>Open PDFs</b> and select multiple PDF files.</li>
  <li>Select the pages or areas you want.</li>
  <li>Click <b>Build Print Order</b>.</li>
  <li>Arrange items in <b>Print Order</b> using Move Up / Move Down.</li>
  <li>Set <b>Output Files</b> to <b>One PDF</b>.</li>
  <li>Click <b>Create Poster PDF</b> or <b>Create Single Page PDF</b>.</li>
</ol>

<p>
The result is one PDF containing the selected pages/areas in the order you chose.
</p>

<hr>

<h3>6. Source PDFs and Print Order</h3>
<ul>
  <li><b>Source PDFs</b>: The PDF files loaded into the workspace.</li>
  <li><b>Print Order</b>: The final order of selected pages/areas to export.</li>
  <li>Double-click an item in Print Order to jump to that page in the preview.</li>
</ul>

<hr>

<h3>7. Auto Select</h3>
<ul>
  <li><b>Auto Select Current Page</b>: Detects the content area on the current page.</li>
  <li><b>Auto Select All Pages</b>: Detects content areas across all loaded source PDFs.</li>
  <li>Sensitivity can be changed in the View tab.</li>
</ul>

<hr>

<h3>8. Poster Print Options</h3>
<ul>
  <li><b>Output Paper Size</b>: Choose A4 or US Letter.</li>
  <li><b>Poster Size Preset</b>: Choose common sizes such as A3/A2/A1/A0, ANSI, or Arch.</li>
  <li><b>Poster Scale</b>: Manually adjust scale percentage.</li>
  <li><b>Tiling Preview</b>: Shows how many sheets will be created and how they are arranged.</li>
  <li><b>Tiling Method</b>: Choose margin/overlap/scale behavior.</li>
  <li><b>Show sheet numbers</b>: Prints small sheet numbers such as 1/4, 2/4.</li>
  <li><b>Show cut guide lines</b>: Adds guide lines for cutting and joining sheets.</li>
</ul>

<hr>

<h3>9. Finding Exported Files</h3>
<p>
After export, the generated PDF opens automatically with the default Windows PDF viewer.
You can also click <b>Open Exports Folder</b> to find all output files.
</p>

<hr>

<h3>10. Saving Projects</h3>
<p>
Use <b>File &gt; Save Project As</b> to save your workspace.
The project stores source PDFs, selections, Print Order, Poster settings, and Output Files mode.
</p>
"""

        dialog = QMessageBox(self)
        dialog.setWindowTitle("User Guide / How to Use")
        dialog.setTextFormat(Qt.TextFormat.RichText)
        dialog.setText(guide)
        dialog.setIcon(QMessageBox.Icon.Information)
        dialog.setStandardButtons(QMessageBox.StandardButton.Ok)
        dialog.exec()

'''

if "def show_user_guide" not in text:
    marker = "    def show_about(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find show_about insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added show_user_guide method")
else:
    print("[SKIP] show_user_guide already exists")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_user_guide_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "User Guide / How to Use",
    "def show_user_guide",
    "How to Create a Poster PDF",
    "How to Combine PDFs into One Output PDF",
    "Separate PDF per selected page",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Help > User Guide / How to Use added")
print("- Detailed guide includes Poster, Single Page, One PDF, Separate PDFs, and PDF-combine workflow")
