﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_autoselect_progress_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Import QProgressDialog / QApplication if missing
# ------------------------------------------------------------
if "QProgressDialog" not in text:
    text = text.replace(
        "    QToolBar,\n",
        "    QToolBar,\n    QProgressDialog,\n",
        1
    )
    print("[OK] Added QProgressDialog import")
else:
    print("[SKIP] QProgressDialog already imported")

if "QApplication" not in text:
    text = text.replace(
        "    QProgressDialog,\n",
        "    QProgressDialog,\n    QApplication,\n",
        1
    )
    print("[OK] Added QApplication import")
else:
    print("[SKIP] QApplication already imported")

# ------------------------------------------------------------
# 2) Replace _auto_select_all_pages_for_current_pdf_no_prompt
# ------------------------------------------------------------
start_marker = "    def _auto_select_all_pages_for_current_pdf_no_prompt(self"
start = text.find(start_marker)

if start == -1:
    print("[ERROR] _auto_select_all_pages_for_current_pdf_no_prompt not found")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# End before next method auto_select_all_workspace_pages
end_marker = "\n    def auto_select_all_workspace_pages"
end = text.find(end_marker, start)

if end == -1:
    print("[ERROR] Could not find end of _auto_select_all_pages_for_current_pdf_no_prompt")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

new_helper = r'''    def _auto_select_all_pages_for_current_pdf_no_prompt(
        self,
        progress_dialog=None,
        progress_offset: int = 0,
        progress_label_prefix: str = "",
    ) -> int:
        if not self.current_pdf_path or self.page_count <= 0:
            return 0

        threshold = 245
        if hasattr(self, "auto_select_sensitivity_combo"):
            threshold = int(self.auto_select_sensitivity_combo.currentData())

        selected_count = 0
        original_page_index = self.current_page_index

        for page_index in range(self.page_count):
            if progress_dialog is not None:
                progress_dialog.setValue(progress_offset + page_index)
                progress_dialog.setLabelText(
                    f"{progress_label_prefix}Page {page_index + 1} / {self.page_count}"
                )
                QApplication.processEvents()

                if progress_dialog.wasCanceled():
                    break

            try:
                # Use the normal render path so this behaves like Auto Select Current Page.
                self.current_page_index = page_index
                self._render_current_page()
                QApplication.processEvents()

                rect = self.preview_label.auto_select_content(threshold=threshold, padding=8)

                if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    self.page_selections.pop(page_index, None)
                    self.checked_pages.discard(page_index)
                    continue

                self.page_selections[page_index] = QRect(rect)
                self.checked_pages.add(page_index)
                selected_count += 1

            except Exception as exc:
                self._log(f"Auto Select failed on page {page_index + 1}: {exc}")

        self.current_page_index = max(0, min(original_page_index, self.page_count - 1))
        self._render_current_page()
        self._refresh_page_list_all_text()
        self._refresh_current_page_check_state()
        self._update_checked_pages_label()

        return selected_count

'''

text = text[:start] + new_helper + text[end:]
print("[OK] Replaced current-PDF auto-select helper with progress/same-render version")

# ------------------------------------------------------------
# 3) Replace auto_select_all_workspace_pages
# ------------------------------------------------------------
start_marker = "    def auto_select_all_workspace_pages(self) -> None:\n"
start = text.find(start_marker)

if start == -1:
    print("[ERROR] auto_select_all_workspace_pages not found")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# End before original auto_select_all_pages
end_marker = "\n    def auto_select_all_pages(self) -> None:"
end = text.find(end_marker, start)

if end == -1:
    print("[ERROR] Could not find end of auto_select_all_workspace_pages")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

new_workspace_func = r'''    def auto_select_all_workspace_pages(self) -> None:
        if not hasattr(self, "workspace_items") or not self.workspace_items:
            QMessageBox.information(self, "Auto Select All Pages", "Workspace is empty.")
            return

        result = QMessageBox.question(
            self,
            "Auto Select All Workspace Pages",
            "Automatically detect content area for all pages in all workspace PDFs?\n\n"
            "Existing selections may be replaced.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if result != QMessageBox.StandardButton.Yes:
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        original_workspace_index = self.current_workspace_index
        total_pages = 0

        for item in self.workspace_items:
            try:
                total_pages += int(item.get("page_count", 0))
            except Exception:
                pass

        if total_pages <= 0:
            QMessageBox.warning(self, "Auto Select All Pages", "No pages found in workspace.")
            return

        progress = QProgressDialog(
            "Preparing auto selection...",
            "Cancel",
            0,
            total_pages,
            self,
        )
        progress.setWindowTitle("Auto Select All Pages")
        progress.setWindowModality(Qt.WindowModality.ApplicationModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)

        total_selected = 0
        processed_pages = 0
        canceled = False

        try:
            for workspace_index, item in enumerate(self.workspace_items):
                if progress.wasCanceled():
                    canceled = True
                    break

                pdf_name = Path(item.get("pdf_path", "")).name

                try:
                    self._load_workspace_index(workspace_index)
                    QApplication.processEvents()

                    selected_count = self._auto_select_all_pages_for_current_pdf_no_prompt(
                        progress_dialog=progress,
                        progress_offset=processed_pages,
                        progress_label_prefix=f"{pdf_name} - ",
                    )

                    total_selected += selected_count
                    processed_pages += self.page_count

                    self._save_current_workspace_state()

                    self._log(
                        f"Workspace auto selected: {pdf_name}, "
                        f"selected={selected_count}/{self.page_count}"
                    )

                except Exception as exc:
                    processed_pages += int(item.get("page_count", 0) or 0)
                    self._log(f"Workspace auto select failed: {item.get('pdf_path', '')}: {exc}")

            progress.setValue(total_pages)
            QApplication.processEvents()

        finally:
            progress.close()

        if original_workspace_index is not None and 0 <= original_workspace_index < len(self.workspace_items):
            self._load_workspace_index(original_workspace_index)
        elif self.workspace_items:
            self._load_workspace_index(0)

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        self.is_modified = True

        if canceled:
            QMessageBox.information(
                self,
                "Auto Select All Workspace Pages",
                f"Auto selection was canceled.\n\nSelected pages before cancel: {total_selected}"
            )
        else:
            QMessageBox.information(
                self,
                "Auto Select All Workspace Pages",
                f"Auto selection completed.\n\nSelected pages: {total_selected}/{total_pages}"
            )

'''

text = text[:start] + new_workspace_func + text[end:]
print("[OK] Replaced workspace auto-select with progress version")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_autoselect_progress_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

required = [
    "QProgressDialog",
    "QApplication",
    "progress_dialog",
    "Auto selection completed",
]

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Auto Select All Pages now uses the normal render path per page")
print("- Progress dialog added")
print("- Cancel button added")
