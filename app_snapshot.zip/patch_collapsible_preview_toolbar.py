﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_collapsible_preview_toolbar_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Replace existing floating toolbar block
# ------------------------------------------------------------
start_marker = "        # Floating toolbar over the preview area for frequent view controls.\n"
end_marker = '        export_button = QPushButton("Create PDF")\n'

start = text.find(start_marker)
end = text.find(end_marker, start)

if start == -1 or end == -1:
    print("[ERROR] Could not find existing floating toolbar block.")
    print("        No patch applied.")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

old_block = text[start:end]

new_block = '''        # Collapsible floating toolbar over the preview area for frequent view controls.
        # Default state is collapsed to avoid covering the preview.
        self.preview_floating_toolbar_expanded = False
        self.preview_floating_toolbar = QFrame(self.preview_scroll)
        self.preview_floating_toolbar.setObjectName("previewFloatingToolbar")
        self.preview_floating_toolbar.setStyleSheet("""
            QFrame#previewFloatingToolbar {
                background-color: rgba(255, 248, 240, 230);
                border: 1px solid #EADBC8;
                border-radius: 8px;
            }
            QFrame#previewFloatingToolbar QPushButton {
                color: #395B64;
                background-color: #EAF7F7;
                border: 1px solid #BFE8E8;
                border-radius: 5px;
                padding: 4px 7px;
                font-weight: 700;
                min-width: 42px;
            }
            QFrame#previewFloatingToolbar QPushButton:hover {
                background-color: #DDF3F5;
                border: 1px solid #9EDDE2;
            }
            QFrame#previewFloatingToolbar QPushButton:pressed {
                background-color: #CDECEF;
            }
        """)

        floating_layout = QVBoxLayout(self.preview_floating_toolbar)
        floating_layout.setContentsMargins(6, 5, 6, 5)
        floating_layout.setSpacing(4)

        self.preview_floating_toggle_button = QPushButton("View ▸")
        self.preview_floating_toggle_button.setToolTip("Show or hide preview view controls")
        self.preview_floating_toggle_button.clicked.connect(self.toggle_preview_floating_toolbar)

        floating_zoom_out_button = QPushButton("−")
        floating_zoom_out_button.setToolTip("Zoom Out")
        floating_zoom_out_button.clicked.connect(self.zoom_out)

        floating_zoom_in_button = QPushButton("+")
        floating_zoom_in_button.setToolTip("Zoom In")
        floating_zoom_in_button.clicked.connect(self.zoom_in)

        floating_fit_button = QPushButton("Fit")
        floating_fit_button.setToolTip("Fit Page")
        floating_fit_button.clicked.connect(self.fit_page)

        floating_actual_button = QPushButton("1:1")
        floating_actual_button.setToolTip("Actual Size")
        floating_actual_button.clicked.connect(self.actual_size)

        floating_rotate_left_button = QPushButton("⟲")
        floating_rotate_left_button.setToolTip("Rotate Left")
        floating_rotate_left_button.clicked.connect(self.rotate_left)

        floating_rotate_right_button = QPushButton("⟳")
        floating_rotate_right_button.setToolTip("Rotate Right")
        floating_rotate_right_button.clicked.connect(self.rotate_right)

        floating_reset_button = QPushButton("Reset")
        floating_reset_button.setToolTip("Reset Rotation")
        floating_reset_button.clicked.connect(self.reset_rotation)

        self.preview_floating_buttons = [
            floating_zoom_out_button,
            floating_zoom_in_button,
            floating_fit_button,
            floating_actual_button,
            floating_rotate_left_button,
            floating_rotate_right_button,
            floating_reset_button,
        ]

        floating_layout.addWidget(self.preview_floating_toggle_button)

        for button in self.preview_floating_buttons:
            floating_layout.addWidget(button)
            button.setVisible(False)

        self.preview_floating_toolbar.adjustSize()
        self.preview_floating_toolbar.move(12, 12)
        self.preview_floating_toolbar.raise_()
        self.preview_floating_toolbar.show()

'''

text = text[:start] + new_block + text[end:]
print("[OK] Replaced floating toolbar with collapsible vertical toolbar")

# ------------------------------------------------------------
# 2) Add toggle method if missing
# ------------------------------------------------------------
method = r'''
    def toggle_preview_floating_toolbar(self) -> None:
        if not hasattr(self, "preview_floating_toolbar"):
            return

        self.preview_floating_toolbar_expanded = not getattr(
            self,
            "preview_floating_toolbar_expanded",
            False,
        )

        expanded = self.preview_floating_toolbar_expanded

        if hasattr(self, "preview_floating_toggle_button"):
            self.preview_floating_toggle_button.setText("View ▾" if expanded else "View ▸")

        for button in getattr(self, "preview_floating_buttons", []):
            button.setVisible(expanded)

        self._refresh_preview_floating_toolbar()

'''

if "def toggle_preview_floating_toolbar" not in text:
    marker = "    def _refresh_preview_floating_toolbar(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find _refresh_preview_floating_toolbar insertion point.")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added toggle_preview_floating_toolbar method")
else:
    print("[SKIP] toggle_preview_floating_toolbar already exists")

# ------------------------------------------------------------
# 3) Make refresh method keep correct size/position
# ------------------------------------------------------------
old_refresh = '''    def _refresh_preview_floating_toolbar(self) -> None:
        if not hasattr(self, "preview_floating_toolbar"):
            return

        self.preview_floating_toolbar.adjustSize()
        self.preview_floating_toolbar.move(12, 12)
        self.preview_floating_toolbar.raise_()
        self.preview_floating_toolbar.show()
'''

new_refresh = '''    def _refresh_preview_floating_toolbar(self) -> None:
        if not hasattr(self, "preview_floating_toolbar"):
            return

        self.preview_floating_toolbar.adjustSize()
        self.preview_floating_toolbar.move(12, 12)
        self.preview_floating_toolbar.raise_()
        self.preview_floating_toolbar.show()
'''

# Currently same, but replace to normalize if found.
if old_refresh in text:
    text = text.replace(old_refresh, new_refresh, 1)
    print("[OK] Normalized _refresh_preview_floating_toolbar")
else:
    print("[SKIP] _refresh_preview_floating_toolbar block not found exactly")

# ------------------------------------------------------------
# 4) Release Notes update
# ------------------------------------------------------------
if "Collapsible vertical preview toolbar" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Collapsible vertical preview toolbar</b>: Preview view controls now stay hidden until the View button is opened.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 5) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_collapsible_preview_toolbar_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "View ▸",
    "View ▾",
    "def toggle_preview_floating_toolbar",
    "preview_floating_toolbar_expanded",
    "Collapsible vertical preview toolbar",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Preview floating toolbar is now vertical and collapsible")
print("- Default state: collapsed")
print("- Click View ▸ to open controls")
