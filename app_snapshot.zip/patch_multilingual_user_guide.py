﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_multilingual_user_guide_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

new_show_user_guide = r'''    def show_user_guide(self) -> None:
        guides = {
            "한국어": """
<h2>PDF Poster Studio - 사용 방법</h2>

<p>
PDF Poster Studio는 PDF 파일에서 필요한 영역을 선택하고, 큰 지도/포스터/게임맵/도면을
A4 또는 US Letter 여러 장으로 나누어 출력할 수 있게 도와주는 프로그램입니다.
</p>

<hr>

<h3>1. 기본 작업 순서</h3>
<ol>
  <li><b>Open PDFs</b>: 하나 이상의 원본 PDF 파일을 엽니다.</li>
  <li><b>영역 선택</b>: 미리보기 화면에서 드래그하거나 Auto Select를 사용합니다.</li>
  <li><b>Build Print Order</b>: 출력할 페이지/영역의 순서를 만듭니다.</li>
  <li><b>Output Files</b>: 하나의 PDF로 만들지, 선택 항목별로 따로 만들지 선택합니다.</li>
  <li><b>Create Poster PDF</b> 또는 <b>Create Single Page PDF</b>를 실행합니다.</li>
</ol>

<hr>

<h3>2. 게임 맵 / 벽 포스터 만들기</h3>
<ol>
  <li><b>Open PDFs</b>로 지도나 포스터 PDF를 엽니다.</li>
  <li>출력할 영역을 선택합니다.</li>
  <li><b>Poster Print</b> 탭에서 용지 크기(A4 또는 US Letter)를 선택합니다.</li>
  <li><b>Poster Small / Medium / Large / Huge</b> 같은 프리셋을 선택합니다.</li>
  <li><b>Tiling Preview</b>에서 몇 장으로 나뉘는지 확인합니다.</li>
  <li><b>Create Poster PDF</b>를 누릅니다.</li>
</ol>

<p>
Hobby preset은 현재 선택된 Output Paper Size를 따릅니다.
예: A4 + Poster Medium은 A4 4장, US Letter + Poster Medium은 Letter 4장입니다.
</p>

<hr>

<h3>3. 포스터 분할 PDF 만들기</h3>
<p>
큰 선택 영역을 여러 장의 종이로 나누어 인쇄하려면 <b>Create Poster PDF</b>를 사용합니다.
</p>

<ol>
  <li>PDF를 열고 원하는 영역을 선택합니다.</li>
  <li><b>Poster Print</b> 탭에서 Output Paper Size를 선택합니다.</li>
  <li>A3/A2/A1/A0, ANSI, Arch 또는 Hobby preset을 선택합니다.</li>
  <li>필요하면 Poster Scale을 수동으로 조정합니다.</li>
  <li>Estimated Sheets와 Tiling Preview를 확인합니다.</li>
  <li>Build Print Order 후 Create Poster PDF를 실행합니다.</li>
</ol>

<hr>

<h3>4. 단일 페이지 PDF 만들기</h3>
<p>
선택한 영역을 포스터 분할이 아닌 깔끔한 단일 페이지 형태로 만들려면
<b>Create Single Page PDF</b>를 사용합니다.
</p>

<ul>
  <li><b>Fit Width</b>: 선택 영역의 가로폭을 페이지에 맞춥니다.</li>
  <li><b>Fit Whole Area</b>: 선택 영역 전체가 잘리지 않게 맞춥니다.</li>
  <li><b>Fill Page Crop</b>: 페이지를 꽉 채우며 일부가 잘릴 수 있습니다.</li>
  <li><b>Fit Height</b>: 선택 영역의 세로높이를 페이지에 맞춥니다.</li>
</ul>

<hr>

<h3>5. One PDF / Separate PDF</h3>
<ul>
  <li><b>One PDF</b>: Print Order에 있는 모든 선택 항목을 하나의 PDF로 만듭니다.</li>
  <li><b>Separate PDF per selected page</b>: 선택한 페이지/영역마다 별도 PDF를 만듭니다.</li>
</ul>

<p>
여러 PDF에서 필요한 부분만 골라 <b>One PDF</b>로 만들면 PDF 합치기처럼 사용할 수 있습니다.
단, 이 프로그램은 단순 병합기가 아니라 선택 영역과 포스터/단일 페이지 처리를 함께 적용합니다.
</p>

<hr>

<h3>6. Source PDFs / Print Order</h3>
<ul>
  <li><b>Source PDFs</b>: 작업에 불러온 원본 PDF 목록입니다.</li>
  <li><b>Print Order</b>: 최종 출력 순서입니다.</li>
  <li>Print Order 항목을 더블클릭하면 해당 PDF/페이지로 이동합니다.</li>
</ul>

<hr>

<h3>7. Auto Select</h3>
<ul>
  <li><b>Auto Select Current Page</b>: 현재 페이지의 내용 영역을 자동 선택합니다.</li>
  <li><b>Auto Select All Pages</b>: 불러온 모든 Source PDFs의 페이지를 자동 선택합니다.</li>
  <li>View 탭에서 감도(Sensitivity)를 조정할 수 있습니다.</li>
</ul>

<hr>

<h3>8. 출력 파일 찾기</h3>
<p>
Export가 끝나면 생성된 PDF가 Windows 기본 PDF 프로그램으로 자동 열립니다.
또한 <b>Open Exports Folder</b> 버튼으로 출력 폴더를 바로 열 수 있습니다.
</p>

<hr>

<h3>9. 프로젝트 저장</h3>
<p>
<b>File &gt; Save Project As</b>로 작업 상태를 저장할 수 있습니다.
Source PDFs, 선택 영역, Print Order, Poster 설정, Output Files 설정이 저장됩니다.
</p>
""",

            "日本語": """
<h2>PDF Poster Studio - 使い方</h2>

<p>
PDF Poster Studio は、PDF 内の必要な範囲を選択し、大きな地図、ポスター、ゲームマップ、
図面などを A4 または US Letter の複数ページに分割して印刷用 PDF を作成するツールです。
</p>

<hr>

<h3>1. 基本の流れ</h3>
<ol>
  <li><b>Open PDFs</b>: 1つ以上の元 PDF を開きます。</li>
  <li><b>範囲選択</b>: プレビュー上でドラッグするか、Auto Select を使います。</li>
  <li><b>Build Print Order</b>: 出力するページ/範囲の順番を作成します。</li>
  <li><b>Output Files</b>: 1つの PDF にまとめるか、選択ページごとに分けるか選びます。</li>
  <li><b>Create Poster PDF</b> または <b>Create Single Page PDF</b> を実行します。</li>
</ol>

<hr>

<h3>2. ゲームマップ / 壁ポスターを印刷する</h3>
<ol>
  <li><b>Open PDFs</b> で地図やポスター PDF を開きます。</li>
  <li>印刷したい範囲を選択します。</li>
  <li><b>Poster Print</b> タブで用紙サイズ（A4 または US Letter）を選びます。</li>
  <li><b>Poster Small / Medium / Large / Huge</b> などのプリセットを選びます。</li>
  <li><b>Tiling Preview</b> で何枚に分割されるか確認します。</li>
  <li><b>Create Poster PDF</b> をクリックします。</li>
</ol>

<p>
Hobby プリセットは現在選択されている Output Paper Size を使います。
例: A4 + Poster Medium は A4 4枚、US Letter + Poster Medium は Letter 4枚です。
</p>

<hr>

<h3>3. ポスター分割 PDF を作成する</h3>
<p>
大きな選択範囲を複数枚の紙に分割して印刷したい場合は <b>Create Poster PDF</b> を使います。
</p>

<ol>
  <li>PDF を開き、必要な範囲を選択します。</li>
  <li><b>Poster Print</b> タブで Output Paper Size を選びます。</li>
  <li>A3/A2/A1/A0、ANSI、Arch、または Hobby プリセットを選びます。</li>
  <li>必要に応じて Poster Scale を手動で調整します。</li>
  <li>Estimated Sheets と Tiling Preview を確認します。</li>
  <li>Build Print Order の後、Create Poster PDF を実行します。</li>
</ol>

<hr>

<h3>4. 単一ページ PDF を作成する</h3>
<p>
選択範囲を分割せず、きれいな単一ページとして出力したい場合は
<b>Create Single Page PDF</b> を使います。
</p>

<ul>
  <li><b>Fit Width</b>: 選択範囲の幅をページ幅に合わせます。</li>
  <li><b>Fit Whole Area</b>: 選択範囲全体が切れないように収めます。</li>
  <li><b>Fill Page Crop</b>: ページいっぱいに配置します。一部が切れる場合があります。</li>
  <li><b>Fit Height</b>: 選択範囲の高さをページ高さに合わせます。</li>
</ul>

<hr>

<h3>5. One PDF / Separate PDF</h3>
<ul>
  <li><b>One PDF</b>: Print Order 内のすべての選択項目を1つの PDF にまとめます。</li>
  <li><b>Separate PDF per selected page</b>: 選択ページ/範囲ごとに別々の PDF を作成します。</li>
</ul>

<p>
複数 PDF から必要な部分だけを選び、<b>One PDF</b> として出力すれば、
PDF 結合のようにも使えます。ただし、このプログラムは単純な結合ではなく、
選択範囲やポスター/単一ページ処理を適用できます。
</p>

<hr>

<h3>6. Source PDFs / Print Order</h3>
<ul>
  <li><b>Source PDFs</b>: ワークスペースに読み込んだ元 PDF の一覧です。</li>
  <li><b>Print Order</b>: 最終的な出力順です。</li>
  <li>Print Order の項目をダブルクリックすると、その PDF/ページへ移動します。</li>
</ul>

<hr>

<h3>7. Auto Select</h3>
<ul>
  <li><b>Auto Select Current Page</b>: 現在ページの内容範囲を自動選択します。</li>
  <li><b>Auto Select All Pages</b>: 読み込んだすべての Source PDFs のページを自動選択します。</li>
  <li>View タブで感度（Sensitivity）を調整できます。</li>
</ul>

<hr>

<h3>8. 出力ファイルを探す</h3>
<p>
Export 完了後、作成された PDF は Windows の既定 PDF ビューアで自動的に開きます。
また、<b>Open Exports Folder</b> ボタンで出力フォルダを開けます。
</p>

<hr>

<h3>9. プロジェクト保存</h3>
<p>
<b>File &gt; Save Project As</b> で作業状態を保存できます。
Source PDFs、選択範囲、Print Order、Poster 設定、Output Files 設定が保存されます。
</p>
""",

            "中文（简体）": """
<h2>PDF Poster Studio - 使用指南</h2>

<p>
PDF Poster Studio 可以帮助你从 PDF 中选择需要的区域，并把大型地图、海报、游戏地图、
工程图纸等内容分割到 A4 或 US Letter 多张纸上，生成可打印的 PDF。
</p>

<hr>

<h3>1. 基本流程</h3>
<ol>
  <li><b>Open PDFs</b>：打开一个或多个源 PDF 文件。</li>
  <li><b>选择区域</b>：在预览中拖拽选择，或使用 Auto Select。</li>
  <li><b>Build Print Order</b>：建立最终输出顺序。</li>
  <li><b>Output Files</b>：选择生成一个 PDF，或每个选择页生成单独 PDF。</li>
  <li>点击 <b>Create Poster PDF</b> 或 <b>Create Single Page PDF</b>。</li>
</ol>

<hr>

<h3>2. 打印游戏地图 / 墙上海报</h3>
<ol>
  <li>使用 <b>Open PDFs</b> 打开地图或海报 PDF。</li>
  <li>选择要打印的地图/海报区域。</li>
  <li>在 <b>Poster Print</b> 标签中选择纸张大小：A4 或 US Letter。</li>
  <li>选择 <b>Poster Small / Medium / Large / Huge</b> 等预设。</li>
  <li>查看 <b>Tiling Preview</b>，确认会分成多少张纸。</li>
  <li>点击 <b>Create Poster PDF</b>。</li>
</ol>

<p>
Hobby 预设会使用当前选择的 Output Paper Size。
例如：A4 + Poster Medium 会生成 A4 4张；US Letter + Poster Medium 会生成 Letter 4张。
</p>

<hr>

<h3>3. 创建分割海报 PDF</h3>
<p>
如果想把一个大区域分割到多张纸上打印，请使用 <b>Create Poster PDF</b>。
</p>

<ol>
  <li>打开 PDF 并选择需要的区域。</li>
  <li>在 <b>Poster Print</b> 标签中选择 Output Paper Size。</li>
  <li>选择 A3/A2/A1/A0、ANSI、Arch 或 Hobby 预设。</li>
  <li>也可以手动调整 Poster Scale。</li>
  <li>确认 Estimated Sheets 和 Tiling Preview。</li>
  <li>Build Print Order 后，点击 Create Poster PDF。</li>
</ol>

<hr>

<h3>4. 创建单页 PDF</h3>
<p>
如果不需要分割海报，而是想把选择区域输出为干净的单页 PDF，
请使用 <b>Create Single Page PDF</b>。
</p>

<ul>
  <li><b>Fit Width</b>：让选择区域按页面宽度适配。</li>
  <li><b>Fit Whole Area</b>：完整显示选择区域，不裁切。</li>
  <li><b>Fill Page Crop</b>：填满页面，可能会裁切边缘。</li>
  <li><b>Fit Height</b>：让选择区域按页面高度适配。</li>
</ul>

<hr>

<h3>5. One PDF / Separate PDF</h3>
<ul>
  <li><b>One PDF</b>：把 Print Order 中的所有选择项合并为一个 PDF。</li>
  <li><b>Separate PDF per selected page</b>：每个选择页/区域生成一个单独 PDF。</li>
</ul>

<p>
你也可以从多个 PDF 中选择需要的部分，然后用 <b>One PDF</b> 输出成一个文件。
这类似 PDF 合并功能，但本程序还可以应用区域选择、海报分割或单页输出处理。
</p>

<hr>

<h3>6. Source PDFs / Print Order</h3>
<ul>
  <li><b>Source PDFs</b>：已加载到工作区的源 PDF 列表。</li>
  <li><b>Print Order</b>：最终输出顺序。</li>
  <li>双击 Print Order 中的项目，可以跳转到对应的 PDF/页面。</li>
</ul>

<hr>

<h3>7. Auto Select</h3>
<ul>
  <li><b>Auto Select Current Page</b>：自动检测当前页面内容区域。</li>
  <li><b>Auto Select All Pages</b>：自动检测所有已加载 Source PDFs 的页面。</li>
  <li>可以在 View 标签中调整灵敏度（Sensitivity）。</li>
</ul>

<hr>

<h3>8. 查找输出文件</h3>
<p>
导出完成后，生成的 PDF 会自动用 Windows 默认 PDF 查看器打开。
也可以点击 <b>Open Exports Folder</b> 打开输出文件夹。
</p>

<hr>

<h3>9. 保存项目</h3>
<p>
使用 <b>File &gt; Save Project As</b> 保存工作区。
项目会保存 Source PDFs、选择区域、Print Order、Poster 设置和 Output Files 设置。
</p>
"""
        }

        dialog = QDialog(self)
        dialog.setWindowTitle("User Guide / How to Use")
        dialog.setMinimumSize(800, 640)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        language_layout = QHBoxLayout()
        language_label = QLabel("Language")
        language_combo = QComboBox()
        language_combo.addItems(list(guides.keys()))
        language_combo.setCurrentText("한국어")
        language_layout.addWidget(language_label)
        language_layout.addWidget(language_combo)
        language_layout.addStretch()

        guide_view = QTextEdit()
        guide_view.setReadOnly(True)
        guide_view.setHtml(guides["한국어"])
        guide_view.setStyleSheet("""
            QTextEdit {
                background-color: #FFFDF8;
                color: #2F4F5F;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 10px;
                font-family: Segoe UI, Arial;
                font-size: 10.5pt;
            }
        """)

        def change_language() -> None:
            guide_view.setHtml(guides.get(language_combo.currentText(), guides["한국어"]))

        language_combo.currentIndexChanged.connect(change_language)

        close_button = QPushButton("Close")
        close_button.clicked.connect(dialog.accept)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_button)

        layout.addLayout(language_layout)
        layout.addWidget(guide_view)
        layout.addLayout(button_layout)

        dialog.exec()
'''

try:
    text = replace_function(text, "show_user_guide", new_show_user_guide)
    print("[OK] Replaced show_user_guide with Korean/Japanese/Chinese guide")
except Exception as exc:
    print(f"[ERROR] Failed to replace show_user_guide: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Update release notes
release_marker = "<li><b>Hobby poster presets</b>: Poster Small, Medium, Large, Huge.</li>"
release_insert = release_marker + "\n  <li><b>Multilingual User Guide</b>: 한국어, 日本語, 中文（简体）.</li>"

if release_marker in text and "Multilingual User Guide" not in text:
    text = text.replace(release_marker, release_insert, 1)
    print("[OK] Release Notes updated for multilingual guide")
else:
    print("[SKIP] Release Notes already updated or marker not found")

# Update welcome what's new
welcome_marker = '''            "• See Help > Release Notes for details\\n\\n"
'''
welcome_insert = '''            "• User Guide supports 한국어, 日本語, 中文（简体）\\n"
            "• See Help > Release Notes for details\\n\\n"
'''

if welcome_marker in text and "User Guide supports 한국어" not in text:
    text = text.replace(welcome_marker, welcome_insert, 1)
    print("[OK] Welcome What's New updated for multilingual guide")
else:
    print("[SKIP] Welcome multilingual note already present or marker not found")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_multilingual_user_guide_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    '"한국어"',
    '"日本語"',
    '"中文（简体）"',
    "Multilingual User Guide",
    "language_combo",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- User Guide now supports 한국어 / 日本語 / 中文（简体）")
print("- Release Notes updated")
print("- Welcome What's New updated")
