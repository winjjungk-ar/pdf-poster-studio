﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_home_tasks_cleanup_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 0) Fix bad literal \N shown in UI text
# ------------------------------------------------------------
bad_count = text.count("\\N")
if bad_count:
    text = text.replace("\\N", "\\n")
    print(f"[OK] Replaced bad literal \\N occurrences: {bad_count}")
else:
    print("[OK] No bad literal \\N found")

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

# ------------------------------------------------------------
# 1) Improve Make Poster task
# ------------------------------------------------------------
new_task_make_poster = r'''    def task_make_poster(self) -> None:
        self._set_combo_by_data_if_exists("export_type_combo", "a3_split")
        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()

        QMessageBox.information(
            self,
            "Make Poster",
            "Make Poster creates tiled poster output.\n\n"
            "Recommended workflow:\n"
            "1. Choose Output Area:\n"
            "   - Whole Page for full maps/images/pages\n"
            "   - Selected Area for only part of a page\n"
            "2. Choose Output Paper Size and Poster Size Preset.\n"
            "3. Check Tiling Preview.\n"
            "4. Build Print Order.\n"
            "5. Click Poster PDF in the toolbar."
        )

        if hasattr(self, "settings_tabs") and hasattr(self, "a3_split_group"):
            self.settings_tabs.setCurrentWidget(self.a3_split_group)

'''

try:
    text = replace_function(text, "task_make_poster", new_task_make_poster)
    print("[OK] Replaced task_make_poster")
except Exception as exc:
    print(f"[WARN] Could not replace task_make_poster: {exc}")

# ------------------------------------------------------------
# 2) Implement Rotate Pages task
# ------------------------------------------------------------
new_task_rotate_pages = r'''    def task_rotate_pages(self) -> None:
        if self.page_count <= 0:
            result = QMessageBox.question(
                self,
                "Rotate Pages",
                "No source file is open yet.\n\nOpen PDFs / Images now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result == QMessageBox.StandardButton.Yes:
                self.open_pdfs()

            return

        target_dialog = QMessageBox(self)
        target_dialog.setWindowTitle("Rotate Pages")
        target_dialog.setText("Which pages do you want to rotate?")

        current_button = target_dialog.addButton("Current Page", QMessageBox.ButtonRole.AcceptRole)
        checked_button = target_dialog.addButton("Checked Pages", QMessageBox.ButtonRole.ActionRole)
        all_button = target_dialog.addButton("All Pages", QMessageBox.ButtonRole.ActionRole)
        cancel_button = target_dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        target_dialog.exec()
        target_clicked = target_dialog.clickedButton()

        if target_clicked == cancel_button:
            return

        if target_clicked == current_button:
            target_pages = [self.current_page_index]
        elif target_clicked == checked_button:
            if not self.checked_pages:
                QMessageBox.information(
                    self,
                    "Rotate Pages",
                    "No checked pages exist.\n\nCheck pages first or choose Current Page / All Pages."
                )
                return
            target_pages = sorted(self.checked_pages)
        elif target_clicked == all_button:
            target_pages = list(range(self.page_count))
        else:
            return

        op_dialog = QMessageBox(self)
        op_dialog.setWindowTitle("Rotate Pages")
        op_dialog.setText(f"Rotation target: {len(target_pages)} page(s)\n\nChoose rotation operation.")

        left_button = op_dialog.addButton("Rotate Left", QMessageBox.ButtonRole.AcceptRole)
        right_button = op_dialog.addButton("Rotate Right", QMessageBox.ButtonRole.ActionRole)
        reset_button = op_dialog.addButton("Reset Rotation", QMessageBox.ButtonRole.ActionRole)
        cancel_button = op_dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        op_dialog.exec()
        op_clicked = op_dialog.clickedButton()

        if op_clicked == cancel_button:
            return

        self._push_undo_state()
        self._save_current_selection()

        for page_index in target_pages:
            old_degrees = int(self.page_rotations.get(page_index, 0)) % 360

            if op_clicked == left_button:
                new_degrees = (old_degrees - 90) % 360
            elif op_clicked == right_button:
                new_degrees = (old_degrees + 90) % 360
            elif op_clicked == reset_button:
                new_degrees = 0
            else:
                continue

            if new_degrees == 0:
                self.page_rotations.pop(page_index, None)
            else:
                self.page_rotations[page_index] = new_degrees

        self.rotation_degrees = self._get_current_rotation_degrees()
        self._render_current_page()

        if hasattr(self, "export_order_list") and self.export_order_list.count() > 0:
            # Rebuild thumbnails so Print Order reflects rotation.
            entries = self._get_export_order_entries()
            self.export_order_list.clear()
            for workspace_index, page_index in entries:
                self._add_export_order_item(workspace_index, page_index)

        self.is_modified = True
        self.update_action_summary()

        QMessageBox.information(
            self,
            "Rotate Pages",
            f"Rotation updated for {len(target_pages)} page(s).\n\n"
            "Create a PDF to save the rotated output."
        )

'''

try:
    text = replace_function(text, "task_rotate_pages", new_task_rotate_pages)
    print("[OK] Replaced task_rotate_pages with actual rotate workflow")
except Exception as exc:
    print(f"[WARN] Could not replace task_rotate_pages: {exc}")

# ------------------------------------------------------------
# 3) Improve Selected Area PDF task
# ------------------------------------------------------------
new_task_selected_area_pdf = r'''    def task_selected_area_pdf(self) -> None:
        self._set_combo_by_data_if_exists("output_area_combo", "selected_area")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()

        QMessageBox.information(
            self,
            "Selected Area PDF",
            "Selected Area PDF exports only the area you select.\n\n"
            "Recommended workflow:\n"
            "1. Drag to select an area in the preview, or use Auto Select.\n"
            "2. Build Print Order.\n"
            "3. Choose Output Files.\n"
            "4. Click Single Page PDF in the toolbar."
        )

        if hasattr(self, "settings_tabs") and hasattr(self, "selection_only_group"):
            self.settings_tabs.setCurrentWidget(self.selection_only_group)

'''

try:
    text = replace_function(text, "task_selected_area_pdf", new_task_selected_area_pdf)
    print("[OK] Replaced task_selected_area_pdf")
except Exception as exc:
    print(f"[WARN] Could not replace task_selected_area_pdf: {exc}")

# ------------------------------------------------------------
# 4) Release Notes update
# ------------------------------------------------------------
if "Home task cleanup and Rotate Pages workflow" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Home task cleanup and Rotate Pages workflow</b>: Home task messages were cleaned up and Rotate Pages can now rotate current, checked, or all pages.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 5) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_home_tasks_cleanup_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Which pages do you want to rotate?",
    "Rotation target:",
    "Recommended workflow:",
    "Home task cleanup and Rotate Pages workflow",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Home task messages cleaned")
print("- Rotate Pages task now has actual page rotation workflow")
print("- Bad literal \\N text fixed if present")
