﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_rotate_task_build_order_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

new_task_rotate_pages = r'''    def task_rotate_pages(self) -> None:
        if self.page_count <= 0:
            result = QMessageBox.question(
                self,
                "Rotate Pages",
                "No source file is open yet.\n\nOpen PDFs / Images now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result == QMessageBox.StandardButton.Yes:
                self.open_pdfs()

            return

        target_dialog = QMessageBox(self)
        target_dialog.setWindowTitle("Rotate Pages")
        target_dialog.setText("Which pages do you want to rotate?")

        current_button = target_dialog.addButton("Current Page", QMessageBox.ButtonRole.AcceptRole)
        checked_button = target_dialog.addButton("Checked Pages", QMessageBox.ButtonRole.ActionRole)
        all_button = target_dialog.addButton("All Pages", QMessageBox.ButtonRole.ActionRole)
        cancel_button = target_dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        target_dialog.exec()
        target_clicked = target_dialog.clickedButton()

        if target_clicked == cancel_button:
            return

        if target_clicked == current_button:
            target_pages = [self.current_page_index]
        elif target_clicked == checked_button:
            if not self.checked_pages:
                QMessageBox.information(
                    self,
                    "Rotate Pages",
                    "No checked pages exist.\n\nCheck pages first or choose Current Page / All Pages."
                )
                return
            target_pages = sorted(self.checked_pages)
        elif target_clicked == all_button:
            target_pages = list(range(self.page_count))
        else:
            return

        op_dialog = QMessageBox(self)
        op_dialog.setWindowTitle("Rotate Pages")
        op_dialog.setText(f"Rotation target: {len(target_pages)} page(s)\n\nChoose rotation operation.")

        left_button = op_dialog.addButton("Rotate Left", QMessageBox.ButtonRole.AcceptRole)
        right_button = op_dialog.addButton("Rotate Right", QMessageBox.ButtonRole.ActionRole)
        reset_button = op_dialog.addButton("Reset Rotation", QMessageBox.ButtonRole.ActionRole)
        cancel_button = op_dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        op_dialog.exec()
        op_clicked = op_dialog.clickedButton()

        if op_clicked == cancel_button:
            return

        self._push_undo_state()
        self._save_current_selection()

        for page_index in target_pages:
            old_degrees = int(self.page_rotations.get(page_index, 0)) % 360

            if op_clicked == left_button:
                new_degrees = (old_degrees - 90) % 360
            elif op_clicked == right_button:
                new_degrees = (old_degrees + 90) % 360
            elif op_clicked == reset_button:
                new_degrees = 0
            else:
                continue

            if new_degrees == 0:
                self.page_rotations.pop(page_index, None)
            else:
                self.page_rotations[page_index] = new_degrees

        # Prepare output workflow for saving rotated pages.
        self._set_combo_by_data_if_exists("output_area_combo", "whole_page")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self._set_combo_by_data_if_exists("batch_output_combo", "single_pdf")
        self.update_export_option_states()
        self.update_output_area_states()

        self.checked_pages = set(target_pages)

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

            workspace_index = self.current_workspace_index if self.current_workspace_index is not None else 0

            for page_index in target_pages:
                self._add_export_order_item(workspace_index, page_index)

        self.rotation_degrees = self._get_current_rotation_degrees()
        self._render_current_page()
        self._refresh_page_list_all_text()
        self._refresh_current_page_check_state()
        self._update_checked_pages_label()
        self._refresh_workspace_list_text()
        self.update_action_summary()

        self.is_modified = True

        if hasattr(self, "settings_tabs"):
            for index in range(self.settings_tabs.count()):
                if self.settings_tabs.tabText(index) == "Status":
                    self.settings_tabs.setCurrentIndex(index)
                    break

        QMessageBox.information(
            self,
            "Rotate Pages",
            f"Rotation updated for {len(target_pages)} page(s).\n\n"
            "Print Order was prepared using Whole Page mode.\n"
            "Click Single Page PDF in the toolbar to save the rotated PDF."
        )

'''

try:
    text = replace_function(text, "task_rotate_pages", new_task_rotate_pages)
    print("[OK] Rotate Pages task now builds Print Order and prepares export")
except Exception as exc:
    print(f"[ERROR] Failed to replace task_rotate_pages: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Release Notes
if "Rotate Pages task prepares export" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Rotate Pages task prepares export</b>: Rotated pages are added to Print Order using Whole Page mode and One PDF output.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_rotate_task_build_order_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Print Order was prepared using Whole Page mode",
    "Rotate Pages task prepares export",
    "Click Single Page PDF in the toolbar to save the rotated PDF",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Rotate Pages task now prepares Print Order")
print("- Output is set to Whole Page + Single Page Mode + One PDF")
print("- User can save rotated PDF with Single Page PDF toolbar button")
