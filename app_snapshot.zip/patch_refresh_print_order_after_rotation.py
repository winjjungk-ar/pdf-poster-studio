﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_refresh_print_order_after_rotation_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def insert_before_function(source: str, func_name: str, code: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + code + "\n" + "".join(lines[node.lineno - 1:])

# ------------------------------------------------------------
# 1) Add helper to refresh Print Order thumbnails
# ------------------------------------------------------------
helper = r'''
    def refresh_print_order_thumbnails(self) -> None:
        """Rebuild Print Order items so thumbnails reflect page rotation changes."""
        if not hasattr(self, "export_order_list"):
            return

        if self.export_order_list.count() <= 0:
            return

        entries = self._get_export_order_entries()

        if not entries:
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        current_row = self.export_order_list.currentRow()

        self.export_order_list.clear()

        for workspace_index, page_index in entries:
            self._add_export_order_item(workspace_index, page_index)

        if 0 <= current_row < self.export_order_list.count():
            self.export_order_list.setCurrentRow(current_row)

        if hasattr(self, "update_action_summary"):
            self.update_action_summary()

        self._log("Print Order thumbnails refreshed.")

'''

if "def refresh_print_order_thumbnails" not in text:
    try:
        text = insert_before_function(text, "rotate_left", helper)
        print("[OK] Added refresh_print_order_thumbnails helper")
    except Exception as exc:
        print(f"[ERROR] Could not insert helper: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] refresh_print_order_thumbnails already exists")

# ------------------------------------------------------------
# 2) Call helper after rotate_left
# ------------------------------------------------------------
old = '''        self._show_pixmap()
        self._log(f"Rotate Left applied on page {self.current_page_index + 1}: {new_degrees} degrees.")
'''

new = '''        self._show_pixmap()
        self.refresh_print_order_thumbnails()
        self._log(f"Rotate Left applied on page {self.current_page_index + 1}: {new_degrees} degrees.")
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] rotate_left now refreshes Print Order thumbnails")
else:
    if "Rotate Left applied on page" in text and "refresh_print_order_thumbnails()" in text:
        print("[SKIP] rotate_left refresh may already be present")
    else:
        print("[WARN] rotate_left block not found")

# ------------------------------------------------------------
# 3) Call helper after rotate_right
# ------------------------------------------------------------
old = '''        self._show_pixmap()
        self._log(f"Rotate Right applied on page {self.current_page_index + 1}: {new_degrees} degrees.")
'''

new = '''        self._show_pixmap()
        self.refresh_print_order_thumbnails()
        self._log(f"Rotate Right applied on page {self.current_page_index + 1}: {new_degrees} degrees.")
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] rotate_right now refreshes Print Order thumbnails")
else:
    if "Rotate Right applied on page" in text and "refresh_print_order_thumbnails()" in text:
        print("[SKIP] rotate_right refresh may already be present")
    else:
        print("[WARN] rotate_right block not found")

# ------------------------------------------------------------
# 4) Call helper after reset_rotation
# ------------------------------------------------------------
old = '''        self._show_pixmap()
        self._log(f"Rotation reset on page {self.current_page_index + 1}.")
'''

new = '''        self._show_pixmap()
        self.refresh_print_order_thumbnails()
        self._log(f"Rotation reset on page {self.current_page_index + 1}.")
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] reset_rotation now refreshes Print Order thumbnails")
else:
    if "Rotation reset on page" in text and "refresh_print_order_thumbnails()" in text:
        print("[SKIP] reset_rotation refresh may already be present")
    else:
        print("[WARN] reset_rotation block not found")

# ------------------------------------------------------------
# 5) Call helper after reset_view
# ------------------------------------------------------------
old = '''        self._log("View reset for current page: rotation=0°, zoom=Fit Page.")
'''

new = '''        self.refresh_print_order_thumbnails()
        self._log("View reset for current page: rotation=0°, zoom=Fit Page.")
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] reset_view now refreshes Print Order thumbnails")
else:
    if "View reset for current page" in text and "refresh_print_order_thumbnails()" in text:
        print("[SKIP] reset_view refresh may already be present")
    else:
        print("[WARN] reset_view block not found")

# ------------------------------------------------------------
# 6) Release Notes
# ------------------------------------------------------------
if "Print Order thumbnails refresh after rotation" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Print Order thumbnails refresh after rotation</b>: Rotating a page now updates Print Order thumbnails immediately.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")
else:
    print("[SKIP] Release Notes already contain rotation thumbnail update")

# ------------------------------------------------------------
# 7) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_refresh_print_order_after_rotation_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "def refresh_print_order_thumbnails",
    "self.refresh_print_order_thumbnails()",
    "Print Order thumbnails refresh after rotation",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Rotating pages now refreshes Print Order thumbnails immediately")
print("- Reset Rotation / Reset View also refresh thumbnails")
print("- If testing EXE, rebuild EXE first")
