﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
DB = ROOT / "app" / "db" / "database.py"
SCHEMA = ROOT / "app" / "db" / "schema.sql"

if not DB.exists():
    print(f"[ERROR] Not found: {DB}")
    sys.exit(1)

if not SCHEMA.exists():
    print(f"[ERROR] Not found: {SCHEMA}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = DB.with_name(f"database.py.bak_embed_schema_{timestamp}")
shutil.copy2(DB, backup)
print(f"[OK] Backup created: {backup}")

schema_text = SCHEMA.read_text(encoding="utf-8", errors="replace")
db_text = DB.read_text(encoding="utf-8", errors="replace")

embedded_schema = f'''EMBEDDED_SCHEMA_SQL = r"""
{schema_text}
"""
'''

# ------------------------------------------------------------
# 1) Ensure embedded schema exists
# ------------------------------------------------------------
if "EMBEDDED_SCHEMA_SQL" not in db_text:
    # Insert after imports and app.config imports
    lines = db_text.splitlines(True)
    insert_at = 0

    for i, line in enumerate(lines):
        if line.startswith("import ") or line.startswith("from "):
            insert_at = i + 1

    db_text = "".join(lines[:insert_at]) + "\n\n" + embedded_schema + "\n" + "".join(lines[insert_at:])
    print("[OK] Added EMBEDDED_SCHEMA_SQL")
else:
    print("[SKIP] EMBEDDED_SCHEMA_SQL already exists")

# ------------------------------------------------------------
# 2) Replace initialize_database with robust version
# ------------------------------------------------------------
new_initialize = r'''def initialize_database() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    schema = None
    tried_paths = []

    candidate_paths = [
        _resource_path("app/db/schema.sql"),
        Path(__file__).resolve().parent / "schema.sql",
    ]

    for schema_path in candidate_paths:
        tried_paths.append(str(schema_path))

        if schema_path.exists():
            schema = schema_path.read_text(encoding="utf-8")
            break

    # Fallback for PyInstaller builds where schema.sql is not available as a file.
    if schema is None:
        schema = EMBEDDED_SCHEMA_SQL

    if not schema or not schema.strip():
        raise FileNotFoundError(
            "schema.sql not found and embedded schema is empty. Tried: "
            + " | ".join(tried_paths)
        )

    with sqlite3.connect(DB_PATH) as conn:
        conn.executescript(schema)
        conn.commit()
'''

try:
    tree = ast.parse(db_text)
    lines = db_text.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == "initialize_database"
    ]

    if not targets:
        print("[ERROR] initialize_database not found")
        shutil.copy2(backup, DB)
        sys.exit(1)

    node = sorted(targets, key=lambda n: n.lineno)[0]
    db_text = "".join(lines[:node.lineno - 1]) + new_initialize + "\n" + "".join(lines[node.end_lineno:])
    print("[OK] Replaced initialize_database with embedded fallback version")

except Exception as exc:
    print(f"[ERROR] Failed to replace initialize_database: {exc}")
    shutil.copy2(backup, DB)
    sys.exit(1)

DB.write_text(db_text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(DB)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = DB.with_name(f"database.py.failed_embed_schema_{timestamp}")
    shutil.copy2(DB, failed)
    shutil.copy2(backup, DB)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = DB.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "EMBEDDED_SCHEMA_SQL",
    "schema = EMBEDDED_SCHEMA_SQL",
    "candidate_paths",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- database.py now has embedded schema fallback")
print("- Rebuild EXE after this patch")
