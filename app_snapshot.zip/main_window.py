from pathlib import Path
from datetime import datetime

from PyQt6.QtCore import Qt, QRect
from PyQt6.QtGui import QPixmap, QTransform
from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QTextEdit,
    QPushButton,
    QFileDialog,
    QMessageBox,
    QDockWidget,
    QScrollArea,
    QSizePolicy,
    QComboBox,
    QCheckBox,
    QGroupBox,
    QTabWidget,
)

from app.config import EXPORTS_DIR, PROJECTS_DIR, RECENT_PROJECTS_PATH
from app.constants import APP_NAME, CREATOR
from app.pdf.pdf_renderer import PdfRenderer
from app.project_manager import ProjectManager
from app.recent_projects import RecentProjects
from app.pdf.poster_exporter import ExportOptions, PosterExporter, SelectionRect
from app.ui.pdf_preview_widget import PdfPreviewWidget


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.current_pdf_path = None
        self.current_project_path = None
        self.is_modified = False

        self.project_manager = ProjectManager()
        self.recent_projects = RecentProjects(RECENT_PROJECTS_PATH)

        self.pdf_renderer = PdfRenderer()
        self.current_page_index = 0
        self.page_count = 0
        self.current_pixmap: QPixmap | None = None
        self.fit_to_page_enabled = True

        self.page_selections: dict[int, QRect] = {}
        self.current_display_scale_x = 1.0
        self.current_display_scale_y = 1.0
        self.render_zoom = 2.5
        self.preview_zoom_factor = 1.0
        self.preview_zoom_min = 0.25
        self.preview_zoom_max = 5.0
        self.preview_zoom_step = 1.25
        self.rotation_degrees = 0
        self.current_display_base_width = 1
        self.current_display_base_height = 1

        self.setWindowTitle(f"{APP_NAME} v0.4.0")
        self.resize(1500, 900)

        self._create_menus()
        self._create_central_ui()
        self._refresh_recent_projects_menu()
        self._create_log_panel()

        self._log("Application started.")
        self._log("SQLite database initialized.")
        self._log("PDF preview module loaded.")
        self._log("Selection module loaded.")
        self._log("Poster export module loaded.")

    def _create_menus(self) -> None:
        menu_bar = self.menuBar()

        self.file_menu = menu_bar.addMenu("File")
        file_menu = self.file_menu
        edit_menu = menu_bar.addMenu("Edit")
        view_menu = menu_bar.addMenu("View")
        options_menu = menu_bar.addMenu("Options")
        help_menu = menu_bar.addMenu("Help")
        about_menu = menu_bar.addMenu("About")

        file_menu.addAction("New Project", self.new_project)
        file_menu.addAction("Open Project", self.open_project)
        file_menu.addAction("Save Project", self.save_project)
        file_menu.addAction("Save Project As", self.save_project_as)
        file_menu.addSeparator()
        self.recent_projects_menu = file_menu.addMenu("Recent Projects")
        file_menu.addSeparator()
        file_menu.addAction("Open PDF", self.open_pdf)
        file_menu.addAction("Export Print PDF", self.export_print_pdf)
        file_menu.addAction("Print", self.print_pdf)
        file_menu.addSeparator()
        file_menu.addAction("Exit", self.close)

        edit_menu.addAction("Undo", self.not_implemented)
        edit_menu.addAction("Redo", self.not_implemented)
        edit_menu.addSeparator()
        edit_menu.addAction("Clear Selection", self.clear_selection)
        edit_menu.addAction("Apply Selection to All Pages", self.apply_selection_to_all_pages)
        edit_menu.addAction("Reset Page Settings", self.not_implemented)

        view_menu.addAction("Previous Page", self.previous_page)
        view_menu.addAction("Next Page", self.next_page)
        view_menu.addSeparator()
        view_menu.addAction("Zoom In", self.zoom_in)
        view_menu.addAction("Zoom Out", self.zoom_out)
        view_menu.addAction("Rotate Left", self.rotate_left)
        view_menu.addAction("Rotate Right", self.rotate_right)
        view_menu.addAction("Reset Rotation", self.reset_rotation)
        view_menu.addAction("Actual Size", self.actual_size)
        view_menu.addAction("Fit Page", self.fit_page)
        view_menu.addSeparator()
        view_menu.addAction("Show Log Panel", self.show_log_panel)

        options_menu.addAction("Basic Mode", self.set_basic_mode)
        options_menu.addAction("Advanced Mode", self.set_advanced_mode)
        options_menu.addSeparator()
        options_menu.addAction("Preferences", self.not_implemented)

        help_menu.addAction("Quick Start", self.show_quick_start)
        help_menu.addAction("Diagnostics", self.run_diagnostics)
        help_menu.addAction("Check Menu Actions", self.check_menu_actions)

        about_menu.addAction("About Program", self.show_about)

    def _refresh_recent_projects_menu(self) -> None:
        self.recent_projects_menu.clear()
        paths = self.recent_projects.load()

        if not paths:
            action = self.recent_projects_menu.addAction("No Recent Projects")
            action.setEnabled(False)
            return

        for path in paths:
            action = self.recent_projects_menu.addAction(path)
            action.triggered.connect(lambda checked=False, p=path: self.load_project_from_path(p))

    def _add_recent_project(self, path: str) -> None:
        self.recent_projects.add(path)
        self._refresh_recent_projects_menu()

    def _collect_project_data(self) -> dict:
        selections = {}

        self._save_current_selection()

        for page_index, rect in self.page_selections.items():
            selections[str(page_index)] = {
                "x": rect.x(),
                "y": rect.y(),
                "width": rect.width(),
                "height": rect.height(),
            }

        return {
            "app": "A4 to A3 Poster Print Studio",
            "version": "0.5.0",
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "pdf_path": self.current_pdf_path,
            "current_page_index": self.current_page_index,
            "page_count": self.page_count,
            "selections": selections,
            "settings": {
                "export_type": self.export_type_combo.currentData(),
                "selection_fit_mode": self.selection_fit_mode_combo.currentData(),
                "page_orientation": self.page_orientation_combo.currentData(),
                "export_quality": self.export_quality_combo.currentData(),
                "output_mode": self.output_mode_combo.currentData(),
                "split_layout": self.split_layout_combo.currentData(),
                "add_numbers": self.numbering_check.isChecked(),
                "add_cut_guides": self.cut_guides_check.isChecked(),
                "rotation_degrees": self.rotation_degrees,
                "preview_zoom_factor": self.preview_zoom_factor,
                "fit_to_page_enabled": self.fit_to_page_enabled,
            },
        }

    def _apply_combo_data(self, combo, value) -> None:
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def _apply_project_data(self, data: dict) -> None:
        pdf_path = data.get("pdf_path")
        if pdf_path:
            self._open_pdf_path(pdf_path, clear_selections=False)

        settings = data.get("settings", {})
        self._apply_combo_data(self.export_type_combo, settings.get("export_type"))
        self._apply_combo_data(self.selection_fit_mode_combo, settings.get("selection_fit_mode"))
        self._apply_combo_data(self.page_orientation_combo, settings.get("page_orientation"))
        self._apply_combo_data(self.export_quality_combo, settings.get("export_quality"))
        self._apply_combo_data(self.output_mode_combo, settings.get("output_mode"))
        self._apply_combo_data(self.split_layout_combo, settings.get("split_layout"))
        self.update_export_option_states()

        self.numbering_check.setChecked(bool(settings.get("add_numbers", True)))
        self.cut_guides_check.setChecked(bool(settings.get("add_cut_guides", True)))

        self.rotation_degrees = int(settings.get("rotation_degrees", 0)) % 360
        self.preview_zoom_factor = float(settings.get("preview_zoom_factor", 1.0))
        self.fit_to_page_enabled = bool(settings.get("fit_to_page_enabled", True))

        self.page_selections.clear()
        selections = data.get("selections", {})

        for page_key, rect_data in selections.items():
            try:
                page_index = int(page_key)
                self.page_selections[page_index] = QRect(
                    int(rect_data.get("x", 0)),
                    int(rect_data.get("y", 0)),
                    int(rect_data.get("width", 0)),
                    int(rect_data.get("height", 0)),
                )
            except Exception:
                continue

        target_page = int(data.get("current_page_index", 0))
        if self.page_count > 0:
            self.current_page_index = max(0, min(target_page, self.page_count - 1))
            self._render_current_page()

        self.is_modified = False

    def load_project_from_path(self, path: str) -> None:
        if not self._confirm_discard_changes():
            return

        try:
            data = self.project_manager.load_project(path)
            self.current_project_path = str(Path(path))
            self._apply_project_data(data)
            self._add_recent_project(self.current_project_path)
            self._log(f"Project loaded: {self.current_project_path}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open Project Error",
                f"Failed to open project.\n\n{exc}"
            )
            self._log(f"Open project error: {exc}")

    def _confirm_discard_changes(self) -> bool:
        if not self.is_modified:
            return True

        result = QMessageBox.question(
            self,
            "Unsaved Changes",
            "There are unsaved changes. Continue without saving?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        return result == QMessageBox.StandardButton.Yes
    def _create_central_ui(self) -> None:
        central = QWidget()
        root_layout = QHBoxLayout(central)

        preview_area = QWidget()
        preview_layout = QVBoxLayout(preview_area)

        self.preview_label = PdfPreviewWidget()
        self.preview_label.setSizePolicy(
            QSizePolicy.Policy.Ignored,
            QSizePolicy.Policy.Ignored,
        )
        self.preview_label.selection_changed.connect(self.on_selection_changed)
        self.preview_label.zoom_requested.connect(self.on_wheel_zoom_requested)

        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(False)
        self.preview_scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_scroll.setWidget(self.preview_label)

        nav_layout = QHBoxLayout()

        self.prev_button = QPushButton("Previous")
        self.next_button = QPushButton("Next")
        self.page_label = QLabel("Page: - / -")
        self.page_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.prev_button.clicked.connect(self.previous_page)
        self.next_button.clicked.connect(self.next_page)

        nav_layout.addWidget(self.prev_button)
        nav_layout.addWidget(self.page_label)
        nav_layout.addWidget(self.next_button)

        preview_layout.addWidget(self.preview_scroll)
        preview_layout.addLayout(nav_layout)

        settings_area = QWidget()
        settings_layout = QVBoxLayout(settings_area)

        title = QLabel("Basic Settings")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")

        self.pdf_path_label = QLabel("PDF: Not selected")
        self.pdf_path_label.setWordWrap(True)
        self.pdf_path_label.setMaximumHeight(48)

        self.pdf_info_label = QLabel("Pages: -")
        self.render_info_label = QLabel("Preview: Not rendered")
        self.zoom_info_label = QLabel("Zoom: Fit Page")
        self.rotation_info_label = QLabel("Rotation: 0°")
        self.selection_info_label = QLabel("Selection: None")
        self.mode_label = QLabel("Mode: Basic")

        self.export_type_combo = QComboBox()
        self.export_type_combo.addItem("A3 Split Mode", "a3_split")
        self.export_type_combo.addItem("Selection Only Mode", "selection_only")
        self.export_type_combo.currentIndexChanged.connect(self.update_export_option_states)

        self.selection_fit_mode_combo = QComboBox()
        self.selection_fit_mode_combo.addItem("Fit Width", "fit_width")
        self.selection_fit_mode_combo.addItem("Fit Whole Area", "fit_whole")
        self.selection_fit_mode_combo.addItem("Fill Page Crop", "fill_crop")
        self.selection_fit_mode_combo.addItem("Fit Height", "fit_height")

        self.page_orientation_combo = QComboBox()
        self.page_orientation_combo.addItem("Auto", "auto")
        self.page_orientation_combo.addItem("Portrait", "portrait")
        self.page_orientation_combo.addItem("Landscape", "landscape")

        self.export_quality_combo = QComboBox()
        self.export_quality_combo.addItem("Standard", 1.5)
        self.export_quality_combo.addItem("High", 2.5)
        self.export_quality_combo.addItem("Very High", 3.5)
        self.export_quality_combo.setCurrentIndex(1)

        self.output_mode_combo = QComboBox()
        self.output_mode_combo.addItem("No-Cut", "no_cut")
        self.output_mode_combo.addItem("Overlap", "overlap")
        self.output_mode_combo.addItem("True Size", "true_size")

        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")

        self.numbering_check = QCheckBox("Add sheet numbers")
        self.numbering_check.setChecked(True)

        self.cut_guides_check = QCheckBox("Add cut guide lines")
        self.cut_guides_check.setChecked(True)

        open_pdf_button = QPushButton("Open PDF")
        open_pdf_button.clicked.connect(self.open_pdf)

        zoom_in_button = QPushButton("Zoom In")
        zoom_in_button.clicked.connect(self.zoom_in)

        zoom_out_button = QPushButton("Zoom Out")
        zoom_out_button.clicked.connect(self.zoom_out)

        rotate_left_button = QPushButton("Rotate Left")
        rotate_left_button.clicked.connect(self.rotate_left)

        rotate_right_button = QPushButton("Rotate Right")
        rotate_right_button.clicked.connect(self.rotate_right)

        reset_rotation_button = QPushButton("Reset Rotation")
        reset_rotation_button.clicked.connect(self.reset_rotation)

        fit_button = QPushButton("Fit Page")
        fit_button.clicked.connect(self.fit_page)

        actual_button = QPushButton("Actual Size")
        actual_button.clicked.connect(self.actual_size)

        clear_selection_button = QPushButton("Clear Selection")
        clear_selection_button.clicked.connect(self.clear_selection)

        apply_all_button = QPushButton("Apply Selection to All Pages")
        apply_all_button.clicked.connect(self.apply_selection_to_all_pages)

        export_button = QPushButton("Export Split Print PDF")
        export_button.clicked.connect(self.export_print_pdf)
        export_button.setStyleSheet("font-weight: bold;")

        status_tab = QWidget()
        status_layout = QVBoxLayout(status_tab)
        status_layout.addWidget(self.pdf_path_label)
        status_layout.addWidget(self.pdf_info_label)
        status_layout.addWidget(self.render_info_label)
        status_layout.addWidget(self.zoom_info_label)
        status_layout.addWidget(self.rotation_info_label)
        status_layout.addWidget(self.selection_info_label)
        status_layout.addStretch()

        view_tab = QWidget()
        view_layout = QVBoxLayout(view_tab)
        view_layout.addWidget(open_pdf_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Zoom"))
        view_layout.addWidget(zoom_in_button)
        view_layout.addWidget(zoom_out_button)
        view_layout.addWidget(fit_button)
        view_layout.addWidget(actual_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Rotation"))
        view_layout.addWidget(rotate_left_button)
        view_layout.addWidget(rotate_right_button)
        view_layout.addWidget(reset_rotation_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Selection"))
        view_layout.addWidget(clear_selection_button)
        view_layout.addWidget(apply_all_button)
        view_layout.addStretch()

        export_tab = QWidget()
        export_layout = QVBoxLayout(export_tab)
        export_layout.addWidget(QLabel("Export Type"))
        export_layout.addWidget(self.export_type_combo)
        export_layout.addWidget(QLabel("Export Quality"))
        export_layout.addWidget(self.export_quality_combo)
        export_layout.addSpacing(12)
        export_layout.addWidget(export_button)
        export_layout.addStretch()

        self.a3_split_group = QWidget()
        a3_layout = QVBoxLayout(self.a3_split_group)
        self.output_mode_title = QLabel("Output Mode")
        self.split_layout_title = QLabel("Split Layout")
        a3_layout.addWidget(self.output_mode_title)
        a3_layout.addWidget(self.output_mode_combo)
        a3_layout.addWidget(self.split_layout_title)
        a3_layout.addWidget(self.split_layout_combo)
        a3_layout.addSpacing(8)
        a3_layout.addWidget(self.numbering_check)
        a3_layout.addWidget(self.cut_guides_check)
        a3_layout.addStretch()

        self.selection_only_group = QWidget()
        selection_layout = QVBoxLayout(self.selection_only_group)
        self.selection_fit_mode_title = QLabel("Selection Fit Mode")
        self.page_orientation_title = QLabel("Page Orientation")
        selection_layout.addWidget(self.selection_fit_mode_title)
        selection_layout.addWidget(self.selection_fit_mode_combo)
        selection_layout.addWidget(self.page_orientation_title)
        selection_layout.addWidget(self.page_orientation_combo)
        selection_layout.addStretch()

        self.settings_tabs = QTabWidget()
        self.settings_tabs.addTab(status_tab, "Status")
        self.settings_tabs.addTab(view_tab, "View")
        self.settings_tabs.addTab(export_tab, "Export")
        self.settings_tabs.addTab(self.a3_split_group, "A3 Split")
        self.settings_tabs.addTab(self.selection_only_group, "Selection")

        settings_layout.addWidget(title)
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.settings_tabs)

        settings_area.setMaximumWidth(520)
        settings_area.setMinimumWidth(420)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setWidget(settings_area)
        settings_scroll.setMinimumWidth(440)
        settings_scroll.setMaximumWidth(540)

        root_layout.addWidget(preview_area, 6)
        root_layout.addWidget(settings_scroll, 2)

self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()

    def update_export_option_states(self) -> None:
        export_type = self.export_type_combo.currentData()

        is_a3_split = export_type == "a3_split"
        is_selection_only = export_type == "selection_only"

        self.selection_only_group.setEnabled(is_selection_only)
        self.a3_split_group.setEnabled(is_a3_split)

        self.selection_fit_mode_title.setEnabled(is_selection_only)
        self.selection_fit_mode_combo.setEnabled(is_selection_only)
        self.page_orientation_title.setEnabled(is_selection_only)
        self.page_orientation_combo.setEnabled(is_selection_only)

        self.output_mode_title.setEnabled(is_a3_split)
        self.output_mode_combo.setEnabled(is_a3_split)
        self.split_layout_title.setEnabled(is_a3_split)
        self.split_layout_combo.setEnabled(is_a3_split)
        self.numbering_check.setEnabled(is_a3_split)
        self.cut_guides_check.setEnabled(is_a3_split)

        if is_selection_only:
            self._log("Export Type changed: Selection Only Mode. A3 split options disabled.")
        else:
            self._log("Export Type changed: A3 Split Mode. Selection-only options disabled.")
    def _create_log_panel(self) -> None:
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)

        self.log_dock = QDockWidget("Log", self)
        self.log_dock.setWidget(self.log_text)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.log_dock)

    def _log(self, message: str) -> None:
        if hasattr(self, "log_text"):
            self.log_text.append(message)

    def _save_current_selection(self) -> None:
        if self.page_count <= 0:
            return

        rect = self.preview_label.get_selection_rect()
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            self.page_selections.pop(self.current_page_index, None)
            return

        self.page_selections[self.current_page_index] = QRect(rect)

    def _restore_current_selection(self) -> None:
        rect = self.page_selections.get(self.current_page_index, QRect())
        self.preview_label.set_selection_rect(rect)
        self._update_selection_info(rect)

    def _update_selection_info(self, rect: QRect) -> None:
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            self.selection_info_label.setText("Selection: None")
            return

        self.selection_info_label.setText(
            f"Selection: x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
        )

    def _get_rotated_pixmap(self) -> QPixmap:
        if self.current_pixmap is None:
            raise RuntimeError("No pixmap is available.")

        angle = self.rotation_degrees % 360

        if angle == 0:
            return self.current_pixmap

        transform = QTransform()
        transform.rotate(angle)
        return self.current_pixmap.transformed(
            transform,
            Qt.TransformationMode.SmoothTransformation,
        )

    def _show_pixmap(self) -> None:
        if self.current_pixmap is None:
            return

        display_base = self._get_rotated_pixmap()
        self.current_display_base_width = display_base.width()
        self.current_display_base_height = display_base.height()

        if self.fit_to_page_enabled:
            viewport_size = self.preview_scroll.viewport().size()
            scaled = display_base.scaled(
                viewport_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

            self.current_display_scale_x = scaled.width() / display_base.width()
            self.current_display_scale_y = scaled.height() / display_base.height()

            self.preview_label.set_preview_pixmap(scaled)
            self.render_info_label.setText(
                f"Preview: Rendered, fitted {scaled.width()} x {scaled.height()}"
            )
            self.zoom_info_label.setText("Zoom: Fit Page")
        else:
            scaled_width = max(1, int(display_base.width() * self.preview_zoom_factor))
            scaled_height = max(1, int(display_base.height() * self.preview_zoom_factor))

            scaled = display_base.scaled(
                scaled_width,
                scaled_height,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

            self.current_display_scale_x = scaled.width() / display_base.width()
            self.current_display_scale_y = scaled.height() / display_base.height()

            self.preview_label.set_preview_pixmap(scaled)
            self.render_info_label.setText(
                f"Preview: Rendered, zoomed {scaled.width()} x {scaled.height()}"
            )
            self.zoom_info_label.setText(
                f"Zoom: {int(self.preview_zoom_factor * 100)}%"
            )

        self.rotation_info_label.setText(f"Rotation: {self.rotation_degrees % 360}°")
        self._restore_current_selection()

    def _render_current_page(self) -> None:
        if self.page_count <= 0:
            self._log("Render skipped: page count is zero.")
            return

        try:
            self._log(f"Rendering page {self.current_page_index + 1}/{self.page_count}...")
            self.current_pixmap = self.pdf_renderer.render_page(
                self.current_page_index,
                zoom=self.render_zoom,
            )
            self._show_pixmap()

            self.page_label.setText(
                f"Page: {self.current_page_index + 1} / {self.page_count}"
            )

            self._update_page_buttons()

            self._log(
                f"Rendered page {self.current_page_index + 1}/{self.page_count}, "
                f"pixmap={self.current_pixmap.width()}x{self.current_pixmap.height()}."
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Render Error",
                f"Failed to render PDF page.\n\n{exc}"
            )
            self._log(f"Render error: {exc}")

    def _update_page_buttons(self) -> None:
        has_pdf = self.page_count > 0
        self.prev_button.setEnabled(has_pdf and self.current_page_index > 0)
        self.next_button.setEnabled(has_pdf and self.current_page_index < self.page_count - 1)

    def _map_rotated_point_to_original_render(self, x: float, y: float) -> tuple[float, float]:
        if self.current_pixmap is None:
            raise RuntimeError("No pixmap is available.")

        original_w = float(self.current_pixmap.width())
        original_h = float(self.current_pixmap.height())
        angle = self.rotation_degrees % 360

        if angle == 0:
            return x, y

        if angle == 90:
            return y, original_h - x

        if angle == 180:
            return original_w - x, original_h - y

        if angle == 270:
            return original_w - y, x

        return x, y

    def _preview_rect_to_pdf_selection(self, rect: QRect) -> SelectionRect:
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            raise RuntimeError("Invalid selection rectangle.")

        x0 = rect.x() / self.current_display_scale_x
        y0 = rect.y() / self.current_display_scale_y
        x1 = (rect.x() + rect.width()) / self.current_display_scale_x
        y1 = (rect.y() + rect.height()) / self.current_display_scale_y

        points = [
            self._map_rotated_point_to_original_render(x0, y0),
            self._map_rotated_point_to_original_render(x1, y0),
            self._map_rotated_point_to_original_render(x0, y1),
            self._map_rotated_point_to_original_render(x1, y1),
        ]

        xs = [point[0] for point in points]
        ys = [point[1] for point in points]

        render_x0 = min(xs)
        render_y0 = min(ys)
        render_x1 = max(xs)
        render_y1 = max(ys)

        pdf_x = render_x0 / self.render_zoom
        pdf_y = render_y0 / self.render_zoom
        pdf_w = (render_x1 - render_x0) / self.render_zoom
        pdf_h = (render_y1 - render_y0) / self.render_zoom

        return SelectionRect(
            x=pdf_x,
            y=pdf_y,
            width=pdf_w,
            height=pdf_h,
        )

    def _build_export_selections(self) -> dict[int, SelectionRect]:
        self._save_current_selection()

        if not self.page_selections:
            raise RuntimeError("No selection exists.")

        result = {}

        for page_index, rect in self.page_selections.items():
            result[page_index] = self._preview_rect_to_pdf_selection(rect)

        return result

    def on_selection_changed(self, rect: QRect) -> None:
        self._update_selection_info(rect)

        if self.page_count > 0:
            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                self.page_selections.pop(self.current_page_index, None)
                self._log(f"Selection cleared for page {self.current_page_index + 1}.")
            else:
                self.page_selections[self.current_page_index] = QRect(rect)
                self._log(
                    f"Selection changed on page {self.current_page_index + 1}: "
                    f"x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
                )

            self.is_modified = True

    def new_project(self) -> None:
        if not self._confirm_discard_changes():
            return

        self.page_selections.clear()
        self.current_pdf_path = None
        self.current_project_path = None
        self.current_page_index = 0
        self.page_count = 0
        self.current_pixmap = None
        self.rotation_degrees = 0
        self.preview_zoom_factor = 1.0
        self.fit_to_page_enabled = True
        self.preview_label.clear_preview()
        self.pdf_path_label.setText("PDF: Not selected")
        self.pdf_info_label.setText("Pages: -")
        self.render_info_label.setText("Preview: Not rendered")
        self.zoom_info_label.setText("Zoom: Fit Page")
        self.rotation_info_label.setText("Rotation: 0°")
        self.selection_info_label.setText("Selection: None")
        self.page_label.setText("Page: - / -")
        self._update_page_buttons()
        self.is_modified = False
        self._log("New Project selected.")

    def open_project(self) -> None:
        if not self._confirm_discard_changes():
            return

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Project",
            str(PROJECTS_DIR),
            "A4 to A3 Project Files (*.a4a3proj);;JSON Files (*.json);;All Files (*)"
        )

        if not file_path:
            return

        self.load_project_from_path(file_path)

    def save_project(self) -> None:
        if not self.current_project_path:
            self.save_project_as()
            return

        try:
            data = self._collect_project_data()
            self.project_manager.save_project(self.current_project_path, data)
            self._add_recent_project(self.current_project_path)
            self.is_modified = False
            self._log(f"Project saved: {self.current_project_path}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Save Project Error",
                f"Failed to save project.\n\n{exc}"
            )
            self._log(f"Save project error: {exc}")

    def save_project_as(self) -> None:
        default_path = PROJECTS_DIR / "project.a4a3proj"

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Project As",
            str(default_path),
            "A4 to A3 Project Files (*.a4a3proj);;JSON Files (*.json);;All Files (*)"
        )

        if not file_path:
            return

        try:
            data = self._collect_project_data()
            self.project_manager.save_project(file_path, data)
            saved_path = Path(file_path)
            if saved_path.suffix.lower() != ".a4a3proj":
                saved_path = saved_path.with_suffix(".a4a3proj")

            self.current_project_path = str(saved_path)
            self._add_recent_project(self.current_project_path)
            self.is_modified = False
            self._log(f"Project saved as: {self.current_project_path}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Save Project Error",
                f"Failed to save project.\n\n{exc}"
            )
            self._log(f"Save project error: {exc}")

    def _open_pdf_path(self, file_path: str, clear_selections: bool = True) -> None:
        self._log(f"Opening PDF: {file_path}")
        self.page_count = self.pdf_renderer.open(file_path)
        self.current_page_index = 0
        self.current_pdf_path = file_path

        if clear_selections:
            self.page_selections.clear()

        self.pdf_path_label.setText(f"PDF: {file_path}")
        self.pdf_info_label.setText(f"Pages: {self.page_count}")
        self.selection_info_label.setText("Selection: None")

        self._log(f"PDF opened: {file_path}")
        self._log(f"PDF page count: {self.page_count}")

        self._render_current_page()

    def open_pdf(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open PDF",
            "",
            "PDF Files (*.pdf)"
        )

        if not file_path:
            return

        try:
            self._open_pdf_path(file_path, clear_selections=True)
            self.is_modified = True

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open PDF Error",
                f"Failed to open PDF.\n\n{exc}"
            )
            self._log(f"Open PDF error: {exc}")

    def previous_page(self) -> None:
        if self.current_page_index <= 0:
            return

        self._save_current_selection()
        self.current_page_index -= 1
        self._render_current_page()

    def next_page(self) -> None:
        if self.current_page_index >= self.page_count - 1:
            return

        self._save_current_selection()
        self.current_page_index += 1
        self._render_current_page()

    def on_wheel_zoom_requested(self, direction: int) -> None:
        if direction > 0:
            self.zoom_in()
        elif direction < 0:
            self.zoom_out()

    def zoom_in(self) -> None:
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.fit_to_page_enabled = False
        self.preview_zoom_factor = min(
            self.preview_zoom_factor * self.preview_zoom_step,
            self.preview_zoom_max,
        )
        self._show_pixmap()
        self._log(f"Zoom In applied: {int(self.preview_zoom_factor * 100)}%.")

    def zoom_out(self) -> None:
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.fit_to_page_enabled = False
        self.preview_zoom_factor = max(
            self.preview_zoom_factor / self.preview_zoom_step,
            self.preview_zoom_min,
        )
        self._show_pixmap()
        self._log(f"Zoom Out applied: {int(self.preview_zoom_factor * 100)}%.")

    def fit_page(self) -> None:
        self._save_current_selection()
        self.fit_to_page_enabled = True
        self._show_pixmap()
        self._log("Fit Page applied.")

    def actual_size(self) -> None:
        self._save_current_selection()
        self.fit_to_page_enabled = False
        self.preview_zoom_factor = 1.0
        self._show_pixmap()
        self._log("Actual Size applied.")

    def clear_selection(self) -> None:
        self.preview_label.clear_selection()
        if self.page_count > 0:
            self.page_selections.pop(self.current_page_index, None)
        self.selection_info_label.setText("Selection: None")
        self.is_modified = True
        self._log("Selection cleared.")

    def apply_selection_to_all_pages(self) -> None:
        if self.page_count <= 0:
            QMessageBox.warning(self, "No PDF", "Please open a PDF first.")
            return

        rect = self.preview_label.get_selection_rect()

        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            QMessageBox.warning(self, "No Selection", "Please select an area first.")
            return

        for page_index in range(self.page_count):
            self.page_selections[page_index] = QRect(rect)

        self.is_modified = True
        self._log(
            f"Selection applied to all pages: x={rect.x()}, y={rect.y()}, "
            f"w={rect.width()}, h={rect.height()}, pages={self.page_count}"
        )
        QMessageBox.information(
            self,
            "Applied",
            f"Selection was applied to all {self.page_count} pages."
        )

    def rotate_left(self) -> None:
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.rotation_degrees = (self.rotation_degrees - 90) % 360
        self._show_pixmap()
        self._log(f"Rotate Left applied: {self.rotation_degrees} degrees.")

    def rotate_right(self) -> None:
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.rotation_degrees = (self.rotation_degrees + 90) % 360
        self._show_pixmap()
        self._log(f"Rotate Right applied: {self.rotation_degrees} degrees.")

    def reset_rotation(self) -> None:
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.rotation_degrees = 0
        self._show_pixmap()
        self._log("Rotation reset.")
    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        try:
            export_selections = self._build_export_selections()
        except Exception as exc:
            QMessageBox.warning(self, "No Selection", str(exc))
            return

        if self.export_type_combo.currentData() == "selection_only":
            default_name = Path(self.current_pdf_path).stem + "_selection_only_A4.pdf"
        else:
            default_name = Path(self.current_pdf_path).stem + "_A3_split_A4.pdf"
        default_path = EXPORTS_DIR / default_name

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export Split Print PDF",
            str(default_path),
            "PDF Files (*.pdf)"
        )

        if not output_path:
            return

        options = ExportOptions(
            export_type=self.export_type_combo.currentData(),
            selection_fit_mode=self.selection_fit_mode_combo.currentData(),
            page_orientation=self.page_orientation_combo.currentData(),
            output_mode=self.output_mode_combo.currentData(),
            split_layout=self.split_layout_combo.currentData(),
            add_numbers=self.numbering_check.isChecked(),
            add_cut_guides=self.cut_guides_check.isChecked(),
            quality_scale=float(self.export_quality_combo.currentData()),
        )

        try:
            self._log("Export started.")
            self._log(f"Output: {output_path}")
            self._log(f"Export type: {options.export_type}")
            self._log(f"Selection fit mode: {options.selection_fit_mode}")
            self._log(f"Page orientation: {options.page_orientation}")
            self._log(f"Export quality scale: {options.quality_scale}")
            self._log(f"Output mode: {options.output_mode}")
            self._log(f"Split layout: {options.split_layout}")
            self._log(f"Cut guides: {options.add_cut_guides}")
            self._log(f"Selected pages: {len(export_selections)}")

            exporter = PosterExporter()
            exporter.export(
                source_pdf_path=self.current_pdf_path,
                output_pdf_path=output_path,
                selections=export_selections,
                options=options,
            )

            self._log("Export completed.")
            QMessageBox.information(
                self,
                "Export Complete",
                f"Output PDF was created:\n\n{output_path}"
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Export Error",
                f"Failed to export split print PDF.\n\n{exc}"
            )
            self._log(f"Export error: {exc}")

    def print_pdf(self) -> None:
        self._log("Print selected.")
        QMessageBox.information(self, "Print", "Print function will be implemented later.")

    def set_basic_mode(self) -> None:
        self.mode_label.setText("Mode: Basic")
        self._log("Switched to Basic Mode.")

    def set_advanced_mode(self) -> None:
        self.mode_label.setText("Mode: Advanced")
        self._log("Switched to Advanced Mode.")

    def show_log_panel(self) -> None:
        self.log_dock.show()
        self._log("Log panel shown.")

    def show_quick_start(self) -> None:
        QMessageBox.information(
            self,
            "Quick Start",
            "1. Open PDF\n2. Drag on preview to select area\n3. Choose output mode\n4. Choose split layout\n5. Export split-print PDF\n6. Print the exported PDF with an A4 printer"
        )

    def run_diagnostics(self) -> None:
        self._log("Diagnostics started.")
        self._log(f"PDF loaded: {bool(self.current_pdf_path)}")
        self._log(f"Page count: {self.page_count}")
        self._log(f"Current page index: {self.current_page_index}")
        self._log(f"Pixmap exists: {self.current_pixmap is not None}")
        self._log(f"Selection pages: {len(self.page_selections)}")
        self._log(f"Export type: {self.export_type_combo.currentData()}")
        self._log(f"Selection fit mode: {self.selection_fit_mode_combo.currentData()}")
        self._log(f"Page orientation: {self.page_orientation_combo.currentData()}")
        self._log(f"Export quality: {self.export_quality_combo.currentText()} / {self.export_quality_combo.currentData()}")
        self._log(f"Cut guides enabled: {self.cut_guides_check.isChecked()}")
        self._log(f"Display scale x: {self.current_display_scale_x}")
        self._log(f"Display scale y: {self.current_display_scale_y}")
        self._log(f"Render zoom: {self.render_zoom}")
        self._log(f"Preview zoom factor: {self.preview_zoom_factor}")
        self._log(f"Rotation degrees: {self.rotation_degrees}")
        self._log("Export quality scale: 2.5")

        current_rect = self.preview_label.get_selection_rect()
        self._log(
            f"Current selection: x={current_rect.x()}, y={current_rect.y()}, "
            f"w={current_rect.width()}, h={current_rect.height()}"
        )

        if self.current_pixmap is not None:
            self._log(
                f"Pixmap size: {self.current_pixmap.width()} x {self.current_pixmap.height()}"
            )

        self._log("Diagnostics finished.")

    def check_menu_actions(self) -> None:
        self._log("Menu action check started.")
        self._log("Menu action check result: Basic menu actions connected.")

    def show_about(self) -> None:
        QMessageBox.about(
            self,
            "About",
            f"{APP_NAME}\nVersion: 0.4.0\nCreator: {CREATOR}"
        )

    def not_implemented(self) -> None:
        self._log("Not implemented menu selected.")
        QMessageBox.information(self, "Not Implemented", "This function will be implemented later.")

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)

        if self.current_pixmap is not None and self.fit_to_page_enabled:
            self._save_current_selection()
            self._show_pixmap()

    def closeEvent(self, event) -> None:
        if self.is_modified:
            result = QMessageBox.question(
                self,
                "Unsaved Changes",
                "There are unsaved changes. Save before exit?",
                QMessageBox.StandardButton.Save |
                QMessageBox.StandardButton.Discard |
                QMessageBox.StandardButton.Cancel
            )

            if result == QMessageBox.StandardButton.Save:
                self.save_project()
                if self.is_modified:
                    event.ignore()
                    return
            elif result == QMessageBox.StandardButton.Cancel:
                event.ignore()
                return

        self.pdf_renderer.close()
        self._log("Application closing.")
        event.accept()