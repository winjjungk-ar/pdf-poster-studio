from pathlib import Path
import os
from datetime import datetime

from PyQt6.QtCore import Qt, QRect
from PyQt6.QtGui import QPixmap, QTransform, QKeySequence, QAction, QImage, QPainter
import fitz

from PyQt6.QtPrintSupport import QPrintDialog, QPrinter

from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QTextEdit,
    QPushButton,
    QFileDialog,
    QMessageBox,
    QDockWidget,
    QScrollArea,
    QSizePolicy,
    QComboBox,
    QCheckBox,
    QGroupBox,
    QTabWidget,
    QSpinBox,
    QListWidget,
    QListWidgetItem,
)

from app.config import EXPORTS_DIR, PROJECTS_DIR, RECENT_PROJECTS_PATH, DATA_DIR
from app.constants import APP_NAME, CREATOR
from app.pdf.pdf_renderer import PdfRenderer
from app.project_manager import ProjectManager
from app.recent_projects import RecentProjects
from app.pdf.poster_exporter import ExportOptions, PosterExporter, SelectionRect
from app.ui.pdf_preview_widget import PdfPreviewWidget


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.current_pdf_path = None
        self.current_project_path = None
        self.is_modified = False

        self.project_manager = ProjectManager()
        self.recent_projects = RecentProjects(RECENT_PROJECTS_PATH)

        self.undo_stack: list[dict] = []
        self.redo_stack: list[dict] = []
        self._restoring_history = False
        self.last_exported_pdf_path: str | None = None
        self.print_dpi = 300
        self.last_temp_print_pdf_path: str | None = None

        self.pdf_renderer = PdfRenderer()
        self.current_page_index = 0
        self.page_count = 0
        self.current_pixmap: QPixmap | None = None
        self.fit_to_page_enabled = True

        self.page_selections: dict[int, QRect] = {}
        self.checked_pages: set[int] = set()
        self._updating_page_list = False
        self.current_display_scale_x = 1.0
        self.current_display_scale_y = 1.0
        self.render_zoom = 2.5
        self.preview_zoom_factor = 1.0
        self.preview_zoom_min = 0.25
        self.preview_zoom_max = 5.0
        self.preview_zoom_step = 1.25
        self.rotation_degrees = 0
        self.current_display_base_width = 1
        self.current_display_base_height = 1

        self.setWindowTitle(f"{APP_NAME} v0.4.0")
        self.resize(1500, 900)

        self._create_menus()
        self._create_central_ui()
        self._refresh_recent_projects_menu()
        self._create_log_panel()

        self._log("Application started.")
        self._log("SQLite database initialized.")
        self._log("PDF preview module loaded.")
        self._log("Selection module loaded.")
        self._log("Poster export module loaded.")

    def _create_menus(self) -> None:
        menu_bar = self.menuBar()

        self.file_menu = menu_bar.addMenu("File")
        edit_menu = menu_bar.addMenu("Edit")
        view_menu = menu_bar.addMenu("View")
        options_menu = menu_bar.addMenu("Options")
        help_menu = menu_bar.addMenu("Help")
        about_menu = menu_bar.addMenu("About")

        # File
        self.file_menu.addAction("New Project", self.new_project)
        self.file_menu.addAction("Open Project", self.open_project)
        self.file_menu.addAction("Save Project", self.save_project)
        self.file_menu.addAction("Save Project As", self.save_project_as)
        self.file_menu.addSeparator()

        self.recent_projects_menu = self.file_menu.addMenu("Recent Projects")
        self.file_menu.addSeparator()

        open_pdf_action = self.file_menu.addAction("Open PDF", self.open_pdf)
        open_pdf_action.setShortcut(QKeySequence("Ctrl+O"))

        export_pdf_action = self.file_menu.addAction("Export PDF", self.export_print_pdf)
        export_pdf_action.setShortcut(QKeySequence("Ctrl+E"))

        open_last_exported_action = self.file_menu.addAction("Open Last Exported PDF", self.open_last_exported_pdf)
        open_last_exported_action.setShortcut(QKeySequence("Ctrl+L"))

        print_action = self.file_menu.addAction("Print", self.print_pdf)
        print_action.setShortcut(QKeySequence("Ctrl+P"))
        self.file_menu.addSeparator()
        self.file_menu.addAction("Exit", self.close)

        # Edit
        self.undo_action = edit_menu.addAction("Undo", self.undo)
        self.undo_action.setShortcut(QKeySequence("Ctrl+Z"))
        self.undo_action.setEnabled(False)

        self.redo_action = edit_menu.addAction("Redo", self.redo)
        self.redo_action.setShortcut(QKeySequence("Ctrl+Y"))
        self.redo_action.setEnabled(False)

        self.redo_alt_action = QAction("Redo Alternative", self)
        self.redo_alt_action.setShortcut(QKeySequence("Ctrl+Shift+Z"))
        self.redo_alt_action.triggered.connect(self.redo)
        self.addAction(self.redo_alt_action)

        edit_menu.addSeparator()
        edit_menu.addAction("Clear Selection", self.clear_selection)
        edit_menu.addAction("Apply Selection to All Pages", self.apply_selection_to_all_pages)

        # View
        view_menu.addAction("Previous Page", self.previous_page)
        view_menu.addAction("Next Page", self.next_page)
        view_menu.addSeparator()
        view_menu.addAction("Zoom In", self.zoom_in)
        view_menu.addAction("Zoom Out", self.zoom_out)
        view_menu.addAction("Fit Page", self.fit_page)
        view_menu.addAction("Actual Size", self.actual_size)
        view_menu.addSeparator()
        view_menu.addAction("Rotate Left", self.rotate_left)
        view_menu.addAction("Rotate Right", self.rotate_right)
        view_menu.addAction("Reset Rotation", self.reset_rotation)
        view_menu.addSeparator()
        view_menu.addAction("Auto Select Current Page", self.auto_select_content)
        view_menu.addAction("Auto Select All Pages", self.auto_select_all_pages)
        view_menu.addSeparator()
        view_menu.addAction("Show Log Panel", self.show_log_panel)

        # Options
        options_menu.addAction("Basic Mode", self.set_basic_mode)
        options_menu.addAction("Advanced Mode", self.set_advanced_mode)
        options_menu.addSeparator()
        preferences_action = options_menu.addAction("Preferences")
        preferences_action.setEnabled(False)

        # Help
        help_menu.addAction("Quick Start", self.show_quick_start)
        help_menu.addAction("Diagnostics", self.run_diagnostics)
        help_menu.addAction("Check Menu Actions", self.check_menu_actions)

        # About
        about_menu.addAction("About Program", self.show_about)
    def _make_history_snapshot(self) -> dict:
        selections = {}
        for page_index, rect in self.page_selections.items():
            selections[str(page_index)] = {
                "x": rect.x(),
                "y": rect.y(),
                "width": rect.width(),
                "height": rect.height(),
            }

        return {
            "current_page_index": self.current_page_index,
            "checked_pages": sorted(list(self.checked_pages)),
            "selections": selections,
            "rotation_degrees": self.rotation_degrees,
            "preview_zoom_factor": self.preview_zoom_factor,
            "fit_to_page_enabled": self.fit_to_page_enabled,
            "export_type": self.export_type_combo.currentData() if hasattr(self, "export_type_combo") else None,
            "selection_fit_mode": self.selection_fit_mode_combo.currentData() if hasattr(self, "selection_fit_mode_combo") else None,
            "page_orientation": self.page_orientation_combo.currentData() if hasattr(self, "page_orientation_combo") else None,
            "export_quality": self.export_quality_combo.currentData() if hasattr(self, "export_quality_combo") else None,
            "batch_output": self.batch_output_combo.currentData() if hasattr(self, "batch_output_combo") else None,
            "output_mode": self.output_mode_combo.currentData() if hasattr(self, "output_mode_combo") else None,
            "split_layout": self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else None,
            "add_numbers": self.numbering_check.isChecked() if hasattr(self, "numbering_check") else True,
            "add_cut_guides": self.cut_guides_check.isChecked() if hasattr(self, "cut_guides_check") else True,
        }

    def _push_undo_state(self) -> None:
        if self._restoring_history:
            return

        if not hasattr(self, "undo_stack"):
            return

        snapshot = self._make_history_snapshot()

        if self.undo_stack and self.undo_stack[-1] == snapshot:
            return

        self.undo_stack.append(snapshot)

        if len(self.undo_stack) > 50:
            self.undo_stack.pop(0)

        self.redo_stack.clear()
        self._update_undo_redo_actions()

    def _restore_history_snapshot(self, snapshot: dict) -> None:
        self._restoring_history = True

        try:
            self.page_selections.clear()
            for page_key, rect_data in snapshot.get("selections", {}).items():
                try:
                    page_index = int(page_key)
                    self.page_selections[page_index] = QRect(
                        int(rect_data.get("x", 0)),
                        int(rect_data.get("y", 0)),
                        int(rect_data.get("width", 0)),
                        int(rect_data.get("height", 0)),
                    )
                except Exception:
                    continue

            self.checked_pages = set()
            for page_index in snapshot.get("checked_pages", []):
                try:
                    self.checked_pages.add(int(page_index))
                except Exception:
                    continue

            self.rotation_degrees = int(snapshot.get("rotation_degrees", 0)) % 360
            self.preview_zoom_factor = float(snapshot.get("preview_zoom_factor", 1.0))
            self.fit_to_page_enabled = bool(snapshot.get("fit_to_page_enabled", True))

            self._apply_combo_data(self.export_type_combo, snapshot.get("export_type"))
            self._apply_combo_data(self.selection_fit_mode_combo, snapshot.get("selection_fit_mode"))
            self._apply_combo_data(self.page_orientation_combo, snapshot.get("page_orientation"))
            self._apply_combo_data(self.export_quality_combo, snapshot.get("export_quality"))
            self._apply_combo_data(self.batch_output_combo, snapshot.get("batch_output"))
            self._apply_combo_data(self.output_mode_combo, snapshot.get("output_mode"))
            self._apply_combo_data(self.split_layout_combo, snapshot.get("split_layout"))

            self.numbering_check.setChecked(bool(snapshot.get("add_numbers", True)))
            self.cut_guides_check.setChecked(bool(snapshot.get("add_cut_guides", True)))

            if self.page_count > 0:
                target_page = int(snapshot.get("current_page_index", 0))
                self.current_page_index = max(0, min(target_page, self.page_count - 1))
                self._render_current_page()
                self._refresh_page_list_all_text()
                self._refresh_current_page_check_state()
                self._update_checked_pages_label()

            self.update_export_option_states()
            self.is_modified = True

        finally:
            self._restoring_history = False

    def _update_undo_redo_actions(self) -> None:
        if hasattr(self, "undo_action"):
            self.undo_action.setEnabled(len(self.undo_stack) > 0)

        if hasattr(self, "redo_action"):
            self.redo_action.setEnabled(len(self.redo_stack) > 0)

    def undo(self) -> None:
        if not self.undo_stack:
            return

        current = self._make_history_snapshot()
        snapshot = self.undo_stack.pop()
        self.redo_stack.append(current)

        self._restore_history_snapshot(snapshot)
        self._update_undo_redo_actions()
        self._log("Undo applied.")

    def redo(self) -> None:
        if not self.redo_stack:
            return

        current = self._make_history_snapshot()
        snapshot = self.redo_stack.pop()
        self.undo_stack.append(current)

        self._restore_history_snapshot(snapshot)
        self._update_undo_redo_actions()
        self._log("Redo applied.")
    def _refresh_recent_projects_menu(self) -> None:
        self.recent_projects_menu.clear()
        paths = self.recent_projects.load()

        if not paths:
            action = self.recent_projects_menu.addAction("No Recent Projects")
            action.setEnabled(False)
            return

        for path in paths:
            action = self.recent_projects_menu.addAction(path)
            action.triggered.connect(lambda checked=False, p=path: self.load_project_from_path(p))

    def _add_recent_project(self, path: str) -> None:
        self.recent_projects.add(path)
        self._refresh_recent_projects_menu()

    def _collect_project_data(self) -> dict:
        selections = {}

        self._save_current_selection()

        for page_index, rect in self.page_selections.items():
            selections[str(page_index)] = {
                "x": rect.x(),
                "y": rect.y(),
                "width": rect.width(),
                "height": rect.height(),
            }

        return {
            "app": "A4 to A3 Poster Print Studio",
            "version": "0.5.0",
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "pdf_path": self.current_pdf_path,
            "last_exported_pdf_path": self.last_exported_pdf_path,
            "current_page_index": self.current_page_index,
            "page_count": self.page_count,
            "selections": selections,
            "checked_pages": sorted(list(self.checked_pages)),
            "settings": {
                "export_type": self.export_type_combo.currentData(),
                "selection_fit_mode": self.selection_fit_mode_combo.currentData(),
                "page_orientation": self.page_orientation_combo.currentData(),
                "export_quality": self.export_quality_combo.currentData(),
                "batch_output": self.batch_output_combo.currentData(),
                "print_quality_dpi": self.print_quality_combo.currentData(),
                "auto_select_sensitivity": self.auto_select_sensitivity_combo.currentData(),
                "output_mode": self.output_mode_combo.currentData(),
                "split_layout": self.split_layout_combo.currentData(),
                "add_numbers": self.numbering_check.isChecked(),
                "add_cut_guides": self.cut_guides_check.isChecked(),
                "rotation_degrees": self.rotation_degrees,
                "preview_zoom_factor": self.preview_zoom_factor,
                "fit_to_page_enabled": self.fit_to_page_enabled,
            },
        }

    def _apply_combo_data(self, combo, value) -> None:
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def _apply_project_data(self, data: dict) -> None:
        self.last_exported_pdf_path = data.get("last_exported_pdf_path")
        pdf_path = data.get("pdf_path")
        if pdf_path:
            self._open_pdf_path(pdf_path, clear_selections=False)

        self.checked_pages = set()
        for page_index in data.get("checked_pages", []):
            try:
                self.checked_pages.add(int(page_index))
            except Exception:
                continue

        settings = data.get("settings", {})
        self._apply_combo_data(self.export_type_combo, settings.get("export_type"))
        self._apply_combo_data(self.selection_fit_mode_combo, settings.get("selection_fit_mode"))
        self._apply_combo_data(self.page_orientation_combo, settings.get("page_orientation"))
        self._apply_combo_data(self.export_quality_combo, settings.get("export_quality"))
        self._apply_combo_data(self.batch_output_combo, settings.get("batch_output"))
        self._apply_combo_data(self.print_quality_combo, settings.get("print_quality_dpi"))
        self._apply_combo_data(self.auto_select_sensitivity_combo, settings.get("auto_select_sensitivity"))
        self._apply_combo_data(self.output_mode_combo, settings.get("output_mode"))
        self._apply_combo_data(self.split_layout_combo, settings.get("split_layout"))
        self.update_export_option_states()

        self.numbering_check.setChecked(bool(settings.get("add_numbers", True)))
        self.cut_guides_check.setChecked(bool(settings.get("add_cut_guides", True)))

        self.rotation_degrees = int(settings.get("rotation_degrees", 0)) % 360
        self.preview_zoom_factor = float(settings.get("preview_zoom_factor", 1.0))
        self.fit_to_page_enabled = bool(settings.get("fit_to_page_enabled", True))

        self.page_selections.clear()
        selections = data.get("selections", {})

        for page_key, rect_data in selections.items():
            try:
                page_index = int(page_key)
                self.page_selections[page_index] = QRect(
                    int(rect_data.get("x", 0)),
                    int(rect_data.get("y", 0)),
                    int(rect_data.get("width", 0)),
                    int(rect_data.get("height", 0)),
                )
            except Exception:
                continue

        target_page = int(data.get("current_page_index", 0))
        if self.page_count > 0:
            self.current_page_index = max(0, min(target_page, self.page_count - 1))
            self._render_current_page()
            self._rebuild_page_list()

        self.is_modified = False

    def load_project_from_path(self, path: str) -> None:
        if not self._confirm_discard_changes():
            return

        try:
            data = self.project_manager.load_project(path)
            self.current_project_path = str(Path(path))
            self._apply_project_data(data)
            self._add_recent_project(self.current_project_path)
            self._log(f"Project loaded: {self.current_project_path}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open Project Error",
                f"Failed to open project.\n\n{exc}"
            )
            self._log(f"Open project error: {exc}")

    def _confirm_discard_changes(self) -> bool:
        if not self.is_modified:
            return True

        result = QMessageBox.question(
            self,
            "Unsaved Changes",
            "There are unsaved changes. Continue without saving?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        return result == QMessageBox.StandardButton.Yes
    def _create_central_ui(self) -> None:
        central = QWidget()
        root_layout = QHBoxLayout(central)

        preview_area = QWidget()
        preview_layout = QVBoxLayout(preview_area)

        self.preview_label = PdfPreviewWidget()
        self.preview_label.setSizePolicy(
            QSizePolicy.Policy.Ignored,
            QSizePolicy.Policy.Ignored,
        )
        self.preview_label.selection_changed.connect(self.on_selection_changed)
        self.preview_label.zoom_requested.connect(self.on_wheel_zoom_requested)

        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(False)
        self.preview_scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_scroll.setWidget(self.preview_label)

        nav_layout = QHBoxLayout()

        self.prev_button = QPushButton("Previous")
        self.next_button = QPushButton("Next")
        self.page_label = QLabel("Page: - / -")
        self.page_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.page_complete_check = QCheckBox("Use this page for export")
        self.page_complete_check.stateChanged.connect(self.on_page_complete_changed)

        self.page_jump_spin = QSpinBox()
        self.page_jump_spin.setMinimum(1)
        self.page_jump_spin.setMaximum(1)
        self.page_jump_spin.setPrefix("Go to page ")
        self.page_jump_spin.valueChanged.connect(self.on_page_jump_changed)

        self.prev_button.clicked.connect(self.previous_page)
        self.next_button.clicked.connect(self.next_page)

        nav_layout.addWidget(self.prev_button)
        nav_layout.addWidget(self.page_label)
        nav_layout.addWidget(self.next_button)
        nav_layout.addWidget(self.page_complete_check)
        nav_layout.addWidget(self.page_jump_spin)

        preview_layout.addWidget(self.preview_scroll)
        preview_layout.addLayout(nav_layout)

        settings_area = QWidget()
        settings_layout = QVBoxLayout(settings_area)

        title = QLabel("Basic Settings")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")

        self.pdf_path_label = QLabel("PDF: Not selected")
        self.pdf_path_label.setWordWrap(True)
        self.pdf_path_label.setMaximumHeight(48)

        self.pdf_info_label = QLabel("Pages: -")
        self.render_info_label = QLabel("Preview: Not rendered")
        self.zoom_info_label = QLabel("Zoom: Fit Page")
        self.rotation_info_label = QLabel("Rotation: 0°")
        self.selection_info_label = QLabel("Selection: None")
        self.checked_pages_label = QLabel("Checked pages: 0")
        self.mode_label = QLabel("Mode: Basic")

        self.export_type_combo = QComboBox()
        self.export_type_combo.addItem("A3 Split Mode", "a3_split")
        self.export_type_combo.addItem("Selection Only Mode", "selection_only")
        self.export_type_combo.currentIndexChanged.connect(self.update_export_option_states)

        self.selection_fit_mode_combo = QComboBox()
        self.selection_fit_mode_combo.addItem("Fit Width", "fit_width")
        self.selection_fit_mode_combo.addItem("Fit Whole Area", "fit_whole")
        self.selection_fit_mode_combo.addItem("Fill Page Crop", "fill_crop")
        self.selection_fit_mode_combo.addItem("Fit Height", "fit_height")

        self.page_orientation_combo = QComboBox()
        self.page_orientation_combo.addItem("Auto", "auto")
        self.page_orientation_combo.addItem("Portrait", "portrait")
        self.page_orientation_combo.addItem("Landscape", "landscape")

        self.export_quality_combo = QComboBox()
        self.export_quality_combo.addItem("Standard", 1.5)
        self.export_quality_combo.addItem("High", 2.5)
        self.export_quality_combo.addItem("Very High", 3.5)
        self.export_quality_combo.setCurrentIndex(1)

        self.batch_output_combo = QComboBox()
        self.batch_output_combo.addItem("Single PDF", "single_pdf")
        self.batch_output_combo.addItem("Separate PDF per checked page", "separate_pdf_per_page")

        self.print_quality_combo = QComboBox()
        self.print_quality_combo.addItem("Fast 150 DPI", 150)
        self.print_quality_combo.addItem("Standard 300 DPI", 300)
        self.print_quality_combo.addItem("High 600 DPI", 600)
        self.print_quality_combo.setCurrentIndex(1)

        self.auto_select_sensitivity_combo = QComboBox()
        self.auto_select_sensitivity_combo.addItem("Strict", 235)
        self.auto_select_sensitivity_combo.addItem("Normal", 245)
        self.auto_select_sensitivity_combo.addItem("Sensitive", 252)
        self.auto_select_sensitivity_combo.setCurrentIndex(1)
        self.output_mode_combo = QComboBox()
        self.output_mode_combo.addItem("No-Cut", "no_cut")
        self.output_mode_combo.addItem("Overlap", "overlap")
        self.output_mode_combo.addItem("True Size", "true_size")

        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")

        self.numbering_check = QCheckBox("Add sheet numbers")
        self.numbering_check.setChecked(True)

        self.cut_guides_check = QCheckBox("Add cut guide lines")
        self.cut_guides_check.setChecked(True)

        open_pdf_button = QPushButton("Open PDF")
        open_pdf_button.clicked.connect(self.open_pdf)

        zoom_in_button = QPushButton("Zoom In")
        zoom_in_button.clicked.connect(self.zoom_in)

        zoom_out_button = QPushButton("Zoom Out")
        zoom_out_button.clicked.connect(self.zoom_out)

        auto_select_button = QPushButton("Auto Select Current Page")
        auto_select_button.clicked.connect(self.auto_select_content)

        auto_select_all_button = QPushButton("Auto Select All Pages")
        auto_select_all_button.clicked.connect(self.auto_select_all_pages)

        rotate_left_button = QPushButton("Rotate Left")
        rotate_left_button.clicked.connect(self.rotate_left)

        rotate_right_button = QPushButton("Rotate Right")
        rotate_right_button.clicked.connect(self.rotate_right)

        reset_rotation_button = QPushButton("Reset Rotation")
        reset_rotation_button.clicked.connect(self.reset_rotation)

        fit_button = QPushButton("Fit Page")
        fit_button.clicked.connect(self.fit_page)

        actual_button = QPushButton("Actual Size")
        actual_button.clicked.connect(self.actual_size)

        clear_selection_button = QPushButton("Clear Selection")
        clear_selection_button.clicked.connect(self.clear_selection)

        apply_all_button = QPushButton("Apply Selection to All Pages")
        apply_all_button.clicked.connect(self.apply_selection_to_all_pages)

        export_button = QPushButton("Export PDF")
        export_button.clicked.connect(self.export_print_pdf)
        export_button.setStyleSheet("font-weight: bold;")

        status_tab = QWidget()
        status_layout = QVBoxLayout(status_tab)
        status_layout.addWidget(self.pdf_path_label)
        status_layout.addWidget(self.pdf_info_label)
        status_layout.addWidget(self.render_info_label)
        status_layout.addWidget(self.zoom_info_label)
        status_layout.addWidget(self.rotation_info_label)
        status_layout.addWidget(self.selection_info_label)
        status_layout.addWidget(self.checked_pages_label)
        status_layout.addWidget(QLabel("Pages for Export"))

        self.page_list_widget = QListWidget()
        self.page_list_widget.setMinimumHeight(260)
        self.page_list_widget.itemChanged.connect(self.on_page_list_item_changed)
        self.page_list_widget.itemClicked.connect(self.on_page_list_item_clicked)

        status_layout.addWidget(self.page_list_widget)
        status_layout.addStretch()

        view_tab = QWidget()
        view_layout = QVBoxLayout(view_tab)
        view_layout.addWidget(open_pdf_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Zoom"))
        view_layout.addWidget(zoom_in_button)
        view_layout.addWidget(zoom_out_button)
        view_layout.addWidget(QLabel("Auto Selection"))
        view_layout.addWidget(QLabel("Sensitivity"))
        view_layout.addWidget(self.auto_select_sensitivity_combo)
        view_layout.addWidget(auto_select_button)
        view_layout.addWidget(auto_select_all_button)
        view_layout.addWidget(fit_button)
        view_layout.addWidget(actual_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Rotation"))
        view_layout.addWidget(rotate_left_button)
        view_layout.addWidget(rotate_right_button)
        view_layout.addWidget(reset_rotation_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Selection"))
        view_layout.addWidget(clear_selection_button)
        view_layout.addWidget(apply_all_button)
        view_layout.addStretch()

        export_tab = QWidget()
        export_layout = QVBoxLayout(export_tab)
        export_layout.addWidget(QLabel("Export Type"))
        export_layout.addWidget(self.export_type_combo)
        export_layout.addWidget(QLabel("Export Quality"))
        export_layout.addWidget(self.export_quality_combo)
        export_layout.addWidget(QLabel("Batch Output"))
        export_layout.addWidget(self.batch_output_combo)
        export_layout.addWidget(QLabel("Print Quality"))
        export_layout.addWidget(self.print_quality_combo)
        export_layout.addSpacing(12)
        export_layout.addWidget(export_button)
        export_layout.addStretch()
        self.a3_split_group = QWidget()
        a3_layout = QVBoxLayout(self.a3_split_group)
        self.output_mode_title = QLabel("Output Mode")
        self.split_layout_title = QLabel("Split Layout")
        a3_layout.addWidget(self.output_mode_title)
        a3_layout.addWidget(self.output_mode_combo)
        a3_layout.addWidget(self.split_layout_title)
        a3_layout.addWidget(self.split_layout_combo)
        a3_layout.addSpacing(8)
        a3_layout.addWidget(self.numbering_check)
        a3_layout.addWidget(self.cut_guides_check)
        a3_layout.addStretch()

        self.selection_only_group = QWidget()
        selection_layout = QVBoxLayout(self.selection_only_group)
        self.selection_fit_mode_title = QLabel("Selection Fit Mode")
        self.page_orientation_title = QLabel("Page Orientation")
        selection_layout.addWidget(self.selection_fit_mode_title)
        selection_layout.addWidget(self.selection_fit_mode_combo)
        selection_layout.addWidget(self.page_orientation_title)
        selection_layout.addWidget(self.page_orientation_combo)
        selection_layout.addStretch()

        self.settings_tabs = QTabWidget()
        self.settings_tabs.addTab(status_tab, "Status")
        self.settings_tabs.addTab(view_tab, "View")
        self.settings_tabs.addTab(export_tab, "Export")
        self.settings_tabs.addTab(self.a3_split_group, "A3 Split")
        self.settings_tabs.addTab(self.selection_only_group, "Selection")

        settings_layout.addWidget(title)
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.settings_tabs)

        settings_area.setMaximumWidth(520)
        settings_area.setMinimumWidth(420)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setWidget(settings_area)
        settings_scroll.setMinimumWidth(440)
        settings_scroll.setMaximumWidth(540)

        root_layout.addWidget(preview_area, 6)
        root_layout.addWidget(settings_scroll, 2)

        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()

    def update_export_option_states(self) -> None:
        export_type = self.export_type_combo.currentData()

        is_a3_split = export_type == "a3_split"
        is_selection_only = export_type == "selection_only"

        self.selection_only_group.setEnabled(is_selection_only)
        self.a3_split_group.setEnabled(is_a3_split)

        self.selection_fit_mode_title.setEnabled(is_selection_only)
        self.selection_fit_mode_combo.setEnabled(is_selection_only)
        self.page_orientation_title.setEnabled(is_selection_only)
        self.page_orientation_combo.setEnabled(is_selection_only)

        self.output_mode_title.setEnabled(is_a3_split)
        self.output_mode_combo.setEnabled(is_a3_split)
        self.split_layout_title.setEnabled(is_a3_split)
        self.split_layout_combo.setEnabled(is_a3_split)
        self.numbering_check.setEnabled(is_a3_split)
        self.cut_guides_check.setEnabled(is_a3_split)

        if is_selection_only:
            self._log("Export Type changed: Selection Only Mode. A3 split options disabled.")
        else:
            self._log("Export Type changed: A3 Split Mode. Selection-only options disabled.")
    def _create_log_panel(self) -> None:
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)

        self.log_dock = QDockWidget("Log", self)
        self.log_dock.setWidget(self.log_text)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.log_dock)
        self.log_dock.hide()
        self.output_mode_combo = QComboBox()
        self.output_mode_combo.addItem("No-Cut", "no_cut")
        self.output_mode_combo.addItem("Overlap", "overlap")
        self.output_mode_combo.addItem("True Size", "true_size")

        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")

        self.numbering_check = QCheckBox("Add sheet numbers")
        self.numbering_check.setChecked(True)

        self.cut_guides_check = QCheckBox("Add cut guide lines")
        self.cut_guides_check.setChecked(True)

        open_pdf_button = QPushButton("Open PDF")
        open_pdf_button.clicked.connect(self.open_pdf)

        zoom_in_button = QPushButton("Zoom In")
        zoom_in_button.clicked.connect(self.zoom_in)

        zoom_out_button = QPushButton("Zoom Out")
        zoom_out_button.clicked.connect(self.zoom_out)

        auto_select_button = QPushButton("Auto Select Current Page")
        auto_select_button.clicked.connect(self.auto_select_content)

        auto_select_all_button = QPushButton("Auto Select All Pages")
        auto_select_all_button.clicked.connect(self.auto_select_all_pages)

        rotate_left_button = QPushButton("Rotate Left")
        rotate_left_button.clicked.connect(self.rotate_left)

        rotate_right_button = QPushButton("Rotate Right")
        rotate_right_button.clicked.connect(self.rotate_right)

        reset_rotation_button = QPushButton("Reset Rotation")
        reset_rotation_button.clicked.connect(self.reset_rotation)

        fit_button = QPushButton("Fit Page")
        fit_button.clicked.connect(self.fit_page)

        actual_button = QPushButton("Actual Size")
        actual_button.clicked.connect(self.actual_size)

        clear_selection_button = QPushButton("Clear Selection")
        clear_selection_button.clicked.connect(self.clear_selection)

        apply_all_button = QPushButton("Apply Selection to All Pages")
        apply_all_button.clicked.connect(self.apply_selection_to_all_pages)

        export_button = QPushButton("Export PDF")
        export_button.clicked.connect(self.export_print_pdf)
        export_button.setStyleSheet("font-weight: bold;")

        status_tab = QWidget()
        status_layout = QVBoxLayout(status_tab)
        status_layout.addWidget(self.pdf_path_label)
        status_layout.addWidget(self.pdf_info_label)
        status_layout.addWidget(self.render_info_label)
        status_layout.addWidget(self.zoom_info_label)
        status_layout.addWidget(self.rotation_info_label)
        status_layout.addWidget(self.selection_info_label)
        status_layout.addWidget(self.checked_pages_label)
        status_layout.addWidget(QLabel("Pages for Export"))

        self.page_list_widget = QListWidget()
        self.page_list_widget.setMinimumHeight(260)
        self.page_list_widget.itemChanged.connect(self.on_page_list_item_changed)
        self.page_list_widget.itemClicked.connect(self.on_page_list_item_clicked)

        status_layout.addWidget(self.page_list_widget)
        status_layout.addStretch()

        view_tab = QWidget()
        view_layout = QVBoxLayout(view_tab)
        view_layout.addWidget(open_pdf_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Zoom"))
        view_layout.addWidget(zoom_in_button)
        view_layout.addWidget(zoom_out_button)
        view_layout.addWidget(QLabel("Auto Selection"))
        view_layout.addWidget(QLabel("Sensitivity"))
        view_layout.addWidget(self.auto_select_sensitivity_combo)
        view_layout.addWidget(auto_select_button)
        view_layout.addWidget(auto_select_all_button)
        view_layout.addWidget(fit_button)
        view_layout.addWidget(actual_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Rotation"))
        view_layout.addWidget(rotate_left_button)
        view_layout.addWidget(rotate_right_button)
        view_layout.addWidget(reset_rotation_button)
        view_layout.addSpacing(8)
        view_layout.addWidget(QLabel("Selection"))
        view_layout.addWidget(clear_selection_button)
        view_layout.addWidget(apply_all_button)
        view_layout.addStretch()

        export_tab = QWidget()
        export_layout = QVBoxLayout(export_tab)
        export_layout.addWidget(QLabel("Export Type"))
        export_layout.addWidget(self.export_type_combo)
        export_layout.addWidget(QLabel("Export Quality"))
        export_layout.addWidget(self.export_quality_combo)
        export_layout.addWidget(QLabel("Batch Output"))
        export_layout.addWidget(self.batch_output_combo)
                export_layout.addWidget(QLabel("Print Quality"))
        export_layout.addWidget(self.print_quality_combo)
export_layout.addSpacing(12)
        export_layout.addWidget(export_button)
        export_layout.addStretch()

        self.a3_split_group = QWidget()
        a3_layout = QVBoxLayout(self.a3_split_group)
        self.output_mode_title = QLabel("Output Mode")
        self.split_layout_title = QLabel("Split Layout")
        a3_layout.addWidget(self.output_mode_title)
        a3_layout.addWidget(self.output_mode_combo)
        a3_layout.addWidget(self.split_layout_title)
        a3_layout.addWidget(self.split_layout_combo)
        a3_layout.addSpacing(8)
        a3_layout.addWidget(self.numbering_check)
        a3_layout.addWidget(self.cut_guides_check)
        a3_layout.addStretch()

        self.selection_only_group = QWidget()
        selection_layout = QVBoxLayout(self.selection_only_group)
        self.selection_fit_mode_title = QLabel("Selection Fit Mode")
        self.page_orientation_title = QLabel("Page Orientation")
        selection_layout.addWidget(self.selection_fit_mode_title)
        selection_layout.addWidget(self.selection_fit_mode_combo)
        selection_layout.addWidget(self.page_orientation_title)
        selection_layout.addWidget(self.page_orientation_combo)
        selection_layout.addStretch()

        self.settings_tabs = QTabWidget()
        self.settings_tabs.addTab(status_tab, "Status")
        self.settings_tabs.addTab(view_tab, "View")
        self.settings_tabs.addTab(export_tab, "Export")
        self.settings_tabs.addTab(self.a3_split_group, "A3 Split")
        self.settings_tabs.addTab(self.selection_only_group, "Selection")

        settings_layout.addWidget(title)
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.settings_tabs)

        settings_area.setMaximumWidth(520)
        settings_area.setMinimumWidth(420)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setWidget(settings_area)
        settings_scroll.setMinimumWidth(440)
        settings_scroll.setMaximumWidth(540)

        root_layout.addWidget(preview_area, 6)
        root_layout.addWidget(settings_scroll, 2)

        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()

    def update_export_option_states(self) -> None:
        export_type = self.export_type_combo.currentData()

        is_a3_split = export_type == "a3_split"
        is_selection_only = export_type == "selection_only"

        self.selection_only_group.setEnabled(is_selection_only)
        self.a3_split_group.setEnabled(is_a3_split)

        self.selection_fit_mode_title.setEnabled(is_selection_only)
        self.selection_fit_mode_combo.setEnabled(is_selection_only)
        self.page_orientation_title.setEnabled(is_selection_only)
        self.page_orientation_combo.setEnabled(is_selection_only)

        self.output_mode_title.setEnabled(is_a3_split)
        self.output_mode_combo.setEnabled(is_a3_split)
        self.split_layout_title.setEnabled(is_a3_split)
        self.split_layout_combo.setEnabled(is_a3_split)
        self.numbering_check.setEnabled(is_a3_split)
        self.cut_guides_check.setEnabled(is_a3_split)

        if is_selection_only:
            self._log("Export Type changed: Selection Only Mode. A3 split options disabled.")
        else:
            self._log("Export Type changed: A3 Split Mode. Selection-only options disabled.")
    def _create_log_panel(self) -> None:
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)

        self.log_dock = QDockWidget("Log", self)
        self.log_dock.setWidget(self.log_text)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.log_dock)

            self.log_dock.hide()
    def _log(self, message: str) -> None:
        if hasattr(self, "log_text"):
            self.log_text.append(message)

    def _update_checked_pages_label(self) -> None:
        self.checked_pages_label.setText(f"Checked pages: {len(self.checked_pages)}")

    def _refresh_current_page_check_state(self) -> None:
        if not hasattr(self, "page_complete_check"):
            return

        self.page_complete_check.blockSignals(True)
        self.page_complete_check.setChecked(self.current_page_index in self.checked_pages)
        self.page_complete_check.blockSignals(False)
        self._update_checked_pages_label()

    def on_page_complete_changed(self, state: int) -> None:
        if self.page_count <= 0:
            return

        if self.page_complete_check.isChecked():
            rect = self.preview_label.get_selection_rect()
            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                self.page_complete_check.blockSignals(True)
                self.page_complete_check.setChecked(False)
                self.page_complete_check.blockSignals(False)
                QMessageBox.warning(
                    self,
                    "No Selection",
                    "Please select an area before checking this page."
                )
                return

            self._save_current_selection()
            self.checked_pages.add(self.current_page_index)
            self._log(f"Page checked for export: {self.current_page_index + 1}")
        else:
            self.checked_pages.discard(self.current_page_index)
            self._log(f"Page unchecked for export: {self.current_page_index + 1}")

        self.is_modified = True
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(self.current_page_index)
        self._update_checked_pages_label()

    def on_page_jump_changed(self, value: int) -> None:
        if self.page_count <= 0:
            return

        target_index = value - 1
        if target_index == self.current_page_index:
            return

        if target_index < 0 or target_index >= self.page_count:
            return

        self._save_current_selection()
        self.current_page_index = target_index
        self._render_current_page()

    def _sync_page_jump_spin(self) -> None:
        if not hasattr(self, "page_jump_spin"):
            return

        self.page_jump_spin.blockSignals(True)
        self.page_jump_spin.setMaximum(max(1, self.page_count))
        self.page_jump_spin.setValue(max(1, self.current_page_index + 1))
        self.page_jump_spin.blockSignals(False)

    def mark_current_page_checked_if_has_selection(self) -> None:
        rect = self.preview_label.get_selection_rect()
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            return

        self.checked_pages.add(self.current_page_index)
        self._refresh_current_page_check_state()
    def _selection_exists_for_page(self, page_index: int) -> bool:
        rect = self.page_selections.get(page_index)
        return rect is not None and not rect.isNull() and rect.width() > 0 and rect.height() > 0

    def _page_list_text(self, page_index: int) -> str:
        page_no = page_index + 1

        if self._selection_exists_for_page(page_index):
            status = "Selected"
        else:
            status = "No selection"

        if page_index == self.current_page_index:
            return f"▶ Page {page_no} - {status}"

        return f"Page {page_no} - {status}"

    def _rebuild_page_list(self) -> None:
        if not hasattr(self, "page_list_widget"):
            return

        self._updating_page_list = True
        self.page_list_widget.clear()

        for page_index in range(self.page_count):
            item = QListWidgetItem(self._page_list_text(page_index))
            item.setData(Qt.ItemDataRole.UserRole, page_index)
            item.setFlags(
                item.flags()
                | Qt.ItemFlag.ItemIsUserCheckable
                | Qt.ItemFlag.ItemIsEnabled
                | Qt.ItemFlag.ItemIsSelectable
            )

            if page_index in self.checked_pages:
                item.setCheckState(Qt.CheckState.Checked)
            else:
                item.setCheckState(Qt.CheckState.Unchecked)

            self.page_list_widget.addItem(item)

        self._updating_page_list = False
        self._update_checked_pages_label()

    def _refresh_page_list_item(self, page_index: int) -> None:
        if not hasattr(self, "page_list_widget"):
            return

        if page_index < 0 or page_index >= self.page_list_widget.count():
            return

        self._updating_page_list = True

        item = self.page_list_widget.item(page_index)
        item.setText(self._page_list_text(page_index))

        if page_index in self.checked_pages:
            item.setCheckState(Qt.CheckState.Checked)
        else:
            item.setCheckState(Qt.CheckState.Unchecked)

        self._updating_page_list = False

    def _refresh_page_list_all_text(self) -> None:
        if not hasattr(self, "page_list_widget"):
            return

        self._updating_page_list = True

        for index in range(self.page_list_widget.count()):
            item = self.page_list_widget.item(index)
            page_index = item.data(Qt.ItemDataRole.UserRole)
            item.setText(self._page_list_text(page_index))

            if page_index in self.checked_pages:
                item.setCheckState(Qt.CheckState.Checked)
            else:
                item.setCheckState(Qt.CheckState.Unchecked)

        self._updating_page_list = False
        self._update_checked_pages_label()

    def on_page_list_item_clicked(self, item: QListWidgetItem) -> None:
        page_index = item.data(Qt.ItemDataRole.UserRole)

        if page_index is None:
            return

        if page_index == self.current_page_index:
            return

        if page_index < 0 or page_index >= self.page_count:
            return

        self._save_current_selection()
        self.current_page_index = page_index
        self._render_current_page()

    def on_page_list_item_changed(self, item: QListWidgetItem) -> None:
        if self._updating_page_list:
            return

        page_index = item.data(Qt.ItemDataRole.UserRole)

        if page_index is None:
            return

        if item.checkState() == Qt.CheckState.Checked:
            if not self._selection_exists_for_page(page_index):
                self._updating_page_list = True
                item.setCheckState(Qt.CheckState.Unchecked)
                self._updating_page_list = False

                QMessageBox.warning(
                    self,
                    "No Selection",
                    f"Page {page_index + 1} has no selection area."
                )
                return

            self.checked_pages.add(page_index)
            self._log(f"Page checked from list: {page_index + 1}")
        else:
            self.checked_pages.discard(page_index)
            self._log(f"Page unchecked from list: {page_index + 1}")

        self.is_modified = True
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(page_index)
        self._update_checked_pages_label()
    def _save_current_selection(self) -> None:
        if self.page_count <= 0:
            return

        rect = self.preview_label.get_selection_rect()
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            self.page_selections.pop(self.current_page_index, None)
            return

        self.page_selections[self.current_page_index] = QRect(rect)

    def _restore_current_selection(self) -> None:
        rect = self.page_selections.get(self.current_page_index, QRect())
        self.preview_label.set_selection_rect(rect)
        self._update_selection_info(rect)

    def _update_selection_info(self, rect: QRect) -> None:
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            self.selection_info_label.setText("Selection: None")
            return

        self.selection_info_label.setText(
            f"Selection: x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
        )

    def _get_rotated_pixmap(self) -> QPixmap:
        if self.current_pixmap is None:
            raise RuntimeError("No pixmap is available.")

        angle = self.rotation_degrees % 360

        if angle == 0:
            return self.current_pixmap

        transform = QTransform()
        transform.rotate(angle)
        return self.current_pixmap.transformed(
            transform,
            Qt.TransformationMode.SmoothTransformation,
        )

    def _show_pixmap(self) -> None:
        if self.current_pixmap is None:
            return

        display_base = self._get_rotated_pixmap()
        self.current_display_base_width = display_base.width()
        self.current_display_base_height = display_base.height()

        if self.fit_to_page_enabled:
            viewport_size = self.preview_scroll.viewport().size()
            scaled = display_base.scaled(
                viewport_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

            self.current_display_scale_x = scaled.width() / display_base.width()
            self.current_display_scale_y = scaled.height() / display_base.height()

            self.preview_label.set_preview_pixmap(scaled)
            self.render_info_label.setText(
                f"Preview: Rendered, fitted {scaled.width()} x {scaled.height()}"
            )
            self.zoom_info_label.setText("Zoom: Fit Page")
        else:
            scaled_width = max(1, int(display_base.width() * self.preview_zoom_factor))
            scaled_height = max(1, int(display_base.height() * self.preview_zoom_factor))

            scaled = display_base.scaled(
                scaled_width,
                scaled_height,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

            self.current_display_scale_x = scaled.width() / display_base.width()
            self.current_display_scale_y = scaled.height() / display_base.height()

            self.preview_label.set_preview_pixmap(scaled)
            self.render_info_label.setText(
                f"Preview: Rendered, zoomed {scaled.width()} x {scaled.height()}"
            )
            self.zoom_info_label.setText(
                f"Zoom: {int(self.preview_zoom_factor * 100)}%"
            )

        self.rotation_info_label.setText(f"Rotation: {self.rotation_degrees % 360}°")
        self._restore_current_selection()

    def _render_current_page(self) -> None:
        if self.page_count <= 0:
            self._log("Render skipped: page count is zero.")
            return

        try:
            self._log(f"Rendering page {self.current_page_index + 1}/{self.page_count}...")
            self.current_pixmap = self.pdf_renderer.render_page(
                self.current_page_index,
                zoom=self.render_zoom,
            )
            self._show_pixmap()

            self.page_label.setText(
                f"Page: {self.current_page_index + 1} / {self.page_count}"
            )

            self._update_page_buttons()
            self._sync_page_jump_spin()
            self._refresh_current_page_check_state()
            self._refresh_page_list_all_text()

            self._log(
                f"Rendered page {self.current_page_index + 1}/{self.page_count}, "
                f"pixmap={self.current_pixmap.width()}x{self.current_pixmap.height()}."
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Render Error",
                f"Failed to render PDF page.\n\n{exc}"
            )
            self._log(f"Render error: {exc}")

    def _update_page_buttons(self) -> None:
        has_pdf = self.page_count > 0
        self.prev_button.setEnabled(has_pdf and self.current_page_index > 0)
        self.next_button.setEnabled(has_pdf and self.current_page_index < self.page_count - 1)

    def _map_rotated_point_to_original_render(self, x: float, y: float) -> tuple[float, float]:
        if self.current_pixmap is None:
            raise RuntimeError("No pixmap is available.")

        original_w = float(self.current_pixmap.width())
        original_h = float(self.current_pixmap.height())
        angle = self.rotation_degrees % 360

        if angle == 0:
            return x, y

        if angle == 90:
            return y, original_h - x

        if angle == 180:
            return original_w - x, original_h - y

        if angle == 270:
            return original_w - y, x

        return x, y

    def _preview_rect_to_pdf_selection(self, rect: QRect) -> SelectionRect:
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            raise RuntimeError("Invalid selection rectangle.")

        x0 = rect.x() / self.current_display_scale_x
        y0 = rect.y() / self.current_display_scale_y
        x1 = (rect.x() + rect.width()) / self.current_display_scale_x
        y1 = (rect.y() + rect.height()) / self.current_display_scale_y

        points = [
            self._map_rotated_point_to_original_render(x0, y0),
            self._map_rotated_point_to_original_render(x1, y0),
            self._map_rotated_point_to_original_render(x0, y1),
            self._map_rotated_point_to_original_render(x1, y1),
        ]

        xs = [point[0] for point in points]
        ys = [point[1] for point in points]

        render_x0 = min(xs)
        render_y0 = min(ys)
        render_x1 = max(xs)
        render_y1 = max(ys)

        pdf_x = render_x0 / self.render_zoom
        pdf_y = render_y0 / self.render_zoom
        pdf_w = (render_x1 - render_x0) / self.render_zoom
        pdf_h = (render_y1 - render_y0) / self.render_zoom

        return SelectionRect(
            x=pdf_x,
            y=pdf_y,
            width=pdf_w,
            height=pdf_h,
        )

    def _build_export_selections(self) -> dict[int, SelectionRect]:
        self._save_current_selection()

        if not self.checked_pages:
            raise RuntimeError("No checked pages exist. Please select an area and check pages for export.")

        result = {}

        for page_index in sorted(self.checked_pages):
            rect = self.page_selections.get(page_index)
            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            result[page_index] = self._preview_rect_to_pdf_selection(rect)

        if not result:
            raise RuntimeError("Checked pages do not have valid selections.")

        return result

    def on_selection_changed(self, rect: QRect) -> None:
        self._push_undo_state()
        self._update_selection_info(rect)

        if self.page_count > 0:
            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                self.page_selections.pop(self.current_page_index, None)
                self.checked_pages.discard(self.current_page_index)
                self._refresh_current_page_check_state()
                self._refresh_page_list_item(self.current_page_index)
                self._log(f"Selection cleared for page {self.current_page_index + 1}.")
            else:
                self.page_selections[self.current_page_index] = QRect(rect)
                self.checked_pages.add(self.current_page_index)
                self._refresh_current_page_check_state()
                self._refresh_page_list_item(self.current_page_index)
                self._log(
                    f"Selection changed on page {self.current_page_index + 1}: "
                    f"x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
                )

            self.is_modified = True

    def new_project(self) -> None:
        if not self._confirm_discard_changes():
            return

        self.page_selections.clear()
        self.checked_pages.clear()
        self.undo_stack.clear()
        self.redo_stack.clear()
        self._update_undo_redo_actions()
        self.last_exported_pdf_path = None
        self.current_pdf_path = None
        self.current_project_path = None
        self.current_page_index = 0
        self.page_count = 0
        self.current_pixmap = None
        self.rotation_degrees = 0
        self.preview_zoom_factor = 1.0
        self.fit_to_page_enabled = True
        self.preview_label.clear_preview()
        self.pdf_path_label.setText("PDF: Not selected")
        self.pdf_info_label.setText("Pages: -")
        self.render_info_label.setText("Preview: Not rendered")
        self.zoom_info_label.setText("Zoom: Fit Page")
        self.rotation_info_label.setText("Rotation: 0°")
        self.selection_info_label.setText("Selection: None")
        self.checked_pages_label.setText("Checked pages: 0")
        self.page_label.setText("Page: - / -")
        if hasattr(self, "page_list_widget"):
            self.page_list_widget.clear()
        self._update_page_buttons()
        self.is_modified = False
        self._log("New Project selected.")

    def open_project(self) -> None:
        if not self._confirm_discard_changes():
            return

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Project",
            str(PROJECTS_DIR),
            "A4 to A3 Project Files (*.a4a3proj);;JSON Files (*.json);;All Files (*)"
        )

        if not file_path:
            return

        self.load_project_from_path(file_path)

    def save_project(self) -> None:
        if not self.current_project_path:
            self.save_project_as()
            return

        try:
            data = self._collect_project_data()
            self.project_manager.save_project(self.current_project_path, data)
            self._add_recent_project(self.current_project_path)
            self.is_modified = False
            self._log(f"Project saved: {self.current_project_path}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Save Project Error",
                f"Failed to save project.\n\n{exc}"
            )
            self._log(f"Save project error: {exc}")

    def save_project_as(self) -> None:
        default_path = PROJECTS_DIR / "project.a4a3proj"

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Project As",
            str(default_path),
            "A4 to A3 Project Files (*.a4a3proj);;JSON Files (*.json);;All Files (*)"
        )

        if not file_path:
            return

        try:
            data = self._collect_project_data()
            self.project_manager.save_project(file_path, data)
            saved_path = Path(file_path)
            if saved_path.suffix.lower() != ".a4a3proj":
                saved_path = saved_path.with_suffix(".a4a3proj")

            self.current_project_path = str(saved_path)
            self._add_recent_project(self.current_project_path)
            self.is_modified = False
            self._log(f"Project saved as: {self.current_project_path}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Save Project Error",
                f"Failed to save project.\n\n{exc}"
            )
            self._log(f"Save project error: {exc}")

    def _open_pdf_path(self, file_path: str, clear_selections: bool = True) -> None:
        self._log(f"Opening PDF: {file_path}")
        self.page_count = self.pdf_renderer.open(file_path)
        self.current_page_index = 0
        self.current_pdf_path = file_path

        if clear_selections:
            self.page_selections.clear()
            self.checked_pages.clear()

        self.pdf_path_label.setText(f"PDF: {file_path}")
        self.pdf_info_label.setText(f"Pages: {self.page_count}")
        self.selection_info_label.setText("Selection: None")

        self._log(f"PDF opened: {file_path}")
        self._log(f"PDF page count: {self.page_count}")

        self._render_current_page()
        self._rebuild_page_list()

    def open_pdf(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open PDF",
            "",
            "PDF Files (*.pdf)"
        )

        if not file_path:
            return

        try:
            self._open_pdf_path(file_path, clear_selections=True)
            self.is_modified = True

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open PDF Error",
                f"Failed to open PDF.\n\n{exc}"
            )
            self._log(f"Open PDF error: {exc}")

    def previous_page(self) -> None:
        if self.current_page_index <= 0:
            return

        self._save_current_selection()
        self.current_page_index -= 1
        self._render_current_page()

    def next_page(self) -> None:
        if self.current_page_index >= self.page_count - 1:
            return

        self._save_current_selection()
        self.current_page_index += 1
        self._render_current_page()

    def on_wheel_zoom_requested(self, direction: int) -> None:
        if direction > 0:
            self.zoom_in()
        elif direction < 0:
            self.zoom_out()

    def zoom_in(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.fit_to_page_enabled = False
        self.preview_zoom_factor = min(
            self.preview_zoom_factor * self.preview_zoom_step,
            self.preview_zoom_max,
        )
        self._show_pixmap()
        self._log(f"Zoom In applied: {int(self.preview_zoom_factor * 100)}%.")

    def zoom_out(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.fit_to_page_enabled = False
        self.preview_zoom_factor = max(
            self.preview_zoom_factor / self.preview_zoom_step,
            self.preview_zoom_min,
        )
        self._show_pixmap()
        self._log(f"Zoom Out applied: {int(self.preview_zoom_factor * 100)}%.")

    def fit_page(self) -> None:
        self._push_undo_state()
        self._save_current_selection()
        self.fit_to_page_enabled = True
        self._show_pixmap()
        self._log("Fit Page applied.")

    def actual_size(self) -> None:
        self._push_undo_state()
        self._save_current_selection()
        self.fit_to_page_enabled = False
        self.preview_zoom_factor = 1.0
        self._show_pixmap()
        self._log("Actual Size applied.")

    def _make_display_basis_pixmap(self, source_pixmap: QPixmap) -> QPixmap:
        display_base = source_pixmap

        angle = self.rotation_degrees % 360
        if angle != 0:
            transform = QTransform()
            transform.rotate(angle)
            display_base = source_pixmap.transformed(
                transform,
                Qt.TransformationMode.SmoothTransformation,
            )

        if self.fit_to_page_enabled:
            viewport_size = self.preview_scroll.viewport().size()
            return display_base.scaled(
                viewport_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

        scaled_width = max(1, int(display_base.width() * self.preview_zoom_factor))
        scaled_height = max(1, int(display_base.height() * self.preview_zoom_factor))

        return display_base.scaled(
            scaled_width,
            scaled_height,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
    def _get_auto_select_threshold(self) -> int:
        if hasattr(self, "auto_select_sensitivity_combo"):
            return int(self.auto_select_sensitivity_combo.currentData())
        return 245

    def _auto_select_rect_from_pixmap(self, pixmap: QPixmap, threshold: int, padding: int = 8) -> QRect:
        image = pixmap.toImage()
        width = image.width()
        height = image.height()

        if width <= 0 or height <= 0:
            return QRect()

        min_x = width
        min_y = height
        max_x = -1
        max_y = -1

        step = max(1, min(width, height) // 1000)

        for y in range(0, height, step):
            for x in range(0, width, step):
                color = image.pixelColor(x, y)

                if (
                    color.red() < threshold
                    or color.green() < threshold
                    or color.blue() < threshold
                ):
                    min_x = min(min_x, x)
                    min_y = min(min_y, y)
                    max_x = max(max_x, x)
                    max_y = max(max_y, y)

        if max_x < min_x or max_y < min_y:
            return QRect()

        min_x = max(0, min_x - padding)
        min_y = max(0, min_y - padding)
        max_x = min(width - 1, max_x + padding)
        max_y = min(height - 1, max_y + padding)

        return QRect(
            min_x,
            min_y,
            max_x - min_x + 1,
            max_y - min_y + 1,
        ).normalized()

    def auto_select_content(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            QMessageBox.warning(self, "No PDF", "Please open a PDF first.")
            return

        threshold = self._get_auto_select_threshold()
        rect = self.preview_label.auto_select_content(threshold=threshold, padding=8)

        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            QMessageBox.information(
                self,
                "Auto Select",
                "No visible content was detected. Please select an area manually."
            )
            self._log("Auto Select Current Page: no content detected.")
            return

        self.page_selections[self.current_page_index] = QRect(rect)
        self.checked_pages.add(self.current_page_index)

        self._update_selection_info(rect)
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(self.current_page_index)
        self._update_checked_pages_label()

        self.is_modified = True

        self._log(
            f"Auto Select Current Page {self.current_page_index + 1}: "
            f"x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}, "
            f"threshold={threshold}"
        )

    def auto_select_all_pages(self) -> None:
        self._push_undo_state()
        if not self.current_pdf_path or self.page_count <= 0:
            QMessageBox.warning(self, "No PDF", "Please open a PDF first.")
            return

        result = QMessageBox.question(
            self,
            "Auto Select All Pages",
            "Automatically detect content area for all pages?\n\nExisting selections may be replaced.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if result != QMessageBox.StandardButton.Yes:
            return

        threshold = self._get_auto_select_threshold()
        selected_count = 0
        failed_pages = []

        original_page_index = self.current_page_index

        try:
            for page_index in range(self.page_count):
                pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)
                display_pixmap = self._make_display_basis_pixmap(pixmap)

                rect = self._auto_select_rect_from_pixmap(
                    pixmap=display_pixmap,
                    threshold=threshold,
                    padding=8,
                )

                if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    self.page_selections.pop(page_index, None)
                    self.checked_pages.discard(page_index)
                    failed_pages.append(page_index + 1)
                    continue

                self.page_selections[page_index] = QRect(rect)
                self.checked_pages.add(page_index)
                selected_count += 1

            self.current_page_index = original_page_index
            self._render_current_page()
            self._refresh_page_list_all_text()
            self._refresh_current_page_check_state()
            self._update_checked_pages_label()

            self.is_modified = True

            message = f"Auto selection completed.\n\nSelected pages: {selected_count}/{self.page_count}"

            if failed_pages:
                message += "\n\nNo content detected on pages:\n"
                message += ", ".join(str(page) for page in failed_pages[:30])

            QMessageBox.information(self, "Auto Select All Pages", message)

            self._log(
                f"Auto Select All Pages completed: selected={selected_count}, "
                f"failed={len(failed_pages)}, threshold={threshold}, basis=preview_display"
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Auto Select Error",
                f"Failed to auto select all pages.\n\n{exc}"
            )
            self._log(f"Auto Select All Pages error: {exc}")
    def clear_selection(self) -> None:
        self._push_undo_state()
        self.preview_label.clear_selection()
        if self.page_count > 0:
            self.page_selections.pop(self.current_page_index, None)
            self.checked_pages.discard(self.current_page_index)
        self.selection_info_label.setText("Selection: None")
        self._refresh_current_page_check_state()
        self._refresh_page_list_item(self.current_page_index)
        self.is_modified = True
        self._log("Selection cleared.")

    def apply_selection_to_all_pages(self) -> None:
        self._push_undo_state()
        if self.page_count <= 0:
            QMessageBox.warning(self, "No PDF", "Please open a PDF first.")
            return

        rect = self.preview_label.get_selection_rect()

        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            QMessageBox.warning(self, "No Selection", "Please select an area first.")
            return

        for page_index in range(self.page_count):
            self.page_selections[page_index] = QRect(rect)
            self.checked_pages.add(page_index)

        self.is_modified = True
        self._refresh_current_page_check_state()
        self._refresh_page_list_all_text()
        self._log(
            f"Selection applied to all pages: x={rect.x()}, y={rect.y()}, "
            f"w={rect.width()}, h={rect.height()}, pages={self.page_count}"
        )
        QMessageBox.information(
            self,
            "Applied",
            f"Selection was applied to all {self.page_count} pages."
        )

    def rotate_left(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.rotation_degrees = (self.rotation_degrees - 90) % 360
        self._show_pixmap()
        self._log(f"Rotate Left applied: {self.rotation_degrees} degrees.")

    def rotate_right(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.rotation_degrees = (self.rotation_degrees + 90) % 360
        self._show_pixmap()
        self._log(f"Rotate Right applied: {self.rotation_degrees} degrees.")

    def reset_rotation(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self.rotation_degrees = 0
        self._show_pixmap()
        self._log("Rotation reset.")
    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        try:
            export_selections = self._build_export_selections()
        except Exception as exc:
            QMessageBox.warning(self, "No Selection", str(exc))
            return

        if self.export_type_combo.currentData() == "selection_only":
            default_name = Path(self.current_pdf_path).stem + "_selection_only_A4.pdf"
        else:
            default_name = Path(self.current_pdf_path).stem + "_A3_split_A4.pdf"
        default_path = EXPORTS_DIR / default_name

        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export PDF",
            str(default_path),
            "PDF Files (*.pdf)"
        )

        if not output_path:
            return

        options = ExportOptions(
            export_type=self.export_type_combo.currentData(),
            selection_fit_mode=self.selection_fit_mode_combo.currentData(),
            page_orientation=self.page_orientation_combo.currentData(),
            output_mode=self.output_mode_combo.currentData(),
            split_layout=self.split_layout_combo.currentData(),
            add_numbers=self.numbering_check.isChecked(),
            add_cut_guides=self.cut_guides_check.isChecked(),
            quality_scale=float(self.export_quality_combo.currentData()),
        )

        try:
            self._log("Export started.")
            self._log(f"Output: {output_path}")
            self._log(f"Export type: {options.export_type}")
            self._log(f"Selection fit mode: {options.selection_fit_mode}")
            self._log(f"Page orientation: {options.page_orientation}")
            self._log(f"Export quality scale: {options.quality_scale}")
            self._log(f"Output mode: {options.output_mode}")
            self._log(f"Split layout: {options.split_layout}")
            self._log(f"Cut guides: {options.add_cut_guides}")
            self._log(f"Selected pages: {len(export_selections)}")
            self._log(f"Batch output: {self.batch_output_combo.currentData()}")
            self._log(f"Auto select sensitivity: {self.auto_select_sensitivity_combo.currentText()} / {self.auto_select_sensitivity_combo.currentData()}")

            exporter = PosterExporter()

            if self.batch_output_combo.currentData() == "separate_pdf_per_page":
                base_path = Path(output_path)
                output_files = []

                for page_index, selection in export_selections.items():
                    page_output = base_path.with_name(
                        f"{base_path.stem}_page_{page_index + 1:03d}{base_path.suffix}"
                    )

                    exporter.export(
                        source_pdf_path=self.current_pdf_path,
                        output_pdf_path=str(page_output),
                        selections={page_index: selection},
                        options=options,
                    )
                    output_files.append(str(page_output))

                if output_files:
                    self.last_exported_pdf_path = output_files[0]

                self._log(f"Export completed. Files created: {len(output_files)}")
                QMessageBox.information(
                    self,
                    "Export Complete",
                    "Separate PDF files were created:\n\n" + "\n".join(output_files[:10])
                )
            else:
                exporter.export(
                    source_pdf_path=self.current_pdf_path,
                    output_pdf_path=output_path,
                    selections=export_selections,
                    options=options,
                )

                self.last_exported_pdf_path = output_path

                self._log("Export completed.")
                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Output PDF was created:\n\n{output_path}"
                )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Export Error",
                f"Failed to export split print PDF.\n\n{exc}"
            )
            self._log(f"Export error: {exc}")

    def _create_temp_print_pdf(self) -> str:
        if not self.current_pdf_path:
            raise RuntimeError("Please open a PDF first.")

        export_selections = self._build_export_selections()

        temp_dir = DATA_DIR / "temp_print"
        temp_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        temp_path = temp_dir / f"temp_print_{timestamp}.pdf"

        options = ExportOptions(
            export_type=self.export_type_combo.currentData(),
            selection_fit_mode=self.selection_fit_mode_combo.currentData(),
            page_orientation=self.page_orientation_combo.currentData(),
            output_mode=self.output_mode_combo.currentData(),
            split_layout=self.split_layout_combo.currentData(),
            add_numbers=self.numbering_check.isChecked(),
            add_cut_guides=self.cut_guides_check.isChecked(),
            quality_scale=float(self.export_quality_combo.currentData()),
        )

        exporter = PosterExporter()
        exporter.export(
            source_pdf_path=self.current_pdf_path,
            output_pdf_path=str(temp_path),
            selections=export_selections,
            options=options,
        )

        self.last_temp_print_pdf_path = str(temp_path)
        self._log(f"Temporary print PDF created: {temp_path}")

        return str(temp_path)
    def open_last_exported_pdf(self) -> None:
        if not self.last_exported_pdf_path:
            QMessageBox.information(
                self,
                "Open Last Exported PDF",
                "No exported PDF is available yet.\n\nPlease export a PDF first."
            )
            return

        path = Path(self.last_exported_pdf_path)

        if not path.exists():
            QMessageBox.warning(
                self,
                "Open Last Exported PDF",
                f"The last exported PDF was not found:\n\n{path}"
            )
            return

        try:
            os.startfile(str(path))
            self._log(f"Opened last exported PDF: {path}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open Error",
                f"Failed to open the exported PDF.\n\n{exc}"
            )
            self._log(f"Open last exported PDF error: {exc}")

    def direct_print_last_exported_pdf(self) -> None:
        self.print_last_exported_pdf_with_dialog()

    def print_last_exported_pdf_with_dialog(self) -> None:
        if not self.last_exported_pdf_path:
            QMessageBox.information(
                self,
                "Print",
                "No exported PDF is available yet.\n\nPlease export a PDF first."
            )
            return

        path = Path(self.last_exported_pdf_path)

        if not path.exists():
            QMessageBox.warning(
                self,
                "Print",
                f"The last exported PDF was not found:\n\n{path}"
            )
            return

        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        printer.setResolution(self.print_dpi)
        printer.setFullPage(False)

        dialog = QPrintDialog(printer, self)
        dialog.setWindowTitle("Print Exported PDF")

        if dialog.exec() != QPrintDialog.DialogCode.Accepted:
            self._log("Print canceled.")
            return

        try:
            self._print_pdf_to_printer(str(path), printer)
            self._log(f"Printed PDF with Qt Print Dialog: {path}")
            QMessageBox.information(
                self,
                "Print",
                "Print job was sent to the printer."
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Print Error",
                f"Failed to print PDF.\n\n{exc}"
            )
            self._log(f"Qt print error: {exc}")

    def _print_pdf_to_printer(self, pdf_path: str, printer: QPrinter) -> None:
        document = fitz.open(pdf_path)
        painter = QPainter()

        if not painter.begin(printer):
            document.close()
            raise RuntimeError("Failed to start printer painter.")

        try:
            page_count = len(document)
            dpi = max(150, int(printer.resolution()))
            zoom = dpi / 72.0

            page_rect = printer.pageRect(QPrinter.Unit.DevicePixel)
            target_width = int(page_rect.width())
            target_height = int(page_rect.height())

            for page_index in range(page_count):
                if page_index > 0:
                    printer.newPage()

                page = document.load_page(page_index)
                matrix = fitz.Matrix(zoom, zoom)

                pix = page.get_pixmap(
                    matrix=matrix,
                    alpha=False,
                    colorspace=fitz.csRGB,
                )

                image = QImage(
                    pix.samples,
                    pix.width,
                    pix.height,
                    pix.stride,
                    QImage.Format.Format_RGB888,
                ).copy()

                scaled = image.scaled(
                    target_width,
                    target_height,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )

                x = int((target_width - scaled.width()) / 2)
                y = int((target_height - scaled.height()) / 2)

                painter.drawImage(x, y, scaled)

        finally:
            painter.end()
            document.close()
    def print_pdf(self) -> None:
        self._log("Print selected.")

        if not self.current_pdf_path:
            QMessageBox.information(
                self,
                "Print",
                "Please open a PDF first."
            )
            return

        try:
            if hasattr(self, "print_quality_combo"):
                self.print_dpi = int(self.print_quality_combo.currentData())

            self._log("Creating temporary PDF for printing...")
            temp_pdf_path = self._create_temp_print_pdf()
        except Exception as exc:
            QMessageBox.warning(
                self,
                "Print",
                f"Failed to create temporary print PDF.\n\n{exc}"
            )
            self._log(f"Temporary print PDF error: {exc}")
            return

        result = QMessageBox.question(
            self,
            "Print",
            "A temporary print PDF was created from the current settings.\n\n"
            "Yes: Print now with printer selection dialog\n"
            "No: Open the temporary PDF and print manually",
            QMessageBox.StandardButton.Yes |
            QMessageBox.StandardButton.No |
            QMessageBox.StandardButton.Cancel
        )

        if result == QMessageBox.StandardButton.Yes:
            old_last_exported = self.last_exported_pdf_path
            self.last_exported_pdf_path = temp_pdf_path

            try:
                self.print_last_exported_pdf_with_dialog()
            finally:
                self.last_exported_pdf_path = old_last_exported

        elif result == QMessageBox.StandardButton.No:
            try:
                os.startfile(temp_pdf_path)
                self._log(f"Opened temporary print PDF: {temp_pdf_path}")
            except Exception as exc:
                QMessageBox.critical(
                    self,
                    "Open Error",
                    f"Failed to open temporary print PDF.\n\n{exc}"
                )
                self._log(f"Open temporary print PDF error: {exc}")
    def set_basic_mode(self) -> None:
        self.mode_label.setText("Mode: Basic")
        self._log("Switched to Basic Mode.")

    def set_advanced_mode(self) -> None:
        self.mode_label.setText("Mode: Advanced")
        self._log("Switched to Advanced Mode.")

    def show_log_panel(self) -> None:
        self.log_dock.show()
        self._log("Log panel shown.")

    def show_quick_start(self) -> None:
        QMessageBox.information(
            self,
            "Quick Start",
            "1. Open PDF\n2. Drag on preview to select area\n3. Choose output mode\n4. Choose split layout\n5. Export split-print PDF\n6. Print the exported PDF with an A4 printer"
        )

    def run_diagnostics(self) -> None:
        self._log("Diagnostics started.")
        self._log(f"PDF loaded: {bool(self.current_pdf_path)}")
        self._log(f"Page count: {self.page_count}")
        self._log(f"Current page index: {self.current_page_index}")
        self._log(f"Pixmap exists: {self.current_pixmap is not None}")
        self._log(f"Selection pages: {len(self.page_selections)}")
        self._log(f"Checked pages: {len(self.checked_pages)}")
        self._log(f"Batch output: {self.batch_output_combo.currentData()}")
        self._log(f"Auto select sensitivity: {self.auto_select_sensitivity_combo.currentText()} / {self.auto_select_sensitivity_combo.currentData()}")
        self._log(f"Export type: {self.export_type_combo.currentData()}")
        self._log(f"Selection fit mode: {self.selection_fit_mode_combo.currentData()}")
        self._log(f"Page orientation: {self.page_orientation_combo.currentData()}")
        self._log(f"Export quality: {self.export_quality_combo.currentText()} / {self.export_quality_combo.currentData()}")
        self._log(f"Cut guides enabled: {self.cut_guides_check.isChecked()}")
        self._log(f"Display scale x: {self.current_display_scale_x}")
        self._log(f"Display scale y: {self.current_display_scale_y}")
        self._log(f"Render zoom: {self.render_zoom}")
        self._log(f"Preview zoom factor: {self.preview_zoom_factor}")
        self._log(f"Rotation degrees: {self.rotation_degrees}")
        self._log("Export quality scale: 2.5")

        current_rect = self.preview_label.get_selection_rect()
        self._log(
            f"Current selection: x={current_rect.x()}, y={current_rect.y()}, "
            f"w={current_rect.width()}, h={current_rect.height()}"
        )

        if self.current_pixmap is not None:
            self._log(
                f"Pixmap size: {self.current_pixmap.width()} x {self.current_pixmap.height()}"
            )

        self._log("Diagnostics finished.")

    def check_menu_actions(self) -> None:
        self._log("Menu action check started.")

        checks = [
            ("File > New Project", callable(self.new_project)),
            ("File > Open Project", callable(self.open_project)),
            ("File > Save Project", callable(self.save_project)),
            ("File > Save Project As", callable(self.save_project_as)),
            ("File > Open PDF", callable(self.open_pdf)),
            ("File > Export PDF", callable(self.export_print_pdf)),
            ("File > Open Last Exported PDF", callable(self.open_last_exported_pdf)),
            ("File > Print", callable(self.print_pdf)),
            ("File > Direct Print Last Exported PDF", callable(self.direct_print_last_exported_pdf)),
            ("File > Qt Print Dialog", callable(self.print_last_exported_pdf_with_dialog)),
            ("Edit > Clear Selection", callable(self.clear_selection)),
            ("Edit > Apply Selection to All Pages", callable(self.apply_selection_to_all_pages)),
            ("View > Previous Page", callable(self.previous_page)),
            ("View > Next Page", callable(self.next_page)),
            ("View > Zoom In", callable(self.zoom_in)),
            ("View > Zoom Out", callable(self.zoom_out)),
            ("View > Fit Page", callable(self.fit_page)),
            ("View > Actual Size", callable(self.actual_size)),
            ("View > Rotate Left", callable(self.rotate_left)),
            ("View > Rotate Right", callable(self.rotate_right)),
            ("View > Reset Rotation", callable(self.reset_rotation)),
            ("View > Auto Select Current Page", callable(self.auto_select_content)),
            ("View > Auto Select All Pages", callable(self.auto_select_all_pages)),
            ("Help > Diagnostics", callable(self.run_diagnostics)),
        ]

        failed = []

        for name, ok in checks:
            if ok:
                self._log(f"OK: {name}")
            else:
                failed.append(name)
                self._log(f"FAILED: {name}")

        self._log(f"Menu action check completed. OK={len(checks) - len(failed)}, Failed={len(failed)}")

        if failed:
            QMessageBox.warning(
                self,
                "Menu Check",
                "Some menu actions are not connected.\n\n" + "\n".join(failed)
            )
        else:
            QMessageBox.information(
                self,
                "Menu Check",
                "All checked menu actions are connected."
            )

    def show_about(self) -> None:
        QMessageBox.about(
            self,
            "About",
            f"{APP_NAME}\nVersion: 0.4.0\nCreator: {CREATOR}"
        )

    def not_implemented(self) -> None:
        self._log("Not implemented menu selected.")
        QMessageBox.information(self, "Not Implemented", "This function will be implemented later.")

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)

        if self.current_pixmap is not None and self.fit_to_page_enabled:
            self._save_current_selection()
            self._show_pixmap()

    def closeEvent(self, event) -> None:
        if self.is_modified:
            result = QMessageBox.question(
                self,
                "Unsaved Changes",
                "There are unsaved changes. Save before exit?",
                QMessageBox.StandardButton.Save |
                QMessageBox.StandardButton.Discard |
                QMessageBox.StandardButton.Cancel
            )

            if result == QMessageBox.StandardButton.Save:
                self.save_project()
                if self.is_modified:
                    event.ignore()
                    return
            elif result == QMessageBox.StandardButton.Cancel:
                event.ignore()
                return

        self.pdf_renderer.close()
        self._log("Application closing.")
        event.accept()