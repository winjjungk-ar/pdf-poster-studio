from PyQt6.QtCore import Qt, QRect
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QTextEdit,
    QPushButton,
    QFileDialog,
    QMessageBox,
    QDockWidget,
    QScrollArea,
    QSizePolicy,
)

from app.constants import APP_NAME, CREATOR
from app.pdf.pdf_renderer import PdfRenderer
from app.ui.pdf_preview_widget import PdfPreviewWidget


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.current_pdf_path = None
        self.is_modified = False

        self.pdf_renderer = PdfRenderer()
        self.current_page_index = 0
        self.page_count = 0
        self.current_pixmap: QPixmap | None = None
        self.fit_to_page_enabled = True

        self.page_selections: dict[int, QRect] = {}

        self.setWindowTitle(f"{APP_NAME} v0.3.0")
        self.resize(1200, 800)

        self._create_menus()
        self._create_central_ui()
        self._create_log_panel()

        self._log("Application started.")
        self._log("SQLite database initialized.")
        self._log("PDF preview module loaded.")
        self._log("Selection module loaded.")

    def _create_menus(self) -> None:
        menu_bar = self.menuBar()

        file_menu = menu_bar.addMenu("File")
        edit_menu = menu_bar.addMenu("Edit")
        view_menu = menu_bar.addMenu("View")
        options_menu = menu_bar.addMenu("Options")
        help_menu = menu_bar.addMenu("Help")
        about_menu = menu_bar.addMenu("About")

        file_menu.addAction("New Project", self.new_project)
        file_menu.addAction("Open Project", self.open_project)
        file_menu.addAction("Save Project", self.save_project)
        file_menu.addAction("Save Project As", self.save_project_as)
        file_menu.addSeparator()
        file_menu.addAction("Open PDF", self.open_pdf)
        file_menu.addAction("Export Print PDF", self.export_print_pdf)
        file_menu.addAction("Print", self.print_pdf)
        file_menu.addSeparator()
        file_menu.addAction("Exit", self.close)

        edit_menu.addAction("Undo", self.not_implemented)
        edit_menu.addAction("Redo", self.not_implemented)
        edit_menu.addSeparator()
        edit_menu.addAction("Clear Selection", self.clear_selection)
        edit_menu.addAction("Apply Selection to All Pages", self.apply_selection_to_all_pages)
        edit_menu.addAction("Reset Page Settings", self.not_implemented)

        view_menu.addAction("Previous Page", self.previous_page)
        view_menu.addAction("Next Page", self.next_page)
        view_menu.addSeparator()
        view_menu.addAction("Actual Size", self.actual_size)
        view_menu.addAction("Fit Page", self.fit_page)
        view_menu.addSeparator()
        view_menu.addAction("Show Log Panel", self.show_log_panel)

        options_menu.addAction("Basic Mode", self.set_basic_mode)
        options_menu.addAction("Advanced Mode", self.set_advanced_mode)
        options_menu.addSeparator()
        options_menu.addAction("Printer Margin Preset", self.not_implemented)
        options_menu.addAction("Output Mode", self.not_implemented)
        options_menu.addAction("Split Layout", self.not_implemented)
        options_menu.addAction("Numbering Settings", self.not_implemented)
        options_menu.addAction("Preferences", self.not_implemented)

        help_menu.addAction("Quick Start", self.show_quick_start)
        help_menu.addAction("Diagnostics", self.run_diagnostics)
        help_menu.addAction("Check Menu Actions", self.check_menu_actions)

        about_menu.addAction("About Program", self.show_about)

    def _create_central_ui(self) -> None:
        central = QWidget()
        root_layout = QHBoxLayout(central)

        preview_area = QWidget()
        preview_layout = QVBoxLayout(preview_area)

        self.preview_label = PdfPreviewWidget()
        self.preview_label.setSizePolicy(
            QSizePolicy.Policy.Ignored,
            QSizePolicy.Policy.Ignored,
        )
        self.preview_label.selection_changed.connect(self.on_selection_changed)

        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(False)
        self.preview_scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_scroll.setWidget(self.preview_label)

        nav_layout = QHBoxLayout()

        self.prev_button = QPushButton("Previous")
        self.next_button = QPushButton("Next")
        self.page_label = QLabel("Page: - / -")
        self.page_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.prev_button.clicked.connect(self.previous_page)
        self.next_button.clicked.connect(self.next_page)

        nav_layout.addWidget(self.prev_button)
        nav_layout.addWidget(self.page_label)
        nav_layout.addWidget(self.next_button)

        preview_layout.addWidget(self.preview_scroll)
        preview_layout.addLayout(nav_layout)

        settings_area = QWidget()
        settings_layout = QVBoxLayout(settings_area)

        title = QLabel("Basic Settings")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")

        self.pdf_path_label = QLabel("PDF: Not selected")
        self.pdf_path_label.setWordWrap(True)

        self.pdf_info_label = QLabel("Pages: -")
        self.render_info_label = QLabel("Preview: Not rendered")
        self.selection_info_label = QLabel("Selection: None")
        self.mode_label = QLabel("Mode: Basic")
        self.output_mode_label = QLabel("Output Mode: No-Cut")
        self.split_layout_label = QLabel("Split Layout: Left-Right")
        self.numbering_label = QLabel("Numbering: Enabled")

        open_pdf_button = QPushButton("Open PDF")
        open_pdf_button.clicked.connect(self.open_pdf)

        fit_button = QPushButton("Fit Page")
        fit_button.clicked.connect(self.fit_page)

        actual_button = QPushButton("Actual Size")
        actual_button.clicked.connect(self.actual_size)

        clear_selection_button = QPushButton("Clear Selection")
        clear_selection_button.clicked.connect(self.clear_selection)

        apply_all_button = QPushButton("Apply Selection to All Pages")
        apply_all_button.clicked.connect(self.apply_selection_to_all_pages)

        export_button = QPushButton("Export Split Print PDF")
        export_button.clicked.connect(self.export_print_pdf)

        settings_layout.addWidget(title)
        settings_layout.addWidget(self.pdf_path_label)
        settings_layout.addWidget(self.pdf_info_label)
        settings_layout.addWidget(self.render_info_label)
        settings_layout.addWidget(self.selection_info_label)
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.output_mode_label)
        settings_layout.addWidget(self.split_layout_label)
        settings_layout.addWidget(self.numbering_label)
        settings_layout.addSpacing(20)
        settings_layout.addWidget(open_pdf_button)
        settings_layout.addWidget(fit_button)
        settings_layout.addWidget(actual_button)
        settings_layout.addWidget(clear_selection_button)
        settings_layout.addWidget(apply_all_button)
        settings_layout.addWidget(export_button)
        settings_layout.addStretch()

        root_layout.addWidget(preview_area, 3)
        root_layout.addWidget(settings_area, 1)

        self.setCentralWidget(central)
        self._update_page_buttons()

    def _create_log_panel(self) -> None:
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)

        self.log_dock = QDockWidget("Log", self)
        self.log_dock.setWidget(self.log_text)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.log_dock)

    def _log(self, message: str) -> None:
        self.log_text.append(message)

    def _save_current_selection(self) -> None:
        if self.page_count <= 0:
            return

        rect = self.preview_label.get_selection_rect()
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            self.page_selections.pop(self.current_page_index, None)
            return

        self.page_selections[self.current_page_index] = rect

    def _restore_current_selection(self) -> None:
        rect = self.page_selections.get(self.current_page_index, QRect())
        self.preview_label.set_selection_rect(rect)
        self._update_selection_info(rect)

    def _update_selection_info(self, rect: QRect) -> None:
        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            self.selection_info_label.setText("Selection: None")
            return

        self.selection_info_label.setText(
            f"Selection: x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
        )

    def _show_pixmap(self) -> None:
        if self.current_pixmap is None:
            return

        if self.fit_to_page_enabled:
            viewport_size = self.preview_scroll.viewport().size()
            scaled = self.current_pixmap.scaled(
                viewport_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            self.preview_label.set_preview_pixmap(scaled)
            self.render_info_label.setText(
                f"Preview: Rendered, fitted {scaled.width()} x {scaled.height()}"
            )
        else:
            self.preview_label.set_preview_pixmap(self.current_pixmap)
            self.render_info_label.setText(
                f"Preview: Rendered, actual {self.current_pixmap.width()} x {self.current_pixmap.height()}"
            )

        self._restore_current_selection()

    def _render_current_page(self) -> None:
        if self.page_count <= 0:
            self._log("Render skipped: page count is zero.")
            return

        try:
            self._log(f"Rendering page {self.current_page_index + 1}/{self.page_count}...")
            self.current_pixmap = self.pdf_renderer.render_page(self.current_page_index)
            self._show_pixmap()

            self.page_label.setText(
                f"Page: {self.current_page_index + 1} / {self.page_count}"
            )

            self._update_page_buttons()

            self._log(
                f"Rendered page {self.current_page_index + 1}/{self.page_count}, "
                f"pixmap={self.current_pixmap.width()}x{self.current_pixmap.height()}."
            )

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Render Error",
                f"Failed to render PDF page.\n\n{exc}"
            )
            self._log(f"Render error: {exc}")

    def _update_page_buttons(self) -> None:
        has_pdf = self.page_count > 0
        self.prev_button.setEnabled(has_pdf and self.current_page_index > 0)
        self.next_button.setEnabled(has_pdf and self.current_page_index < self.page_count - 1)

    def on_selection_changed(self, rect: QRect) -> None:
        self._update_selection_info(rect)

        if self.page_count > 0:
            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                self.page_selections.pop(self.current_page_index, None)
                self._log(f"Selection cleared for page {self.current_page_index + 1}.")
            else:
                self.page_selections[self.current_page_index] = rect
                self._log(
                    f"Selection changed on page {self.current_page_index + 1}: "
                    f"x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
                )

            self.is_modified = True

    def new_project(self) -> None:
        self.page_selections.clear()
        self.current_pdf_path = None
        self.current_page_index = 0
        self.page_count = 0
        self.current_pixmap = None
        self.preview_label.clear_preview()
        self.pdf_path_label.setText("PDF: Not selected")
        self.pdf_info_label.setText("Pages: -")
        self.render_info_label.setText("Preview: Not rendered")
        self.selection_info_label.setText("Selection: None")
        self.page_label.setText("Page: - / -")
        self._update_page_buttons()
        self.is_modified = False
        self._log("New Project selected.")

    def open_project(self) -> None:
        self._log("Open Project selected.")
        QMessageBox.information(self, "Open Project", "Project loading will be implemented later.")

    def save_project(self) -> None:
        self._log("Save Project selected.")
        self.is_modified = False

    def save_project_as(self) -> None:
        self._log("Save Project As selected.")
        self.is_modified = False

    def open_pdf(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open PDF",
            "",
            "PDF Files (*.pdf)"
        )

        if not file_path:
            return

        try:
            self._log(f"Opening PDF: {file_path}")
            self.page_count = self.pdf_renderer.open(file_path)
            self.current_page_index = 0
            self.current_pdf_path = file_path
            self.page_selections.clear()

            self.pdf_path_label.setText(f"PDF: {file_path}")
            self.pdf_info_label.setText(f"Pages: {self.page_count}")
            self.selection_info_label.setText("Selection: None")
            self.is_modified = True

            self._log(f"PDF opened: {file_path}")
            self._log(f"PDF page count: {self.page_count}")

            self._render_current_page()

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open PDF Error",
                f"Failed to open PDF.\n\n{exc}"
            )
            self._log(f"Open PDF error: {exc}")

    def previous_page(self) -> None:
        if self.current_page_index <= 0:
            return

        self._save_current_selection()
        self.current_page_index -= 1
        self._render_current_page()

    def next_page(self) -> None:
        if self.current_page_index >= self.page_count - 1:
            return

        self._save_current_selection()
        self.current_page_index += 1
        self._render_current_page()

    def fit_page(self) -> None:
        self._save_current_selection()
        self.fit_to_page_enabled = True
        self._show_pixmap()
        self._log("Fit Page applied.")

    def actual_size(self) -> None:
        self._save_current_selection()
        self.fit_to_page_enabled = False
        self._show_pixmap()
        self._log("Actual Size applied.")

    def clear_selection(self) -> None:
        self.preview_label.clear_selection()
        if self.page_count > 0:
            self.page_selections.pop(self.current_page_index, None)
        self.selection_info_label.setText("Selection: None")
        self.is_modified = True
        self._log("Selection cleared.")

    def apply_selection_to_all_pages(self) -> None:
        if self.page_count <= 0:
            QMessageBox.warning(self, "No PDF", "Please open a PDF first.")
            return

        rect = self.preview_label.get_selection_rect()

        if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
            QMessageBox.warning(self, "No Selection", "Please select an area first.")
            return

        for page_index in range(self.page_count):
            self.page_selections[page_index] = QRect(rect)

        self.is_modified = True
        self._log(
            f"Selection applied to all pages: x={rect.x()}, y={rect.y()}, "
            f"w={rect.width()}, h={rect.height()}, pages={self.page_count}"
        )
        QMessageBox.information(
            self,
            "Applied",
            f"Selection was applied to all {self.page_count} pages."
        )

    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        if not self.page_selections:
            QMessageBox.warning(self, "No Selection", "Please select an area first.")
            return

        self._log("Export Print PDF selected.")
        QMessageBox.information(
            self,
            "Export",
            "Split-print PDF export will be implemented in version 0.4.0."
        )

    def print_pdf(self) -> None:
        self._log("Print selected.")
        QMessageBox.information(self, "Print", "Print function will be implemented later.")

    def set_basic_mode(self) -> None:
        self.mode_label.setText("Mode: Basic")
        self._log("Switched to Basic Mode.")

    def set_advanced_mode(self) -> None:
        self.mode_label.setText("Mode: Advanced")
        self._log("Switched to Advanced Mode.")

    def show_log_panel(self) -> None:
        self.log_dock.show()
        self._log("Log panel shown.")

    def show_quick_start(self) -> None:
        QMessageBox.information(
            self,
            "Quick Start",
            "1. Open PDF\n2. Drag on preview to select area\n3. Choose output mode\n4. Export split-print PDF\n5. Print with A4 printer"
        )

    def run_diagnostics(self) -> None:
        self._log("Diagnostics started.")
        self._log(f"PDF loaded: {bool(self.current_pdf_path)}")
        self._log(f"Page count: {self.page_count}")
        self._log(f"Current page index: {self.current_page_index}")
        self._log(f"Pixmap exists: {self.current_pixmap is not None}")
        self._log(f"Selection pages: {len(self.page_selections)}")

        current_rect = self.preview_label.get_selection_rect()
        self._log(
            f"Current selection: x={current_rect.x()}, y={current_rect.y()}, "
            f"w={current_rect.width()}, h={current_rect.height()}"
        )

        if self.current_pixmap is not None:
            self._log(
                f"Pixmap size: {self.current_pixmap.width()} x {self.current_pixmap.height()}"
            )

        self._log("Diagnostics finished.")

    def check_menu_actions(self) -> None:
        self._log("Menu action check started.")
        self._log("Menu action check result: Basic menu actions connected.")

    def show_about(self) -> None:
        QMessageBox.about(
            self,
            "About",
            f"{APP_NAME}\nVersion: 0.3.0\nCreator: {CREATOR}"
        )

    def not_implemented(self) -> None:
        self._log("Not implemented menu selected.")
        QMessageBox.information(self, "Not Implemented", "This function will be implemented later.")

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)

        if self.current_pixmap is not None and self.fit_to_page_enabled:
            self._save_current_selection()
            self._show_pixmap()

    def closeEvent(self, event) -> None:
        if self.is_modified:
            result = QMessageBox.question(
                self,
                "Unsaved Changes",
                "There are unsaved changes. Do you want to exit?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result != QMessageBox.StandardButton.Yes:
                event.ignore()
                return

        self.pdf_renderer.close()
        self._log("Application closing.")
        event.accept()