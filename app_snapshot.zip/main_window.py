from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QTextEdit,
    QPushButton,
    QFileDialog,
    QMessageBox,
    QDockWidget,
)

from app.constants import APP_NAME, APP_VERSION, CREATOR


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.current_pdf_path = None
        self.is_modified = False

        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(1200, 800)

        self._create_menus()
        self._create_central_ui()
        self._create_log_panel()
        self._log("Application started.")

    def _create_menus(self) -> None:
        menu_bar = self.menuBar()

        file_menu = menu_bar.addMenu("File")
        edit_menu = menu_bar.addMenu("Edit")
        view_menu = menu_bar.addMenu("View")
        options_menu = menu_bar.addMenu("Options")
        help_menu = menu_bar.addMenu("Help")
        about_menu = menu_bar.addMenu("About")

        file_menu.addAction("New Project", self.new_project)
        file_menu.addAction("Open Project", self.open_project)
        file_menu.addAction("Save Project", self.save_project)
        file_menu.addAction("Save Project As", self.save_project_as)
        file_menu.addSeparator()
        file_menu.addAction("Open PDF", self.open_pdf)
        file_menu.addAction("Export Print PDF", self.export_print_pdf)
        file_menu.addAction("Print", self.print_pdf)
        file_menu.addSeparator()
        file_menu.addAction("Exit", self.close)

        edit_menu.addAction("Undo", self.not_implemented)
        edit_menu.addAction("Redo", self.not_implemented)
        edit_menu.addSeparator()
        edit_menu.addAction("Clear Selection", self.not_implemented)
        edit_menu.addAction("Apply Selection to All Pages", self.not_implemented)
        edit_menu.addAction("Reset Page Settings", self.not_implemented)

        view_menu.addAction("Zoom In", self.not_implemented)
        view_menu.addAction("Zoom Out", self.not_implemented)
        view_menu.addAction("Fit Page", self.not_implemented)
        view_menu.addAction("Fit Width", self.not_implemented)
        view_menu.addSeparator()
        view_menu.addAction("Show Grid", self.not_implemented)
        view_menu.addAction("Show Cut Guides", self.not_implemented)
        view_menu.addAction("Show Numbering Preview", self.not_implemented)
        view_menu.addAction("Show Log Panel", self.show_log_panel)

        options_menu.addAction("Basic Mode", self.set_basic_mode)
        options_menu.addAction("Advanced Mode", self.set_advanced_mode)
        options_menu.addSeparator()
        options_menu.addAction("Printer Margin Preset", self.not_implemented)
        options_menu.addAction("Output Mode", self.not_implemented)
        options_menu.addAction("Split Layout", self.not_implemented)
        options_menu.addAction("Numbering Settings", self.not_implemented)
        options_menu.addAction("Preferences", self.not_implemented)

        help_menu.addAction("User Guide", self.not_implemented)
        help_menu.addAction("Quick Start", self.show_quick_start)
        help_menu.addAction("Troubleshooting", self.not_implemented)
        help_menu.addAction("Diagnostics", self.run_diagnostics)
        help_menu.addAction("Check Menu Actions", self.check_menu_actions)

        about_menu.addAction("About Program", self.show_about)

    def _create_central_ui(self) -> None:
        central = QWidget()
        root_layout = QHBoxLayout(central)

        preview_area = QWidget()
        preview_layout = QVBoxLayout(preview_area)

        self.preview_label = QLabel("PDF Preview Area\n\nOpen a PDF to begin.")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setStyleSheet(
            "QLabel { border: 1px solid #999; background: #f8f8f8; font-size: 18px; }"
        )

        preview_layout.addWidget(self.preview_label)

        settings_area = QWidget()
        settings_layout = QVBoxLayout(settings_area)

        title = QLabel("Basic Settings")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")

        self.pdf_path_label = QLabel("PDF: Not selected")
        self.mode_label = QLabel("Mode: Basic")
        self.output_mode_label = QLabel("Output Mode: No-Cut")
        self.split_layout_label = QLabel("Split Layout: Left-Right")
        self.numbering_label = QLabel("Numbering: Enabled")

        open_pdf_button = QPushButton("Open PDF")
        open_pdf_button.clicked.connect(self.open_pdf)

        export_button = QPushButton("Export Split Print PDF")
        export_button.clicked.connect(self.export_print_pdf)

        settings_layout.addWidget(title)
        settings_layout.addWidget(self.pdf_path_label)
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.output_mode_label)
        settings_layout.addWidget(self.split_layout_label)
        settings_layout.addWidget(self.numbering_label)
        settings_layout.addSpacing(20)
        settings_layout.addWidget(open_pdf_button)
        settings_layout.addWidget(export_button)
        settings_layout.addStretch()

        root_layout.addWidget(preview_area, 3)
        root_layout.addWidget(settings_area, 1)

        self.setCentralWidget(central)

    def _create_log_panel(self) -> None:
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)

        self.log_dock = QDockWidget("Log", self)
        self.log_dock.setWidget(self.log_text)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.log_dock)

    def _log(self, message: str) -> None:
        self.log_text.append(message)

    def new_project(self) -> None:
        self._log("New Project selected.")
        self.is_modified = False

    def open_project(self) -> None:
        self._log("Open Project selected.")
        QMessageBox.information(self, "Open Project", "Project loading will be implemented later.")

    def save_project(self) -> None:
        self._log("Save Project selected.")
        self.is_modified = False

    def save_project_as(self) -> None:
        self._log("Save Project As selected.")
        self.is_modified = False

    def open_pdf(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open PDF",
            "",
            "PDF Files (*.pdf)"
        )

        if not file_path:
            return

        self.current_pdf_path = file_path
        self.pdf_path_label.setText(f"PDF: {file_path}")
        self.preview_label.setText(f"PDF Loaded:\n{file_path}\n\nPreview rendering will be implemented in the next patch.")
        self.is_modified = True
        self._log(f"PDF opened: {file_path}")

    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        self._log("Export Print PDF selected.")
        QMessageBox.information(
            self,
            "Export",
            "Split-print PDF export will be implemented in the next PDF patch."
        )

    def print_pdf(self) -> None:
        self._log("Print selected.")
        QMessageBox.information(self, "Print", "Print function will be implemented later.")

    def set_basic_mode(self) -> None:
        self.mode_label.setText("Mode: Basic")
        self._log("Switched to Basic Mode.")

    def set_advanced_mode(self) -> None:
        self.mode_label.setText("Mode: Advanced")
        self._log("Switched to Advanced Mode.")

    def show_log_panel(self) -> None:
        self.log_dock.show()
        self._log("Log panel shown.")

    def show_quick_start(self) -> None:
        QMessageBox.information(
            self,
            "Quick Start",
            "1. Open PDF\n2. Select area\n3. Choose output mode\n4. Export split-print PDF\n5. Print with A4 printer"
        )

    def run_diagnostics(self) -> None:
        self._log("Diagnostics started.")
        self._log("Diagnostics result: Basic UI OK.")

    def check_menu_actions(self) -> None:
        self._log("Menu action check started.")
        self._log("Menu action check result: All basic menu actions are connected.")

    def show_about(self) -> None:
        QMessageBox.about(
            self,
            "About",
            f"{APP_NAME}\nVersion: {APP_VERSION}\nCreator: {CREATOR}"
        )

    def not_implemented(self) -> None:
        self._log("Not implemented menu selected.")
        QMessageBox.information(self, "Not Implemented", "This function will be implemented later.")

    def closeEvent(self, event) -> None:
        if self.is_modified:
            result = QMessageBox.question(
                self,
                "Unsaved Changes",
                "There are unsaved changes. Do you want to exit?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result != QMessageBox.StandardButton.Yes:
                event.ignore()
                return

        self._log("Application closing.")
        event.accept()