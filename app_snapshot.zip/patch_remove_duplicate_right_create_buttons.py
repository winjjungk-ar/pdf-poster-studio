﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_remove_duplicate_action_buttons_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Remove duplicated Create Poster / Create Single Page buttons
#    under right settings tabs, keep only action_summary_label.
# ------------------------------------------------------------
old_block = '''        action_button_layout = QHBoxLayout()

        self.action_create_poster_button = QPushButton("Create Poster PDF")
        self.action_create_poster_button.clicked.connect(self.create_poster_pdf)

        self.action_create_single_button = QPushButton("Create Single Page PDF")
        self.action_create_single_button.clicked.connect(self.create_single_page_pdf)

        action_button_layout.addWidget(self.action_create_poster_button)
        action_button_layout.addWidget(self.action_create_single_button)

        settings_layout.addWidget(self.action_summary_label)
        settings_layout.addLayout(action_button_layout)
'''

new_block = '''        settings_layout.addWidget(self.action_summary_label)
'''

if old_block in text:
    text = text.replace(old_block, new_block, 1)
    print("[OK] Removed duplicate Create buttons from right panel action bar")
else:
    print("[WARN] Exact action button block not found. Trying fallback removal.")

    fallback_parts = [
        '''        action_button_layout = QHBoxLayout()

''',
        '''        self.action_create_poster_button = QPushButton("Create Poster PDF")
        self.action_create_poster_button.clicked.connect(self.create_poster_pdf)

''',
        '''        self.action_create_single_button = QPushButton("Create Single Page PDF")
        self.action_create_single_button.clicked.connect(self.create_single_page_pdf)

''',
        '''        action_button_layout.addWidget(self.action_create_poster_button)
        action_button_layout.addWidget(self.action_create_single_button)

''',
        '''        settings_layout.addLayout(action_button_layout)
''',
    ]

    changed = False
    for part in fallback_parts:
        if part in text:
            text = text.replace(part, "", 1)
            changed = True

    if changed:
        print("[OK] Removed duplicate Create buttons by fallback")
    else:
        print("[SKIP] Duplicate Create buttons not found or already removed")

# ------------------------------------------------------------
# 2) Improve summary label wording to make it clear buttons are in toolbar
# ------------------------------------------------------------
old = '''        self.action_summary_label = QLabel("Print Order: 0 item(s) | Output: One PDF")
'''

new = '''        self.action_summary_label = QLabel(
            "Print Order: 0 item(s) | Output: One PDF | Use toolbar buttons to create PDFs"
        )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Updated action summary default wording")
else:
    print("[SKIP] Summary default wording already changed or anchor not found")

old = '''        self.action_summary_label.setText(
            f"Print Order: {print_order_count} item(s) | "
            f"Output: {output_text} | Area: {area_text}"
        )
'''

new = '''        self.action_summary_label.setText(
            f"Print Order: {print_order_count} item(s) | "
            f"Output: {output_text} | Area: {area_text}\\n"
            f"Use toolbar: Create Poster PDF / Create Single Page PDF"
        )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Updated action summary runtime wording")
else:
    print("[SKIP] Runtime summary wording already changed or anchor not found")

# ------------------------------------------------------------
# 3) Release Notes update
# ------------------------------------------------------------
if "Duplicate right-panel create buttons removed" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Duplicate right-panel create buttons removed</b>: Create Poster PDF and Create Single Page PDF remain in the main toolbar.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 4) Write and compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_remove_duplicate_action_buttons_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Duplicate right-panel create buttons removed",
    "Use toolbar: Create Poster PDF / Create Single Page PDF",
]:
    print(f"  - {marker}: {marker in new_text}")

# Check removed object names.
for marker in [
    "self.action_create_poster_button",
    "self.action_create_single_button",
]:
    print(f"  - removed {marker}: {marker not in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Duplicate Create Poster PDF / Create Single Page PDF buttons removed from right panel")
print("- Toolbar buttons remain")
print("- Right panel keeps only summary information")
