﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_make_poster_one_file_choice_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

def insert_before_function(source: str, func_name: str, code: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + code + "\n" + "".join(lines[node.lineno - 1:])

# ------------------------------------------------------------
# 1) Add open_one_source_file_for_poster helper
# ------------------------------------------------------------
helper = r'''
    def open_one_source_file_for_poster(self) -> bool:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open One PDF or Image for Poster",
            "",
            "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp);;"
            "PDF Files (*.pdf);;"
            "Image Files (*.png *.jpg *.jpeg *.bmp *.webp);;"
            "All Files (*)"
        )

        if not file_path:
            return False

        try:
            pdf_path = self._prepare_source_file_for_workspace(file_path)

            self.workspace_items = [self._make_workspace_item(pdf_path)]
            self.current_workspace_index = None

            if hasattr(self, "workspace_pdf_list"):
                self.workspace_pdf_list.clear()
            if hasattr(self, "export_order_list"):
                self.export_order_list.clear()

            self._refresh_workspace_list_text()
            self._load_workspace_index(0)

            self.is_modified = True
            self._log(f"Opened one source file for poster: {file_path}")
            return True

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open One File",
                f"Failed to open file.\\n\\n{exc}"
            )
            self._log(f"Open one source file for poster error: {exc}")
            return False

'''

if "def open_one_source_file_for_poster" not in text:
    try:
        text = insert_before_function(text, "task_make_poster", helper)
        print("[OK] Added open_one_source_file_for_poster")
    except Exception as exc:
        print(f"[ERROR] Could not insert helper: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] open_one_source_file_for_poster already exists")

# ------------------------------------------------------------
# 2) Replace task_make_poster
# ------------------------------------------------------------
new_task_make_poster = r'''    def task_make_poster(self) -> None:
        has_sources = hasattr(self, "workspace_items") and bool(self.workspace_items)

        if has_sources:
            source_dialog = QMessageBox(self)
            source_dialog.setWindowTitle("Make Poster")
            source_dialog.setIcon(QMessageBox.Icon.Question)
            source_dialog.setText("Choose source files for the poster.")
            source_dialog.setInformativeText(
                "Open One File is best for a single map, poster, image, or drawing.\n\n"
                "Use Current Source PDFs keeps the files already loaded in Source PDFs."
            )

            open_one_button = source_dialog.addButton("Open One File", QMessageBox.ButtonRole.AcceptRole)
            use_current_button = source_dialog.addButton("Use Current Source PDFs", QMessageBox.ButtonRole.ActionRole)
            cancel_button = source_dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

            source_dialog.setDefaultButton(open_one_button)
            source_dialog.exec()

            clicked = source_dialog.clickedButton()

            if clicked == cancel_button:
                return

            if clicked == open_one_button:
                if not self.open_one_source_file_for_poster():
                    return

            elif clicked == use_current_button:
                pass

            else:
                return

        else:
            if not self.open_one_source_file_for_poster():
                return

        self._set_combo_by_data_if_exists("export_type_combo", "a3_split")

        area_dialog = QMessageBox(self)
        area_dialog.setWindowTitle("Make Poster")
        area_dialog.setIcon(QMessageBox.Icon.Question)
        area_dialog.setText("What area do you want to use for the poster?")
        area_dialog.setInformativeText(
            "Whole Page uses the full page or image.\n\n"
            "Selected Area uses only the area you select in the preview."
        )

        whole_button = area_dialog.addButton("Use Whole Page", QMessageBox.ButtonRole.AcceptRole)
        selected_button = area_dialog.addButton("Use Selected Area", QMessageBox.ButtonRole.ActionRole)
        cancel_button = area_dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        area_dialog.setDefaultButton(whole_button)
        area_dialog.exec()

        clicked = area_dialog.clickedButton()

        if clicked == cancel_button:
            return

        if clicked == whole_button:
            self._set_combo_by_data_if_exists("output_area_combo", "whole_page")
            area_message = (
                "Output Area set to Whole Page.\n\n"
                "Choose Poster Size Preset, check Tiling Preview, then click Poster PDF in the toolbar."
            )
        elif clicked == selected_button:
            self._set_combo_by_data_if_exists("output_area_combo", "selected_area")
            area_message = (
                "Output Area set to Selected Area.\n\n"
                "Drag to select an area or use Auto Select, then Build Print Order and click Poster PDF."
            )
        else:
            return

        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()

        if hasattr(self, "settings_tabs") and hasattr(self, "a3_split_group"):
            self.settings_tabs.setCurrentWidget(self.a3_split_group)

        QMessageBox.information(
            self,
            "Make Poster",
            area_message
        )

'''

try:
    text = replace_function(text, "task_make_poster", new_task_make_poster)
    print("[OK] Make Poster now offers Open One File / Use Current Source PDFs")
except Exception as exc:
    print(f"[ERROR] Failed to replace task_make_poster: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 3) Release Notes
# ------------------------------------------------------------
if "Make Poster source choice" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Make Poster source choice</b>: Make Poster now offers Open One File or Use Current Source PDFs.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 4) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_make_poster_one_file_choice_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Open One File",
    "Use Current Source PDFs",
    "def open_one_source_file_for_poster",
    "Make Poster source choice",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Make Poster now defaults to one-file workflow")
print("- Advanced users can still use current Source PDFs")
