﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_tiling_preview_newlines_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

new_update_tiling_preview = '''    def update_tiling_preview(self, cols: int | None = None, rows: int | None = None) -> None:
        if not hasattr(self, "tiling_preview_label"):
            return

        if not cols or not rows or cols <= 0 or rows <= 0:
            self.tiling_preview_label.setText("-")
            return

        max_cells = 40
        total = cols * rows

        lines = []
        sheet_no = 1

        for row in range(rows):
            cells = []

            for col in range(cols):
                if sheet_no > max_cells:
                    cells.append(" ... ")
                else:
                    cells.append(f"{sheet_no:^5}")

                sheet_no += 1

            lines.append("[" + "][".join(cells) + "]")

            if sheet_no > max_cells and row < rows - 1:
                lines.append("...")
                break

        preview = "\\n".join(lines)

        self.tiling_preview_label.setText(
            f"{cols} x {rows} = {total} sheets\\n{preview}"
        )
'''

try:
    text = replace_function(text, "update_tiling_preview", new_update_tiling_preview)
    print("[OK] Replaced update_tiling_preview with real newline version")
except Exception as exc:
    print(f"[ERROR] Failed to replace update_tiling_preview: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Ensure split_layout_combo changes refresh the estimate/preview.
connect_line = "        self.split_layout_combo.currentIndexChanged.connect(self.update_poster_sheet_estimate)\n"

if connect_line not in text:
    anchor = '''        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")
'''
    replacement = '''        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")
        self.split_layout_combo.currentIndexChanged.connect(self.update_poster_sheet_estimate)
'''
    if anchor in text:
        text = text.replace(anchor, replacement, 1)
        print("[OK] Connected split layout changes to preview update")
    else:
        print("[WARN] Could not find split_layout_combo anchor")
else:
    print("[SKIP] split_layout_combo signal already connected")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_tiling_preview_newlines_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Tiling Preview now uses real line breaks")
print("- Top-Bottom should display vertically")
print("- Left-Right should display horizontally")
