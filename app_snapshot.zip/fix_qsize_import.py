﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_qsize_import_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# Find PyQt6.QtCore import line/block and add QSize safely.
core_single = re.search(r"^from PyQt6\.QtCore import (.+)$", text, re.M)

if core_single:
    imports = [x.strip() for x in core_single.group(1).split(",")]
    if "QSize" not in imports:
        imports.append("QSize")
        new_line = "from PyQt6.QtCore import " + ", ".join(imports)
        text = text[:core_single.start()] + new_line + text[core_single.end():]
        print("[OK] Added QSize to PyQt6.QtCore import line")
    else:
        print("[SKIP] QSize already in PyQt6.QtCore import line")
else:
    # Fallback for multi-line imports
    if "from PyQt6.QtCore import (" in text:
        if re.search(r"from PyQt6\.QtCore import \([\s\S]*?\bQSize\b[\s\S]*?\)", text):
            print("[SKIP] QSize already in PyQt6.QtCore import block")
        else:
            text = text.replace(
                "from PyQt6.QtCore import (",
                "from PyQt6.QtCore import (\n    QSize,",
                1
            )
            print("[OK] Added QSize to PyQt6.QtCore import block")
    else:
        text = "from PyQt6.QtCore import QSize\n" + text
        print("[OK] Added standalone QSize import")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_qsize_import_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

# Source check
new_text = MAIN.read_text(encoding="utf-8", errors="replace")
first_lines = "\n".join(new_text.splitlines()[:20])

if "QSize" not in first_lines:
    print("[WARN] QSize not found near top imports. Please paste first 20 lines of main_window.py.")
else:
    print("[OK] QSize import confirmed near top")

print("[OK] py_compile passed")
print("")
print("Done. Now run: python main.py")
