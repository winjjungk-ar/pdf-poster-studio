﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_image_release_notes_marker_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add explicit data/image_imports marker near image conversion
# ------------------------------------------------------------
old = '''        temp_dir = DATA_DIR / "image_imports"
        temp_dir.mkdir(parents=True, exist_ok=True)
'''

new = '''        # Temporary image imports are stored under data/image_imports.
        temp_dir = DATA_DIR / "image_imports"
        temp_dir.mkdir(parents=True, exist_ok=True)
'''

if old in text and "data/image_imports" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added data/image_imports marker comment")
else:
    print("[SKIP] data/image_imports marker already present or anchor not found")

# ------------------------------------------------------------
# 2) Add Release Notes image import section
# ------------------------------------------------------------
if "Image import support" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.3</h3>
<ul>
  <li><b>Image import support</b>: Open PDFs / Images now supports PNG, JPG, JPEG, BMP, and WEBP files.</li>
  <li>Image files are converted internally to temporary PDF pages under data/image_imports.</li>
  <li>Poster Print and Single Page workflows can be used with imported images.</li>
</ul>
<hr>
"""

    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Added Image import support to Release Notes")
    else:
        print("[WARN] Release Notes anchor not found")
else:
    print("[SKIP] Release Notes already mention Image import support")

# ------------------------------------------------------------
# 3) Ensure Welcome What's New mentions image support
# ------------------------------------------------------------
if "Open PDFs / Images now supports image files" not in text:
    marker = "• See Help > Release Notes for details"
    addition = "• Open PDFs / Images now supports image files\\n"

    if marker in text:
        text = text.replace(marker, addition + marker, 1)
        print("[OK] Added image support note to Welcome What's New")
    else:
        print("[SKIP] Welcome marker not found or already changed")
else:
    print("[SKIP] Welcome already mentions image support")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_image_release_notes_marker_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "data/image_imports",
    "Image import support",
    "Open PDFs / Images now supports image files",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Release Notes now mention image import support")
print("- data/image_imports marker added")
