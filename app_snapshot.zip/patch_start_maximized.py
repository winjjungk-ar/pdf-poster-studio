﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_start_maximized_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Replace fixed resize with minimum size + maximize scheduling
# ------------------------------------------------------------
old = '''        self.setWindowTitle("PDF Poster Studio - A4/A3 Print Workspace")
        self.setWindowIcon(self._create_app_icon())
        self.resize(1500, 900)
'''

new = '''        self.setWindowTitle("PDF Poster Studio - A4/A3 Print Workspace")
        self.setWindowIcon(self._create_app_icon())

        # Start comfortably on any monitor, then maximize after the UI is created.
        self.setMinimumSize(1000, 700)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Replaced fixed resize with adaptive minimum size")
else:
    if "self.resize(1500, 900)" in text:
        text = text.replace("        self.resize(1500, 900)\n", "        self.setMinimumSize(1000, 700)\n", 1)
        print("[OK] Replaced resize fallback")
    else:
        print("[SKIP] Fixed resize not found")

# ------------------------------------------------------------
# 2) Add showMaximized after UI creation using QTimer
# ------------------------------------------------------------
old_tail = '''        QTimer.singleShot(350, self._show_welcome_dialog)
'''

new_tail = '''        QTimer.singleShot(0, self.showMaximized)
        QTimer.singleShot(350, self._show_welcome_dialog)
'''

if old_tail in text and "QTimer.singleShot(0, self.showMaximized)" not in text:
    text = text.replace(old_tail, new_tail, 1)
    print("[OK] Added startup maximize timer")
elif "QTimer.singleShot(0, self.showMaximized)" in text:
    print("[SKIP] Startup maximize already present")
else:
    # fallback: insert after Poster export log
    marker = '        self._log("Poster export module loaded.")\n'
    if marker in text and "QTimer.singleShot(0, self.showMaximized)" not in text:
        text = text.replace(
            marker,
            marker + "\n        QTimer.singleShot(0, self.showMaximized)\n",
            1
        )
        print("[OK] Added startup maximize by fallback")
    else:
        print("[WARN] Could not insert startup maximize timer")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_start_maximized_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

if "QTimer.singleShot(0, self.showMaximized)" not in new_text:
    print("[WARN] showMaximized timer not found after patch")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Program now starts maximized")
print("- Fixed 1500x900 resize replaced with adaptive minimum size")
