﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_large_pdf_autoselect_warning_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            targets.append(node)

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno

    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

# ------------------------------------------------------------
# 1) Replace auto_select_all_pages with large PDF warning version
# ------------------------------------------------------------
new_auto_select_all_pages = r'''    def auto_select_all_pages(self) -> None:
        if hasattr(self, "workspace_items") and len(self.workspace_items) > 1:
            self.auto_select_all_workspace_pages()
            return

        if not self.current_pdf_path or self.page_count <= 0:
            QMessageBox.information(
                self,
                "Auto Select All Pages",
                "Please open a PDF or image first."
            )
            return

        # Large PDFs can take a long time. Warn before starting.
        large_page_threshold = 200
        if self.page_count >= large_page_threshold:
            large_result = QMessageBox.question(
                self,
                "Large PDF Detected",
                f"This file has {self.page_count} pages.\n\n"
                "Auto Select All Pages may take several minutes and can use significant CPU.\n"
                "You can cancel during processing.\n\n"
                "Continue?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if large_result != QMessageBox.StandardButton.Yes:
                return

        result = QMessageBox.question(
            self,
            "Auto Select All Pages",
            "Automatically detect content area for all pages?\n\n"
            "Existing selections may be replaced.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if result != QMessageBox.StandardButton.Yes:
            return

        progress = QProgressDialog(
            "Preparing auto selection...",
            "Cancel",
            0,
            self.page_count,
            self,
        )
        progress.setWindowTitle("Auto Select All Pages")
        progress.setWindowModality(Qt.WindowModality.ApplicationModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        progress.show()
        QApplication.processEvents()

        selected_count = 0
        canceled = False

        try:
            selected_count = self._auto_select_all_pages_for_current_pdf_no_prompt(
                progress_dialog=progress,
                progress_offset=0,
                progress_label_prefix="",
            )

            if progress.wasCanceled():
                canceled = True

            progress.setValue(self.page_count)
            QApplication.processEvents()

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Auto Select All Pages",
                f"Auto selection failed.\n\n{exc}"
            )
            self._log(f"Auto Select All Pages error: {exc}")
            return

        finally:
            progress.close()

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        self.is_modified = True

        if canceled:
            QMessageBox.information(
                self,
                "Auto Select All Pages",
                f"Auto selection was canceled.\n\nSelected pages before cancel: {selected_count}"
            )
        else:
            QMessageBox.information(
                self,
                "Auto Select All Pages",
                f"Auto selection completed.\n\nSelected pages: {selected_count}/{self.page_count}"
            )

        self._log(
            f"Auto Select All Pages completed: selected={selected_count}/{self.page_count}"
        )

'''

try:
    text = replace_function(text, "auto_select_all_pages", new_auto_select_all_pages)
    print("[OK] Added large PDF warning to auto_select_all_pages")
except Exception as exc:
    print(f"[ERROR] Failed to replace auto_select_all_pages: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 2) Release Notes update
# ------------------------------------------------------------
if "Large PDF warning" not in text:
    marker = "<li><b>Auto Select All Pages progress improvement</b>: Single large PDFs now show a progress dialog.</li>"
    addition = marker + "\n  <li><b>Large PDF warning</b>: Files with many pages now show a warning before Auto Select All Pages starts.</li>"

    if marker in text:
        text = text.replace(marker, addition, 1)
        print("[OK] Release Notes updated with Large PDF warning")
    else:
        print("[WARN] Release Notes marker not found")

# ------------------------------------------------------------
# 3) Welcome What's New update
# ------------------------------------------------------------
if "Large PDFs show a warning before Auto Select All Pages" not in text:
    marker = "• Auto Select All Pages now shows progress for large PDFs\\n"
    addition = marker + "• Large PDFs show a warning before Auto Select All Pages\\n"

    if marker in text:
        text = text.replace(marker, addition, 1)
        print("[OK] Welcome What's New updated with Large PDF warning")
    else:
        print("[SKIP] Welcome marker not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_large_pdf_autoselect_warning_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Large PDF Detected",
    "large_page_threshold = 200",
    "Large PDF warning",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Auto Select All Pages now warns for PDFs with 200+ pages")
print("- Progress dialog and Cancel remain available")
