﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fixed_all_presets_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

# ------------------------------------------------------------
# 1) Replace fixed grid helper with preset-aware version
# ------------------------------------------------------------
new_helper = r'''    def _get_fixed_a_series_tile_grid(self) -> tuple[int | None, int | None]:
        """Return fixed tile grid for known poster size presets.

        User expectation:
        - A3 / ANSI B / Arch B -> 2 sheets
        - A2 / ANSI C / Arch C -> 4 sheets
        - A1 / ANSI D / Arch D -> 8 sheets
        - A0 / ANSI E / Arch E -> 16 sheets
        """
        if not hasattr(self, "poster_size_preset_combo"):
            return None, None

        preset_text = self.poster_size_preset_combo.currentText()
        split_layout = self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else "left_right"

        # No fixed grid for manual/custom.
        if not preset_text or "Manual" in preset_text or "Custom" in preset_text:
            return None, None

        # 2 sheets
        if (
            preset_text.startswith("A3 ")
            or preset_text.startswith("ANSI B")
            or preset_text.startswith("Arch B")
        ):
            return (1, 2) if split_layout == "top_bottom" else (2, 1)

        # 4 sheets
        if (
            preset_text.startswith("A2 ")
            or preset_text.startswith("ANSI C")
            or preset_text.startswith("Arch C")
        ):
            return 2, 2

        # 8 sheets
        if (
            preset_text.startswith("A1 ")
            or preset_text.startswith("ANSI D")
            or preset_text.startswith("Arch D")
        ):
            return (2, 4) if split_layout == "top_bottom" else (4, 2)

        # 16 sheets
        if (
            preset_text.startswith("A0 ")
            or preset_text.startswith("ANSI E")
            or preset_text.startswith("Arch E")
        ):
            return 4, 4

        return None, None

'''

try:
    text = replace_function(text, "_get_fixed_a_series_tile_grid", new_helper)
    print("[OK] Replaced _get_fixed_a_series_tile_grid with all-preset fixed grid")
except Exception as exc:
    print(f"[ERROR] Failed to replace fixed grid helper: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 2) Improve estimate size text for all preset families
# ------------------------------------------------------------
old_block = '''                if total == 2:
                    size_text = "Approx Poster Size: A3"
                elif total == 4:
                    size_text = "Approx Poster Size: A2"
                elif total == 8:
                    size_text = "Approx Poster Size: A1"
                elif total == 16:
                    size_text = "Approx Poster Size: A0"
                else:
                    size_text = "Approx Poster Size: preset"
'''

new_block = '''                preset_text = self.poster_size_preset_combo.currentText() if hasattr(self, "poster_size_preset_combo") else ""

                if "ANSI" in preset_text:
                    if total == 2:
                        size_text = "Approx Poster Size: ANSI B / Tabloid"
                    elif total == 4:
                        size_text = "Approx Poster Size: ANSI C"
                    elif total == 8:
                        size_text = "Approx Poster Size: ANSI D"
                    elif total == 16:
                        size_text = "Approx Poster Size: ANSI E"
                    else:
                        size_text = "Approx Poster Size: ANSI preset"
                elif "Arch" in preset_text:
                    if total == 2:
                        size_text = "Approx Poster Size: Arch B"
                    elif total == 4:
                        size_text = "Approx Poster Size: Arch C"
                    elif total == 8:
                        size_text = "Approx Poster Size: Arch D"
                    elif total == 16:
                        size_text = "Approx Poster Size: Arch E"
                    else:
                        size_text = "Approx Poster Size: Arch preset"
                else:
                    if total == 2:
                        size_text = "Approx Poster Size: A3"
                    elif total == 4:
                        size_text = "Approx Poster Size: A2"
                    elif total == 8:
                        size_text = "Approx Poster Size: A1"
                    elif total == 16:
                        size_text = "Approx Poster Size: A0"
                    else:
                        size_text = "Approx Poster Size: preset"
'''

if old_block in text:
    text = text.replace(old_block, new_block, 1)
    print("[OK] Improved preset estimate size text")
else:
    print("[WARN] Could not find size_text estimate block. Continuing.")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fixed_all_presets_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "ANSI B / Arch B -> 2 sheets",
    'preset_text.startswith("ANSI C")',
    'preset_text.startswith("Arch D")',
    "Approx Poster Size: ANSI C",
    "Approx Poster Size: Arch E",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- A-series presets fixed: A3=2, A2=4, A1=8, A0=16")
print("- ANSI presets fixed: B=2, C=4, D=8, E=16")
print("- Arch presets fixed: B=2, C=4, D=8, E=16")
print("- Tiling Preview and export tile count should now match these presets")
