from dataclasses import dataclass
from pathlib import Path

import fitz


MM_TO_PT = 72.0 / 25.4

A4_WIDTH_PT = 210 * MM_TO_PT
A4_HEIGHT_PT = 297 * MM_TO_PT

A3_WIDTH_PT = 297 * MM_TO_PT
A3_HEIGHT_PT = 420 * MM_TO_PT


@dataclass
class SelectionRect:
    x: float
    y: float
    width: float
    height: float


@dataclass
class ExportOptions:
    output_mode: str
    split_layout: str
    export_type: str = "a3_split"
    selection_fit_mode: str = "fit_width"
    page_orientation: str = "auto"
    safe_margin_mm: float = 5.0
    overlap_mm: float = 5.0
    add_numbers: bool = True
    add_cut_guides: bool = True
    quality_scale: float = 2.5


class PosterExporter:
    def export(
        self,
        source_pdf_path: str,
        output_pdf_path: str,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        source_path = Path(source_pdf_path)
        output_path = Path(output_pdf_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        src_doc = fitz.open(str(source_path))
        out_doc = fitz.open()

        try:
            if options.export_type == "selection_only":
                self._export_selection_only(src_doc, out_doc, selections, options)
            else:
                self._export_a3_split(src_doc, out_doc, selections, options)

            if len(out_doc) == 0:
                raise RuntimeError("No output pages were generated.")

            out_doc.save(str(output_path), garbage=4, deflate=True)

        finally:
            out_doc.close()
            src_doc.close()

    def _export_a3_split(
        self,
        src_doc: fitz.Document,
        out_doc: fitz.Document,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        sheet_total = len(selections) * 2
        sheet_no = 1

        for page_index in sorted(selections.keys()):
            if page_index < 0 or page_index >= len(src_doc):
                continue

            src_page = src_doc.load_page(page_index)
            selection = selections[page_index]
            full_clip = self._selection_to_rect(selection)

            if full_clip.width <= 0 or full_clip.height <= 0:
                continue

            tile_clips, tile_names = self._make_tile_clips(full_clip, options)

            for tile_index, tile_clip in enumerate(tile_clips):
                page = out_doc.new_page(width=A4_WIDTH_PT, height=A4_HEIGHT_PT)

                tile_pix = self._render_tile_to_a4(
                    src_page=src_page,
                    full_clip=full_clip,
                    tile_clip=tile_clip,
                    options=options,
                )

                target_rect = self._get_target_rect(
                    options=options,
                    page_width=A4_WIDTH_PT,
                    page_height=A4_HEIGHT_PT,
                )
                page.insert_image(target_rect, pixmap=tile_pix)

                if options.add_cut_guides:
                    self._draw_cut_guides(
                        page=page,
                        options=options,
                        tile_name=tile_names[tile_index],
                        page_width=A4_WIDTH_PT,
                        page_height=A4_HEIGHT_PT,
                    )

                if options.add_numbers:
                    self._draw_numbering(
                        page=page,
                        page_width=A4_WIDTH_PT,
                        page_height=A4_HEIGHT_PT,
                        sheet_no=sheet_no,
                        sheet_total=sheet_total,
                        source_page=page_index + 1,
                        tile_no=tile_index + 1,
                        tile_total=2,
                        tile_name=tile_names[tile_index],
                    )

                sheet_no += 1

    def _export_selection_only(
        self,
        src_doc: fitz.Document,
        out_doc: fitz.Document,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        sheet_total = len(selections)
        sheet_no = 1

        for page_index in sorted(selections.keys()):
            if page_index < 0 or page_index >= len(src_doc):
                continue

            selection = selections[page_index]
            clip = self._selection_to_rect(selection)

            if clip.width <= 0 or clip.height <= 0:
                continue

            page_width, page_height = self._get_selection_page_size(clip, options)
            page = out_doc.new_page(width=page_width, height=page_height)

            printable_rect = self._get_target_rect(
                options=options,
                page_width=page_width,
                page_height=page_height,
            )

            source_clip, target_rect = self._calculate_selection_mapping(
                clip=clip,
                printable_rect=printable_rect,
                options=options,
            )

            page.show_pdf_page(
                target_rect,
                src_doc,
                page_index,
                clip=source_clip,
                keep_proportion=True,
            )

            self._draw_selection_border(page, target_rect)

            if options.add_numbers:
                self._draw_selection_only_numbering(
                    page=page,
                    page_width=page_width,
                    page_height=page_height,
                    sheet_no=sheet_no,
                    sheet_total=sheet_total,
                    source_page=page_index + 1,
                )

            sheet_no += 1

    def _selection_to_rect(self, selection: SelectionRect) -> fitz.Rect:
        return fitz.Rect(
            selection.x,
            selection.y,
            selection.x + selection.width,
            selection.y + selection.height,
        )

    def _get_selection_page_size(
        self,
        clip: fitz.Rect,
        options: ExportOptions,
    ) -> tuple[float, float]:
        orientation = options.page_orientation

        if orientation == "auto":
            if clip.width >= clip.height:
                orientation = "landscape"
            else:
                orientation = "portrait"

        if orientation == "landscape":
            return A4_HEIGHT_PT, A4_WIDTH_PT

        return A4_WIDTH_PT, A4_HEIGHT_PT

    def _calculate_selection_mapping(
        self,
        clip: fitz.Rect,
        printable_rect: fitz.Rect,
        options: ExportOptions,
    ) -> tuple[fitz.Rect, fitz.Rect]:
        mode = options.selection_fit_mode

        if mode == "fit_whole":
            return clip, self._fit_rect_keep_aspect(clip, printable_rect)

        if mode == "fit_width":
            target = fitz.Rect(
                printable_rect.x0,
                printable_rect.y0,
                printable_rect.x1,
                printable_rect.y0 + printable_rect.width * (clip.height / clip.width),
            )
            target = self._center_rect_vertically(target, printable_rect)
            return clip, target

        if mode == "fit_height":
            target = fitz.Rect(
                printable_rect.x0,
                printable_rect.y0,
                printable_rect.x0 + printable_rect.height * (clip.width / clip.height),
                printable_rect.y1,
            )
            target = self._center_rect_horizontally(target, printable_rect)
            return clip, target

        if mode == "fill_crop":
            cropped_clip = self._crop_source_to_target_aspect(clip, printable_rect)
            return cropped_clip, printable_rect

        return clip, self._fit_rect_keep_aspect(clip, printable_rect)

    def _fit_rect_keep_aspect(
        self,
        source_rect: fitz.Rect,
        target_rect: fitz.Rect,
    ) -> fitz.Rect:
        source_ratio = source_rect.width / source_rect.height
        target_ratio = target_rect.width / target_rect.height

        if source_ratio >= target_ratio:
            width = target_rect.width
            height = width / source_ratio
        else:
            height = target_rect.height
            width = height * source_ratio

        x0 = target_rect.x0 + (target_rect.width - width) / 2.0
        y0 = target_rect.y0 + (target_rect.height - height) / 2.0

        return fitz.Rect(x0, y0, x0 + width, y0 + height)

    def _center_rect_vertically(
        self,
        rect: fitz.Rect,
        bounds: fitz.Rect,
    ) -> fitz.Rect:
        height = rect.height

        if height > bounds.height:
            return bounds

        y0 = bounds.y0 + (bounds.height - height) / 2.0
        return fitz.Rect(rect.x0, y0, rect.x1, y0 + height)

    def _center_rect_horizontally(
        self,
        rect: fitz.Rect,
        bounds: fitz.Rect,
    ) -> fitz.Rect:
        width = rect.width

        if width > bounds.width:
            return bounds

        x0 = bounds.x0 + (bounds.width - width) / 2.0
        return fitz.Rect(x0, rect.y0, x0 + width, rect.y1)

    def _crop_source_to_target_aspect(
        self,
        source_rect: fitz.Rect,
        target_rect: fitz.Rect,
    ) -> fitz.Rect:
        source_ratio = source_rect.width / source_rect.height
        target_ratio = target_rect.width / target_rect.height

        if source_ratio > target_ratio:
            new_width = source_rect.height * target_ratio
            x0 = source_rect.x0 + (source_rect.width - new_width) / 2.0
            return fitz.Rect(
                x0,
                source_rect.y0,
                x0 + new_width,
                source_rect.y1,
            )

        new_height = source_rect.width / target_ratio
        y0 = source_rect.y0 + (source_rect.height - new_height) / 2.0
        return fitz.Rect(
            source_rect.x0,
            y0,
            source_rect.x1,
            y0 + new_height,
        )

    def _make_tile_clips(
        self,
        full_clip: fitz.Rect,
        options: ExportOptions,
    ) -> tuple[list[fitz.Rect], list[str]]:
        overlap_pt = 0.0

        if options.output_mode == "overlap":
            overlap_pt = options.overlap_mm * MM_TO_PT

        if options.split_layout == "top_bottom":
            mid_y = (full_clip.y0 + full_clip.y1) / 2.0

            top = fitz.Rect(
                full_clip.x0,
                full_clip.y0,
                full_clip.x1,
                min(full_clip.y1, mid_y + overlap_pt),
            )

            bottom = fitz.Rect(
                full_clip.x0,
                max(full_clip.y0, mid_y - overlap_pt),
                full_clip.x1,
                full_clip.y1,
            )

            return [top, bottom], ["TOP", "BOTTOM"]

        mid_x = (full_clip.x0 + full_clip.x1) / 2.0

        left = fitz.Rect(
            full_clip.x0,
            full_clip.y0,
            min(full_clip.x1, mid_x + overlap_pt),
            full_clip.y1,
        )

        right = fitz.Rect(
            max(full_clip.x0, mid_x - overlap_pt),
            full_clip.y0,
            full_clip.x1,
            full_clip.y1,
        )

        return [left, right], ["LEFT", "RIGHT"]

    def _render_tile_to_a4(
        self,
        src_page: fitz.Page,
        full_clip: fitz.Rect,
        tile_clip: fitz.Rect,
        options: ExportOptions,
    ) -> fitz.Pixmap:
        zoom = self._calculate_a3_split_zoom(full_clip, options)
        high_quality_zoom = zoom * max(options.quality_scale, 1.0)
        matrix = fitz.Matrix(high_quality_zoom, high_quality_zoom)

        return src_page.get_pixmap(
            matrix=matrix,
            clip=tile_clip,
            alpha=False,
            colorspace=fitz.csRGB,
        )

    def _calculate_a3_split_zoom(
        self,
        full_clip: fitz.Rect,
        options: ExportOptions,
    ) -> float:
        if full_clip.width <= 0 or full_clip.height <= 0:
            raise RuntimeError("Invalid selection area.")

        if options.split_layout == "top_bottom":
            target_w_pt = A4_WIDTH_PT
            target_h_pt = A3_HEIGHT_PT
        else:
            target_w_pt = A3_WIDTH_PT
            target_h_pt = A4_HEIGHT_PT

        if options.output_mode == "no_cut":
            scale_factor = 0.96
        else:
            scale_factor = 1.0

        zoom_x = target_w_pt / full_clip.width
        zoom_y = target_h_pt / full_clip.height

        return min(zoom_x, zoom_y) * scale_factor

    def _get_target_rect(
        self,
        options: ExportOptions,
        page_width: float,
        page_height: float,
    ) -> fitz.Rect:
        if options.output_mode == "true_size":
            margin = 0
        elif options.output_mode == "overlap":
            margin = 3 * MM_TO_PT
        else:
            margin = options.safe_margin_mm * MM_TO_PT

        return fitz.Rect(
            margin,
            margin,
            page_width - margin,
            page_height - margin,
        )

    def _draw_cut_guides(
        self,
        page: fitz.Page,
        options: ExportOptions,
        tile_name: str,
        page_width: float,
        page_height: float,
    ) -> None:
        color = (0.85, 0.0, 0.0)
        width = 0.6
        dash = "[3 3] 0"

        margin = 4 * MM_TO_PT
        label_margin = 6 * MM_TO_PT

        if options.split_layout == "top_bottom":
            if tile_name == "TOP":
                y = page_height - margin
                page.draw_line(
                    fitz.Point(margin, y),
                    fitz.Point(page_width - margin, y),
                    color=color,
                    width=width,
                    dashes=dash,
                )
                self._draw_cut_label(page, "CUT / JOIN LINE", label_margin, y - 10, page_width)
            else:
                y = margin
                page.draw_line(
                    fitz.Point(margin, y),
                    fitz.Point(page_width - margin, y),
                    color=color,
                    width=width,
                    dashes=dash,
                )
                self._draw_cut_label(page, "CUT / JOIN LINE", label_margin, y + 2, page_width)
            return

        if tile_name == "LEFT":
            x = page_width - margin
            page.draw_line(
                fitz.Point(x, margin),
                fitz.Point(x, page_height - margin),
                color=color,
                width=width,
                dashes=dash,
            )
            self._draw_cut_label(page, "CUT / JOIN LINE", x - 70, label_margin, page_width)
        else:
            x = margin
            page.draw_line(
                fitz.Point(x, margin),
                fitz.Point(x, page_height - margin),
                color=color,
                width=width,
                dashes=dash,
            )
            self._draw_cut_label(page, "CUT / JOIN LINE", x + 3, label_margin, page_width)

    def _draw_cut_label(
        self,
        page: fitz.Page,
        text: str,
        x: float,
        y: float,
        page_width: float,
    ) -> None:
        rect = fitz.Rect(
            x,
            y,
            min(x + 90, page_width - 2 * MM_TO_PT),
            y + 10,
        )
        page.insert_textbox(
            rect,
            text,
            fontsize=6,
            fontname="helv",
            color=(0.85, 0.0, 0.0),
            align=fitz.TEXT_ALIGN_LEFT,
        )

    def _draw_selection_border(
        self,
        page: fitz.Page,
        target_rect: fitz.Rect,
    ) -> None:
        page.draw_rect(
            target_rect,
            color=(0.65, 0.65, 0.65),
            width=0.4,
        )

    def _draw_numbering(
        self,
        page: fitz.Page,
        page_width: float,
        page_height: float,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
        tile_no: int,
        tile_total: int,
        tile_name: str,
    ) -> None:
        text = (
            f"Sheet {sheet_no}/{sheet_total} | "
            f"Source {source_page} | "
            f"Tile {tile_no}/{tile_total} {tile_name}"
        )

        rect = fitz.Rect(
            8 * MM_TO_PT,
            page_height - 12 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            page_height - 5 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=7,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
            align=fitz.TEXT_ALIGN_RIGHT,
        )

    def _draw_selection_only_numbering(
        self,
        page: fitz.Page,
        page_width: float,
        page_height: float,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
    ) -> None:
        text = (
            f"Selection Only | "
            f"Sheet {sheet_no}/{sheet_total} | "
            f"Source {source_page}"
        )

        rect = fitz.Rect(
            8 * MM_TO_PT,
            page_height - 12 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            page_height - 5 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=7,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
            align=fitz.TEXT_ALIGN_RIGHT,
        )