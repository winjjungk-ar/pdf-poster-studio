from dataclasses import dataclass
from pathlib import Path

import fitz


MM_TO_PT = 72.0 / 25.4

A4_WIDTH_PT = 210 * MM_TO_PT
A4_HEIGHT_PT = 297 * MM_TO_PT

A3_WIDTH_PT = 297 * MM_TO_PT
A3_HEIGHT_PT = 420 * MM_TO_PT


@dataclass
class SelectionRect:
    x: float
    y: float
    width: float
    height: float


@dataclass
class ExportOptions:
    output_mode: str
    split_layout: str
    safe_margin_mm: float = 5.0
    overlap_mm: float = 5.0
    add_numbers: bool = True


class PosterExporter:
    def export(
        self,
        source_pdf_path: str,
        output_pdf_path: str,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        source_path = Path(source_pdf_path)
        output_path = Path(output_pdf_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        src_doc = fitz.open(str(source_path))
        out_doc = fitz.open()

        try:
            sheet_total = len(selections) * 2
            sheet_no = 1

            for page_index in sorted(selections.keys()):
                if page_index < 0 or page_index >= len(src_doc):
                    continue

                src_page = src_doc.load_page(page_index)
                selection = selections[page_index]
                clip = fitz.Rect(
                    selection.x,
                    selection.y,
                    selection.x + selection.width,
                    selection.y + selection.height,
                )

                pix = self._render_selection_to_a3(src_page, clip, options)

                if options.split_layout == "top_bottom":
                    parts = self._split_pixmap_top_bottom(pix)
                    part_names = ["TOP", "BOTTOM"]
                else:
                    parts = self._split_pixmap_left_right(pix)
                    part_names = ["LEFT", "RIGHT"]

                for tile_index, part in enumerate(parts):
                    page = out_doc.new_page(width=A4_WIDTH_PT, height=A4_HEIGHT_PT)

                    target_rect = self._get_target_rect(options)
                    page.insert_image(target_rect, pixmap=part)

                    if options.add_numbers:
                        self._draw_numbering(
                            page=page,
                            sheet_no=sheet_no,
                            sheet_total=sheet_total,
                            source_page=page_index + 1,
                            tile_no=tile_index + 1,
                            tile_total=2,
                            tile_name=part_names[tile_index],
                        )

                    sheet_no += 1

            if len(out_doc) == 0:
                raise RuntimeError("No output pages were generated.")

            out_doc.save(str(output_path), garbage=4, deflate=True)

        finally:
            out_doc.close()
            src_doc.close()

    def _render_selection_to_a3(
        self,
        page: fitz.Page,
        clip: fitz.Rect,
        options: ExportOptions,
    ) -> fitz.Pixmap:
        if clip.width <= 0 or clip.height <= 0:
            raise RuntimeError("Invalid selection area.")

        if options.split_layout == "top_bottom":
            target_w_pt = A4_WIDTH_PT
            target_h_pt = A3_HEIGHT_PT
        else:
            target_w_pt = A3_WIDTH_PT
            target_h_pt = A4_HEIGHT_PT

        if options.output_mode == "no_cut":
            scale_factor = 0.96
        else:
            scale_factor = 1.0

        zoom_x = (target_w_pt / clip.width) * scale_factor
        zoom_y = (target_h_pt / clip.height) * scale_factor
        zoom = min(zoom_x, zoom_y)

        matrix = fitz.Matrix(zoom, zoom)

        return page.get_pixmap(
            matrix=matrix,
            clip=clip,
            alpha=False,
            colorspace=fitz.csRGB,
        )

    def _split_pixmap_left_right(self, pix: fitz.Pixmap) -> list[fitz.Pixmap]:
        half_w = pix.width // 2
        left_rect = fitz.IRect(0, 0, half_w, pix.height)
        right_rect = fitz.IRect(half_w, 0, pix.width, pix.height)

        return [
            fitz.Pixmap(pix, left_rect),
            fitz.Pixmap(pix, right_rect),
        ]

    def _split_pixmap_top_bottom(self, pix: fitz.Pixmap) -> list[fitz.Pixmap]:
        half_h = pix.height // 2
        top_rect = fitz.IRect(0, 0, pix.width, half_h)
        bottom_rect = fitz.IRect(0, half_h, pix.width, pix.height)

        return [
            fitz.Pixmap(pix, top_rect),
            fitz.Pixmap(pix, bottom_rect),
        ]

    def _get_target_rect(self, options: ExportOptions) -> fitz.Rect:
        if options.output_mode == "true_size":
            margin = 0
        elif options.output_mode == "overlap":
            margin = 3 * MM_TO_PT
        else:
            margin = options.safe_margin_mm * MM_TO_PT

        return fitz.Rect(
            margin,
            margin,
            A4_WIDTH_PT - margin,
            A4_HEIGHT_PT - margin,
        )

    def _draw_numbering(
        self,
        page: fitz.Page,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
        tile_no: int,
        tile_total: int,
        tile_name: str,
    ) -> None:
        text = (
            f"Sheet {sheet_no}/{sheet_total} | "
            f"Source {source_page} | "
            f"Tile {tile_no}/{tile_total} {tile_name}"
        )

        rect = fitz.Rect(
            8 * MM_TO_PT,
            A4_HEIGHT_PT - 12 * MM_TO_PT,
            A4_WIDTH_PT - 8 * MM_TO_PT,
            A4_HEIGHT_PT - 5 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=7,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
            align=fitz.TEXT_ALIGN_RIGHT,
        )