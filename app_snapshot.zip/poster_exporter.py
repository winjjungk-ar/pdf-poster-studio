from dataclasses import dataclass
from pathlib import Path

import fitz


MM_TO_PT = 72.0 / 25.4

A4_WIDTH_PT = 210 * MM_TO_PT
A4_HEIGHT_PT = 297 * MM_TO_PT

A3_WIDTH_PT = 297 * MM_TO_PT
A3_HEIGHT_PT = 420 * MM_TO_PT


@dataclass
class SelectionRect:
    x: float
    y: float
    width: float
    height: float


@dataclass
class ExportOptions:
    output_mode: str
    split_layout: str
    safe_margin_mm: float = 5.0
    overlap_mm: float = 5.0
    add_numbers: bool = True
    quality_scale: float = 2.5


class PosterExporter:
    def export(
        self,
        source_pdf_path: str,
        output_pdf_path: str,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        source_path = Path(source_pdf_path)
        output_path = Path(output_pdf_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        src_doc = fitz.open(str(source_path))
        out_doc = fitz.open()

        try:
            sheet_total = len(selections) * 2
            sheet_no = 1

            for page_index in sorted(selections.keys()):
                if page_index < 0 or page_index >= len(src_doc):
                    continue

                src_page = src_doc.load_page(page_index)
                selection = selections[page_index]

                full_clip = fitz.Rect(
                    selection.x,
                    selection.y,
                    selection.x + selection.width,
                    selection.y + selection.height,
                )

                if full_clip.width <= 0 or full_clip.height <= 0:
                    continue

                tile_clips, tile_names = self._make_tile_clips(full_clip, options)

                for tile_index, tile_clip in enumerate(tile_clips):
                    page = out_doc.new_page(width=A4_WIDTH_PT, height=A4_HEIGHT_PT)

                    tile_pix = self._render_tile_to_a4(
                        src_page=src_page,
                        full_clip=full_clip,
                        tile_clip=tile_clip,
                        options=options,
                    )

                    target_rect = self._get_target_rect(options)
                    page.insert_image(target_rect, pixmap=tile_pix)

                    if options.add_numbers:
                        self._draw_numbering(
                            page=page,
                            sheet_no=sheet_no,
                            sheet_total=sheet_total,
                            source_page=page_index + 1,
                            tile_no=tile_index + 1,
                            tile_total=2,
                            tile_name=tile_names[tile_index],
                        )

                    sheet_no += 1

            if len(out_doc) == 0:
                raise RuntimeError("No output pages were generated.")

            out_doc.save(str(output_path), garbage=4, deflate=True)

        finally:
            out_doc.close()
            src_doc.close()

    def _make_tile_clips(
        self,
        full_clip: fitz.Rect,
        options: ExportOptions,
    ) -> tuple[list[fitz.Rect], list[str]]:
        overlap_pt = 0.0

        if options.output_mode == "overlap":
            overlap_pt = options.overlap_mm * MM_TO_PT

        if options.split_layout == "top_bottom":
            mid_y = (full_clip.y0 + full_clip.y1) / 2.0

            top = fitz.Rect(
                full_clip.x0,
                full_clip.y0,
                full_clip.x1,
                min(full_clip.y1, mid_y + overlap_pt),
            )

            bottom = fitz.Rect(
                full_clip.x0,
                max(full_clip.y0, mid_y - overlap_pt),
                full_clip.x1,
                full_clip.y1,
            )

            return [top, bottom], ["TOP", "BOTTOM"]

        mid_x = (full_clip.x0 + full_clip.x1) / 2.0

        left = fitz.Rect(
            full_clip.x0,
            full_clip.y0,
            min(full_clip.x1, mid_x + overlap_pt),
            full_clip.y1,
        )

        right = fitz.Rect(
            max(full_clip.x0, mid_x - overlap_pt),
            full_clip.y0,
            full_clip.x1,
            full_clip.y1,
        )

        return [left, right], ["LEFT", "RIGHT"]

    def _render_tile_to_a4(
        self,
        src_page: fitz.Page,
        full_clip: fitz.Rect,
        tile_clip: fitz.Rect,
        options: ExportOptions,
    ) -> fitz.Pixmap:
        zoom = self._calculate_zoom(full_clip, options)

        # Increase raster resolution for better print quality.
        high_quality_zoom = zoom * max(options.quality_scale, 1.0)

        matrix = fitz.Matrix(high_quality_zoom, high_quality_zoom)

        return src_page.get_pixmap(
            matrix=matrix,
            clip=tile_clip,
            alpha=False,
            colorspace=fitz.csRGB,
        )

    def _calculate_zoom(
        self,
        full_clip: fitz.Rect,
        options: ExportOptions,
    ) -> float:
        if full_clip.width <= 0 or full_clip.height <= 0:
            raise RuntimeError("Invalid selection area.")

        if options.split_layout == "top_bottom":
            target_w_pt = A4_WIDTH_PT
            target_h_pt = A3_HEIGHT_PT
        else:
            target_w_pt = A3_WIDTH_PT
            target_h_pt = A4_HEIGHT_PT

        if options.output_mode == "no_cut":
            scale_factor = 0.96
        else:
            scale_factor = 1.0

        zoom_x = target_w_pt / full_clip.width
        zoom_y = target_h_pt / full_clip.height

        return min(zoom_x, zoom_y) * scale_factor

    def _get_target_rect(self, options: ExportOptions) -> fitz.Rect:
        if options.output_mode == "true_size":
            margin = 0
        elif options.output_mode == "overlap":
            margin = 3 * MM_TO_PT
        else:
            margin = options.safe_margin_mm * MM_TO_PT

        return fitz.Rect(
            margin,
            margin,
            A4_WIDTH_PT - margin,
            A4_HEIGHT_PT - margin,
        )

    def _draw_numbering(
        self,
        page: fitz.Page,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
        tile_no: int,
        tile_total: int,
        tile_name: str,
    ) -> None:
        text = (
            f"Sheet {sheet_no}/{sheet_total} | "
            f"Source {source_page} | "
            f"Tile {tile_no}/{tile_total} {tile_name}"
        )

        rect = fitz.Rect(
            8 * MM_TO_PT,
            A4_HEIGHT_PT - 12 * MM_TO_PT,
            A4_WIDTH_PT - 8 * MM_TO_PT,
            A4_HEIGHT_PT - 5 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=7,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
            align=fitz.TEXT_ALIGN_RIGHT,
        )