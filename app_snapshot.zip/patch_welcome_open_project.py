﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_welcome_open_project_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# Replace welcome subtitle and steps
# ------------------------------------------------------------
old = '''        subtitle = QLabel(
            "Open one or more PDFs, select the area you want, arrange the page order, "
            "then export a print-ready PDF."
        )
'''
new = '''        subtitle = QLabel(
            "Start a new print workspace from PDFs, or continue an existing project."
        )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Updated welcome subtitle")
else:
    print("[SKIP] Subtitle block not found or already changed")

old = '''        steps = QLabel(
            "1. Click “Open PDFs” and choose your PDF files.\\n"
            "2. Use “Auto Select Current Page” or “Auto Select All Pages”.\\n"
            "3. Press “Refresh Order” and arrange the selected pages.\\n"
            "4. Click “Export PDF” to create your final print file."
        )
'''
new = '''        steps = QLabel(
            "New work:\\n"
            "1. Click “Open PDFs” and choose one or more PDF files.\\n"
            "2. Select areas, refresh the export order, then export.\\n\\n"
            "Existing work:\\n"
            "• Click “Open Project” to continue a saved .a4a3proj file.\\n"
            "• Recent projects are also available from File > Recent Projects."
        )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Updated welcome steps")
else:
    print("[SKIP] Steps block not found or already changed")

# ------------------------------------------------------------
# Add Open Project button
# ------------------------------------------------------------
old = '''        open_button = QPushButton("Open PDFs")
        open_button.setObjectName("openPdfsButton")

        close_button = QPushButton("Close")
        close_button.setObjectName("closeWelcomeButton")

        button_layout.addWidget(open_button)
        button_layout.addWidget(close_button)
        button_layout.addStretch()
        layout.addLayout(button_layout)

        def open_and_close() -> None:
            dialog.accept()
            self.open_pdfs()

        open_button.clicked.connect(open_and_close)
        close_button.clicked.connect(dialog.reject)

        dialog.exec()
'''

new = '''        open_button = QPushButton("Open PDFs")
        open_button.setObjectName("openPdfsButton")

        open_project_button = QPushButton("Open Project")
        open_project_button.setObjectName("openProjectButton")

        close_button = QPushButton("Continue")
        close_button.setObjectName("closeWelcomeButton")

        button_layout.addWidget(open_button)
        button_layout.addWidget(open_project_button)
        button_layout.addWidget(close_button)
        button_layout.addStretch()
        layout.addLayout(button_layout)

        def open_pdfs_and_close() -> None:
            dialog.accept()
            self.open_pdfs()

        def open_project_and_close() -> None:
            dialog.accept()
            self.open_project()

        open_button.clicked.connect(open_pdfs_and_close)
        open_project_button.clicked.connect(open_project_and_close)
        close_button.clicked.connect(dialog.reject)

        dialog.exec()
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Open Project button to welcome dialog")
else:
    print("[WARN] Welcome button block not found")

# ------------------------------------------------------------
# Style Open Project button
# ------------------------------------------------------------
old = '''            QPushButton#closeWelcomeButton {
                color: #395B64;
                background-color: #F6E7CB;
                border: 1px solid #E4CFA8;
                border-radius: 8px;
                padding: 9px 16px;
                font-weight: 700;
            }
'''
new = '''            QPushButton#openProjectButton {
                color: #395B64;
                background-color: #DDF3D5;
                border: 1px solid #B7DFAE;
                border-radius: 8px;
                padding: 9px 16px;
                font-weight: 800;
            }
            QPushButton#openProjectButton:hover {
                background-color: #CFECC5;
            }
            QPushButton#closeWelcomeButton {
                color: #395B64;
                background-color: #F6E7CB;
                border: 1px solid #E4CFA8;
                border-radius: 8px;
                padding: 9px 16px;
                font-weight: 700;
            }
'''

if old in text and "QPushButton#openProjectButton" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Open Project button style")
else:
    print("[SKIP] Open Project style already present or style block not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_welcome_open_project_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    'QPushButton("Open Project")',
    "open_project_and_close",
    "self.open_project()",
    'QPushButton("Continue")',
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Welcome popup now supports Open PDFs / Open Project / Continue")
