﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = EXPORTER.with_name(f"poster_exporter.py.bak_short_number_near_cut_{timestamp}")
shutil.copy2(EXPORTER, backup)
print(f"[OK] Backup created: {backup}")

text = EXPORTER.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

new_draw_numbering = r'''    def _draw_numbering(
        self,
        page: fitz.Page,
        page_width: float,
        page_height: float,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
        tile_no: int,
        tile_total: int,
        tile_name: str,
    ) -> None:
        # Minimal sheet label. Keep it short so it does not distract from the print.
        text = f"{sheet_no}/{sheet_total}"

        margin = 4 * MM_TO_PT
        offset = 4 * MM_TO_PT

        # Place near the cut/join guide, without any label box.
        if tile_name == "LEFT":
            point = fitz.Point(page_width - margin - 16 * MM_TO_PT, margin + offset)
        elif tile_name == "RIGHT":
            point = fitz.Point(margin + offset, margin + offset)
        elif tile_name == "TOP":
            point = fitz.Point(margin + offset, page_height - margin - offset)
        elif tile_name == "BOTTOM":
            point = fitz.Point(margin + offset, margin + 2 * offset)
        else:
            point = fitz.Point(margin + offset, margin + offset)

        page.insert_text(
            point,
            text,
            fontsize=8,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
        )
'''

new_draw_poster_tiling_numbering = r'''    def _draw_poster_tiling_numbering(
        self,
        page: fitz.Page,
        page_width: float,
        page_height: float,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
        tile: dict,
    ) -> None:
        # Minimal sheet label for tiled poster printing.
        # Example: 1/12, 2/12, ...
        text = f"{sheet_no}/{sheet_total}"

        row = int(tile.get("row", 0))
        col = int(tile.get("col", 0))
        rows = int(tile.get("rows", 1))
        cols = int(tile.get("cols", 1))

        margin = 5 * MM_TO_PT
        offset = 4 * MM_TO_PT

        # Prefer a location near a join/cut side.
        if col < cols - 1:
            point = fitz.Point(page_width - margin - 16 * MM_TO_PT, margin + offset)
        elif col > 0:
            point = fitz.Point(margin + offset, margin + offset)
        elif row < rows - 1:
            point = fitz.Point(margin + offset, page_height - margin - offset)
        elif row > 0:
            point = fitz.Point(margin + offset, margin + 2 * offset)
        else:
            point = fitz.Point(margin + offset, margin + offset)

        page.insert_text(
            point,
            text,
            fontsize=8,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
        )
'''

try:
    text = replace_function(text, "_draw_numbering", new_draw_numbering)
    print("[OK] Replaced legacy numbering with short label near cut guide")

    text = replace_function(text, "_draw_poster_tiling_numbering", new_draw_poster_tiling_numbering)
    print("[OK] Replaced poster tiling numbering with short label near cut guide")

except Exception as exc:
    print(f"[ERROR] Failed to replace numbering functions: {exc}")
    EXPORTER.write_text(original, encoding="utf-8")
    sys.exit(1)

EXPORTER.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(EXPORTER)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = EXPORTER.with_name(f"poster_exporter.py.failed_short_number_near_cut_{timestamp}")
    shutil.copy2(EXPORTER, failed)
    shutil.copy2(backup, EXPORTER)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = EXPORTER.read_text(encoding="utf-8", errors="replace")

required = [
    "Minimal sheet label",
    "text = f\"{sheet_no}/{sheet_total}\"",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Some expected markers were not found:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Sheet number is now short: 1/2, 2/2, 1/12, ...")
print("- No white label box is used")
print("- Label is placed near cut/join guide area")
