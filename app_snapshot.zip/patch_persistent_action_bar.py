﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_persistent_action_bar_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add persistent action bar under settings_tabs
# ------------------------------------------------------------
old = '''        settings_layout.addWidget(title)
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.settings_tabs)
'''

new = '''        settings_layout.addWidget(title)
        settings_layout.addWidget(self.mode_label)
        settings_layout.addWidget(self.settings_tabs)

        self.action_summary_label = QLabel("Print Order: 0 item(s) | Output: One PDF")
        self.action_summary_label.setWordWrap(True)
        self.action_summary_label.setStyleSheet(
            "color: #395B64; background-color: #FFF8F0; "
            "border: 1px solid #EADBC8; border-radius: 8px; padding: 6px;"
        )

        action_button_layout = QHBoxLayout()

        self.action_create_poster_button = QPushButton("Create Poster PDF")
        self.action_create_poster_button.clicked.connect(self.create_poster_pdf)

        self.action_create_single_button = QPushButton("Create Single Page PDF")
        self.action_create_single_button.clicked.connect(self.create_single_page_pdf)

        action_button_layout.addWidget(self.action_create_poster_button)
        action_button_layout.addWidget(self.action_create_single_button)

        settings_layout.addWidget(self.action_summary_label)
        settings_layout.addLayout(action_button_layout)
'''

if old in text and "self.action_summary_label" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added persistent action bar")
else:
    if "self.action_summary_label" in text:
        print("[SKIP] Persistent action bar already exists")
    else:
        print("[ERROR] Could not find settings_layout insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 2) Add update_action_summary method
# ------------------------------------------------------------
method = r'''
    def update_action_summary(self) -> None:
        if not hasattr(self, "action_summary_label"):
            return

        print_order_count = 0
        if hasattr(self, "export_order_list"):
            print_order_count = self.export_order_list.count()

        output_text = "One PDF"
        if hasattr(self, "batch_output_combo"):
            output_text = self.batch_output_combo.currentText()

        area_text = "Whole Page"
        if hasattr(self, "output_area_combo"):
            area_text = self.output_area_combo.currentText()

        self.action_summary_label.setText(
            f"Print Order: {print_order_count} item(s) | "
            f"Output: {output_text} | Area: {area_text}"
        )

'''

if "def update_action_summary" not in text:
    marker = "    def update_output_area_states(self) -> None:\n"
    pos = text.find(marker)
    if pos == -1:
        print("[ERROR] Could not find update_output_area_states marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added update_action_summary")
else:
    print("[SKIP] update_action_summary already exists")

# ------------------------------------------------------------
# 3) Connect Output Files / Output Area changes to summary
# ------------------------------------------------------------
old = '''        self.batch_output_combo.addItem("One PDF", "single_pdf")
        self.batch_output_combo.addItem("Separate PDF per selected page", "separate_pdf_per_page")
'''

new = '''        self.batch_output_combo.addItem("One PDF", "single_pdf")
        self.batch_output_combo.addItem("Separate PDF per selected page", "separate_pdf_per_page")
        self.batch_output_combo.currentIndexChanged.connect(self.update_action_summary)
'''

if old in text and "self.batch_output_combo.currentIndexChanged.connect(self.update_action_summary)" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Connected batch_output_combo to action summary")
else:
    print("[SKIP] batch_output_combo summary signal already present or anchor not found")

old = '''        self.output_area_combo.currentIndexChanged.connect(self.update_output_area_states)
'''

new = '''        self.output_area_combo.currentIndexChanged.connect(self.update_output_area_states)
        self.output_area_combo.currentIndexChanged.connect(self.update_action_summary)
'''

if old in text and "self.output_area_combo.currentIndexChanged.connect(self.update_action_summary)" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Connected output_area_combo to action summary")
else:
    print("[SKIP] output_area_combo summary signal already present or anchor not found")

# ------------------------------------------------------------
# 4) Update summary after Print Order changes
# ------------------------------------------------------------
targets = [
    "self._log(f\"Print order refreshed: {self.export_order_list.count()} pages\")",
    "self._log(f\"Print Order auto-synced: {self.export_order_list.count()} pages\")",
    "self._log(f\"Print Order built from all source pages: {total_added} pages\")",
    "self._log(f\"Print Order built from page range '{range_text}': {total_added} pages\")",
]

for target in targets:
    if target in text:
        replacement = target + "\n        self.update_action_summary()"
        if replacement not in text:
            text = text.replace(target, replacement, 1)
            print(f"[OK] Added summary update after: {target[:50]}")

# After moving rows
old = '''        self.export_order_list.setCurrentRow(target_row)

        # User manually changed order; stop automatic rebuild to preserve custom order.
        self._auto_sync_print_order_enabled = False
'''

new = '''        self.export_order_list.setCurrentRow(target_row)
        self.update_action_summary()

        # User manually changed order; stop automatic rebuild to preserve custom order.
        self._auto_sync_print_order_enabled = False
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Summary updates after Print Order manual move")

# After UI creation
old = '''        self.update_export_option_states()
        self.update_output_area_states()
        self._refresh_preview_floating_toolbar()
'''

new = '''        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()
        self._refresh_preview_floating_toolbar()
'''

if old in text and "self.update_action_summary()" not in text[text.find("def _create_central_ui"):text.find("def update_action_summary") if "def update_action_summary" in text else text.find("def update_output_area_states")]:
    text = text.replace(old, new, 1)
    print("[OK] Summary updates after UI creation")

# ------------------------------------------------------------
# 5) Extract Pages should go to Status tab, not Export tab
# ------------------------------------------------------------
old = '''            for index in range(self.settings_tabs.count()):
                if self.settings_tabs.tabText(index) == "Export":
                    self.settings_tabs.setCurrentIndex(index)
                    break
'''

new = '''            for index in range(self.settings_tabs.count()):
                if self.settings_tabs.tabText(index) == "Status":
                    self.settings_tabs.setCurrentIndex(index)
                    break
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Extract Pages now returns to Status tab")

# ------------------------------------------------------------
# 6) Release Notes
# ------------------------------------------------------------
if "Persistent action bar" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Persistent action bar</b>: Print Order count, Output Files mode, and Create buttons are now visible below the settings tabs.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

# ------------------------------------------------------------
# 7) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_persistent_action_bar_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "self.action_summary_label",
    "def update_action_summary",
    "Persistent action bar",
    "Print Order:",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Persistent action bar added under settings tabs")
print("- Status can remain visible while Create buttons are available")
print("- Extract Pages now returns to Status tab")
