﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_paper_scale_ui_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add UI controls in Poster/A3 tab
# ------------------------------------------------------------
anchor = '''        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")

        self.numbering_check = QCheckBox("Add sheet numbers")
'''

insert = '''        self.split_layout_combo = QComboBox()
        self.split_layout_combo.addItem("Left-Right", "left_right")
        self.split_layout_combo.addItem("Top-Bottom", "top_bottom")

        self.paper_size_combo = QComboBox()
        self.paper_size_combo.addItem("A4", "a4")
        self.paper_size_combo.addItem("US Letter", "letter")
        self.paper_size_combo.currentIndexChanged.connect(self.update_poster_sheet_estimate)

        self.poster_scale_spin = QSpinBox()
        self.poster_scale_spin.setRange(100, 500)
        self.poster_scale_spin.setSingleStep(25)
        self.poster_scale_spin.setSuffix("%")
        self.poster_scale_spin.setValue(100)
        self.poster_scale_spin.valueChanged.connect(self.update_poster_sheet_estimate)

        self.poster_sheet_estimate_label = QLabel("Estimated Sheets: -")

        self.numbering_check = QCheckBox("Add sheet numbers")
'''

if anchor in text and "self.paper_size_combo" not in text:
    text = text.replace(anchor, insert, 1)
    print("[OK] Added paper size / poster scale controls")
else:
    print("[SKIP] Paper/scale controls already present or anchor not found")

# Add widgets to A3 layout.
anchor = '''        a3_layout.addWidget(self.split_layout_title)
        a3_layout.addWidget(self.split_layout_combo)
        a3_layout.addSpacing(8)
        a3_layout.addWidget(self.numbering_check)
'''

insert = '''        a3_layout.addWidget(self.split_layout_title)
        a3_layout.addWidget(self.split_layout_combo)

        a3_layout.addSpacing(8)
        a3_layout.addWidget(QLabel("Output Paper Size"))
        a3_layout.addWidget(self.paper_size_combo)
        a3_layout.addWidget(QLabel("Poster Scale"))
        a3_layout.addWidget(self.poster_scale_spin)
        a3_layout.addWidget(self.poster_sheet_estimate_label)

        a3_layout.addSpacing(8)
        a3_layout.addWidget(self.numbering_check)
'''

if anchor in text and 'QLabel("Output Paper Size")' not in text:
    text = text.replace(anchor, insert, 1)
    print("[OK] Added paper/scale widgets to Poster tab")
else:
    print("[SKIP] Paper/scale widgets already added or anchor not found")

# ------------------------------------------------------------
# 2) Add estimate update method before update_export_option_states
# ------------------------------------------------------------
method = r'''
    def update_poster_sheet_estimate(self) -> None:
        if not hasattr(self, "poster_sheet_estimate_label"):
            return

        try:
            if self.page_count <= 0:
                self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
                return

            rect = self.preview_label.get_selection_rect()

            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                rect = self.page_selections.get(self.current_page_index, QRect())

            if rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                self.poster_sheet_estimate_label.setText("Estimated Sheets: select an area first")
                return

            selection = self._preview_rect_to_pdf_selection(rect)
            scale = max(self.poster_scale_spin.value() / 100.0, 0.1)

            paper = self.paper_size_combo.currentData()

            if paper == "letter":
                page_w = 8.5 * 72
                page_h = 11 * 72
            else:
                page_w = 210 * 72 / 25.4
                page_h = 297 * 72 / 25.4

            margin = 5 * 72 / 25.4
            printable_w = max(page_w - margin * 2, 1)
            printable_h = max(page_h - margin * 2, 1)

            poster_w = selection.width * scale
            poster_h = selection.height * scale

            import math
            cols = max(1, math.ceil(poster_w / printable_w))
            rows = max(1, math.ceil(poster_h / printable_h))
            total = cols * rows

            paper_name = self.paper_size_combo.currentText()
            self.poster_sheet_estimate_label.setText(
                f"Estimated Sheets: {cols} x {rows} = {total} ({paper_name}, {self.poster_scale_spin.value()}%)"
            )

        except Exception as exc:
            self.poster_sheet_estimate_label.setText("Estimated Sheets: -")
            self._log(f"Poster sheet estimate error: {exc}")

'''

if "def update_poster_sheet_estimate" not in text:
    marker = "    def update_export_option_states(self) -> None:\n"
    pos = text.find(marker)
    if pos == -1:
        print("[ERROR] Could not find update_export_option_states marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added sheet estimate method")
else:
    print("[SKIP] Sheet estimate method already exists")

# ------------------------------------------------------------
# 3) Update estimate on selection change/render
# ------------------------------------------------------------
old = '''            self.is_modified = True
'''
new = '''            self.is_modified = True
            self.update_poster_sheet_estimate()
'''

# only replace first occurrence inside on_selection_changed-ish section if not already nearby
if "self.update_poster_sheet_estimate()" not in text[text.find("def on_selection_changed"):text.find("def new_project")]:
    pos = text.find("def on_selection_changed")
    end = text.find("def new_project", pos)
    segment = text[pos:end]
    if old in segment:
        segment = segment.replace(old, new, 1)
        text = text[:pos] + segment + text[end:]
        print("[OK] Estimate updates on selection change")
else:
    print("[SKIP] Selection estimate update already present")

# Also after render.
old = '''            self._refresh_page_list_all_text()
            self._log(
'''
new = '''            self._refresh_page_list_all_text()
            self.update_poster_sheet_estimate()
            self._log(
'''

if old in text and "self.update_poster_sheet_estimate()" not in text[text.find("def _render_current_page"):text.find("def _update_page_buttons")]:
    text = text.replace(old, new, 1)
    print("[OK] Estimate updates after render")
else:
    print("[SKIP] Render estimate update already present or anchor not found")

# ------------------------------------------------------------
# 4) Pass paper_size/poster_scale to ExportOptions
# ------------------------------------------------------------
old = '''            quality_scale=float(self.export_quality_combo.currentData()),
        )
'''
new = '''            quality_scale=float(self.export_quality_combo.currentData()),
            paper_size=self.paper_size_combo.currentData() if hasattr(self, "paper_size_combo") else "a4",
            poster_scale=(self.poster_scale_spin.value() / 100.0) if hasattr(self, "poster_scale_spin") else 1.0,
        )
'''

count = text.count(old)
if count > 0 and "paper_size=self.paper_size_combo.currentData()" not in text:
    text = text.replace(old, new)
    print(f"[OK] Added paper_size/poster_scale to ExportOptions in {count} place(s)")
else:
    print("[SKIP] ExportOptions already patched or anchor not found")

# ------------------------------------------------------------
# 5) Save/load settings
# ------------------------------------------------------------
old = '''                "fit_to_page_enabled": self.fit_to_page_enabled,
            },
'''
new = '''                "fit_to_page_enabled": self.fit_to_page_enabled,
                "paper_size": self.paper_size_combo.currentData() if hasattr(self, "paper_size_combo") else "a4",
                "poster_scale_percent": self.poster_scale_spin.value() if hasattr(self, "poster_scale_spin") else 100,
            },
'''

if old in text and '"poster_scale_percent"' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Project save includes paper/scale")
else:
    print("[SKIP] Project save already includes paper/scale or anchor not found")

old = '''        self.fit_to_page_enabled = bool(settings.get("fit_to_page_enabled", True))

        workspace = data.get("workspace", {})
'''
new = '''        self.fit_to_page_enabled = bool(settings.get("fit_to_page_enabled", True))

        if hasattr(self, "paper_size_combo"):
            self._apply_combo_data(self.paper_size_combo, settings.get("paper_size", "a4"))
        if hasattr(self, "poster_scale_spin"):
            self.poster_scale_spin.setValue(int(settings.get("poster_scale_percent", 100)))

        workspace = data.get("workspace", {})
'''

if old in text and 'settings.get("poster_scale_percent"' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Project load restores paper/scale")
else:
    print("[SKIP] Project load already restores paper/scale or anchor not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 6) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_paper_scale_ui_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "self.paper_size_combo",
    "self.poster_scale_spin",
    "Estimated Sheets",
    "def update_poster_sheet_estimate",
    "paper_size=self.paper_size_combo.currentData()",
    "poster_scale=(self.poster_scale_spin.value() / 100.0)",
]

missing = [x for x in required if x not in new_text]
if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Paper Size UI added: A4 / US Letter")
print("- Poster Scale UI added: 100% ~ 500%")
print("- Estimated Sheets label added")
print("- Export/Print now passes paper_size/poster_scale to PosterExporter")
