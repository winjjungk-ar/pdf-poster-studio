﻿from pathlib import Path
import ast
import re
import sys
from datetime import datetime

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"
OUT = ROOT / "current_ui_audit_report.txt"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

main_text = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace") if EXPORTER.exists() else ""

def syntax_status(path: Path, text: str) -> str:
    try:
        ast.parse(text)
        return "OK"
    except SyntaxError as exc:
        return f"FAILED: {exc}"

def grep_lines(text: str, terms: list[str]) -> list[str]:
    rows = []
    for idx, line in enumerate(text.splitlines(), 1):
        if any(term.lower() in line.lower() for term in terms):
            rows.append(f"{idx:05d}: {line}")
    return rows

def function_defs(text: str, name: str) -> list[tuple[int, int]]:
    result = []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return result

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            result.append((node.lineno, getattr(node, "end_lineno", node.lineno)))
    return sorted(result)

old_visible_terms = [
    "A3 Split",
    "A3 Split Mode",
    "Selection Only Mode",
    "Export Order",
    "PDF Workspace",
    "Collect Pages",
    "Open Multiple PDFs",
]

expected_terms = [
    "Poster Print Mode",
    "Single Page Mode",
    "Source PDFs",
    "Print Order",
    "Build Print Order",
    "Open PDFs",
    "Open Exports Folder",
    "Poster Size Preset",
    "Output Paper Size",
    "Poster Scale",
]

report = []
report.append("# Current UI Audit Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py lines: {len(main_text.splitlines())}")
report.append(f"- poster_exporter.py lines: {len(exporter_text.splitlines()) if exporter_text else 'missing'}")
report.append("")

report.append("## 1. Syntax")
report.append(f"- main_window.py: {syntax_status(MAIN, main_text)}")
if exporter_text:
    report.append(f"- poster_exporter.py: {syntax_status(EXPORTER, exporter_text)}")
else:
    report.append("- poster_exporter.py: MISSING")
report.append("")

report.append("## 2. Old visible term counts")
for term in old_visible_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

report.append("## 3. Expected term counts")
for term in expected_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

report.append("## 4. Old visible term contexts")
old_rows = grep_lines(main_text, old_visible_terms)
if old_rows:
    report.append("```text")
    report.append("\n".join(old_rows[:300]))
    report.append("```")
else:
    report.append("- [OK] No old visible terms found.")
report.append("")

report.append("## 5. Main UI label/action lines")
ui_rows = []
for idx, line in enumerate(main_text.splitlines(), 1):
    if any(x in line for x in ["QLabel(", "QPushButton(", "QAction(", "addAction(", "addTab(", ".addItem("]):
        if any(term.lower() in line.lower() for term in [
            "poster", "single", "source", "print", "order", "pdf", "export",
            "paper", "scale", "quality", "selection", "open", "folder"
        ]):
            ui_rows.append(f"{idx:05d}: {line}")

report.append("```text")
report.append("\n".join(ui_rows[:600]))
report.append("```")
report.append("")

report.append("## 6. Duplicate function checks")
for fn in ["_create_log_panel", "_create_central_ui", "_create_quick_toolbar", "export_print_pdf", "print_pdf"]:
    defs = function_defs(main_text, fn)
    report.append(f"- `{fn}`: {len(defs)} definition(s)")
    for start, end in defs:
        report.append(f"  - lines {start}-{end} ({end - start + 1} lines)")
report.append("")

report.append("## 7. Export quality UI check")
quality_rows = grep_lines(main_text, ["Export Quality", "export_quality_combo", "quality_scale"])
if quality_rows:
    report.append("```text")
    report.append("\n".join(quality_rows[:200]))
    report.append("```")
else:
    report.append("- No export quality references found.")
report.append("")

report.append("## 8. Poster exporter vector/raster check")
if exporter_text:
    rows = grep_lines(exporter_text, [
        "show_pdf_page",
        "insert_image",
        "_render_tile_to_a4",
        "quality_scale",
        "paper_size",
        "poster_scale",
        "A3",
        "LETTER",
        "Sheet",
    ])
    report.append("```text")
    report.append("\n".join(rows[:400]))
    report.append("```")
else:
    report.append("- poster_exporter.py missing")
report.append("")

report.append("## 9. Suggested interpretation")
report.append("- Old terms inside internal names like `a3_split_group` are acceptable if not visible.")
report.append("- `Selection Only Mode` should no longer appear in visible text if Single Page rename was applied.")
report.append("- `Export Quality` can be hidden if vector export is now the main path.")
report.append("- Duplicate `_create_log_panel` should be exactly 1.")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste current_ui_audit_report.txt here.")
