﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = EXPORTER.with_name(f"poster_exporter.py.bak_move_legacy_numbering_top_{timestamp}")
shutil.copy2(EXPORTER, backup)
print(f"[OK] Backup created: {backup}")

text = EXPORTER.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

new_draw_numbering = r'''    def _draw_numbering(
        self,
        page: fitz.Page,
        page_width: float,
        page_height: float,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
        tile_no: int,
        tile_total: int,
        tile_name: str,
    ) -> None:
        text = (
            f"Sheet {sheet_no}/{sheet_total}  "
            f"Source Page {source_page}  "
            f"{tile_name} {tile_no}/{tile_total}"
        )

        # Place sheet number near the top margin instead of bottom-right.
        # This avoids interfering with the poster/image area.
        rect = fitz.Rect(
            8 * MM_TO_PT,
            5 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            11 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=8,
            fontname="helv",
            color=(0.15, 0.15, 0.15),
            align=fitz.TEXT_ALIGN_RIGHT,
        )
'''

try:
    text = replace_function(text, "_draw_numbering", new_draw_numbering)
    print("[OK] Replaced legacy _draw_numbering: moved sheet number to top margin")
except Exception as exc:
    print(f"[ERROR] Failed to replace _draw_numbering: {exc}")
    EXPORTER.write_text(original, encoding="utf-8")
    sys.exit(1)

EXPORTER.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(EXPORTER)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = EXPORTER.with_name(f"poster_exporter.py.failed_move_legacy_numbering_top_{timestamp}")
    shutil.copy2(EXPORTER, failed)
    shutil.copy2(backup, EXPORTER)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = EXPORTER.read_text(encoding="utf-8", errors="replace")

if "Place sheet number near the top margin instead of bottom-right" not in new_text:
    print("[WARN] Expected marker not found after patch")
else:
    print("[OK] Top-margin legacy numbering marker confirmed")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- A4 100% / classic 2-sheet Poster Print numbering moved from bottom-right to top margin")
