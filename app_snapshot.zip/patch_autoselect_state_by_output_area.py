﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_autoselect_state_by_output_area_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Store toolbar auto-select actions as self members
# ------------------------------------------------------------
old = '''        auto_current_action = QAction("Auto Select Current Page", self)
        auto_current_action.triggered.connect(self.auto_select_content)
        toolbar.addAction(auto_current_action)

        auto_all_action = QAction("Auto Select All Pages", self)
        auto_all_action.triggered.connect(self.auto_select_all_pages)
        auto_all_action.setObjectName("autoSelectAllPagesAction")
        toolbar.addAction(auto_all_action)

        auto_all_button = toolbar.widgetForAction(auto_all_action)
        if auto_all_button is not None:
            auto_all_button.setObjectName("autoSelectAllPagesButton")
'''

new = '''        self.auto_current_action = QAction("Auto Select Current Page", self)
        self.auto_current_action.triggered.connect(self.auto_select_content)
        toolbar.addAction(self.auto_current_action)

        self.auto_all_action = QAction("Auto Select All Pages", self)
        self.auto_all_action.triggered.connect(self.auto_select_all_pages)
        self.auto_all_action.setObjectName("autoSelectAllPagesAction")
        toolbar.addAction(self.auto_all_action)

        auto_all_button = toolbar.widgetForAction(self.auto_all_action)
        if auto_all_button is not None:
            auto_all_button.setObjectName("autoSelectAllPagesButton")
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Toolbar Auto Select actions stored as self members")
elif "self.auto_current_action" in text and "self.auto_all_action" in text:
    print("[SKIP] Toolbar Auto Select actions already stored")
else:
    print("[WARN] Could not find toolbar Auto Select action block")

# ------------------------------------------------------------
# 2) Connect output_area_combo change signal
# ------------------------------------------------------------
old = '''        self.output_area_combo.addItem("Whole Page", "whole_page")
        self.output_area_combo.addItem("Selected Area", "selected_area")
        self.output_area_combo.setCurrentIndex(0)
'''

new = '''        self.output_area_combo.addItem("Whole Page", "whole_page")
        self.output_area_combo.addItem("Selected Area", "selected_area")
        self.output_area_combo.setCurrentIndex(0)
        self.output_area_combo.currentIndexChanged.connect(self.update_output_area_states)
'''

if old in text and "self.output_area_combo.currentIndexChanged.connect(self.update_output_area_states)" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Connected output_area_combo to update_output_area_states")
else:
    if "update_output_area_states" in text:
        print("[SKIP] output_area_combo state signal already present")
    else:
        print("[WARN] Could not connect output_area_combo")

# ------------------------------------------------------------
# 3) Add update_output_area_states method
# ------------------------------------------------------------
method = r'''
    def update_output_area_states(self) -> None:
        is_selected_area = True

        if hasattr(self, "output_area_combo"):
            is_selected_area = self.output_area_combo.currentData() == "selected_area"

        disabled_tip = (
            "Disabled because Output Area is Whole Page. "
            "Choose Selected Area to use Auto Select."
        )
        enabled_tip_current = "Automatically detect the content area on the current page."
        enabled_tip_all = "Automatically detect content areas on all pages."

        if hasattr(self, "auto_current_action"):
            self.auto_current_action.setEnabled(is_selected_area)
            self.auto_current_action.setToolTip(enabled_tip_current if is_selected_area else disabled_tip)

        if hasattr(self, "auto_all_action"):
            self.auto_all_action.setEnabled(is_selected_area)
            self.auto_all_action.setToolTip(enabled_tip_all if is_selected_area else disabled_tip)

'''

if "def update_output_area_states" not in text:
    marker = "    def update_export_option_states(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find update_export_option_states marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added update_output_area_states method")
else:
    print("[SKIP] update_output_area_states already exists")

# ------------------------------------------------------------
# 4) Call update_output_area_states after UI creation
# ------------------------------------------------------------
old = '''        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()
'''

new = '''        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()
        self.update_output_area_states()
'''

if old in text and "self.update_output_area_states()" not in text[text.find("def _create_central_ui"):text.find("def update_output_area_states") if "def update_output_area_states" in text else text.find("def update_export_option_states")]:
    text = text.replace(old, new, 1)
    print("[OK] update_output_area_states called after UI creation")
else:
    print("[SKIP] UI creation state update already present or anchor not found")

# ------------------------------------------------------------
# 5) Call after project load restore too
# ------------------------------------------------------------
old = '''        if hasattr(self, "update_poster_sheet_estimate"):
            self.update_poster_sheet_estimate()

        self.is_modified = False
'''

new = '''        if hasattr(self, "update_poster_sheet_estimate"):
            self.update_poster_sheet_estimate()

        if hasattr(self, "update_output_area_states"):
            self.update_output_area_states()

        self.is_modified = False
'''

if old in text and "self.update_output_area_states()" not in text[text.find("def _apply_project_data"):text.find("self.is_modified = False", text.find("def _apply_project_data")) + 200]:
    text = text.replace(old, new, 1)
    print("[OK] update_output_area_states called after project load")
else:
    print("[SKIP] Project load state update already present or anchor not found")

# ------------------------------------------------------------
# 6) Release Notes update
# ------------------------------------------------------------
if "Auto Select buttons now follow Output Area" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.5</h3>
<ul>
  <li><b>Output Area workflow</b>: Auto Select buttons are disabled when Output Area is Whole Page.</li>
  <li><b>Auto Select buttons now follow Output Area</b>: Choose Selected Area to enable Auto Select.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for Auto Select state behavior")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 7) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_autoselect_state_by_output_area_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "self.auto_current_action",
    "self.auto_all_action",
    "def update_output_area_states",
    "Choose Selected Area to use Auto Select",
    "Auto Select buttons now follow Output Area",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Auto Select buttons now disable when Output Area is Whole Page")
print("- Auto Select buttons enable when Output Area is Selected Area")
print("- Release Notes updated")
