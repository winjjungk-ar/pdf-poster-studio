﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_selected_area_task_choice_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

new_task_selected_area = r'''    def task_selected_area_pdf(self) -> None:
        self._set_combo_by_data_if_exists("output_area_combo", "selected_area")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()

        dialog = QMessageBox(self)
        dialog.setWindowTitle("Selected Area PDF")
        dialog.setIcon(QMessageBox.Icon.Question)
        dialog.setText("How do you want to select the area?")
        dialog.setInformativeText(
            "Auto Select detects the content area on the current page.\n\n"
            "Select Manually lets you drag an area in the preview."
        )

        auto_button = dialog.addButton("Auto Select Current Page", QMessageBox.ButtonRole.AcceptRole)
        manual_button = dialog.addButton("Select Manually", QMessageBox.ButtonRole.ActionRole)
        cancel_button = dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        dialog.setDefaultButton(auto_button)
        dialog.exec()

        clicked = dialog.clickedButton()

        if clicked == cancel_button:
            return

        if hasattr(self, "settings_tabs") and hasattr(self, "selection_only_group"):
            self.settings_tabs.setCurrentWidget(self.selection_only_group)

        if clicked == auto_button:
            if self.page_count <= 0:
                QMessageBox.information(
                    self,
                    "Selected Area PDF",
                    "Please open a PDF or image first."
                )
                return

            self.auto_select_content()

            QMessageBox.information(
                self,
                "Selected Area PDF",
                "Auto Select completed for the current page.\n\n"
                "Click Build Print Order, then click Single Page PDF in the toolbar."
            )
            return

        if clicked == manual_button:
            QMessageBox.information(
                self,
                "Selected Area PDF",
                "Drag on the preview to select an area.\n\n"
                "Then click Build Print Order and click Single Page PDF in the toolbar."
            )

'''

try:
    text = replace_function(text, "task_selected_area_pdf", new_task_selected_area)
    print("[OK] Selected Area PDF task now asks Auto Select / Manual")
except Exception as exc:
    print(f"[ERROR] Failed to replace task_selected_area_pdf: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Release Notes
if "Selected Area PDF task choice" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Selected Area PDF task choice</b>: Home > Selected Area PDF now offers Auto Select Current Page or Select Manually.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_selected_area_task_choice_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "How do you want to select the area?",
    "Auto Select Current Page",
    "Select Manually",
    "Selected Area PDF task choice",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Home > Selected Area PDF now asks Auto Select or Manual")
print("- Single Page tab opens after selection")
