﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

main_backup = MAIN.with_name(f"main_window.py.bak_fixed_a_series_tiles_{timestamp}")
exporter_backup = EXPORTER.with_name(f"poster_exporter.py.bak_fixed_a_series_tiles_{timestamp}")

shutil.copy2(MAIN, main_backup)
shutil.copy2(EXPORTER, exporter_backup)

print(f"[OK] Backup created: {main_backup}")
print(f"[OK] Backup created: {exporter_backup}")

# ------------------------------------------------------------
# 1) poster_exporter.py: add tile_cols/tile_rows to ExportOptions
# ------------------------------------------------------------
exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace")
original_exporter = exporter_text

if "tile_cols: int | None" not in exporter_text:
    old = '''    paper_size: str = "a4"
    poster_scale: float = 1.0
    add_numbers: bool = True
'''
    new = '''    paper_size: str = "a4"
    poster_scale: float = 1.0
    tile_cols: int | None = None
    tile_rows: int | None = None
    add_numbers: bool = True
'''
    if old in exporter_text:
        exporter_text = exporter_text.replace(old, new, 1)
        print("[OK] ExportOptions extended with tile_cols/tile_rows")
    else:
        print("[ERROR] Could not extend ExportOptions")
        EXPORTER.write_text(original_exporter, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] ExportOptions already has tile_cols/tile_rows")

# ------------------------------------------------------------
# 2) Replace _make_poster_tiles with fixed-grid-aware version
# ------------------------------------------------------------
pattern = re.compile(
    r"^    def _make_poster_tiles\([\s\S]*?(?=^    def _export_poster_tiling)",
    re.M
)

new_make_poster_tiles = r'''    def _make_poster_tiles(
        self,
        full_clip: fitz.Rect,
        options: ExportOptions,
        printable_rect: fitz.Rect,
    ) -> list[dict]:
        scale = max(float(getattr(options, "poster_scale", 1.0) or 1.0), 0.1)
        overlap_pt = 0.0

        if getattr(options, "output_mode", "") == "overlap":
            overlap_pt = max(float(getattr(options, "overlap_mm", 0.0) or 0.0), 0.0) * MM_TO_PT

        forced_cols = getattr(options, "tile_cols", None)
        forced_rows = getattr(options, "tile_rows", None)

        tiles: list[dict] = []

        # Preset-driven fixed grid, e.g. A2 from A4 = 2 x 2 = 4 sheets.
        if forced_cols and forced_rows and int(forced_cols) > 0 and int(forced_rows) > 0:
            cols = int(forced_cols)
            rows = int(forced_rows)

            tile_w = full_clip.width / cols
            tile_h = full_clip.height / rows

            overlap_source = overlap_pt / scale if overlap_pt > 0 else 0.0

            for row in range(rows):
                for col in range(cols):
                    x0 = full_clip.x0 + col * tile_w
                    y0 = full_clip.y0 + row * tile_h
                    x1 = full_clip.x0 + (col + 1) * tile_w
                    y1 = full_clip.y0 + (row + 1) * tile_h

                    # Add overlap toward neighboring tiles.
                    clip = fitz.Rect(
                        max(full_clip.x0, x0 - (overlap_source if col > 0 else 0)),
                        max(full_clip.y0, y0 - (overlap_source if row > 0 else 0)),
                        min(full_clip.x1, x1 + (overlap_source if col < cols - 1 else 0)),
                        min(full_clip.y1, y1 + (overlap_source if row < rows - 1 else 0)),
                    )

                    target_rect = printable_rect

                    tiles.append(
                        {
                            "row": row,
                            "col": col,
                            "rows": rows,
                            "cols": cols,
                            "clip": clip,
                            "target_rect": target_rect,
                        }
                    )

            return tiles

        printable_w = max(printable_rect.width, 1.0)
        printable_h = max(printable_rect.height, 1.0)

        # In output coordinates, each sheet covers printable_w/h.
        # Convert back to source PDF coordinates by dividing by scale.
        source_tile_w = printable_w / scale
        source_tile_h = printable_h / scale

        source_step_w = max((printable_w - overlap_pt) / scale, source_tile_w * 0.25)
        source_step_h = max((printable_h - overlap_pt) / scale, source_tile_h * 0.25)

        cols = max(1, math.ceil(max(full_clip.width - source_tile_w, 0.0) / source_step_w) + 1)
        rows = max(1, math.ceil(max(full_clip.height - source_tile_h, 0.0) / source_step_h) + 1)

        for row in range(rows):
            for col in range(cols):
                x0 = full_clip.x0 + col * source_step_w
                y0 = full_clip.y0 + row * source_step_h
                x1 = min(x0 + source_tile_w, full_clip.x1)
                y1 = min(y0 + source_tile_h, full_clip.y1)

                if x1 <= x0 or y1 <= y0:
                    continue

                clip = fitz.Rect(x0, y0, x1, y1)

                # Target size reflects true scale. Last row/column may not fill whole printable area.
                target_w = clip.width * scale
                target_h = clip.height * scale

                target_rect = fitz.Rect(
                    printable_rect.x0,
                    printable_rect.y0,
                    min(printable_rect.x0 + target_w, printable_rect.x1),
                    min(printable_rect.y0 + target_h, printable_rect.y1),
                )

                tiles.append(
                    {
                        "row": row,
                        "col": col,
                        "rows": rows,
                        "cols": cols,
                        "clip": clip,
                        "target_rect": target_rect,
                    }
                )

        return tiles

'''

if pattern.search(exporter_text):
    exporter_text = pattern.sub(new_make_poster_tiles, exporter_text, count=1)
    print("[OK] Replaced _make_poster_tiles with fixed-grid-aware version")
else:
    print("[ERROR] Could not find _make_poster_tiles")
    EXPORTER.write_text(original_exporter, encoding="utf-8")
    sys.exit(1)

EXPORTER.write_text(exporter_text, encoding="utf-8")

# ------------------------------------------------------------
# 3) main_window.py: add helper for fixed A-series grid
# ------------------------------------------------------------
main_text = MAIN.read_text(encoding="utf-8", errors="replace")
original_main = main_text

helper = r'''
    def _get_fixed_a_series_tile_grid(self) -> tuple[int | None, int | None]:
        if not hasattr(self, "paper_size_combo") or not hasattr(self, "poster_scale_spin"):
            return None, None

        paper = self.paper_size_combo.currentData()
        scale_percent = int(self.poster_scale_spin.value())
        split_layout = self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else "left_right"

        if paper != "a4":
            return None, None

        # A-series from A4 expected sheet counts.
        # A3 = 2, A2 = 4, A1 = 8, A0 = 16.
        if scale_percent <= 141:
            return (1, 2) if split_layout == "top_bottom" else (2, 1)

        if scale_percent <= 200:
            return 2, 2

        if scale_percent <= 283:
            return (2, 4) if split_layout == "top_bottom" else (4, 2)

        if scale_percent <= 400:
            return 4, 4

        return None, None

'''

if "def _get_fixed_a_series_tile_grid" not in main_text:
    marker = "    def update_tiling_preview"
    pos = main_text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find update_tiling_preview marker")
        MAIN.write_text(original_main, encoding="utf-8")
        EXPORTER.write_text(original_exporter, encoding="utf-8")
        sys.exit(1)

    main_text = main_text[:pos] + helper + "\n" + main_text[pos:]
    print("[OK] Added _get_fixed_a_series_tile_grid helper")
else:
    print("[SKIP] _get_fixed_a_series_tile_grid already exists")

# ------------------------------------------------------------
# 4) main_window.py: update estimate to use fixed grid
# ------------------------------------------------------------
# Replace classic branch condition block area more broadly.
old = '''            # Classic A4 poster behavior:
            # A4 100% and A3 from A4 141% should both be 2 A4 sheets.
            if paper == "a4" and scale_percent <= 141:
                split_layout = self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else "left_right"

                if split_layout == "top_bottom":
                    layout_text = "1 x 2 = 2"
                    size_text = "Approx Poster Size: A3-like, 210 x 420 mm"
                else:
                    layout_text = "2 x 1 = 2"
                    size_text = "Approx Poster Size: A3, 420 x 297 mm"

                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text}\\n{size_text}"
                )

                if split_layout == "top_bottom":
                    self.update_tiling_preview(cols=1, rows=2)
                else:
                    self.update_tiling_preview(cols=2, rows=1)

                return
'''

new = '''            fixed_cols, fixed_rows = self._get_fixed_a_series_tile_grid()

            if fixed_cols and fixed_rows:
                total = fixed_cols * fixed_rows

                if total == 2:
                    size_text = "Approx Poster Size: A3"
                elif total == 4:
                    size_text = "Approx Poster Size: A2"
                elif total == 8:
                    size_text = "Approx Poster Size: A1"
                elif total == 16:
                    size_text = "Approx Poster Size: A0"
                else:
                    size_text = "Approx Poster Size: preset"

                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {fixed_cols} x {fixed_rows} = {total}\\n{size_text}"
                )
                self.update_tiling_preview(cols=fixed_cols, rows=fixed_rows)
                return
'''

if old in main_text:
    main_text = main_text.replace(old, new, 1)
    print("[OK] Estimate now uses fixed A-series grid")
else:
    print("[WARN] Could not find old classic estimate branch. It may already be patched.")

# ------------------------------------------------------------
# 5) main_window.py: pass tile_cols/tile_rows into ExportOptions
# ------------------------------------------------------------
old = '''            paper_size=self.paper_size_combo.currentData() if hasattr(self, "paper_size_combo") else "a4",
            poster_scale=(self.poster_scale_spin.value() / 100.0) if hasattr(self, "poster_scale_spin") else 1.0,
        )
'''

new = '''            paper_size=self.paper_size_combo.currentData() if hasattr(self, "paper_size_combo") else "a4",
            poster_scale=(self.poster_scale_spin.value() / 100.0) if hasattr(self, "poster_scale_spin") else 1.0,
            tile_cols=self._get_fixed_a_series_tile_grid()[0] if hasattr(self, "_get_fixed_a_series_tile_grid") else None,
            tile_rows=self._get_fixed_a_series_tile_grid()[1] if hasattr(self, "_get_fixed_a_series_tile_grid") else None,
        )
'''

count = main_text.count(old)
if count:
    main_text = main_text.replace(old, new)
    print(f"[OK] ExportOptions now receives tile_cols/tile_rows in {count} place(s)")
else:
    if "tile_cols=self._get_fixed_a_series_tile_grid()" in main_text:
        print("[SKIP] ExportOptions already has tile_cols/tile_rows")
    else:
        print("[WARN] Could not find ExportOptions paper/scale block")

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 6) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup in [
    (MAIN, main_backup),
    (EXPORTER, exporter_backup),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_fixed_a_series_tiles_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 7) verification
# ------------------------------------------------------------
main_new = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_new = EXPORTER.read_text(encoding="utf-8", errors="replace")

checks = [
    ("main helper", "def _get_fixed_a_series_tile_grid" in main_new),
    ("main tile_cols", "tile_cols=self._get_fixed_a_series_tile_grid()[0]" in main_new),
    ("exporter tile_cols field", "tile_cols: int | None" in exporter_new),
    ("exporter forced grid", "forced_cols = getattr(options, \"tile_cols\", None)" in exporter_new),
]

for name, ok in checks:
    print(f"[CHECK] {name}: {'OK' if ok else 'MISSING'}")

print("")
print("Done.")
print("- A2 from A4 200% should now estimate 2 x 2 = 4")
print("- A2 from A4 200% should now export 4 pages")
print("- A1 from A4 should export 8 pages")
print("- A0 from A4 should export 16 pages")
