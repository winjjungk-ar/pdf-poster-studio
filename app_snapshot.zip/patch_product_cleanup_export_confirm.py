﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_product_cleanup_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Menu cleanup
# ------------------------------------------------------------
old_menu_head = '''        view_menu = menu_bar.addMenu("View")
        options_menu = menu_bar.addMenu("Options")
        help_menu = menu_bar.addMenu("Help")
        about_menu = menu_bar.addMenu("About")
'''
new_menu_head = '''        view_menu = menu_bar.addMenu("View")
        help_menu = menu_bar.addMenu("Help")
'''

if old_menu_head in text:
    text = text.replace(old_menu_head, new_menu_head, 1)
    print("[OK] Removed Options/About top-level menus")
else:
    print("[SKIP] Menu head already cleaned or block not found")

old_options_block = '''        # Options
        preferences_action = options_menu.addAction("Preferences")
        preferences_action.setEnabled(False)

        # Help
        help_menu.addAction("Quick Start", self.show_quick_start)
        help_menu.addAction("Diagnostics", self.run_diagnostics)
        help_menu.addAction("Check Menu Actions", self.check_menu_actions)

        # About
        about_menu.addAction("About Program", self.show_about)
'''
new_help_block = '''        # Help
        help_menu.addAction("Quick Start", self.show_quick_start)
        help_menu.addAction("Diagnostics", self.run_diagnostics)
        help_menu.addSeparator()
        help_menu.addAction("About Program", self.show_about)
'''

if old_options_block in text:
    text = text.replace(old_options_block, new_help_block, 1)
    print("[OK] Cleaned Help/Options/About menu block")
else:
    # Fallback cleanup
    before = text
    text = text.replace('        # Options\n        preferences_action = options_menu.addAction("Preferences")\n        preferences_action.setEnabled(False)\n\n', '')
    text = text.replace('        help_menu.addAction("Check Menu Actions", self.check_menu_actions)\n', '')
    text = text.replace('        # About\n        about_menu.addAction("About Program", self.show_about)\n', '')
    if 'help_menu.addAction("About Program", self.show_about)' not in text:
        text = text.replace(
            '        help_menu.addAction("Diagnostics", self.run_diagnostics)\n',
            '        help_menu.addAction("Diagnostics", self.run_diagnostics)\n        help_menu.addSeparator()\n        help_menu.addAction("About Program", self.show_about)\n',
            1
        )
    if text != before:
        print("[OK] Menu cleanup fallback applied")
    else:
        print("[WARN] Menu cleanup fallback made no changes")

# ------------------------------------------------------------
# 2) Rename Refresh Order button
# ------------------------------------------------------------
text = text.replace(
    '        refresh_export_order_button = QPushButton("Refresh Order")\n',
    '        refresh_export_order_button = QPushButton("Build Export Order")\n',
    1
)
print("[OK] Renamed Refresh Order button if found")

# Welcome text also update
text = text.replace(
    '            "3. Press “Refresh Order” and arrange the selected pages.\\n"',
    '            "3. Press “Build Export Order” and arrange the selected pages.\\n"'
)
text = text.replace(
    '            "2. Select areas, refresh the export order, then export.\\n\\n"',
    '            "2. Select areas, build the export order, then export.\\n\\n"'
)

# ------------------------------------------------------------
# 3) Add Clear All Selections method
# ------------------------------------------------------------
clear_method = r'''
    def clear_all_selections(self) -> None:
        if not self.current_pdf_path and not getattr(self, "workspace_items", []):
            return

        result = QMessageBox.question(
            self,
            "Clear All Selections",
            "Clear all selected areas and checked pages?\n\n"
            "This affects the current workspace.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if result != QMessageBox.StandardButton.Yes:
            return

        if hasattr(self, "workspace_items") and self.workspace_items:
            if self.current_workspace_index is not None:
                self._save_current_workspace_state()

            for item in self.workspace_items:
                item["page_selections"] = {}
                item["checked_pages"] = set()
                item["current_page_index"] = int(item.get("current_page_index", 0))

            self.page_selections.clear()
            self.checked_pages.clear()

            if self.current_workspace_index is not None:
                self._load_workspace_index(self.current_workspace_index)
            elif self.workspace_items:
                self._load_workspace_index(0)

            self._refresh_workspace_list_text()

        else:
            self.page_selections.clear()
            self.checked_pages.clear()
            self.preview_label.clear_selection()
            self._refresh_current_page_check_state()
            self._refresh_page_list_all_text()
            self._update_checked_pages_label()

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        self.selection_info_label.setText("Selection: None")
        self.is_modified = True
        self._log("All selections cleared.")

'''

if "def clear_all_selections(self) -> None:" not in text:
    marker = "    def clear_selection(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find clear_selection marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + clear_method + "\n" + text[pos:]
    print("[OK] Added clear_all_selections method")
else:
    print("[SKIP] clear_all_selections already exists")

# ------------------------------------------------------------
# 4) Add Clear All Selections to toolbar
# ------------------------------------------------------------
old_toolbar_part = '''        auto_all_button = toolbar.widgetForAction(auto_all_action)
        if auto_all_button is not None:
            auto_all_button.setObjectName("autoSelectAllPagesButton")

        toolbar.addSeparator()

        export_action = QAction("Export PDF", self)
'''
new_toolbar_part = '''        auto_all_button = toolbar.widgetForAction(auto_all_action)
        if auto_all_button is not None:
            auto_all_button.setObjectName("autoSelectAllPagesButton")

        clear_all_action = QAction("Clear All Selections", self)
        clear_all_action.triggered.connect(self.clear_all_selections)
        toolbar.addAction(clear_all_action)

        toolbar.addSeparator()

        export_action = QAction("Export PDF", self)
'''

if old_toolbar_part in text and "Clear All Selections" not in text[text.find("def _create_quick_toolbar"):text.find("def _create_menus")]:
    text = text.replace(old_toolbar_part, new_toolbar_part, 1)
    print("[OK] Added Clear All Selections to toolbar")
else:
    print("[SKIP] Toolbar Clear All already present or block not found")

# ------------------------------------------------------------
# 5) Add export confirmation methods
# ------------------------------------------------------------
confirm_methods = r'''
    def _build_export_confirmation_lines(self, limit: int = 30) -> list[str]:
        lines: list[str] = []

        if self._workspace_has_multiple_pdfs():
            if self.current_workspace_index is not None:
                self._save_current_workspace_state()

            entries = self._get_export_order_entries()

            if not entries:
                for workspace_index, item in enumerate(self.workspace_items):
                    checked_pages = sorted(list(item.get("checked_pages", set())))
                    for page_index in checked_pages:
                        entries.append((workspace_index, page_index))

            for order_no, (workspace_index, page_index) in enumerate(entries, 1):
                if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                    continue

                pdf_name = Path(self.workspace_items[workspace_index].get("pdf_path", "")).name
                lines.append(f"{order_no}. {pdf_name} - Page {page_index + 1}")

                if len(lines) >= limit:
                    remaining = len(entries) - limit
                    if remaining > 0:
                        lines.append(f"... and {remaining} more page(s)")
                    break

            return lines

        try:
            export_selections = self._build_export_selections()
        except Exception:
            return []

        for order_no, page_index in enumerate(sorted(export_selections.keys()), 1):
            pdf_name = Path(self.current_pdf_path or "").name
            lines.append(f"{order_no}. {pdf_name} - Page {page_index + 1}")

            if len(lines) >= limit:
                remaining = len(export_selections) - limit
                if remaining > 0:
                    lines.append(f"... and {remaining} more page(s)")
                break

        return lines

    def _confirm_export_order(self, output_path: str) -> bool:
        lines = self._build_export_confirmation_lines()

        if not lines:
            QMessageBox.warning(
                self,
                "Export",
                "No selected pages were found for export."
            )
            return False

        preview = "\n".join(lines)
        message = (
            f"Export the selected pages in this order?\n\n"
            f"{preview}\n\n"
            f"Output:\n{output_path}"
        )

        result = QMessageBox.question(
            self,
            "Confirm Export",
            message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        return result == QMessageBox.StandardButton.Yes

'''

if "def _confirm_export_order" not in text:
    marker = "    def export_print_pdf(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find export_print_pdf marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + confirm_methods + "\n" + text[pos:]
    print("[OK] Added export confirmation methods")
else:
    print("[SKIP] Export confirmation methods already exist")

# ------------------------------------------------------------
# 6) Insert confirmation into export_print_pdf after output_path selected
# ------------------------------------------------------------
old_export_output_block = '''        if not output_path:
            return

        options = ExportOptions(
'''
new_export_output_block = '''        if not output_path:
            return

        if not self._confirm_export_order(output_path):
            return

        options = ExportOptions(
'''

if old_export_output_block in text and "self._confirm_export_order(output_path)" not in text[text.find("def export_print_pdf"):text.find("def _create_temp_print_pdf")]:
    text = text.replace(old_export_output_block, new_export_output_block, 1)
    print("[OK] Added export confirmation call")
else:
    print("[SKIP] Export confirmation call already present or block not found")

# ------------------------------------------------------------
# 7) Diagnostics references cleanup
# ------------------------------------------------------------
text = text.replace(
    '            ("File > Collect Pages from PDFs", callable(self.open_page_collector_dialog)),\n',
    ''
)
text = text.replace(
    '            ("Help > Check Menu Actions", callable(self.check_menu_actions)),\n',
    ''
)
text = text.replace(
    '            ("Options > Preferences", True),\n',
    ''
)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 8) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_product_cleanup_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "def clear_all_selections",
    "def _confirm_export_order",
    "Build Export Order",
    "Clear All Selections",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Menu cleaned")
print("- Refresh Order renamed to Build Export Order")
print("- Clear All Selections added")
print("- Export confirmation added")
