﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
TARGET = ROOT / "app" / "pdf" / "poster_exporter.py"

if not TARGET.exists():
    print(f"[ERROR] Not found: {TARGET}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = TARGET.with_name(f"poster_exporter.py.bak_poster_tiling_core_{timestamp}")
shutil.copy2(TARGET, backup)
print(f"[OK] Backup created: {backup}")

text = TARGET.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add math import
# ------------------------------------------------------------
if "import math" not in text:
    text = text.replace("from pathlib import Path\n", "from pathlib import Path\nimport math\n", 1)
    print("[OK] Added math import")
else:
    print("[SKIP] math import already exists")

# ------------------------------------------------------------
# 2) Add US Letter constants
# ------------------------------------------------------------
if "LETTER_WIDTH_PT" not in text:
    anchor = """A3_WIDTH_PT = 297 * MM_TO_PT
A3_HEIGHT_PT = 420 * MM_TO_PT
"""
    replacement = """A3_WIDTH_PT = 297 * MM_TO_PT
A3_HEIGHT_PT = 420 * MM_TO_PT

LETTER_WIDTH_PT = 8.5 * 72
LETTER_HEIGHT_PT = 11 * 72
"""
    if anchor in text:
        text = text.replace(anchor, replacement, 1)
        print("[OK] Added US Letter constants")
    else:
        print("[ERROR] Could not find A3 constants anchor")
        TARGET.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] US Letter constants already exist")

# ------------------------------------------------------------
# 3) Extend ExportOptions
# ------------------------------------------------------------
if "paper_size: str" not in text:
    old = """    overlap_mm: float = 5.0
    add_numbers: bool = True
    add_cut_guides: bool = True
    quality_scale: float = 2.5
"""
    new = """    overlap_mm: float = 5.0
    paper_size: str = "a4"
    poster_scale: float = 1.0
    add_numbers: bool = True
    add_cut_guides: bool = True
    quality_scale: float = 2.5
"""
    if old in text:
        text = text.replace(old, new, 1)
        print("[OK] Extended ExportOptions with paper_size/poster_scale")
    else:
        print("[ERROR] Could not patch ExportOptions")
        TARGET.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] ExportOptions already has paper_size")

# ------------------------------------------------------------
# 4) Patch _export_a3_split route to new poster tiling when needed
# ------------------------------------------------------------
old_start = """    def _export_a3_split(
        self,
        src_doc: fitz.Document,
        out_doc: fitz.Document,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        sheet_total = len(selections) * 2
"""
new_start = """    def _export_a3_split(
        self,
        src_doc: fitz.Document,
        out_doc: fitz.Document,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        # Keep legacy 2-sheet behavior for the current default A4 / 100% mode.
        # New poster tiling is activated by UI later when paper_size or poster_scale changes.
        paper_size = str(getattr(options, "paper_size", "a4") or "a4").lower()
        poster_scale = float(getattr(options, "poster_scale", 1.0) or 1.0)

        if paper_size != "a4" or abs(poster_scale - 1.0) > 0.000001:
            self._export_poster_tiling(src_doc, out_doc, selections, options)
            return

        sheet_total = len(selections) * 2
"""

if old_start in text and "_export_poster_tiling(src_doc" not in text:
    text = text.replace(old_start, new_start, 1)
    print("[OK] Patched _export_a3_split to route poster tiling")
else:
    print("[SKIP] _export_a3_split route already patched or anchor not found")

# ------------------------------------------------------------
# 5) Add poster tiling methods before _draw_cut_guides
# ------------------------------------------------------------
methods = r'''
    def _get_output_paper_size(self, options: ExportOptions) -> tuple[float, float]:
        paper_size = str(getattr(options, "paper_size", "a4") or "a4").lower()

        if paper_size in ("letter", "us_letter", "us letter"):
            return LETTER_WIDTH_PT, LETTER_HEIGHT_PT

        return A4_WIDTH_PT, A4_HEIGHT_PT

    def _get_poster_tiling_printable_rect(
        self,
        options: ExportOptions,
        page_width: float,
        page_height: float,
    ) -> fitz.Rect:
        margin = max(float(getattr(options, "safe_margin_mm", 5.0) or 0.0), 0.0) * MM_TO_PT

        # Keep a small minimum margin so cut guides and numbers remain visible.
        margin = max(margin, 3 * MM_TO_PT)

        return fitz.Rect(
            margin,
            margin,
            page_width - margin,
            page_height - margin,
        )

    def _make_poster_tiles(
        self,
        full_clip: fitz.Rect,
        options: ExportOptions,
        printable_rect: fitz.Rect,
    ) -> list[dict]:
        scale = max(float(getattr(options, "poster_scale", 1.0) or 1.0), 0.1)
        overlap_pt = 0.0

        if getattr(options, "output_mode", "") == "overlap":
            overlap_pt = max(float(getattr(options, "overlap_mm", 0.0) or 0.0), 0.0) * MM_TO_PT

        printable_w = max(printable_rect.width, 1.0)
        printable_h = max(printable_rect.height, 1.0)

        # In output coordinates, each sheet covers printable_w/h.
        # Convert back to source PDF coordinates by dividing by scale.
        source_tile_w = printable_w / scale
        source_tile_h = printable_h / scale

        source_step_w = max((printable_w - overlap_pt) / scale, source_tile_w * 0.25)
        source_step_h = max((printable_h - overlap_pt) / scale, source_tile_h * 0.25)

        cols = max(1, math.ceil(max(full_clip.width - source_tile_w, 0.0) / source_step_w) + 1)
        rows = max(1, math.ceil(max(full_clip.height - source_tile_h, 0.0) / source_step_h) + 1)

        tiles: list[dict] = []

        for row in range(rows):
            for col in range(cols):
                x0 = full_clip.x0 + col * source_step_w
                y0 = full_clip.y0 + row * source_step_h
                x1 = min(x0 + source_tile_w, full_clip.x1)
                y1 = min(y0 + source_tile_h, full_clip.y1)

                if x1 <= x0 or y1 <= y0:
                    continue

                clip = fitz.Rect(x0, y0, x1, y1)

                # Target size reflects true scale. Last row/column may not fill whole printable area.
                target_w = clip.width * scale
                target_h = clip.height * scale

                target_rect = fitz.Rect(
                    printable_rect.x0,
                    printable_rect.y0,
                    min(printable_rect.x0 + target_w, printable_rect.x1),
                    min(printable_rect.y0 + target_h, printable_rect.y1),
                )

                tiles.append(
                    {
                        "row": row,
                        "col": col,
                        "rows": rows,
                        "cols": cols,
                        "clip": clip,
                        "target_rect": target_rect,
                    }
                )

        return tiles

    def _export_poster_tiling(
        self,
        src_doc: fitz.Document,
        out_doc: fitz.Document,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
        paper_width, paper_height = self._get_output_paper_size(options)
        printable_rect = self._get_poster_tiling_printable_rect(
            options=options,
            page_width=paper_width,
            page_height=paper_height,
        )

        all_tiles: list[tuple[int, fitz.Page, dict]] = []

        for page_index in sorted(selections.keys()):
            if page_index < 0 or page_index >= len(src_doc):
                continue

            src_page = src_doc.load_page(page_index)
            full_clip = self._selection_to_rect(selections[page_index])

            if full_clip.width <= 0 or full_clip.height <= 0:
                continue

            tiles = self._make_poster_tiles(
                full_clip=full_clip,
                options=options,
                printable_rect=printable_rect,
            )

            for tile in tiles:
                all_tiles.append((page_index, src_page, tile))

        sheet_total = len(all_tiles)
        sheet_no = 1

        for page_index, src_page, tile in all_tiles:
            page = out_doc.new_page(width=paper_width, height=paper_height)

            page.show_pdf_page(
                tile["target_rect"],
                src_doc,
                page_index,
                clip=tile["clip"],
                keep_proportion=False,
            )

            if options.add_cut_guides:
                self._draw_poster_tiling_cut_guides(
                    page=page,
                    page_width=paper_width,
                    page_height=paper_height,
                    printable_rect=printable_rect,
                    tile=tile,
                    options=options,
                )

            if options.add_numbers:
                self._draw_poster_tiling_numbering(
                    page=page,
                    page_width=paper_width,
                    page_height=paper_height,
                    sheet_no=sheet_no,
                    sheet_total=sheet_total,
                    source_page=page_index + 1,
                    tile=tile,
                )

            sheet_no += 1

    def _draw_poster_tiling_cut_guides(
        self,
        page: fitz.Page,
        page_width: float,
        page_height: float,
        printable_rect: fitz.Rect,
        tile: dict,
        options: ExportOptions,
    ) -> None:
        color = (0.85, 0.0, 0.0)
        width = 0.6
        dash = "[3 3] 0"

        row = int(tile.get("row", 0))
        col = int(tile.get("col", 0))
        rows = int(tile.get("rows", 1))
        cols = int(tile.get("cols", 1))

        # Outer printable trim rectangle.
        page.draw_rect(
            printable_rect,
            color=color,
            width=width,
            dashes=dash,
        )

        label_margin = 5 * MM_TO_PT

        # Join guide lines only on sides that have neighboring sheets.
        if col > 0:
            x = printable_rect.x0
            page.draw_line(
                fitz.Point(x, printable_rect.y0),
                fitz.Point(x, printable_rect.y1),
                color=color,
                width=width,
                dashes=dash,
            )
            self._draw_cut_label(page, "JOIN LEFT", x + 3, label_margin, page_width)

        if col < cols - 1:
            x = printable_rect.x1
            page.draw_line(
                fitz.Point(x, printable_rect.y0),
                fitz.Point(x, printable_rect.y1),
                color=color,
                width=width,
                dashes=dash,
            )
            self._draw_cut_label(page, "JOIN RIGHT", x - 78, label_margin, page_width)

        if row > 0:
            y = printable_rect.y0
            page.draw_line(
                fitz.Point(printable_rect.x0, y),
                fitz.Point(printable_rect.x1, y),
                color=color,
                width=width,
                dashes=dash,
            )
            self._draw_cut_label(page, "JOIN TOP", label_margin, y + 2, page_width)

        if row < rows - 1:
            y = printable_rect.y1
            page.draw_line(
                fitz.Point(printable_rect.x0, y),
                fitz.Point(printable_rect.x1, y),
                color=color,
                width=width,
                dashes=dash,
            )
            self._draw_cut_label(page, "JOIN BOTTOM", label_margin, y - 10, page_width)

        # If overlap mode is active, draw an inner overlap reference line.
        if getattr(options, "output_mode", "") == "overlap":
            overlap_pt = max(float(getattr(options, "overlap_mm", 0.0) or 0.0), 0.0) * MM_TO_PT

            if overlap_pt > 0:
                guide_color = (1.0, 0.45, 0.0)

                if col > 0:
                    x = min(printable_rect.x0 + overlap_pt, printable_rect.x1)
                    page.draw_line(
                        fitz.Point(x, printable_rect.y0),
                        fitz.Point(x, printable_rect.y1),
                        color=guide_color,
                        width=0.5,
                        dashes="[2 2] 0",
                    )

                if row > 0:
                    y = min(printable_rect.y0 + overlap_pt, printable_rect.y1)
                    page.draw_line(
                        fitz.Point(printable_rect.x0, y),
                        fitz.Point(printable_rect.x1, y),
                        color=guide_color,
                        width=0.5,
                        dashes="[2 2] 0",
                    )

    def _draw_poster_tiling_numbering(
        self,
        page: fitz.Page,
        page_width: float,
        page_height: float,
        sheet_no: int,
        sheet_total: int,
        source_page: int,
        tile: dict,
    ) -> None:
        row = int(tile.get("row", 0))
        col = int(tile.get("col", 0))
        rows = int(tile.get("rows", 1))
        cols = int(tile.get("cols", 1))

        text = (
            f"Sheet {sheet_no}/{sheet_total}  "
            f"Source Page {source_page}  "
            f"Tile R{row + 1}C{col + 1} / {rows}x{cols}"
        )

        rect = fitz.Rect(
            8 * MM_TO_PT,
            page_height - 12 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            page_height - 5 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=8,
            fontname="helv",
            color=(0.1, 0.1, 0.1),
            align=fitz.TEXT_ALIGN_RIGHT,
        )

'''

if "def _export_poster_tiling" not in text:
    marker = "    def _draw_cut_guides(\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find _draw_cut_guides insertion point")
        TARGET.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + methods + "\n" + text[pos:]
    print("[OK] Added poster tiling methods")
else:
    print("[SKIP] Poster tiling methods already exist")

TARGET.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 6) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(TARGET)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = TARGET.with_name(f"poster_exporter.py.failed_poster_tiling_core_{timestamp}")
    shutil.copy2(TARGET, failed)
    shutil.copy2(backup, TARGET)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = TARGET.read_text(encoding="utf-8", errors="replace")
required = [
    "LETTER_WIDTH_PT",
    "paper_size: str",
    "poster_scale: float",
    "def _export_poster_tiling",
    "def _draw_poster_tiling_cut_guides",
    "def _make_poster_tiles",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, TARGET)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- PosterExporter now supports internal paper_size/poster_scale tiling core")
print("- Default A4 / 100% keeps legacy 2-sheet behavior")
print("- UI wiring will be added in the next step")
