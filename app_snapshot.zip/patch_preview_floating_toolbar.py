﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_preview_floating_toolbar_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Import QFrame if missing
# ------------------------------------------------------------
if "QFrame" not in text:
    if "    QToolBar,\n" in text:
        text = text.replace(
            "    QToolBar,\n",
            "    QToolBar,\n    QFrame,\n",
            1
        )
        print("[OK] Added QFrame import")
    elif "    QWidget,\n" in text:
        text = text.replace(
            "    QWidget,\n",
            "    QWidget,\n    QFrame,\n",
            1
        )
        print("[OK] Added QFrame import by fallback")
    else:
        print("[WARN] Could not find import anchor for QFrame")
else:
    print("[SKIP] QFrame already imported")

# ------------------------------------------------------------
# 2) Add floating toolbar creation after View buttons are created
# ------------------------------------------------------------
old = '''        apply_all_button = QPushButton("Apply Selection to All Pages")
        apply_all_button.clicked.connect(self.apply_selection_to_all_pages)

        export_button = QPushButton("Create PDF")
'''

new = '''        apply_all_button = QPushButton("Apply Selection to All Pages")
        apply_all_button.clicked.connect(self.apply_selection_to_all_pages)

        # Floating toolbar over the preview area for frequent view controls.
        self.preview_floating_toolbar = QFrame(self.preview_scroll)
        self.preview_floating_toolbar.setObjectName("previewFloatingToolbar")
        self.preview_floating_toolbar.setStyleSheet("""
            QFrame#previewFloatingToolbar {
                background-color: rgba(255, 248, 240, 230);
                border: 1px solid #EADBC8;
                border-radius: 8px;
            }
            QFrame#previewFloatingToolbar QPushButton {
                color: #395B64;
                background-color: #EAF7F7;
                border: 1px solid #BFE8E8;
                border-radius: 5px;
                padding: 4px 7px;
                font-weight: 700;
                min-width: 34px;
            }
            QFrame#previewFloatingToolbar QPushButton:hover {
                background-color: #DDF3F5;
                border: 1px solid #9EDDE2;
            }
            QFrame#previewFloatingToolbar QPushButton:pressed {
                background-color: #CDECEF;
            }
        """)

        floating_layout = QHBoxLayout(self.preview_floating_toolbar)
        floating_layout.setContentsMargins(6, 5, 6, 5)
        floating_layout.setSpacing(4)

        floating_zoom_out_button = QPushButton("−")
        floating_zoom_out_button.setToolTip("Zoom Out")
        floating_zoom_out_button.clicked.connect(self.zoom_out)

        floating_zoom_in_button = QPushButton("+")
        floating_zoom_in_button.setToolTip("Zoom In")
        floating_zoom_in_button.clicked.connect(self.zoom_in)

        floating_fit_button = QPushButton("Fit")
        floating_fit_button.setToolTip("Fit Page")
        floating_fit_button.clicked.connect(self.fit_page)

        floating_actual_button = QPushButton("1:1")
        floating_actual_button.setToolTip("Actual Size")
        floating_actual_button.clicked.connect(self.actual_size)

        floating_rotate_left_button = QPushButton("⟲")
        floating_rotate_left_button.setToolTip("Rotate Left")
        floating_rotate_left_button.clicked.connect(self.rotate_left)

        floating_rotate_right_button = QPushButton("⟳")
        floating_rotate_right_button.setToolTip("Rotate Right")
        floating_rotate_right_button.clicked.connect(self.rotate_right)

        floating_reset_button = QPushButton("Reset")
        floating_reset_button.setToolTip("Reset Rotation")
        floating_reset_button.clicked.connect(self.reset_rotation)

        floating_layout.addWidget(floating_zoom_out_button)
        floating_layout.addWidget(floating_zoom_in_button)
        floating_layout.addWidget(floating_fit_button)
        floating_layout.addWidget(floating_actual_button)
        floating_layout.addWidget(floating_rotate_left_button)
        floating_layout.addWidget(floating_rotate_right_button)
        floating_layout.addWidget(floating_reset_button)

        self.preview_floating_toolbar.adjustSize()
        self.preview_floating_toolbar.move(12, 12)
        self.preview_floating_toolbar.raise_()
        self.preview_floating_toolbar.show()

        export_button = QPushButton("Create PDF")
'''

if old in text and "previewFloatingToolbar" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added preview floating toolbar")
else:
    if "previewFloatingToolbar" in text:
        print("[SKIP] Preview floating toolbar already exists")
    else:
        print("[ERROR] Could not find insertion point for floating toolbar")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 3) Add helper method to keep toolbar visible/raised
# ------------------------------------------------------------
method = r'''
    def _refresh_preview_floating_toolbar(self) -> None:
        if not hasattr(self, "preview_floating_toolbar"):
            return

        self.preview_floating_toolbar.adjustSize()
        self.preview_floating_toolbar.move(12, 12)
        self.preview_floating_toolbar.raise_()
        self.preview_floating_toolbar.show()

'''

if "def _refresh_preview_floating_toolbar" not in text:
    marker = "    def update_output_area_states(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        marker = "    def update_export_option_states(self) -> None:\n"
        pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find insertion point for helper method")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added _refresh_preview_floating_toolbar")
else:
    print("[SKIP] Floating toolbar helper already exists")

# ------------------------------------------------------------
# 4) Call helper after render if possible
# ------------------------------------------------------------
old = '''            self.update_poster_sheet_estimate()
            self._log(
'''

new = '''            self.update_poster_sheet_estimate()
            self._refresh_preview_floating_toolbar()
            self._log(
'''

if old in text and "self._refresh_preview_floating_toolbar()" not in text[text.find("def _render_current_page"):text.find("def _update_page_buttons")]:
    text = text.replace(old, new, 1)
    print("[OK] Floating toolbar refreshed after render")
else:
    print("[SKIP] Render refresh already present or anchor not found")

# Call after central UI creation.
old = '''        self.update_export_option_states()
        self.update_output_area_states()
'''

new = '''        self.update_export_option_states()
        self.update_output_area_states()
        self._refresh_preview_floating_toolbar()
'''

if old in text and "self._refresh_preview_floating_toolbar()" not in text[text.find("def _create_central_ui"):text.find("def _refresh_preview_floating_toolbar") if "def _refresh_preview_floating_toolbar" in text else text.find("def update_export_option_states")]:
    text = text.replace(old, new, 1)
    print("[OK] Floating toolbar refreshed after UI creation")
else:
    print("[SKIP] UI creation refresh already present or anchor not found")

# ------------------------------------------------------------
# 5) Release Notes update
# ------------------------------------------------------------
if "Preview floating toolbar" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Preview floating toolbar</b>: Zoom, Fit, Actual Size, and Rotate controls are now available directly over the preview.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for preview floating toolbar")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 6) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_preview_floating_toolbar_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "previewFloatingToolbar",
    "def _refresh_preview_floating_toolbar",
    "Preview floating toolbar",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Preview floating toolbar added")
print("- View controls are now available directly over the preview")
