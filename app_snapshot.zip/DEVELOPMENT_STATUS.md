# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.7.2

## Current Phase
Qt Print Dialog

## Implemented
- Print with PyQt6 QPrintDialog
- Internal PDF rendering for print
- Default print DPI: 300
- Printer selection dialog
- Manual print fallback by opening PDF
- Existing Export PDF workflow preserved

## Print Quality
- PDF pages are rendered at printer DPI.
- Default is 300 DPI for good document quality.
- Higher DPI can improve quality but increases memory and print time.

## Security Policy
- No security bypass
- No privilege elevation
- User must confirm print through print dialog
- Uses normal Windows printer infrastructure