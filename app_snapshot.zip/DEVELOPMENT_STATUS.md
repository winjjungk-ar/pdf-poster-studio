# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.3.0

## Current Phase
Selection Tool Foundation

## Implemented
- SQLite initialization at startup
- PyMuPDF renderer module
- PDF open function
- PDF preview rendering
- Page count display
- Previous/Next page navigation
- Fit Page / Actual Size
- Mouse drag selection rectangle
- Red selection overlay
- Selection coordinate display
- Per-page selection storage
- Clear Selection
- Apply Selection to All Pages
- Render diagnostics log

## Last Patch
Version 0.3.0:
- Added PdfPreviewWidget.
- Added mouse-based rectangle selection.
- Added selection storage per page.
- Added Apply Selection to All Pages.

## Known Limitation
- Selection coordinates are currently based on displayed preview pixels.
- PDF coordinate conversion will be implemented in version 0.4.0.

## Next Patch Plan
Version 0.4.0:
- Convert preview selection to PDF coordinates.
- Add A4 to A3 split export.
- Add Left-Right / Top-Bottom layout.
- Add sheet numbering overlay.