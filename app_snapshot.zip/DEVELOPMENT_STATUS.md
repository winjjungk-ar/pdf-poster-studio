# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.3

## Current Phase
Preview Zoom Improvement

## Implemented
- PDF preview rendering
- Larger preview area
- Reduced Basic Settings panel width
- Mouse drag selection rectangle
- Per-page selection storage
- A4 two-sheet split export
- Left-Right split layout
- Top-Bottom split layout
- No-Cut / Overlap / True Size export mode
- Sheet numbering overlay
- High quality export rendering
- Preview Zoom In
- Preview Zoom Out
- Fit Page
- Actual Size
- Zoom ratio display

## Last Patch
Version 0.4.3:
- Added Preview Zoom In / Zoom Out.
- Added zoom buttons to Basic Settings.
- Added View menu zoom actions.
- Added zoom ratio label.
- Improved selection usability by allowing enlarged preview before selecting.

## Known Limitation
- Existing selection rectangles are display-coordinate based. For best accuracy, zoom first and then select the area.
- Project save/load is not implemented yet.

## Next Patch Plan
Version 0.5.0:
- Add cut guide lines.
- Add overlap guide marks.
- Add project save/load.
- Add recent projects.