# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.8

## Current Phase
Selection Only Clean Output

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Rotation controls
- A3 Split Mode
- Selection Only Mode
- Selection Fit Mode
  - Fit Width
  - Fit Whole Area
  - Fill Page Crop
  - Fit Height
- Page Orientation
  - Auto
  - Portrait
  - Landscape
- A4 two-sheet split export
- Cut guide lines for A3 Split Mode
- Sheet numbering overlay for A3 Split Mode
- Clean Selection Only output without numbering or cut guides

## Last Patch
Version 0.4.8:
- Selection Only Mode now ignores Add sheet numbers.
- Selection Only Mode now ignores Add cut guide lines.
- Removed Selection Only border/numbering output for clean single-page export.

## Product Positioning
This application is a PDF print/export helper, not a full PDF editor.

## Known Limitation
- Fill Page Crop may crop part of the selected area.
- Project save/load is not implemented yet.