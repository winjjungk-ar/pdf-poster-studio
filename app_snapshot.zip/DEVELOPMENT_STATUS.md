# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.5.0

## Current Phase
Project Save Load and Recent Projects

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Rotation controls
- A3 Split Mode
- Selection Only Mode
- Selection Fit Mode
- Page Orientation
- Cut guide lines for A3 Split Mode
- Clean Selection Only output
- Project save
- Project save as
- Project open
- Recent projects menu
- Recent projects limit 5
- Exit save confirmation

## Last Patch
Version 0.5.0:
- Added .a4a3proj project file save/load.
- Added recent projects management.
- Added File > Recent Projects menu.
- Added exit save confirmation.

## Project File
- Extension: .a4a3proj
- Format: JSON UTF-8
- Stores PDF path, selections, export settings, zoom, and rotation.

## Not Included
- EXE build. This is intentionally postponed.

## Known Limitation
- If the original PDF path changes, the project cannot automatically find it yet.
- Build/deploy GUI is not implemented yet.