# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.6.0

## Current Phase
Export Quality and UI Grouping

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Rotation controls
- A3 Split Mode
- Selection Only Mode
- Selection Fit Mode
- Page Orientation
- Export Quality selector
  - Standard
  - High
  - Very High
- UI group boxes
  - Project / View
  - Export
  - A3 Split Options
  - Selection Only Options
- Project save/load
- Recent projects menu
- Clean Selection Only output
- Cut guide lines for A3 Split Mode

## Last Patch
Version 0.6.0:
- Added Export Quality selector.
- Added UI group boxes.
- Improved settings panel readability.
- Saved export quality in project files.

## Not Included
- EXE build. This is intentionally postponed.

## Known Limitation
- Very High quality may increase PDF size and export time.
- If original PDF path changes, project recovery is not automatic yet.