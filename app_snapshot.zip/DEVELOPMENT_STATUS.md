# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.2

## Current Phase
Preview and Export Quality Improvement

## Implemented
- SQLite initialization at startup
- PyMuPDF renderer module
- PDF open function
- Larger PDF preview area
- Reduced Basic Settings panel width
- Higher preview render zoom
- Mouse drag selection rectangle
- Per-page selection storage
- A4 two-sheet split export
- Left-Right split layout
- Top-Bottom split layout
- No-Cut / Overlap / True Size export mode
- Sheet numbering overlay
- High quality export rendering
- Multi-page selected export

## Last Patch
Version 0.4.2:
- Enlarged preview area.
- Reduced Basic Settings panel width.
- Increased preview render zoom from 1.5 to 2.5.
- Increased export raster quality using quality_scale 2.5.
- Added basic overlap clip extension.

## Known Limitation
- Higher export quality increases output PDF file size.
- Project save/load is not implemented yet.

## Next Patch Plan
Version 0.5.0:
- Add cut guide lines.
- Add overlap guide marks.
- Add project save/load.
- Add recent projects.