# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.6.4

## Current Phase
Page Check and Batch Output

## Implemented
- PDF preview rendering
- Page navigation
- Page jump
- Per-page selection
- Per-page export checkbox
- Checked pages counter
- A3 Split Mode
- Selection Only Mode
- Batch Output
  - Single PDF
  - Separate PDF per checked page
- Project save/load includes checked pages
- Recent projects
- Tab-based settings UI

## Last Patch
Version 0.6.4:
- Added per-page export checkbox.
- Added checked pages list.
- Added batch output mode.
- Added separate PDF per checked page export.
- Applied to both A3 Split Mode and Selection Only Mode.

## Notes
- A page is automatically checked when a valid selection is made.
- Clearing selection unchecks the current page.
- Separate output creates files with suffix `_page_001`, `_page_002`, etc.