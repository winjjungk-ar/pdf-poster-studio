# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.7.0

## Current Phase
Undo Redo and Last Exported PDF

## Implemented
- Undo
- Redo
- Last exported PDF tracking
- Open Last Exported PDF
- Print menu opens last exported PDF for manual printing
- Project save/load includes last exported PDF path
- Existing A3 Split and Selection Only export preserved

## Undo / Redo Scope
- Selection rectangles
- Checked pages
- Current page
- Rotation
- Preview zoom
- Export settings
- A3 Split settings
- Selection Only settings

## Notes
- Direct printer control is not implemented yet.
- Print workflow is currently: Export PDF -> Open PDF -> Print from viewer.