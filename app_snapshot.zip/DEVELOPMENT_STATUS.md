# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.7.1

## Current Phase
Keyboard Shortcuts and Direct Print

## Implemented
- Undo shortcut: Ctrl+Z
- Redo shortcut: Ctrl+Y
- Redo alternative shortcut: Ctrl+Shift+Z
- Open PDF shortcut: Ctrl+O
- Export PDF shortcut: Ctrl+E
- Open Last Exported PDF shortcut: Ctrl+L
- Print shortcut: Ctrl+P
- Direct print through Windows default PDF print handler
- Manual print fallback by opening the exported PDF

## Print Policy
Direct print uses Windows default PDF viewer and printer settings.
No security bypass, no privilege elevation, and no hidden execution are used.

## Notes
- Direct print requires a default PDF viewer that supports the Windows print verb.
- If direct print does not work, use Open Last Exported PDF and print manually.