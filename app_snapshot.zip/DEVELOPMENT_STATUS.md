# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.1.0

## Current Phase
Initial Skeleton

## Implemented
- Project folder structure
- PyQt6 main window
- Commercial-style menu order
  - File
  - Edit
  - View
  - Options
  - Help
  - About
- Basic settings panel
- Log dock panel
- PDF open placeholder
- Export placeholder
- SQLite schema
- Build script placeholder
- Release ZIP script placeholder
- Patch history file

## Not Implemented Yet
- PDF preview rendering
- Selection rectangle
- Multi-page processing
- A4 to A3 split export
- No-Cut Mode
- Overlap Mode
- True Size Mode
- Sheet numbering
- Project save/load
- Recent projects
- Backup/restore/patch GUI
- Build/deploy GUI

## Next Patch Plan
Version 0.2.0:
- Initialize SQLite at startup
- Add PDF preview rendering with PyMuPDF
- Add PDF page count display
- Add page navigation controls

## Development Rules
- Patch-first workflow
- Automatic backup before patch
- py_compile check after patch
- Update patch_history.json
- Update DEVELOPMENT_STATUS.md
- UTF-8 files
- Relative paths
- Windows Korean/Japanese font consideration
- No security bypass