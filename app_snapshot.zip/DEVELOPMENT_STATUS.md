# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.2.2

## Current Phase
Forced PDF Preview Repair

## Implemented
- SQLite initialization at startup
- PyMuPDF renderer module
- PDF open function
- PDF preview rendering
- Page count display
- Previous/Next page navigation
- Fit Page / Actual Size
- Render diagnostics log

## Last Patch
Version 0.2.2:
- Re-created missing pdf_renderer.py.
- Replaced main.py with DB initialization version.
- Replaced main_window.py with PDF preview version.

## Next Patch Plan
Version 0.3.0:
- Mouse selection rectangle.
- Selection coordinate display.
- Selection storage per page.