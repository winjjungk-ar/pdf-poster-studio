# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.0

## Current Phase
A4 to A3 Split PDF Export

## Implemented
- SQLite initialization at startup
- PyMuPDF renderer module
- PDF open function
- PDF preview rendering
- Page count display
- Previous/Next page navigation
- Fit Page / Actual Size
- Mouse drag selection rectangle
- Red selection overlay
- Selection coordinate display
- Per-page selection storage
- Clear Selection
- Apply Selection to All Pages
- Preview selection to PDF coordinate conversion
- A3-size rendering from selected PDF area
- A4 two-sheet split export
- Left-Right split layout
- Top-Bottom split layout
- No-Cut / Overlap / True Size export mode
- Sheet numbering overlay
- Multi-page selected export

## Last Patch
Version 0.4.0:
- Added PosterExporter.
- Added split-print PDF export.
- Added output mode and split layout UI.
- Added sheet numbering.

## Known Limitation
- No-Cut mode uses 96% scale.
- Overlap mode currently uses reduced margin but does not yet add visual cut/overlap guide lines.
- Project save/load is not implemented yet.

## Next Patch Plan
Version 0.5.0:
- Add cut guide lines.
- Add overlap guide marks.
- Add project save/load.
- Add recent projects.