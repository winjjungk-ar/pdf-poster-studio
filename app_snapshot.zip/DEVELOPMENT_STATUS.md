# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.6.5

## Current Phase
Visible Page Checklist

## Implemented
- PDF preview rendering
- Page navigation
- Page jump
- Per-page selection
- Per-page export checkbox
- Visible page checklist in Status tab
- Checked pages counter
- A3 Split Mode
- Selection Only Mode
- Batch Output
  - Single PDF
  - Separate PDF per checked page
- Project save/load includes checked pages
- Recent projects
- Tab-based settings UI

## Last Patch
Version 0.6.5:
- Added visible page checklist.
- Added page status text: Selected / No selection.
- Added current page marker.
- Added click-to-jump from page list.
- Added check/uncheck control from page list.

## Notes
- Pages without selection cannot be checked.
- Selecting an area automatically checks that page.
- Clearing a selection unchecks that page.