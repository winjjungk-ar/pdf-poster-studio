# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.6.7

## Current Phase
Auto Select Sensitivity and All Pages

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Fixed heavy zoom-out selection coordinate issue
- Auto Select Current Page
- Auto Select All Pages
- Auto Select Sensitivity
  - Strict
  - Normal
  - Sensitive
- Per-page export checklist
- A3 Split Mode
- Selection Only Mode
- Batch Output
- Project save/load includes auto select sensitivity

## Last Patch
Version 0.6.7:
- Added Auto Select Sensitivity.
- Added Auto Select All Pages.
- Auto selection can now process all pages and check them for export.

## Notes
- Strict: fewer false detections.
- Normal: recommended default.
- Sensitive: detects light gray content but may include more background noise.