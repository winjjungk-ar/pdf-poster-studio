# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.7.4

## Current Phase
Print Quality and Workspace Improvements

## Implemented
- Print Quality selector
  - Fast 150 DPI
  - Standard 300 DPI
  - High 600 DPI
- Default print quality: Standard 300 DPI
- Print uses selected DPI before creating print job
- Selection rectangle is adjusted when the preview is resized or fullscreen is used
- Log panel is hidden by default to maximize workspace
- Log panel can still be shown from View > Show Log Panel

## Notes
- 600 DPI improves print sharpness but may increase memory usage and print time.
- 300 DPI remains recommended for normal office documents.
- Log is still available for diagnostics but no longer occupies space by default.