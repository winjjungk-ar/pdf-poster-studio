# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.5

## Current Phase
Export Type and Cut Guide Support

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Rotation controls
- A3 Split Mode
- Selection Only Mode
- A4 two-sheet split export
- Left-Right split layout
- Top-Bottom split layout
- No-Cut / Overlap / True Size export mode
- Sheet numbering overlay
- Cut guide lines for A3 Split Mode
- High quality export rendering

## Last Patch
Version 0.4.5:
- Added Export Type selection.
- Added Selection Only Mode.
- Added Add Cut Guide Lines option.
- Added dotted cut/join guide lines for A3 Split Mode.

## Product Positioning
This application is still a PDF print/export helper, not a full PDF editor.
It creates output PDFs from selected areas but does not edit original PDF contents.

## Known Limitation
- Selection Only Mode exports selected area fitted to A4.
- Cut guide lines are basic dotted guide lines.
- Project save/load is not implemented yet.

## Next Patch Plan
Version 0.5.0:
- Project save/load.
- Recent projects.
- Better guide line options.
- Export quality selector.