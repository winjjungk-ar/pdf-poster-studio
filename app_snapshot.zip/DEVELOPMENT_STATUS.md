# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.5.1

## Current Phase
Export Option UI Cleanup

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Rotation controls
- A3 Split Mode
- Selection Only Mode
- Selection Fit Mode
- Page Orientation
- Cut guide lines for A3 Split Mode
- Clean Selection Only output
- Project save
- Project save as
- Project open
- Recent projects menu
- Recent projects limit 5
- Exit save confirmation
- Export Type dependent UI enable/disable

## Last Patch
Version 0.5.1:
- Disabled Selection Fit Mode and Page Orientation in A3 Split Mode.
- Disabled Output Mode, Split Layout, Add sheet numbers, and Add cut guide lines in Selection Only Mode.
- Added automatic UI state refresh when Export Type changes.

## Not Included
- EXE build. This is intentionally postponed.

## Next Patch Plan
Version 0.6.0:
- Add Export Quality selector.
- Add better UI grouping.
- Add project path recovery helper.