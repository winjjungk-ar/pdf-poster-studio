# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.7

## Current Phase
Selection Only Fit Mode and Auto Orientation

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Rotation controls
- A3 Split Mode
- Selection Only Mode
- Selection Fit Mode
  - Fit Width
  - Fit Whole Area
  - Fill Page Crop
  - Fit Height
- Page Orientation
  - Auto
  - Portrait
  - Landscape
- A4 two-sheet split export
- Cut guide lines for A3 Split Mode
- Sheet numbering overlay
- High quality export rendering

## Last Patch
Version 0.4.7:
- Added Selection Fit Mode.
- Added Page Orientation.
- Improved Selection Only Mode to reduce unnecessary margins.
- Added auto portrait/landscape page selection.

## Recommended Settings
For Selection Only Mode:
- Selection Fit Mode: Fit Width
- Page Orientation: Auto

## Product Positioning
This application is a PDF print/export helper, not a full PDF editor.

## Known Limitation
- Fill Page Crop may crop part of the selected area.
- Project save/load is not implemented yet.