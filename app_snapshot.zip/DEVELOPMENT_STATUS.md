# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.6.6

## Current Phase
Zoom Selection Fix and Auto Content Selection

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Fixed heavy zoom-out selection coordinate issue
- Auto Select Content
- Per-page export checklist
- A3 Split Mode
- Selection Only Mode
- Batch Output
- Project save/load
- Tab-based settings UI

## Last Patch
Version 0.6.6:
- Fixed selection problems after repeated Zoom Out.
- Preview widget now matches displayed pixmap size exactly.
- Added Auto Select Content button and menu action.
- Auto selection detects non-white content area and marks the page for export.

## Notes
- Auto Select Content works best on documents with white margins and dark text/graphics.
- Very light gray content may require manual selection.