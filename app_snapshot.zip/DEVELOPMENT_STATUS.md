# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.4

## Current Phase
Mouse Wheel Zoom and Rotation

## Implemented
- PDF preview rendering
- Larger preview area
- Mouse drag selection rectangle
- Mouse wheel zoom
- Zoom In / Zoom Out buttons
- View menu zoom actions
- Rotate Left
- Rotate Right
- Reset Rotation
- Rotation-aware selection coordinate conversion
- A4 two-sheet split export
- Left-Right split layout
- Top-Bottom split layout
- No-Cut / Overlap / True Size export mode
- Sheet numbering overlay
- High quality export rendering

## Last Patch
Version 0.4.4:
- Added mouse wheel zoom on preview.
- Added rotation controls.
- Added rotation status display.
- Added coordinate conversion support for 0/90/180/270 degree rotation.

## Known Limitation
- If selection looks shifted after rotation, clear selection and select again after rotation.
- Project save/load is not implemented yet.

## Next Patch Plan
Version 0.5.0:
- Add cut guide lines.
- Add overlap guide marks.
- Add project save/load.
- Add recent projects.