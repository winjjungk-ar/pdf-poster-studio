# Development Status

## Project
A4 to A3 Poster Print Studio

## Creator
JI JEONG GEUN

## Current Version
0.4.6

## Current Phase
Selection Only Export Fix

## Implemented
- PDF preview rendering
- Mouse drag selection rectangle
- Mouse wheel zoom
- Rotation controls
- A3 Split Mode
- Selection Only Mode
- A4 two-sheet split export
- Cut guide lines for A3 Split Mode
- Sheet numbering overlay
- High quality export rendering
- Selection Only vector-based export

## Last Patch
Version 0.4.6:
- Fixed Selection Only Mode where only the center area could appear.
- Changed Selection Only export from raster image insertion to vector PDF placement.
- Added a light border around the Selection Only output area.

## Product Positioning
This application is a PDF print/export helper, not a full PDF editor.
It creates output PDFs from selected areas without modifying the original PDF.

## Known Limitation
- A3 Split Mode still uses raster rendering.
- Project save/load is not implemented yet.

## Next Patch Plan
Version 0.4.7 or 0.5.0:
- Improve A3 Split Mode quality using vector-based page placement.
- Add project save/load.
- Add recent projects.