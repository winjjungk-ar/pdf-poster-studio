﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_welcome_icon_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Imports
# ------------------------------------------------------------
if "QTimer" not in text:
    text = text.replace(
        "from PyQt6.QtCore import Qt, QRect\n",
        "from PyQt6.QtCore import Qt, QRect, QTimer\n",
        1
    )
    print("[OK] Added QTimer import")
else:
    print("[SKIP] QTimer already imported")

if "QIcon" not in text:
    text = text.replace(
        "from PyQt6.QtGui import QPixmap, QTransform, QKeySequence, QAction, QImage, QPainter\n",
        "from PyQt6.QtGui import QPixmap, QTransform, QKeySequence, QAction, QImage, QPainter, QIcon, QColor, QPen, QBrush, QFont\n",
        1
    )
    print("[OK] Added icon drawing imports")
else:
    print("[SKIP] QIcon already imported")

# Widgets imports
widget_imports = []
if "QDialog" not in text:
    widget_imports.append("    QDialog,\n")
if "QDialogButtonBox" not in text:
    widget_imports.append("    QDialogButtonBox,\n")

if widget_imports:
    text = text.replace(
        "    QAbstractItemView,\n",
        "    QAbstractItemView,\n" + "".join(widget_imports),
        1
    )
    print("[OK] Added welcome dialog widget imports")
else:
    print("[SKIP] Welcome dialog widget imports already present")

# ------------------------------------------------------------
# 2) Add methods before _create_quick_toolbar
# ------------------------------------------------------------
methods = r'''
    def _create_app_icon(self) -> QIcon:
        pixmap = QPixmap(64, 64)
        pixmap.fill(QColor("#00000000"))

        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Pastel background circle
        painter.setBrush(QBrush(QColor("#DDF3F5")))
        painter.setPen(QPen(QColor("#8CCFD6"), 2))
        painter.drawEllipse(3, 3, 58, 58)

        # Paper
        painter.setBrush(QBrush(QColor("#FFFFFF")))
        painter.setPen(QPen(QColor("#6C8EA4"), 2))
        painter.drawRoundedRect(17, 10, 30, 42, 4, 4)

        # Fold corner
        painter.setBrush(QBrush(QColor("#EAF7FF")))
        painter.setPen(QPen(QColor("#6C8EA4"), 1))
        painter.drawPolygon(
            [
                pixmap.rect().topLeft() + pixmap.rect().topLeft(),
            ]
        )

        # Poster split guide
        painter.setPen(QPen(QColor("#9BB7FF"), 2))
        painter.drawLine(32, 16, 32, 47)
        painter.drawLine(21, 31, 43, 31)

        # Selection rectangle
        painter.setBrush(QBrush(QColor(255, 214, 165, 90)))
        painter.setPen(QPen(QColor("#FF9F68"), 2))
        painter.drawRoundedRect(22, 20, 20, 18, 3, 3)

        # Small PDF label
        painter.setFont(QFont("Segoe UI", 7, QFont.Weight.Bold))
        painter.setPen(QColor("#4F6F8F"))
        painter.drawText(20, 50, "PDF")

        painter.end()
        return QIcon(pixmap)

    def _show_welcome_dialog(self) -> None:
        if hasattr(self, "workspace_items") and self.workspace_items:
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Welcome to PDF Poster Studio")
        dialog.setModal(True)
        dialog.setMinimumWidth(520)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(26, 24, 26, 24)
        layout.setSpacing(14)

        dialog.setStyleSheet("""
            QDialog {
                background-color: #FFF8F0;
            }
            QLabel#welcomeTitle {
                color: #395B64;
                font-size: 22px;
                font-weight: 800;
            }
            QLabel#welcomeSubtitle {
                color: #4F6F8F;
                font-size: 13px;
                line-height: 1.4;
            }
            QLabel#welcomeSteps {
                color: #395B64;
                background-color: #EAF7F7;
                border: 1px solid #BFE8E8;
                border-radius: 10px;
                padding: 14px;
                font-size: 13px;
            }
            QPushButton#openPdfsButton {
                color: white;
                background-color: #6AA6FF;
                border: 1px solid #4C8FE8;
                border-radius: 8px;
                padding: 10px 18px;
                font-size: 15px;
                font-weight: 800;
            }
            QPushButton#openPdfsButton:hover {
                background-color: #5A98F0;
            }
            QPushButton#closeWelcomeButton {
                color: #395B64;
                background-color: #F6E7CB;
                border: 1px solid #E4CFA8;
                border-radius: 8px;
                padding: 9px 16px;
                font-weight: 700;
            }
            QPushButton#closeWelcomeButton:hover {
                background-color: #EFDDBA;
            }
        """)

        title = QLabel("PDF Poster Studio")
        title.setObjectName("welcomeTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel(
            "Open one or more PDFs, select the area you want, arrange the page order, "
            "then export a print-ready PDF."
        )
        subtitle.setObjectName("welcomeSubtitle")
        subtitle.setWordWrap(True)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        steps = QLabel(
            "1. Click “Open PDFs” and choose your PDF files.\n"
            "2. Use “Auto Select Current Page” or “Auto Select All Pages”.\n"
            "3. Press “Refresh Order” and arrange the selected pages.\n"
            "4. Click “Export PDF” to create your final print file."
        )
        steps.setObjectName("welcomeSteps")
        steps.setWordWrap(True)
        layout.addWidget(steps)

        button_layout = QHBoxLayout()
        button_layout.addStretch()

        open_button = QPushButton("Open PDFs")
        open_button.setObjectName("openPdfsButton")

        close_button = QPushButton("Close")
        close_button.setObjectName("closeWelcomeButton")

        button_layout.addWidget(open_button)
        button_layout.addWidget(close_button)
        button_layout.addStretch()
        layout.addLayout(button_layout)

        def open_and_close() -> None:
            dialog.accept()
            self.open_pdfs()

        open_button.clicked.connect(open_and_close)
        close_button.clicked.connect(dialog.reject)

        dialog.exec()

'''

if "def _show_welcome_dialog" not in text:
    marker = "    def _create_quick_toolbar(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        marker = "    def _create_menus(self) -> None:\n"
        pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + methods + "\n" + text[pos:]
    print("[OK] Added app icon and welcome dialog methods")
else:
    print("[SKIP] Welcome dialog already exists")

# ------------------------------------------------------------
# 3) Patch __init__: title/icon/welcome popup
# ------------------------------------------------------------
old_title = '        self.setWindowTitle(f"{APP_NAME} v0.4.0")\n'
new_title = '        self.setWindowTitle("PDF Poster Studio - A4/A3 Print Workspace")\n        self.setWindowIcon(self._create_app_icon())\n'

if old_title in text and "PDF Poster Studio - A4/A3 Print Workspace" not in text:
    text = text.replace(old_title, new_title, 1)
    print("[OK] Updated window title and icon")
elif "PDF Poster Studio - A4/A3 Print Workspace" in text:
    print("[SKIP] Window title/icon already patched")
else:
    print("[WARN] Could not find old window title line")

old_tail = '''        self._log("Application started.")
        self._log("SQLite database initialized.")
        self._log("PDF preview module loaded.")
        self._log("Selection module loaded.")
        self._log("Poster export module loaded.")
'''

new_tail = '''        self._log("Application started.")
        self._log("SQLite database initialized.")
        self._log("PDF preview module loaded.")
        self._log("Selection module loaded.")
        self._log("Poster export module loaded.")

        QTimer.singleShot(350, self._show_welcome_dialog)
'''

if old_tail in text and "QTimer.singleShot(350, self._show_welcome_dialog)" not in text:
    text = text.replace(old_tail, new_tail, 1)
    print("[OK] Added startup welcome popup")
elif "QTimer.singleShot(350, self._show_welcome_dialog)" in text:
    print("[SKIP] Startup welcome popup already connected")
else:
    print("[WARN] Could not connect welcome popup")

# ------------------------------------------------------------
# 4) Fix unsafe polygon block if needed
# The earlier icon method includes a useless polygon from rect top-left. Replace with simple fold lines.
# ------------------------------------------------------------
bad_polygon = '''        painter.drawPolygon(
            [
                pixmap.rect().topLeft() + pixmap.rect().topLeft(),
            ]
        )
'''
good_fold = '''        painter.drawLine(39, 10, 47, 18)
        painter.drawLine(47, 18, 47, 19)
'''

if bad_polygon in text:
    text = text.replace(bad_polygon, good_fold, 1)
    print("[OK] Simplified icon fold drawing")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_welcome_icon_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

required = [
    "def _show_welcome_dialog",
    "def _create_app_icon",
    "QTimer.singleShot",
    "PDF Poster Studio - A4/A3 Print Workspace",
]

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Startup pastel welcome popup added")
print("- Open PDFs button added to popup")
print("- App identity updated to PDF Poster Studio")
print("- Program icon generated in code")
