﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN_PY = ROOT / "main.py"

if not MAIN_PY.exists():
    print(f"[ERROR] Not found: {MAIN_PY}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN_PY.with_name(f"main.py.bak_runtime_show_fix_{timestamp}")
shutil.copy2(MAIN_PY, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN_PY.read_text(encoding="utf-8", errors="replace")
original = text

old = '''def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("A4 to A3 Poster Print Studio")
    app.setOrganizationName("JI JEONG GEUN")

    try:
        initialize_database()
    except Exception as exc:
        QMessageBox.critical(
            None,
            "Database Error",
            f"Failed to initialize database.\\n\\n{exc}"
        )
        return 1

    window = MainWindow()
    window.show()

    return app.exec()
'''

new = '''def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("PDF Poster Studio")
    app.setOrganizationName("JI JEONG GEUN")
    app.setQuitOnLastWindowClosed(True)

    try:
        initialize_database()
    except Exception as exc:
        QMessageBox.critical(
            None,
            "Database Error",
            f"Failed to initialize database.\\n\\n{exc}"
        )
        return 1

    print("[INFO] Creating MainWindow...")
    window = MainWindow()

    # Keep a strong reference on QApplication as well.
    app.main_window = window

    print("[INFO] Showing MainWindow...")
    window.show()
    window.showMaximized()
    window.raise_()
    window.activateWindow()

    print("[INFO] Entering QApplication event loop...")
    exit_code = app.exec()
    print(f"[INFO] QApplication exited with code: {exit_code}")
    return exit_code
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched main.py runtime show logic")
else:
    print("[WARN] Exact main() block not found. Applying fallback.")

    if "window = MainWindow()\n    window.show()" in text:
        text = text.replace(
            "    window = MainWindow()\n    window.show()\n\n    return app.exec()\n",
            '''    print("[INFO] Creating MainWindow...")
    window = MainWindow()
    app.main_window = window

    print("[INFO] Showing MainWindow...")
    window.show()
    window.showMaximized()
    window.raise_()
    window.activateWindow()

    print("[INFO] Entering QApplication event loop...")
    exit_code = app.exec()
    print(f"[INFO] QApplication exited with code: {exit_code}")
    return exit_code
''',
            1
        )
        text = text.replace(
            'app.setApplicationName("A4 to A3 Poster Print Studio")',
            'app.setApplicationName("PDF Poster Studio")',
            1
        )
        print("[OK] Fallback patch applied")
    else:
        print("[ERROR] Could not patch main.py")
        MAIN_PY.write_text(original, encoding="utf-8")
        sys.exit(1)

MAIN_PY.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN_PY)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN_PY.with_name(f"main.py.failed_runtime_show_fix_{timestamp}")
    shutil.copy2(MAIN_PY, failed)
    shutil.copy2(backup, MAIN_PY)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done. Now run:")
print("python -u .\\main.py")
