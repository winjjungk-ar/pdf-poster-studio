﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_restore_output_files_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Restore/show batch output as "Output Files"
# ------------------------------------------------------------
text = text.replace('self.batch_output_label = QLabel("Batch Output")', 'self.batch_output_label = QLabel("Output Files")')
text = text.replace('self.batch_output_label.setVisible(False)', 'self.batch_output_label.setVisible(True)')
text = text.replace('self.batch_output_combo.setVisible(False)', 'self.batch_output_combo.setVisible(True)')

# Rename combo item display text.
text = text.replace('self.batch_output_combo.addItem("Single PDF", "single_pdf")',
                    'self.batch_output_combo.addItem("One PDF", "single_pdf")')
text = text.replace('self.batch_output_combo.addItem("Separate PDF per checked page", "separate_pdf_per_page")',
                    'self.batch_output_combo.addItem("Separate PDF per selected page", "separate_pdf_per_page")')

# If old QLabel direct block remains, change it too.
text = text.replace('QLabel("Batch Output")', 'QLabel("Output Files")')

# ------------------------------------------------------------
# 2) Remove forced single_pdf at export start
# ------------------------------------------------------------
forced_block = '''        # Batch output UI is hidden. Use one print-ready PDF by default.
        if hasattr(self, "batch_output_combo"):
            self._apply_combo_data(self.batch_output_combo, "single_pdf")

'''
if forced_block in text:
    text = text.replace(forced_block, "", 1)
    print("[OK] Removed forced single_pdf export behavior")
else:
    print("[SKIP] Forced single_pdf block not found")

# ------------------------------------------------------------
# 3) Add workspace separate export method
# ------------------------------------------------------------
method = r'''
    def _export_workspace_to_separate_pdfs(self, output_path: str, options: ExportOptions) -> list[str]:
        if not self.workspace_items:
            raise RuntimeError("Workspace is empty.")

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        export_order_entries = self._get_export_order_entries()

        if not export_order_entries:
            for workspace_index, item in enumerate(self.workspace_items):
                checked_pages = sorted(list(item.get("checked_pages", set())))
                for page_index in checked_pages:
                    export_order_entries.append((workspace_index, page_index))

        if not export_order_entries:
            raise RuntimeError("No pages are checked for export.")

        base_path = Path(output_path)
        output_files: list[str] = []
        exporter = PosterExporter()

        for order_index, entry in enumerate(export_order_entries, 1):
            workspace_index, page_index = entry

            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                continue

            item = self.workspace_items[workspace_index]
            pdf_path = item.get("pdf_path")
            selections_qrect = item.get("page_selections", {})
            checked_pages = set(item.get("checked_pages", set()))

            if not pdf_path:
                continue

            if page_index not in checked_pages:
                continue

            rect = selections_qrect.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            # Load correct PDF/page so coordinate conversion uses correct page data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path
            self.current_page_index = page_index
            self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)

            converted = {
                page_index: self._preview_rect_to_pdf_selection(rect)
            }

            source_stem = Path(pdf_path).stem
            page_output = base_path.with_name(
                f"{base_path.stem}_{order_index:03d}_{source_stem}_page_{page_index + 1:03d}{base_path.suffix}"
            )

            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(page_output),
                selections=converted,
                options=options,
            )

            output_files.append(str(page_output))

        if not output_files:
            raise RuntimeError("No valid selected pages were found for export.")

        self.last_exported_pdf_path = output_files[0]
        self._log(f"Workspace separate export completed. Files created: {len(output_files)}")

        return output_files

'''

if "def _export_workspace_to_separate_pdfs" not in text:
    marker = "    def _export_workspace_to_pdf(self, output_path: str, options: ExportOptions) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find _export_workspace_to_pdf marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added workspace separate PDFs export method")
else:
    print("[SKIP] Workspace separate export method already exists")

# ------------------------------------------------------------
# 4) Patch workspace export branch to support separate PDFs
# ------------------------------------------------------------
old_branch = '''            if workspace_mode:
                self._export_workspace_to_pdf(output_path, options)
                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Print output PDF was created:\\n\\n{output_path}"
                )
                try:
                    os.startfile(output_path)
                    self._log(f"Opened exported PDF: {output_path}")
                except Exception as exc:
                    self._log(f"Open exported PDF failed: {exc}")
                return

            exporter = PosterExporter()
'''

new_branch = '''            if workspace_mode:
                if self.batch_output_combo.currentData() == "separate_pdf_per_page":
                    output_files = self._export_workspace_to_separate_pdfs(output_path, options)

                    QMessageBox.information(
                        self,
                        "Export Complete",
                        "Separate PDF files were created:\\n\\n" + "\\n".join(output_files[:10])
                    )

                    try:
                        if output_files:
                            os.startfile(output_files[0])
                            self._log(f"Opened first exported PDF: {output_files[0]}")
                    except Exception as exc:
                        self._log(f"Open exported PDF failed: {exc}")

                    return

                self._export_workspace_to_pdf(output_path, options)
                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Print output PDF was created:\\n\\n{output_path}"
                )
                try:
                    os.startfile(output_path)
                    self._log(f"Opened exported PDF: {output_path}")
                except Exception as exc:
                    self._log(f"Open exported PDF failed: {exc}")
                return

            exporter = PosterExporter()
'''

if old_branch in text:
    text = text.replace(old_branch, new_branch, 1)
    print("[OK] Patched workspace export branch for separate PDFs")
else:
    if "_export_workspace_to_separate_pdfs(output_path, options)" in text:
        print("[SKIP] Workspace branch already supports separate PDFs")
    else:
        print("[ERROR] Could not find workspace export branch")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 5) Adjust log wording
# ------------------------------------------------------------
text = text.replace('self._log("Batch output: single_pdf")',
                    'self._log(f"Output files mode: {self.batch_output_combo.currentData()}")')
text = text.replace('self._log(f"Batch output: {self.batch_output_combo.currentData()}")',
                    'self._log(f"Output files mode: {self.batch_output_combo.currentData()}")')

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 6) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_restore_output_files_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    'QLabel("Output Files")',
    'addItem("One PDF", "single_pdf")',
    'addItem("Separate PDF per selected page", "separate_pdf_per_page")',
    'def _export_workspace_to_separate_pdfs',
    '_export_workspace_to_separate_pdfs(output_path, options)',
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Output Files option restored")
print("- One PDF / Separate PDF per selected page available")
print("- Workspace separate PDF export added")
