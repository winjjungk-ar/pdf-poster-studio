﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_page_rotation_independent_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Fix _get_current_rotation_degrees fallback
# ------------------------------------------------------------
old = '''    def _get_current_rotation_degrees(self) -> int:
        return int(self.page_rotations.get(self.current_page_index, self.rotation_degrees)) % 360
'''

new = '''    def _get_current_rotation_degrees(self) -> int:
        # Page rotation must be independent.
        # If the current page has no saved rotation, use 0 degrees.
        return int(self.page_rotations.get(self.current_page_index, 0)) % 360
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Fixed _get_current_rotation_degrees fallback to 0")
elif "return int(self.page_rotations.get(self.current_page_index, 0)) % 360" in text:
    print("[SKIP] _get_current_rotation_degrees already fixed")
else:
    print("[ERROR] Could not find _get_current_rotation_degrees block")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 2) Normalize _set_current_rotation_degrees
# Remove page entry when rotation is 0, to keep state clean.
# ------------------------------------------------------------
old = '''    def _set_current_rotation_degrees(self, degrees: int) -> None:
        self.page_rotations[self.current_page_index] = int(degrees) % 360
        self.rotation_degrees = self.page_rotations[self.current_page_index]
'''

new = '''    def _set_current_rotation_degrees(self, degrees: int) -> None:
        degrees = int(degrees) % 360

        if degrees == 0:
            self.page_rotations.pop(self.current_page_index, None)
        else:
            self.page_rotations[self.current_page_index] = degrees

        self.rotation_degrees = degrees
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Normalized _set_current_rotation_degrees")
elif "self.page_rotations.pop(self.current_page_index, None)" in text:
    print("[SKIP] _set_current_rotation_degrees already normalized")
else:
    print("[WARN] Could not normalize _set_current_rotation_degrees")

# ------------------------------------------------------------
# 3) Ensure page switch updates visible rotation state after current_page_index is set
# ------------------------------------------------------------
# This block may already exist; ensure correct order in _load_workspace_index.
old = '''        target_page = int(item.get("current_page_index", 0))
        self.current_page_index = max(0, min(target_page, self.page_count - 1))
        self.rotation_degrees = self._get_current_rotation_degrees()
'''

if old in text:
    print("[OK] _load_workspace_index rotation order already correct")
else:
    wrong = '''        self.rotation_degrees = self._get_current_rotation_degrees()

        target_page = int(item.get("current_page_index", 0))
        self.current_page_index = max(0, min(target_page, self.page_count - 1))
'''
    fixed = '''        target_page = int(item.get("current_page_index", 0))
        self.current_page_index = max(0, min(target_page, self.page_count - 1))
        self.rotation_degrees = self._get_current_rotation_degrees()
'''
    if wrong in text:
        text = text.replace(wrong, fixed, 1)
        print("[OK] Fixed _load_workspace_index rotation order")
    else:
        print("[SKIP] _load_workspace_index rotation order block not found")

# ------------------------------------------------------------
# 4) Ensure page navigation updates rotation_degrees for current page before render
# ------------------------------------------------------------
# previous_page
old = '''        self._save_current_selection()
        self.current_page_index -= 1
        self._render_current_page()
'''

new = '''        self._save_current_selection()
        self.current_page_index -= 1
        self.rotation_degrees = self._get_current_rotation_degrees()
        self._render_current_page()
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] previous_page updates page-specific rotation")
else:
    print("[SKIP] previous_page block not found or already patched")

# next_page
old = '''        self._save_current_selection()
        self.current_page_index += 1
        self._render_current_page()
'''

new = '''        self._save_current_selection()
        self.current_page_index += 1
        self.rotation_degrees = self._get_current_rotation_degrees()
        self._render_current_page()
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] next_page updates page-specific rotation")
else:
    print("[SKIP] next_page block not found or already patched")

# page jump
old = '''        self._save_current_selection()
        self.current_page_index = target_index
        self._render_current_page()
'''

new = '''        self._save_current_selection()
        self.current_page_index = target_index
        self.rotation_degrees = self._get_current_rotation_degrees()
        self._render_current_page()
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] page jump updates page-specific rotation")
else:
    print("[SKIP] page jump block not found or already patched")

# page list click
old = '''        self._save_current_selection()
        self.current_page_index = page_index
        self._render_current_page()
'''

new = '''        self._save_current_selection()
        self.current_page_index = page_index
        self.rotation_degrees = self._get_current_rotation_degrees()
        self._render_current_page()
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] page list click updates page-specific rotation")
else:
    print("[SKIP] page list click block not found or already patched")

# ------------------------------------------------------------
# 5) Release Notes
# ------------------------------------------------------------
if "Independent page rotation fallback fix" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Independent page rotation fallback fix</b>: Pages without a saved rotation now correctly use 0 degrees.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 6) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_page_rotation_independent_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "return int(self.page_rotations.get(self.current_page_index, 0)) % 360",
    "self.page_rotations.pop(self.current_page_index, None)",
    "Independent page rotation fallback fix",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Rotation is now truly page-specific")
print("- Pages without saved rotation default to 0 degrees")
print("- If testing EXE, rebuild EXE first")
