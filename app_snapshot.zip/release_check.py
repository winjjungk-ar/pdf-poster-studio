﻿from pathlib import Path
from datetime import datetime
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
OUT = ROOT / "release_check_report.txt"

MAIN = ROOT / "app" / "main_window.py"

important_files = [
    ROOT / "main.py",
    ROOT / "app" / "main_window.py",
    ROOT / "app" / "config.py",
    ROOT / "app" / "pdf" / "pdf_renderer.py",
    ROOT / "app" / "pdf" / "poster_exporter.py",
    ROOT / "app" / "pdf" / "pdf_page_collector.py",
    ROOT / "app" / "ui" / "pdf_preview_widget.py",
    ROOT / "app" / "ui" / "page_collector_dialog.py",
]

required_markers = {
    "Unified Open PDFs": [
        "def open_pdfs",
        'addAction("Open PDFs", self.open_pdfs)',
    ],
    "Workspace": [
        "self.workspace_items",
        "def _make_workspace_item",
        "def _load_workspace_index",
        "def _save_current_workspace_state",
    ],
    "Export Order": [
        "self.export_order_list",
        "Build Export Order",
        "def refresh_export_order_from_checked_pages",
        "def _get_export_order_entries",
    ],
    "Export Order thumbnails": [
        "def _create_export_order_thumbnail",
        "setIcon(self._create_export_order_thumbnail",
    ],
    "Export Order double click jump": [
        "itemDoubleClicked.connect(self.on_export_order_item_double_clicked)",
        "def on_export_order_item_double_clicked",
    ],
    "Auto Select Workspace": [
        "def auto_select_all_workspace_pages",
        "QProgressDialog",
        "QApplication.processEvents",
    ],
    "Export/Print mode prompt": [
        "def _prompt_export_type",
        "self._prompt_export_type()",
    ],
    "Project workspace save/load": [
        "def _serialize_workspace_items",
        "def _restore_workspace_items_from_project",
        '"workspace":',
        '"export_order": export_order',
    ],
    "Welcome popup/icon": [
        "def _show_welcome_dialog",
        "def _create_app_icon",
        "QTimer.singleShot",
    ],
    "Start maximized": [
        "QTimer.singleShot(0, self.showMaximized)",
        "setMinimumSize",
    ],
    "Combo restore fix": [
        "def _apply_combo_data",
        "tolerant type matching",
    ],
}

deprecated_markers = {
    "Old Open PDF menu action": 'addAction("Open PDF", self.open_pdf)',
    "Old Open Multiple PDFs menu action": 'Open Multiple PDFs as Workspace',
    "Old Collect Pages menu action": 'Collect Pages from PDFs',
    "Options menu": 'menu_bar.addMenu("Options")',
    "Quick Start menu": 'help_menu.addAction("Quick Start"',
    "Diagnostics menu": 'help_menu.addAction("Diagnostics"',
    "Check Menu Actions menu": 'help_menu.addAction("Check Menu Actions"',
    "Old blue toolbar style": "background-color: #0B63CE",
}

report = []
report.append("# Release Check Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- python: {sys.executable}")
report.append("")

# ------------------------------------------------------------
# File existence
# ------------------------------------------------------------
report.append("## 1. Important file existence")
for path in important_files:
    status = "OK" if path.exists() else "MISSING"
    report.append(f"- [{status}] `{path.relative_to(ROOT) if path.exists() or ROOT in path.parents else path}`")
report.append("")

# ------------------------------------------------------------
# py_compile
# ------------------------------------------------------------
report.append("## 2. py_compile")
compile_failed = False

for path in important_files:
    if not path.exists():
        report.append(f"- [SKIP] `{path}` not found")
        continue

    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode == 0:
        report.append(f"- [OK] `{path.relative_to(ROOT)}`")
    else:
        compile_failed = True
        report.append(f"- [FAILED] `{path.relative_to(ROOT)}`")
        if result.stdout.strip():
            report.append("  - stdout:")
            report.append("```text")
            report.append(result.stdout.strip())
            report.append("```")
        if result.stderr.strip():
            report.append("  - stderr:")
            report.append("```text")
            report.append(result.stderr.strip())
            report.append("```")
report.append("")

# ------------------------------------------------------------
# ast parse
# ------------------------------------------------------------
report.append("## 3. AST parse")
for path in important_files:
    if not path.exists():
        continue

    try:
        src = path.read_text(encoding="utf-8", errors="replace")
        ast.parse(src)
        report.append(f"- [OK] `{path.relative_to(ROOT)}`")
    except SyntaxError as exc:
        report.append(f"- [FAILED] `{path.relative_to(ROOT)}`: {exc}")
report.append("")

# ------------------------------------------------------------
# main_window marker checks
# ------------------------------------------------------------
report.append("## 4. main_window.py feature marker checks")

if MAIN.exists():
    main_text = MAIN.read_text(encoding="utf-8", errors="replace")

    for feature, markers in required_markers.items():
        missing = [m for m in markers if m not in main_text]
        if missing:
            report.append(f"- [WARN] {feature}: missing")
            for m in missing:
                report.append(f"  - `{m}`")
        else:
            report.append(f"- [OK] {feature}")

    report.append("")
    report.append("## 5. Deprecated/old UI marker checks")

    for name, marker in deprecated_markers.items():
        if marker in main_text:
            report.append(f"- [WARN] {name} still found: `{marker}`")
        else:
            report.append(f"- [OK] {name} not found")

    report.append("")
    report.append("## 6. Title/version related lines")
    lines = main_text.splitlines()
    matched = []
    for idx, line in enumerate(lines, 1):
        if (
            "setWindowTitle" in line
            or '"version"' in line
            or "APP_NAME" in line
            or "PDF Poster Studio" in line
        ):
            matched.append(f"{idx:05d}: {line}")

    if matched:
        report.append("```text")
        report.append("\n".join(matched[:120]))
        report.append("```")
    else:
        report.append("(none)")
else:
    report.append("- [FAILED] main_window.py missing")

report.append("")

# ------------------------------------------------------------
# Patch/backup clutter
# ------------------------------------------------------------
report.append("## 7. Patch scripts and backup files")

patch_scripts = sorted(ROOT.glob("patch_*.py")) + sorted(ROOT.glob("fix_*.py")) + sorted(ROOT.glob("extract_*.py"))
backup_files = sorted((ROOT / "app").rglob("*.bak_*")) if (ROOT / "app").exists() else []

report.append(f"- patch/fix/extract scripts in root: {len(patch_scripts)}")
for p in patch_scripts[:80]:
    report.append(f"  - `{p.name}`")
if len(patch_scripts) > 80:
    report.append(f"  - ... and {len(patch_scripts) - 80} more")

report.append(f"- backup files under app/: {len(backup_files)}")
for p in backup_files[:80]:
    report.append(f"  - `{p.relative_to(ROOT)}`")
if len(backup_files) > 80:
    report.append(f"  - ... and {len(backup_files) - 80} more")

report.append("")

# ------------------------------------------------------------
# Directory sanity
# ------------------------------------------------------------
report.append("## 8. Directory sanity")
dirs = [
    ROOT / "app",
    ROOT / "app" / "pdf",
    ROOT / "app" / "ui",
    ROOT / "data",
    ROOT / "exports",
    ROOT / "projects",
]

for d in dirs:
    report.append(f"- [{'OK' if d.exists() else 'MISSING'}] `{d.relative_to(ROOT)}`")
report.append("")

# ------------------------------------------------------------
# Summary
# ------------------------------------------------------------
report.append("## 9. Summary")

if compile_failed:
    report.append("- Overall: **FAILED**")
    report.append("- Reason: one or more files failed `py_compile`.")
else:
    report.append("- Overall: **CHECK COMPLETE**")
    report.append("- If only WARN items are patch scripts/backups/deprecated non-menu code, the app may still be runnable.")
    report.append("- Recommended before EXE build: move patch/fix/extract scripts and `.bak_*` files to a separate backup folder.")

OUT.write_text("\n".join(report), encoding="utf-8")

print(f"[OK] Release check report written: {OUT}")
print("")
if compile_failed:
    print("[RESULT] FAILED: py_compile errors found.")
else:
    print("[RESULT] CHECK COMPLETE")
print("Please open release_check_report.txt and review WARN/FAILED items.")
