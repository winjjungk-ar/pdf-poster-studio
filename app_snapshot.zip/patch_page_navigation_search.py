﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_page_navigation_search_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Import QInputDialog if missing
# ------------------------------------------------------------
if "QInputDialog" not in text:
    if "    QMessageBox,\n" in text:
        text = text.replace(
            "    QMessageBox,\n",
            "    QMessageBox,\n    QInputDialog,\n",
            1
        )
        print("[OK] Added QInputDialog import")
    else:
        print("[WARN] Could not find QMessageBox import anchor")
else:
    print("[SKIP] QInputDialog already imported")

# ------------------------------------------------------------
# 2) Add state in __init__
# ------------------------------------------------------------
old = '''        self.last_temp_print_pdf_path: str | None = None

        self.pdf_renderer = PdfRenderer()
'''

new = '''        self.last_temp_print_pdf_path: str | None = None

        self.last_search_text: str = ""
        self.last_search_page_index: int = -1

        self.pdf_renderer = PdfRenderer()
'''

if old in text and "self.last_search_text" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added search state")
else:
    print("[SKIP] Search state already exists or anchor not found")

# ------------------------------------------------------------
# 3) Add View menu actions
# ------------------------------------------------------------
old = '''        # View
        view_menu.addAction("Previous Page", self.previous_page)
        view_menu.addAction("Next Page", self.next_page)
        view_menu.addSeparator()
'''

new = '''        # View
        view_menu.addAction("Previous Page", self.previous_page)
        view_menu.addAction("Next Page", self.next_page)

        go_to_page_action = view_menu.addAction("Go to Page", self.go_to_page_dialog)
        go_to_page_action.setShortcut(QKeySequence("Ctrl+G"))

        find_text_action = view_menu.addAction("Find Text", self.find_text_dialog)
        find_text_action.setShortcut(QKeySequence("Ctrl+F"))

        find_next_action = view_menu.addAction("Find Next", self.find_next_text)
        find_next_action.setShortcut(QKeySequence("F3"))

        view_menu.addSeparator()
'''

if old in text and "Find Text" not in text[text.find("def _create_menus"):text.find("def _create_app_icon") if "def _create_app_icon" in text else text.find("def _create_quick_toolbar")]:
    text = text.replace(old, new, 1)
    print("[OK] Added View menu navigation/search actions")
else:
    print("[SKIP] View menu search actions already exist or anchor not found")

# ------------------------------------------------------------
# 4) Add toolbar buttons after Open PDFs / Images
# ------------------------------------------------------------
old = '''        toolbar.addAction(open_pdfs_action)

        toolbar.addSeparator()
'''

new = '''        toolbar.addAction(open_pdfs_action)

        go_to_page_action = QAction("Go Page", self)
        go_to_page_action.setToolTip("Go to page (Ctrl+G)")
        go_to_page_action.triggered.connect(self.go_to_page_dialog)
        toolbar.addAction(go_to_page_action)

        find_text_action = QAction("Find", self)
        find_text_action.setToolTip("Find text (Ctrl+F)")
        find_text_action.triggered.connect(self.find_text_dialog)
        toolbar.addAction(find_text_action)

        toolbar.addSeparator()
'''

toolbar_start = text.find("    def _create_quick_toolbar")
toolbar_end = text.find("\n    def ", toolbar_start + 10) if toolbar_start != -1 else -1
toolbar_segment = text[toolbar_start:toolbar_end if toolbar_end != -1 else len(text)]

if toolbar_start != -1 and "QAction(\"Find\", self)" not in toolbar_segment:
    if old in toolbar_segment:
        toolbar_segment = toolbar_segment.replace(old, new, 1)
        text = text[:toolbar_start] + toolbar_segment + text[toolbar_end if toolbar_end != -1 else len(text):]
        print("[OK] Added Go Page / Find to toolbar")
    else:
        print("[WARN] Toolbar open action anchor not found")
else:
    print("[SKIP] Toolbar Go Page / Find already exists or toolbar not found")

# ------------------------------------------------------------
# 5) Add methods before previous_page
# ------------------------------------------------------------
methods = r'''
    def go_to_page_dialog(self) -> None:
        if self.page_count <= 0:
            QMessageBox.information(self, "Go to Page", "Please open a PDF or image first.")
            return

        page_no, ok = QInputDialog.getInt(
            self,
            "Go to Page",
            f"Enter page number (1 - {self.page_count}):",
            value=self.current_page_index + 1,
            min=1,
            max=self.page_count,
        )

        if not ok:
            return

        target_index = page_no - 1

        if target_index == self.current_page_index:
            return

        self._save_current_selection()
        self.current_page_index = target_index
        self.rotation_degrees = self._get_current_rotation_degrees()
        self._render_current_page()
        self._log(f"Go to page: {page_no}")

    def find_text_dialog(self) -> None:
        if not self.current_pdf_path or self.page_count <= 0:
            QMessageBox.information(self, "Find Text", "Please open a PDF first.")
            return

        text, ok = QInputDialog.getText(
            self,
            "Find Text",
            "Enter text to find:",
            text=self.last_search_text,
        )

        if not ok:
            return

        query = text.strip()

        if not query:
            return

        self.last_search_text = query
        self.last_search_page_index = self.current_page_index - 1
        self.find_next_text()

    def find_next_text(self) -> None:
        if not self.current_pdf_path or self.page_count <= 0:
            QMessageBox.information(self, "Find Next", "Please open a PDF first.")
            return

        query = (self.last_search_text or "").strip()

        if not query:
            self.find_text_dialog()
            return

        start_index = self.last_search_page_index + 1

        if start_index < 0:
            start_index = 0

        try:
            doc = fitz.open(self.current_pdf_path)

            try:
                # Search from the next page to the end, then wrap to the beginning.
                search_order = list(range(start_index, len(doc))) + list(range(0, start_index))

                for page_index in search_order:
                    page = doc.load_page(page_index)
                    hits = page.search_for(query)

                    if hits:
                        self._save_current_selection()
                        self.current_page_index = page_index
                        self.last_search_page_index = page_index
                        self.rotation_degrees = self._get_current_rotation_degrees()
                        self._render_current_page()

                        QMessageBox.information(
                            self,
                            "Find Text",
                            f"Found '{query}' on page {page_index + 1}."
                        )
                        self._log(f"Find Text: '{query}' found on page {page_index + 1}")
                        return

            finally:
                doc.close()

            QMessageBox.information(
                self,
                "Find Text",
                f"'{query}' was not found."
            )
            self._log(f"Find Text: '{query}' not found")

        except Exception as exc:
            QMessageBox.warning(
                self,
                "Find Text",
                f"Search failed.\n\n{exc}"
            )
            self._log(f"Find Text error: {exc}")

'''

if "def go_to_page_dialog" not in text:
    marker = "    def previous_page(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find previous_page insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + methods + "\n" + text[pos:]
    print("[OK] Added Go to Page / Find Text methods")
else:
    print("[SKIP] Go to Page / Find Text methods already exist")

# ------------------------------------------------------------
# 6) Release Notes
# ------------------------------------------------------------
if "Find Text and Go to Page" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Find Text and Go to Page</b>: Added Ctrl+F text search, F3 Find Next, and Ctrl+G Go to Page for large PDFs.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for search/navigation")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 7) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_page_navigation_search_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "def go_to_page_dialog",
    "def find_text_dialog",
    "def find_next_text",
    'QKeySequence("Ctrl+F")',
    'QKeySequence("Ctrl+G")',
    'QKeySequence("F3")',
    "Find Text and Go to Page",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Ctrl+G Go to Page added")
print("- Ctrl+F Find Text added")
print("- F3 Find Next added")
print("- Toolbar buttons added: Go Page / Find")
