﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_hide_export_quality_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Replace Export Quality QLabel with instance label so it can be hidden.
# ------------------------------------------------------------
old = '''        export_layout.addWidget(QLabel("Export Quality"))
        export_layout.addWidget(self.export_quality_combo)
'''

new = '''        self.export_quality_label = QLabel("Export Quality")
        self.export_quality_label.setVisible(False)
        self.export_quality_combo.setVisible(False)
        export_layout.addWidget(self.export_quality_label)
        export_layout.addWidget(self.export_quality_combo)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Export Quality UI hidden in active export tab")
else:
    print("[SKIP] Active Export Quality block not found or already patched")

# ------------------------------------------------------------
# 2) If duplicate/dead block remains, patch it too harmlessly.
# ------------------------------------------------------------
if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Export Quality UI hidden in duplicate block too")

# ------------------------------------------------------------
# 3) Add explanatory log once after combo creation if not present.
# ------------------------------------------------------------
marker = '''        self.export_quality_combo.setCurrentIndex(1)
'''

insert = '''        self.export_quality_combo.setCurrentIndex(1)
        # Kept internally for backward compatibility. Current vector-based PDF export
        # usually preserves original PDF quality without raster quality scaling.
'''

if marker in text and "Current vector-based PDF export" not in text:
    text = text.replace(marker, insert, 1)
    print("[OK] Added compatibility comment")
else:
    print("[SKIP] Compatibility comment already present or marker not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_hide_export_quality_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Export Quality is hidden from the UI")
print("- Internal compatibility is preserved")
