﻿from pathlib import Path
import ast
import re
import sys
from datetime import datetime

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
OUT = ROOT / "project_save_audit_report.txt"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

text = MAIN.read_text(encoding="utf-8", errors="replace")

def get_function_source(source: str, func_name: str):
    tree = ast.parse(source)
    lines = source.splitlines()
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            return node.lineno, node.end_lineno, "\n".join(lines[node.lineno-1:node.end_lineno])
    return None

functions = [
    "_collect_project_data",
    "_apply_project_data",
    "_serialize_workspace_items",
    "_restore_workspace_items_from_project",
    "_serialize_export_order",
    "_restore_export_order_from_project",
]

required_save_markers = [
    '"workspace"',
    '"items"',
    '"current_workspace_index"',
    '"export_order"',
    '"settings"',
    '"export_type"',
    '"selection_fit_mode"',
    '"page_orientation"',
    '"batch_output"',
    '"print_quality_dpi"',
    '"output_mode"',
    '"split_layout"',
    '"paper_size"',
    '"poster_scale_percent"',
    '"poster_size_preset_index"',
]

required_load_markers = [
    'settings.get("paper_size"',
    'settings.get("poster_scale_percent"',
    'settings.get("poster_size_preset_index"',
    'workspace.get("items"',
    'workspace.get("export_order"',
    '_restore_workspace_items_from_project',
    '_restore_export_order_from_project',
]

report = []
report.append("# Project Save/Load Audit Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py lines: {len(text.splitlines())}")
report.append("")

report.append("## 1. Syntax")
try:
    ast.parse(text)
    report.append("- [OK] main_window.py")
except SyntaxError as exc:
    report.append(f"- [FAILED] main_window.py: {exc}")
report.append("")

report.append("## 2. Required save markers")
for marker in required_save_markers:
    report.append(f"- [{'OK' if marker in text else 'WARN'}] `{marker}`")
report.append("")

report.append("## 3. Required load markers")
for marker in required_load_markers:
    report.append(f"- [{'OK' if marker in text else 'WARN'}] `{marker}`")
report.append("")

report.append("## 4. Relevant function blocks")
for fn in functions:
    block = get_function_source(text, fn)
    report.append(f"### `{fn}`")
    if not block:
        report.append("- [WARN] not found")
        report.append("")
        continue

    start, end, code = block
    report.append(f"- lines: {start}-{end}")
    report.append("```python")
    report.append(code[:8000])
    if len(code) > 8000:
        report.append("\n# ... truncated ...")
    report.append("```")
    report.append("")

report.append("## 5. Interpretation")
report.append("- `batch_output` should be saved/restored because Output Files is user-visible.")
report.append("- `poster_size_preset_index`, `paper_size`, and `poster_scale_percent` should be saved/restored together.")
report.append("- Print Order should be restored after Source PDFs are restored.")
report.append("- Tiling Preview should update after project load; if not, call `update_poster_sheet_estimate()` after restore.")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste project_save_audit_report.txt here.")
