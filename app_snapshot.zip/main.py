import sys
from PyQt6.QtWidgets import QApplication
from app.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("A4 to A3 Poster Print Studio")
    app.setOrganizationName("JI JEONG GEUN")

    window = MainWindow()
    window.show()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())