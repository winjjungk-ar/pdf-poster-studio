﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

# ------------------------------------------------------------
# 1) Backup main before version update
# ------------------------------------------------------------
main_backup = MAIN.with_name(f"main_window.py.bak_version_091_{timestamp}")
shutil.copy2(MAIN, main_backup)
print(f"[OK] Backup created: {main_backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 2) Version update
# ------------------------------------------------------------
replacements = [
    ("Version: 0.9.0-workspace", "Version: 0.9.1"),
    ('"version": "0.9.0-workspace"', '"version": "0.9.1"'),
    ("0.9.0-workspace", "0.9.1"),
]

changed = 0
for old, new in replacements:
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        changed += count
        print(f"[OK] Version replace {count}: {old} -> {new}")

# If About still has old 0.4.0, fix it.
text = text.replace("Version: 0.4.0", "Version: 0.9.1")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) Compile core files before moving scripts
# ------------------------------------------------------------
core_files = [
    ROOT / "main.py",
    ROOT / "app" / "main_window.py",
    ROOT / "app" / "config.py",
    ROOT / "app" / "pdf" / "pdf_renderer.py",
    ROOT / "app" / "pdf" / "poster_exporter.py",
    ROOT / "app" / "ui" / "pdf_preview_widget.py",
]

print("[INFO] Running py_compile on core files...")
for path in core_files:
    if not path.exists():
        print(f"[WARN] Missing core file: {path}")
        continue

    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = MAIN.with_name(f"main_window.py.failed_version_091_{timestamp}")
        shutil.copy2(MAIN, failed)
        shutil.copy2(main_backup, MAIN)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] main_window.py restored from {main_backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 4) Move dev scripts/reports/backups to archive
# ------------------------------------------------------------
archive_root = ROOT / "dev_archive" / f"release_0.9.1_cleanup_{timestamp}"
scripts_dir = archive_root / "scripts"
reports_dir = archive_root / "reports"
backups_dir = archive_root / "backups"

scripts_dir.mkdir(parents=True, exist_ok=True)
reports_dir.mkdir(parents=True, exist_ok=True)
backups_dir.mkdir(parents=True, exist_ok=True)

moved_scripts = []
moved_reports = []
moved_backups = []

# Keep this script until it finishes; it will move itself at the end if possible.
current_script_name = Path(__file__).name if "__file__" in globals() else "release_cleanup_091.py"

script_patterns = [
    "patch_*.py",
    "fix_*.py",
    "audit_*.py",
    "*check*.py",
    "extract_*.py",
    "diagnose_*.py",
    "force_*.py",
    "cleanup_*.py",
]

for pattern in script_patterns:
    for path in ROOT.glob(pattern):
        if not path.is_file():
            continue
        if path.name == current_script_name:
            continue

        target = scripts_dir / path.name
        if target.exists():
            target = scripts_dir / f"{path.stem}_{timestamp}{path.suffix}"

        shutil.move(str(path), str(target))
        moved_scripts.append(path.name)

report_patterns = [
    "*report.txt",
    "*extract.txt",
]

for pattern in report_patterns:
    for path in ROOT.glob(pattern):
        if not path.is_file():
            continue

        target = reports_dir / path.name
        if target.exists():
            target = reports_dir / f"{path.stem}_{timestamp}{path.suffix}"

        shutil.move(str(path), str(target))
        moved_reports.append(path.name)

app_dir = ROOT / "app"
if app_dir.exists():
    for path in app_dir.rglob("*.bak_*"):
        if not path.is_file():
            continue

        rel = path.relative_to(app_dir)
        target = backups_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)

        if target.exists():
            target = target.with_name(f"{target.name}_{timestamp}")

        shutil.move(str(path), str(target))
        moved_backups.append(str(rel))

# Move root-level main backups if any
for path in ROOT.glob("main.py.bak_*"):
    if path.is_file():
        target = backups_dir / "root" / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(path), str(target))
        moved_backups.append(str(path.relative_to(ROOT)))

summary = archive_root / "cleanup_summary.txt"
summary.write_text(
    "\n".join([
        "# Release 0.9.1 Cleanup Summary",
        f"timestamp: {timestamp}",
        f"root: {ROOT}",
        "",
        f"version_changes: {changed}",
        "",
        f"moved_scripts: {len(moved_scripts)}",
        *[f"- {x}" for x in moved_scripts],
        "",
        f"moved_reports: {len(moved_reports)}",
        *[f"- {x}" for x in moved_reports],
        "",
        f"moved_backups: {len(moved_backups)}",
        *[f"- {x}" for x in moved_backups],
        "",
        "Note: Files were moved, not deleted.",
    ]),
    encoding="utf-8"
)

print("")
print("[OK] Release cleanup complete")
print(f"- archive: {archive_root}")
print(f"- version replacements: {changed}")
print(f"- moved scripts: {len(moved_scripts)}")
print(f"- moved reports: {len(moved_reports)}")
print(f"- moved backups: {len(moved_backups)}")
print("")
print("Next:")
print("1. Run: python main.py")
print("2. Check Help > About Program shows Version: 0.9.1")
print("3. Run manual export tests")
