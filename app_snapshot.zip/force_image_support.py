﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_force_image_support_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno

    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

def insert_before_function(source: str, func_name: str, code: str) -> str:
    marker = f"    def {func_name}"
    pos = source.find(marker)

    if pos == -1:
        raise RuntimeError(f"Could not find function marker: {func_name}")

    return source[:pos] + code + "\n" + source[pos:]

# ------------------------------------------------------------
# 1) Add image helper methods
# ------------------------------------------------------------
helpers = r'''
    def _is_supported_image_path(self, file_path: str) -> bool:
        suffix = Path(file_path).suffix.lower()
        return suffix in {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

    def _prepare_source_file_for_workspace(self, file_path: str) -> str:
        """Return a PDF path usable by the existing PDF renderer/exporter.

        PDF files are returned as-is.
        Image files are converted to a temporary single-page PDF.
        """
        suffix = Path(file_path).suffix.lower()

        if suffix == ".pdf":
            return file_path

        if self._is_supported_image_path(file_path):
            return self._convert_image_to_temp_pdf(file_path)

        raise RuntimeError(f"Unsupported file type: {file_path}")

    def _convert_image_to_temp_pdf(self, image_path: str) -> str:
        image_file = Path(image_path)

        if not image_file.exists():
            raise RuntimeError(f"Image file not found: {image_path}")

        temp_dir = DATA_DIR / "image_imports"
        temp_dir.mkdir(parents=True, exist_ok=True)

        safe_stem = "".join(ch if ch not in '<>:"/\\\\|?*' else "_" for ch in image_file.stem)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        output_pdf = temp_dir / f"{safe_stem}_{timestamp}.pdf"

        doc = fitz.open()
        img_doc = None

        try:
            img_doc = fitz.open(str(image_file))
            rect = img_doc[0].rect

            if rect.width <= 0 or rect.height <= 0:
                raise RuntimeError("Invalid image size.")

            page = doc.new_page(width=rect.width, height=rect.height)
            page.insert_image(page.rect, filename=str(image_file))
            doc.save(str(output_pdf), garbage=4, deflate=True)

        finally:
            doc.close()
            if img_doc is not None:
                img_doc.close()

        self._log(f"Image converted to temporary PDF: {image_file} -> {output_pdf}")
        return str(output_pdf)

'''

if "def _convert_image_to_temp_pdf" not in text:
    text = insert_before_function(text, "open_pdfs", helpers)
    print("[OK] Added image helper methods")
else:
    print("[SKIP] Image helper methods already exist")

file_filter = (
    '"PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp);;"\n'
    '            "PDF Files (*.pdf);;"\n'
    '            "Image Files (*.png *.jpg *.jpeg *.bmp *.webp);;"\n'
    '            "All Files (*)"'
)

# ------------------------------------------------------------
# 2) Replace open_pdfs
# ------------------------------------------------------------
new_open_pdfs = r'''    def open_pdfs(self) -> None:
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Open PDFs or Images",
            "",
            "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp);;"
            "PDF Files (*.pdf);;"
            "Image Files (*.png *.jpg *.jpeg *.bmp *.webp);;"
            "All Files (*)"
        )

        if not file_paths:
            return

        try:
            self.workspace_items = []
            self.current_workspace_index = None

            if hasattr(self, "workspace_pdf_list"):
                self.workspace_pdf_list.clear()
            if hasattr(self, "export_order_list"):
                self.export_order_list.clear()

            loaded_count = 0

            for source_path in file_paths:
                pdf_path = self._prepare_source_file_for_workspace(source_path)
                self.workspace_items.append(self._make_workspace_item(pdf_path))
                loaded_count += 1

            self._refresh_workspace_list_text()

            if self.workspace_items:
                self._load_workspace_index(0)

            self.is_modified = True
            self._log(f"Open PDFs/images: {loaded_count} file(s) loaded.")

        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open PDFs or Images Error",
                f"Failed to open files.\n\n{exc}"
            )
            self._log(f"Open PDFs/images error: {exc}")

'''

text = replace_function(text, "open_pdfs", new_open_pdfs)
print("[OK] Replaced open_pdfs")

# ------------------------------------------------------------
# 3) Replace open_multiple_pdfs_workspace if present
# ------------------------------------------------------------
if "def open_multiple_pdfs_workspace" in text:
    new_open_multiple = r'''    def open_multiple_pdfs_workspace(self) -> None:
        # Backward-compatible wrapper.
        self.open_pdfs()

'''
    text = replace_function(text, "open_multiple_pdfs_workspace", new_open_multiple)
    print("[OK] Replaced open_multiple_pdfs_workspace with wrapper")

# ------------------------------------------------------------
# 4) Replace add_pdfs_to_workspace if present
# ------------------------------------------------------------
if "def add_pdfs_to_workspace" in text:
    new_add_pdfs = r'''    def add_pdfs_to_workspace(self) -> None:
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Add PDFs or Images to Source PDFs",
            "",
            "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp);;"
            "PDF Files (*.pdf);;"
            "Image Files (*.png *.jpg *.jpeg *.bmp *.webp);;"
            "All Files (*)"
        )

        if not file_paths:
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        existing = {item.get("pdf_path") for item in self.workspace_items}
        added_count = 0

        for source_path in file_paths:
            pdf_path = self._prepare_source_file_for_workspace(source_path)

            if pdf_path not in existing:
                self.workspace_items.append(self._make_workspace_item(pdf_path))
                existing.add(pdf_path)
                added_count += 1

        self._refresh_workspace_list_text()

        if self.current_workspace_index is None and self.workspace_items:
            self._load_workspace_index(0)

        self.is_modified = True
        self._log(f"Added PDFs/images to workspace: {added_count}")

'''
    text = replace_function(text, "add_pdfs_to_workspace", new_add_pdfs)
    print("[OK] Replaced add_pdfs_to_workspace")

# ------------------------------------------------------------
# 5) Update visible text / version markers
# ------------------------------------------------------------
text = text.replace(
    "from normal PDF files.",
    "from PDF or image files."
)
text = text.replace(
    "1. Open one or more source PDF files.",
    "1. Open one or more source PDF or image files."
)
text = text.replace(
    "Open one or more source PDF files.",
    "Open one or more source PDF or image files."
)
text = text.replace(
    "PDF Poster Studio helps you open one or more PDF files",
    "PDF Poster Studio helps you open one or more PDF or image files"
)

# Version bump if still 0.9.2
text = text.replace("Version: 0.9.2", "Version: 0.9.3")
text = text.replace('"version": "0.9.2"', '"version": "0.9.3"')
text = text.replace("What's new in 0.9.2", "What's new in 0.9.3")

# Welcome note
if "Open PDFs now supports PDF and image files" not in text:
    text = text.replace(
        "• See Help > Release Notes for details",
        "• Open PDFs now supports PDF and image files\n"
        "• See Help > Release Notes for details"
    )

# Release note simple insertion
if "Image import support" not in text and "<h2>PDF Poster Studio - Release Notes</h2>" in text:
    text = text.replace(
        "<h2>PDF Poster Studio - Release Notes</h2>",
        """<h2>PDF Poster Studio - Release Notes</h2>

<h3>Version 0.9.3</h3>
<ul>
  <li><b>Image import support</b>: Open PDFs now supports PNG, JPG, JPEG, BMP, and WEBP image files.</li>
  <li>Images are converted internally to temporary PDF pages so Poster Print and Single Page workflows can be used.</li>
</ul>
<hr>
""",
        1
    )

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 6) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_force_image_support_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Open PDFs or Images",
    "PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp)",
    "Image Files (*.png *.jpg *.jpeg *.bmp *.webp)",
    "def _convert_image_to_temp_pdf",
    "_prepare_source_file_for_workspace(source_path)",
    "Image import support",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Open PDFs now supports PDF and image files")
print("- Supported images: PNG, JPG, JPEG, BMP, WEBP")
print("- Images are converted to temporary PDFs under data/image_imports")
print("- Version bumped to 0.9.3")
