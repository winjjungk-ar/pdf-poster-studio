﻿from pathlib import Path
from datetime import datetime
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
OUT = ROOT / "final_release_check_report.txt"

MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

important_files = [
    ROOT / "main.py",
    MAIN,
    ROOT / "app" / "config.py",
    ROOT / "app" / "pdf" / "pdf_renderer.py",
    EXPORTER,
    ROOT / "app" / "ui" / "pdf_preview_widget.py",
]

required_main_markers = {
    "Identity": [
        "PDF Poster Studio",
        "PDF Poster Studio - A4/A3 Print Workspace",
    ],
    "Toolbar": [
        'QAction("Open PDFs", self)',
        'QAction("Create Poster PDF", self)',
        'QAction("Create Single Page PDF", self)',
        'QAction("Open Exports Folder", self)',
    ],
    "Source PDFs": [
        "Source PDFs",
        "self.workspace_pdf_list",
        "def open_pdfs",
    ],
    "Print Order": [
        "Print Order",
        "Build Print Order",
        "self.export_order_list",
        "def refresh_export_order_from_checked_pages",
        "def on_export_order_item_double_clicked",
    ],
    "Output Files": [
        "Output Files",
        "One PDF",
        "Separate PDF per selected page",
        "def _export_workspace_to_separate_pdfs",
    ],
    "Poster Print": [
        "Poster Print Mode",
        "Output Paper Size",
        "Poster Size Preset",
        "Poster Scale",
        "Tiling Preview",
        "def update_tiling_preview",
    ],
    "Single Page": [
        "Single Page Mode",
        "Single Page Fit Mode",
        "Used only for Single Page Mode",
    ],
    "Project save/load": [
        "def _serialize_workspace_items",
        "def _restore_workspace_items_from_project",
        '"workspace":',
        '"export_order": export_order',
        "poster_scale_percent",
        "poster_size_preset_index",
    ],
    "Auto select": [
        "def auto_select_all_workspace_pages",
        "QProgressDialog",
        "Auto Select All Pages",
    ],
    "Default app open": [
        "def _open_file_with_default_app",
        "os.startfile",
    ],
}

required_exporter_markers = {
    "Paper sizes": [
        "A4_WIDTH_PT",
        "LETTER_WIDTH_PT",
        "paper_size: str",
        "poster_scale: float",
    ],
    "Vector output": [
        "show_pdf_page",
        "Keep PDF text/vector graphics sharp",
    ],
    "Poster tiling": [
        "def _export_poster_tiling",
        "def _make_poster_tiles",
        "def _draw_poster_tiling_cut_guides",
        "def _draw_poster_tiling_numbering",
    ],
    "Short sheet numbers": [
        'text = f"{sheet_no}/{sheet_total}"',
        "Minimal and consistent sheet label",
    ],
}

old_visible_terms = [
    "A3 Split Mode",
    "Selection Only Mode",
    "Export Order",
    "PDF Workspace",
    "Collect Pages from PDFs",
    "Open Multiple PDFs",
]

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""

def py_compile(path: Path):
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )
    return result

def ast_status(path: Path, text: str):
    try:
        ast.parse(text)
        return "OK"
    except SyntaxError as exc:
        return f"FAILED: {exc}"

def function_defs(text: str, name: str):
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []

    result = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            result.append((node.lineno, getattr(node, "end_lineno", node.lineno)))
    return sorted(result)

def grep_lines(text: str, terms: list[str]):
    rows = []
    for idx, line in enumerate(text.splitlines(), 1):
        if any(term.lower() in line.lower() for term in terms):
            rows.append(f"{idx:05d}: {line}")
    return rows

main_text = read(MAIN)
exporter_text = read(EXPORTER)

report = []
report.append("# Final Release Check Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append(f"- python: {sys.executable}")
report.append(f"- main_window.py lines: {len(main_text.splitlines()) if main_text else 'missing'}")
report.append(f"- poster_exporter.py lines: {len(exporter_text.splitlines()) if exporter_text else 'missing'}")
report.append("")

# 1 file existence
report.append("## 1. Important files")
for path in important_files:
    report.append(f"- [{'OK' if path.exists() else 'MISSING'}] `{path.relative_to(ROOT) if path.exists() else path}`")
report.append("")

# 2 py_compile
report.append("## 2. py_compile")
compile_failed = False
for path in important_files:
    if not path.exists():
        report.append(f"- [SKIP] `{path}` missing")
        continue
    result = py_compile(path)
    if result.returncode == 0:
        report.append(f"- [OK] `{path.relative_to(ROOT)}`")
    else:
        compile_failed = True
        report.append(f"- [FAILED] `{path.relative_to(ROOT)}`")
        report.append("```text")
        report.append((result.stdout or "") + (result.stderr or ""))
        report.append("```")
report.append("")

# 3 AST
report.append("## 3. AST parse")
for path in important_files:
    if not path.exists():
        continue
    text = read(path)
    report.append(f"- [{ast_status(path, text)}] `{path.relative_to(ROOT)}`")
report.append("")

# 4 required main markers
report.append("## 4. Required main_window.py feature markers")
for group, markers in required_main_markers.items():
    missing = [m for m in markers if m not in main_text]
    if missing:
        report.append(f"- [WARN] {group}: missing")
        for m in missing:
            report.append(f"  - `{m}`")
    else:
        report.append(f"- [OK] {group}")
report.append("")

# 5 required exporter markers
report.append("## 5. Required poster_exporter.py markers")
for group, markers in required_exporter_markers.items():
    missing = [m for m in markers if m not in exporter_text]
    if missing:
        report.append(f"- [WARN] {group}: missing")
        for m in missing:
            report.append(f"  - `{m}`")
    else:
        report.append(f"- [OK] {group}")
report.append("")

# 6 old terms
report.append("## 6. Old visible term counts")
for term in old_visible_terms:
    report.append(f"- `{term}`: {main_text.count(term)}")
report.append("")

old_rows = grep_lines(main_text, old_visible_terms)
report.append("## 7. Old visible term contexts")
if old_rows:
    report.append("```text")
    report.append("\n".join(old_rows[:200]))
    report.append("```")
else:
    report.append("- [OK] No old visible terms found.")
report.append("")

# 8 duplicate funcs
report.append("## 8. Duplicate function checks")
for fn in [
    "_create_log_panel",
    "_create_central_ui",
    "_create_quick_toolbar",
    "export_print_pdf",
    "print_pdf",
    "update_tiling_preview",
    "_export_workspace_to_separate_pdfs",
]:
    defs = function_defs(main_text, fn)
    status = "OK" if len(defs) == 1 else "WARN"
    report.append(f"- [{status}] `{fn}`: {len(defs)} definition(s)")
    for start, end in defs:
        report.append(f"  - lines {start}-{end} ({end-start+1} lines)")
report.append("")

# 9 UI lines
report.append("## 9. Key UI lines")
ui_terms = [
    "Open PDFs",
    "Create Poster PDF",
    "Create Single Page PDF",
    "Open Exports Folder",
    "Source PDFs",
    "Print Order",
    "Build Print Order",
    "Output Files",
    "One PDF",
    "Separate PDF per selected page",
    "Poster Print Mode",
    "Single Page Mode",
    "Tiling Preview",
    "Poster Size Preset",
    "Output Paper Size",
    "Poster Scale",
]
rows = grep_lines(main_text, ui_terms)
report.append("```text")
report.append("\n".join(rows[:500]))
report.append("```")
report.append("")

# 10 exporter quality/raster
report.append("## 10. Exporter vector/raster references")
rows = grep_lines(exporter_text, [
    "show_pdf_page",
    "insert_image",
    "_render_tile_to_a4",
    "quality_scale",
    "poster_scale",
    "paper_size",
])
report.append("```text")
report.append("\n".join(rows[:300]))
report.append("```")
report.append("")

# 11 clutter
report.append("## 11. Patch/backup clutter")
patch_scripts = sorted(ROOT.glob("patch_*.py")) + sorted(ROOT.glob("fix_*.py")) + sorted(ROOT.glob("audit_*.py")) + sorted(ROOT.glob("*check*.py"))
backup_files = sorted((ROOT / "app").rglob("*.bak_*")) if (ROOT / "app").exists() else []
report.append(f"- root patch/fix/audit/check scripts: {len(patch_scripts)}")
for p in patch_scripts[:100]:
    report.append(f"  - `{p.name}`")
if len(patch_scripts) > 100:
    report.append(f"  - ... and {len(patch_scripts)-100} more")
report.append(f"- app backup files: {len(backup_files)}")
for p in backup_files[:100]:
    report.append(f"  - `{p.relative_to(ROOT)}`")
if len(backup_files) > 100:
    report.append(f"  - ... and {len(backup_files)-100} more")
report.append("")

# 12 summary
report.append("## 12. Summary")
if compile_failed:
    report.append("- Overall: **FAILED**")
    report.append("- Reason: py_compile failure.")
else:
    report.append("- Overall: **CHECK COMPLETE**")
    report.append("- Review WARN items. If warnings are only internal compatibility names or cleanup scripts, release testing can continue.")
report.append("")
report.append("## 13. Recommended manual tests")
report.append("1. Open one PDF and create Poster PDF: A4 100%, A3 preset, A2 preset.")
report.append("2. Open multiple PDFs, Auto Select All Pages, Build Print Order.")
report.append("3. Output Files = One PDF, Create Poster PDF.")
report.append("4. Output Files = Separate PDF per selected page, Create Poster PDF.")
report.append("5. Create Single Page PDF with One PDF and Separate outputs.")
report.append("6. Save Project As, close app, reopen project, verify Source PDFs / Print Order / Poster settings.")
report.append("7. Confirm exported PDF opens automatically.")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Final release check report written: {OUT}")
print("Paste final_release_check_report.txt here.")
