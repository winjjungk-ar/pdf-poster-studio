﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
TARGET = ROOT / "app" / "main_window.py"

if not TARGET.exists():
    print(f"[ERROR] Not found: {TARGET}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = TARGET.with_name(f"main_window.py.bak_{timestamp}")
shutil.copy2(TARGET, backup)
print(f"[OK] Backup created: {backup}")

text = TARGET.read_text(encoding="utf-8", errors="replace")
original = text

# 1) Import QSplitter if missing
if "QSplitter" not in text:
    # Add QSplitter after QScrollArea in PyQt6.QtWidgets import block
    text = text.replace(
        "    QScrollArea,\n",
        "    QScrollArea,\n    QSplitter,\n",
        1
    )
    print("[OK] Added QSplitter import")
else:
    print("[SKIP] QSplitter already imported")

# 2) Replace right panel fixed-width/root layout ending in _create_central_ui
old_block = """        settings_area.setMaximumWidth(520)
        settings_area.setMinimumWidth(420)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setWidget(settings_area)
        settings_scroll.setMinimumWidth(440)
        settings_scroll.setMaximumWidth(540)

        root_layout.addWidget(preview_area, 6)
        root_layout.addWidget(settings_scroll, 2)

        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()
"""

new_block = """        # Right settings panel is resizable through the main splitter.
        settings_area.setMinimumWidth(280)
        settings_area.setMaximumWidth(16777215)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setWidget(settings_area)
        settings_scroll.setMinimumWidth(300)
        settings_scroll.setMaximumWidth(760)

        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.main_splitter.setChildrenCollapsible(False)
        self.main_splitter.addWidget(preview_area)
        self.main_splitter.addWidget(settings_scroll)

        # Preview takes remaining space; settings panel can be resized by dragging.
        self.main_splitter.setStretchFactor(0, 1)
        self.main_splitter.setStretchFactor(1, 0)
        self.main_splitter.setSizes([1000, 360])

        root_layout.addWidget(self.main_splitter)

        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()
"""

count = text.count(old_block)

if count == 0:
    print("[ERROR] Target block not found. No patch applied.")
    TARGET.write_text(original, encoding="utf-8")
    sys.exit(1)

# There are duplicated similar blocks in extracted info.
# Patch only the first one, which belongs to _create_central_ui.
text = text.replace(old_block, new_block, 1)
print("[OK] Patched _create_central_ui layout ending")

TARGET.write_text(text, encoding="utf-8")
print(f"[OK] Written: {TARGET}")

# 3) Compile check
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(TARGET)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    print("[ERROR] py_compile failed")
    print(result.stdout)
    print(result.stderr)

    restore = TARGET.with_name(f"main_window.py.failed_{timestamp}")
    shutil.copy2(TARGET, restore)
    shutil.copy2(backup, TARGET)
    print(f"[RESTORED] Original restored from backup: {backup}")
    print(f"[INFO] Failed patched file saved as: {restore}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done. Run the app and drag the vertical splitter between preview and Basic Settings.")
