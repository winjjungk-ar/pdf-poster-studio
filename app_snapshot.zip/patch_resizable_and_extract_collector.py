﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# -----------------------------
# Part 1: Resizable Basic Settings patch
# -----------------------------
backup = MAIN.with_name(f"main_window.py.bak_resizable_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

if "QSplitter" not in text:
    text = text.replace(
        "    QScrollArea,\n",
        "    QScrollArea,\n    QSplitter,\n",
        1
    )
    print("[OK] Added QSplitter import")
else:
    print("[SKIP] QSplitter already imported")

old_block = """        settings_area.setMaximumWidth(520)
        settings_area.setMinimumWidth(420)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setWidget(settings_area)
        settings_scroll.setMinimumWidth(440)
        settings_scroll.setMaximumWidth(540)

        root_layout.addWidget(preview_area, 6)
        root_layout.addWidget(settings_scroll, 2)

        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()
"""

new_block = """        # Right settings panel is resizable through the main splitter.
        settings_area.setMinimumWidth(280)
        settings_area.setMaximumWidth(16777215)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setWidget(settings_area)
        settings_scroll.setMinimumWidth(300)
        settings_scroll.setMaximumWidth(760)

        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.main_splitter.setChildrenCollapsible(False)
        self.main_splitter.addWidget(preview_area)
        self.main_splitter.addWidget(settings_scroll)

        # Preview takes remaining space; settings panel can be resized by dragging.
        self.main_splitter.setStretchFactor(0, 1)
        self.main_splitter.setStretchFactor(1, 0)
        self.main_splitter.setSizes([1000, 360])

        root_layout.addWidget(self.main_splitter)

        self.setCentralWidget(central)
        self._update_page_buttons()
        self.update_export_option_states()
"""

if old_block in text:
    text = text.replace(old_block, new_block, 1)
    print("[OK] Patched _create_central_ui for QSplitter")
else:
    if "self.main_splitter = QSplitter(Qt.Orientation.Horizontal)" in text:
        print("[SKIP] QSplitter layout patch seems already applied")
    else:
        print("[WARN] Target layout block not found. Resizable patch not applied.")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile for main_window.py...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_resizable_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)
    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed patched file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")

# -----------------------------
# Part 2: Extract PDF collector / merge info
# -----------------------------
OUT = ROOT / "pdf_collector_extract.txt"

def read_file(path):
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        return f"<<READ ERROR: {exc}>>"

def line_no_from_pos(source, pos):
    return source.count("\n", 0, pos) + 1

def extract_function_block(source, func_name):
    pattern = re.compile(rf"^([ \t]*)def {re.escape(func_name)}\s*\(", re.M)
    m = pattern.search(source)
    if not m:
        return None

    indent = m.group(1)
    start = m.start()
    source_lines = source.splitlines(True)

    acc = 0
    start_idx = None
    for i, line in enumerate(source_lines):
        if acc == start:
            start_idx = i
            break
        acc += len(line)

    if start_idx is None:
        return None

    base_indent_len = len(indent)
    end_idx = len(source_lines)

    for j in range(start_idx + 1, len(source_lines)):
        raw = source_lines[j]
        stripped = raw.strip()
        if not stripped:
            continue
        current_indent_len = len(raw) - len(raw.lstrip(" \t"))
        if current_indent_len <= base_indent_len and (
            raw.lstrip().startswith("def ") or raw.lstrip().startswith("class ")
        ):
            end_idx = j
            break

    block = "".join(source_lines[start_idx:end_idx])
    return line_no_from_pos(source, start), line_no_from_pos(source, start) + block.count("\n"), block

def grep_file(path, patterns):
    source = read_file(path)
    rows = []
    for idx, line in enumerate(source.splitlines(), 1):
        for pat in patterns:
            if re.search(pat, line, re.I):
                rows.append(f"{idx:05d}: {line}")
                break
    return rows

collector_candidates = []
for p in ROOT.rglob("*.py"):
    name = p.name.lower()
    rel = str(p.relative_to(ROOT)).lower()
    if (
        "collector" in name
        or "collect" in name
        or "merge" in name
        or "pdf" in name
        or p == MAIN
    ):
        collector_candidates.append(p)

patterns = [
    r"collect",
    r"collector",
    r"merge",
    r"page range",
    r"page_range",
    r"ranges",
    r"fitz",
    r"insert_pdf",
    r"open.*created",
    r"open_pdf",
    r"QFileDialog",
    r"QDialog",
    r"QListWidget",
    r"QTableWidget",
    r"add.*pdf",
    r"create.*pdf",
]

func_names = [
    "collect_pages",
    "collect_pages_from_pdfs",
    "open_page_collector",
    "open_pdf_collector",
    "create_collected_pdf",
    "parse_page_ranges",
    "parse_page_range",
    "open_pdf",
    "_create_menu",
    "_create_menus",
    "create_menus",
    "_create_file_menu",
]

report = []
report.append("# pdf_collector_extract.txt")
report.append("")
report.append("## Environment")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py: {MAIN}")
report.append("")

report.append("## Candidate Python files")
for p in collector_candidates:
    report.append(f"- {p.relative_to(ROOT)}")
report.append("")

for p in collector_candidates:
    source = read_file(p)
    report.append(f"## File: {p.relative_to(ROOT)}")
    report.append(f"- lines: {len(source.splitlines())}")
    try:
        ast.parse(source)
        report.append("- ast.parse: OK")
    except SyntaxError as exc:
        report.append(f"- ast.parse: FAILED: {exc}")
    report.append("")

    rows = grep_file(p, patterns)
    report.append("### Keyword references")
    if rows:
        report.append("```text")
        report.append("\n".join(rows[:220]))
        report.append("```")
    else:
        report.append("(none)")
    report.append("")

    for fn in func_names:
        block = extract_function_block(source, fn)
        if block:
            s, e, code = block
            report.append(f"### Function: `{fn}` lines {s}-{e}")
            report.append("```python")
            report.append(code.rstrip())
            report.append("```")
            report.append("")

    # Extract likely classes
    class_matches = list(re.finditer(r"^class\s+([A-Za-z0-9_]+)", source, re.M))
    if class_matches:
        report.append("### Classes")
        for m in class_matches:
            report.append(f"- line {line_no_from_pos(source, m.start())}: `{m.group(1)}`")
        report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Extracted PDF collector info to: {OUT}")
print("")
print("NEXT:")
print("1. Run the app and check if Basic Settings panel is draggable.")
print("2. Paste pdf_collector_extract.txt here so I can patch the PDF merge/collector feature.")
