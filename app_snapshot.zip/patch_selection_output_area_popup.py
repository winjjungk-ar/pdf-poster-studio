﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_selection_popup_notice_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add one-time notice flag in __init__
# ------------------------------------------------------------
old = '''        self.rotation_degrees = 0
        self.current_display_base_width = 1
        self.current_display_base_height = 1

        self.setWindowTitle("PDF Poster Studio - Maps, Posters & Drawings")
'''

new = '''        self.rotation_degrees = 0
        self.current_display_base_width = 1
        self.current_display_base_height = 1

        # Show the manual-selection Output Area notice only once per app session.
        self._selection_output_area_notice_shown = False

        self.setWindowTitle("PDF Poster Studio - Maps, Posters & Drawings")
'''

if old in text and "_selection_output_area_notice_shown" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added one-time selection notice flag")
elif "_selection_output_area_notice_shown" in text:
    print("[SKIP] Selection notice flag already exists")
else:
    print("[WARN] Could not find __init__ insertion point")

# ------------------------------------------------------------
# 2) Add popup when manual selection switches Output Area to Selected Area
# ------------------------------------------------------------
old = '''                if hasattr(self, "output_area_combo") and self.output_area_combo.currentData() != "selected_area":
                    self._apply_combo_data(self.output_area_combo, "selected_area")
                    self.update_output_area_states()
                    self._log("Output Area automatically changed to Selected Area.")

                self.page_selections[self.current_page_index] = QRect(rect)
'''

new = '''                if hasattr(self, "output_area_combo") and self.output_area_combo.currentData() != "selected_area":
                    self._apply_combo_data(self.output_area_combo, "selected_area")
                    self.update_output_area_states()
                    self._log("Output Area automatically changed to Selected Area.")

                    if not getattr(self, "_selection_output_area_notice_shown", False):
                        self._selection_output_area_notice_shown = True
                        QMessageBox.information(
                            self,
                            "Output Area Changed",
                            "Output Area changed to Selected Area.\\n\\n"
                            "Because you selected an area manually, the output will use "
                            "the selected area instead of the whole page."
                        )

                self.page_selections[self.current_page_index] = QRect(rect)
'''

if old in text and "Output Area Changed" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added one-time popup for manual selection Output Area change")
elif "Output Area Changed" in text:
    print("[SKIP] Popup notice already exists")
else:
    print("[ERROR] Could not find auto Selected Area switch block")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 3) Release Notes update
# ------------------------------------------------------------
if "Manual selection notice" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.5</h3>
<ul>
  <li><b>Manual selection notice</b>: When a manual selection changes Output Area to Selected Area, a one-time notice is shown.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_selection_popup_notice_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "_selection_output_area_notice_shown",
    "Output Area Changed",
    "Manual selection notice",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Manual selection now shows a one-time popup when Output Area changes to Selected Area")
