﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_toolbar_create_pdf_buttons_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add export helper methods
# ------------------------------------------------------------
methods = r'''
    def create_poster_pdf(self) -> None:
        if hasattr(self, "export_type_combo"):
            self._apply_combo_data(self.export_type_combo, "a3_split")
            self.update_export_option_states()

        self.export_print_pdf(skip_type_prompt=True)

    def create_single_page_pdf(self) -> None:
        if hasattr(self, "export_type_combo"):
            self._apply_combo_data(self.export_type_combo, "selection_only")
            self.update_export_option_states()

        self.export_print_pdf(skip_type_prompt=True)

'''

if "def create_poster_pdf" not in text:
    marker = "    def export_print_pdf("
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find export_print_pdf insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + methods + "\n" + text[pos:]
    print("[OK] Added create_poster_pdf / create_single_page_pdf")
else:
    print("[SKIP] Create PDF helper methods already exist")

# ------------------------------------------------------------
# 2) Change export_print_pdf signature and prompt behavior
# ------------------------------------------------------------
old = '''    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        if not self._prompt_export_type():
            return
'''

new = '''    def export_print_pdf(self, skip_type_prompt: bool = False) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        if not skip_type_prompt:
            if not self._prompt_export_type():
                return
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] export_print_pdf now supports skip_type_prompt")
else:
    if "skip_type_prompt" in text:
        print("[SKIP] export_print_pdf already supports skip_type_prompt")
    else:
        print("[ERROR] Could not patch export_print_pdf signature")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 3) Replace toolbar Export PDF action with two clearer actions
# ------------------------------------------------------------
old = '''        export_action = QAction("Export PDF", self)
        export_action.triggered.connect(self.export_print_pdf)
        toolbar.addAction(export_action)

        open_exports_folder_action = QAction("Open Exports Folder", self)
'''

new = '''        create_poster_action = QAction("Create Poster PDF", self)
        create_poster_action.triggered.connect(self.create_poster_pdf)
        toolbar.addAction(create_poster_action)

        create_single_page_action = QAction("Create Single Page PDF", self)
        create_single_page_action.triggered.connect(self.create_single_page_pdf)
        toolbar.addAction(create_single_page_action)

        open_exports_folder_action = QAction("Open Exports Folder", self)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Toolbar Export PDF replaced with Create Poster/Single Page buttons")
else:
    if "Create Poster PDF" in text:
        print("[SKIP] Toolbar already has Create Poster PDF")
    else:
        print("[ERROR] Could not find toolbar Export PDF action")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# ------------------------------------------------------------
# 4) Improve Export tab button text
# ------------------------------------------------------------
text = text.replace(
    'export_button = QPushButton("Export PDF")',
    'export_button = QPushButton("Create PDF")',
    1
)

# Keep menu File > Export PDF as advanced/fallback.
# ------------------------------------------------------------

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_toolbar_create_pdf_buttons_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "def create_poster_pdf",
    "def create_single_page_pdf",
    "skip_type_prompt",
    'QAction("Create Poster PDF", self)',
    'QAction("Create Single Page PDF", self)',
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Toolbar now has Create Poster PDF and Create Single Page PDF")
print("- These buttons skip the mode-selection popup")
print("- Output Files option still controls One PDF vs Separate PDFs")
print("- File > Export PDF remains as fallback with mode prompt")
