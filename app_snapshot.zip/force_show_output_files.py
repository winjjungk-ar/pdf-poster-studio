﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_force_show_output_files_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Force visibility back on
# ------------------------------------------------------------
text = text.replace("self.batch_output_combo.setVisible(False)", "self.batch_output_combo.setVisible(True)")
text = text.replace("self.batch_output_label.setVisible(False)", "self.batch_output_label.setVisible(True)")

# ------------------------------------------------------------
# 2) Rename display text if old items remain
# ------------------------------------------------------------
text = text.replace(
    'self.batch_output_combo.addItem("Single PDF", "single_pdf")',
    'self.batch_output_combo.addItem("One PDF", "single_pdf")'
)
text = text.replace(
    'self.batch_output_combo.addItem("Separate PDF per checked page", "separate_pdf_per_page")',
    'self.batch_output_combo.addItem("Separate PDF per selected page", "separate_pdf_per_page")'
)

# ------------------------------------------------------------
# 3) If label block exists but says Batch Output, rename it
# ------------------------------------------------------------
text = text.replace('QLabel("Batch Output")', 'QLabel("Output Files")')
text = text.replace('self.batch_output_label = QLabel("Batch Output")', 'self.batch_output_label = QLabel("Output Files")')

# ------------------------------------------------------------
# 4) Ensure active Export tab has visible Output Files label+combo
# ------------------------------------------------------------
# Case A: existing hidden label block
if "self.batch_output_label = QLabel(\"Output Files\")" in text:
    print("[OK] Output Files label object exists")
else:
    # Replace direct layout block if present
    old = '''        export_layout.addWidget(QLabel("Output Files"))
        export_layout.addWidget(self.batch_output_combo)
'''
    new = '''        self.batch_output_label = QLabel("Output Files")
        self.batch_output_label.setVisible(True)
        self.batch_output_combo.setVisible(True)
        export_layout.addWidget(self.batch_output_label)
        export_layout.addWidget(self.batch_output_combo)
'''
    if old in text:
        text = text.replace(old, new, 1)
        print("[OK] Converted direct Output Files label to visible instance label")
    else:
        # Insert before Print Quality in active export tab
        anchor = '''        export_layout.addWidget(QLabel("Print Quality"))
        export_layout.addWidget(self.print_quality_combo)
'''
        insert = '''        self.batch_output_label = QLabel("Output Files")
        self.batch_output_label.setVisible(True)
        self.batch_output_combo.setVisible(True)
        export_layout.addWidget(self.batch_output_label)
        export_layout.addWidget(self.batch_output_combo)

        export_layout.addWidget(QLabel("Print Quality"))
        export_layout.addWidget(self.print_quality_combo)
'''
        if anchor in text:
            text = text.replace(anchor, insert, 1)
            print("[OK] Inserted Output Files block before Print Quality")
        else:
            print("[WARN] Could not find Print Quality anchor")

# ------------------------------------------------------------
# 5) Remove old comment saying it is hidden
# ------------------------------------------------------------
text = text.replace(
    "        # Kept internally for backward compatibility.\n        # The app now uses Print Order and normally creates one print-ready PDF.\n",
    ""
)

# ------------------------------------------------------------
# 6) Ensure export does NOT force single_pdf
# ------------------------------------------------------------
forced_block = '''        # Batch output UI is hidden. Use one print-ready PDF by default.
        if hasattr(self, "batch_output_combo"):
            self._apply_combo_data(self.batch_output_combo, "single_pdf")

'''
if forced_block in text:
    text = text.replace(forced_block, "", 1)
    print("[OK] Removed hidden-batch forced single_pdf block")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 7) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_force_show_output_files_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Visibility/code check:")
for term in [
    'self.batch_output_label = QLabel("Output Files")',
    'self.batch_output_label.setVisible(True)',
    'self.batch_output_combo.setVisible(True)',
    'addItem("One PDF", "single_pdf")',
    'addItem("Separate PDF per selected page", "separate_pdf_per_page")',
]:
    print(f"  - {term}: {term in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Output Files should now be visible in the Export tab")
print("- Options: One PDF / Separate PDF per selected page")
