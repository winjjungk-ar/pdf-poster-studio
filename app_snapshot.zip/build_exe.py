﻿from pathlib import Path
from datetime import datetime
import subprocess
import sys
import shutil
import os

ROOT = Path.cwd()
MAIN = ROOT / "main.py"
APP_DIR = ROOT / "app"
BUILD_DIR = ROOT / "build"
DIST_DIR = ROOT / "dist"
SPEC_PATH = ROOT / "PDF_Poster_Studio.spec"
ICON_PY = ROOT / "create_icon_for_build.py"

APP_NAME = "PDF Poster Studio"

if not MAIN.exists():
    print(f"[ERROR] main.py not found: {MAIN}")
    sys.exit(1)

if not APP_DIR.exists():
    print(f"[ERROR] app folder not found: {APP_DIR}")
    sys.exit(1)

print(f"[INFO] Root: {ROOT}")
print(f"[INFO] Python: {sys.executable}")

# ------------------------------------------------------------
# 1) Check PyInstaller
# ------------------------------------------------------------
print("[INFO] Checking PyInstaller...")
check = subprocess.run(
    [sys.executable, "-m", "PyInstaller", "--version"],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if check.returncode != 0:
    print("[WARN] PyInstaller is not installed.")
    print("[INFO] Installing PyInstaller...")
    install = subprocess.run(
        [sys.executable, "-m", "pip", "install", "pyinstaller"],
        cwd=str(ROOT),
        text=True,
    )

    if install.returncode != 0:
        print("[ERROR] Failed to install PyInstaller.")
        sys.exit(1)
else:
    print(f"[OK] PyInstaller version: {check.stdout.strip()}")

# ------------------------------------------------------------
# 2) Create app icon
# ------------------------------------------------------------
icon_path = ROOT / "app_icon.ico"

icon_code = r'''
from pathlib import Path
from PyQt6.QtGui import QPixmap, QPainter, QColor, QPen, QBrush, QFont, QIcon
from PyQt6.QtWidgets import QApplication
import sys

app = QApplication(sys.argv)

out = Path("app_icon.ico")

pixmap = QPixmap(256, 256)
pixmap.fill(QColor("#00000000"))

p = QPainter(pixmap)
p.setRenderHint(QPainter.RenderHint.Antialiasing)

# Background
p.setBrush(QBrush(QColor("#DDF3F5")))
p.setPen(QPen(QColor("#8CCFD6"), 8))
p.drawEllipse(12, 12, 232, 232)

# Paper
p.setBrush(QBrush(QColor("#FFFFFF")))
p.setPen(QPen(QColor("#5F7F95"), 7))
p.drawRoundedRect(70, 38, 116, 164, 16, 16)

# Poster split lines
p.setPen(QPen(QColor("#8EA7FF"), 7))
p.drawLine(128, 60, 128, 180)
p.drawLine(88, 120, 168, 120)

# Selection rectangle
p.setBrush(QBrush(QColor(255, 188, 120, 110)))
p.setPen(QPen(QColor("#FF9F68"), 7))
p.drawRoundedRect(88, 82, 80, 70, 12, 12)

# PDF text
p.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
p.setPen(QColor("#395B64"))
p.drawText(78, 218, "PDF")

p.end()

icon = QIcon(pixmap)
icon.addPixmap(pixmap)
icon_engine_sizes = [16, 24, 32, 48, 64, 128, 256]
icon.save(str(out))

print(f"[OK] Icon created: {out.resolve()}")
'''

ICON_PY.write_text(icon_code, encoding="utf-8")

print("[INFO] Creating icon...")
icon_result = subprocess.run(
    [sys.executable, str(ICON_PY)],
    cwd=str(ROOT),
    text=True,
)

if icon_result.returncode != 0 or not icon_path.exists():
    print("[WARN] Icon creation failed. Build will continue without custom icon.")
    icon_arg = ""
else:
    icon_arg = str(icon_path)

# ------------------------------------------------------------
# 3) Clean old build/dist
# ------------------------------------------------------------
print("[INFO] Cleaning old build/dist...")
for path in [BUILD_DIR, DIST_DIR]:
    if path.exists():
        shutil.rmtree(path)
        print(f"[OK] Removed: {path}")

if SPEC_PATH.exists():
    SPEC_PATH.unlink()
    print(f"[OK] Removed old spec: {SPEC_PATH}")

# ------------------------------------------------------------
# 4) Build command
# ------------------------------------------------------------
cmd = [
    sys.executable,
    "-m",
    "PyInstaller",
    "--noconfirm",
    "--windowed",
    "--name",
    APP_NAME,
]

if icon_arg:
    cmd.extend(["--icon", icon_arg])

# Add package/data folders if needed.
# PyInstaller will collect Python modules automatically.
cmd.extend([
    "--add-data",
    f"{APP_DIR};app",
])

# Exclude dev archive if present.
cmd.extend([
    "--exclude-module",
    "tkinter",
])

cmd.append(str(MAIN))

print("[INFO] Running PyInstaller...")
print(" ".join(f'"{x}"' if " " in x else x for x in cmd))

build = subprocess.run(
    cmd,
    cwd=str(ROOT),
    text=True,
)

if build.returncode != 0:
    print("[ERROR] PyInstaller build failed.")
    sys.exit(build.returncode)

# ------------------------------------------------------------
# 5) Create runtime folders beside EXE
# ------------------------------------------------------------
exe_dir = DIST_DIR / APP_NAME
if not exe_dir.exists():
    print(f"[WARN] Expected dist folder not found: {exe_dir}")
else:
    for name in ["data", "exports", "projects"]:
        folder = exe_dir / name
        folder.mkdir(parents=True, exist_ok=True)
        print(f"[OK] Runtime folder ready: {folder}")

exe_path = exe_dir / f"{APP_NAME}.exe"

print("")
if exe_path.exists():
    print("[OK] Build completed.")
    print(f"EXE: {exe_path}")
else:
    print("[WARN] Build finished but EXE path not found:")
    print(exe_path)

print("")
print("Next test:")
print(f'& "{exe_path}"')
