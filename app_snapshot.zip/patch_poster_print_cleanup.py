﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

main_backup = MAIN.with_name(f"main_window.py.bak_poster_print_cleanup_{timestamp}")
exporter_backup = EXPORTER.with_name(f"poster_exporter.py.bak_poster_print_cleanup_{timestamp}")

shutil.copy2(MAIN, main_backup)
shutil.copy2(EXPORTER, exporter_backup)

print(f"[OK] Backup created: {main_backup}")
print(f"[OK] Backup created: {exporter_backup}")

# ------------------------------------------------------------
# 1) main_window.py user-facing rename
# ------------------------------------------------------------
main_text = MAIN.read_text(encoding="utf-8", errors="replace")
original_main = main_text

replacements = [
    ('self.export_type_combo.addItem("A3 Split Mode", "a3_split")',
     'self.export_type_combo.addItem("Poster Print Mode", "a3_split")'),

    ('self.settings_tabs.addTab(self.a3_split_group, "A3 Split")',
     'self.settings_tabs.addTab(self.a3_split_group, "Poster Print")'),

    ('"A3 Split Mode"', '"Poster Print Mode"'),
    ('A3 Split Mode', 'Poster Print Mode'),
    ('A3 split options', 'Poster Print options'),
    ('A3 Split', 'Poster Print'),
    ('A3_split', 'poster_print'),
    ('_A3_split_A4.pdf', '_poster_print.pdf'),
]

changed = 0
for old, new in replacements:
    c = main_text.count(old)
    if c:
        main_text = main_text.replace(old, new)
        changed += c
        print(f"[OK] main replace {c}: {old} -> {new}")

# Rename A3 layout group variable names? Do NOT rename internal variable self.a3_split_group for safety.
# Fix any accidental filename/case oddity only if present.
main_text = main_text.replace("_poster_print_A4.pdf", "_poster_print.pdf")

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 2) poster_exporter.py: always use poster tiling for Poster Print/a3_split
# ------------------------------------------------------------
exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace")
original_exporter = exporter_text

old_route = '''        # Keep legacy 2-sheet behavior for the current default A4 / 100% mode.
        # New poster tiling is activated by UI later when paper_size or poster_scale changes.
        paper_size = str(getattr(options, "paper_size", "a4") or "a4").lower()
        poster_scale = float(getattr(options, "poster_scale", 1.0) or 1.0)

        if paper_size != "a4" or abs(poster_scale - 1.0) > 0.000001:
            self._export_poster_tiling(src_doc, out_doc, selections, options)
            return

        sheet_total = len(selections) * 2
'''

new_route = '''        # Poster Print mode now always uses the scalable tiling engine.
        # This keeps Estimated Sheets and actual exported pages consistent.
        self._export_poster_tiling(src_doc, out_doc, selections, options)
        return

        sheet_total = len(selections) * 2
'''

if old_route in exporter_text:
    exporter_text = exporter_text.replace(old_route, new_route, 1)
    print("[OK] Exporter now always uses poster tiling for poster print mode")
else:
    # Fallback: replace just after function header if previous route shape changed.
    marker = '''    def _export_a3_split(
        self,
        src_doc: fitz.Document,
        out_doc: fitz.Document,
        selections: dict[int, SelectionRect],
        options: ExportOptions,
    ) -> None:
'''
    pos = exporter_text.find(marker)
    if pos != -1 and "Poster Print mode now always uses the scalable tiling engine" not in exporter_text[pos:pos+600]:
        insert_pos = pos + len(marker)
        exporter_text = (
            exporter_text[:insert_pos]
            + '''        # Poster Print mode now always uses the scalable tiling engine.
        # This keeps Estimated Sheets and actual exported pages consistent.
        self._export_poster_tiling(src_doc, out_doc, selections, options)
        return

'''
            + exporter_text[insert_pos:]
        )
        print("[OK] Exporter route patched by fallback")
    else:
        print("[SKIP] Exporter route already patched or marker not found")

# ------------------------------------------------------------
# 3) Move poster tiling sheet numbers to top margin outside printable content
# ------------------------------------------------------------
old_numbering_rect = '''        rect = fitz.Rect(
            8 * MM_TO_PT,
            page_height - 12 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            page_height - 5 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=8,
            fontname="helv",
            color=(0.1, 0.1, 0.1),
            align=fitz.TEXT_ALIGN_RIGHT,
        )
'''

new_numbering_rect = '''        # Place sheet number in the top margin, outside the main printable content.
        rect = fitz.Rect(
            8 * MM_TO_PT,
            1.5 * MM_TO_PT,
            page_width - 8 * MM_TO_PT,
            5.0 * MM_TO_PT,
        )

        page.insert_textbox(
            rect,
            text,
            fontsize=7,
            fontname="helv",
            color=(0.35, 0.35, 0.35),
            align=fitz.TEXT_ALIGN_RIGHT,
        )
'''

# Replace only first occurrence in _draw_poster_tiling_numbering if possible.
fn_pos = exporter_text.find("    def _draw_poster_tiling_numbering(")
if fn_pos != -1:
    next_fn = exporter_text.find("\n    def ", fn_pos + 10)
    if next_fn == -1:
        next_fn = len(exporter_text)

    segment = exporter_text[fn_pos:next_fn]

    if old_numbering_rect in segment:
        segment = segment.replace(old_numbering_rect, new_numbering_rect, 1)
        exporter_text = exporter_text[:fn_pos] + segment + exporter_text[next_fn:]
        print("[OK] Poster tiling sheet numbers moved to top margin")
    elif "top margin, outside the main printable content" in segment:
        print("[SKIP] Poster tiling numbering already moved")
    else:
        print("[WARN] Could not find poster tiling numbering rect block")
else:
    print("[WARN] _draw_poster_tiling_numbering not found")

# Also move legacy _draw_numbering if it still gets used anywhere.
legacy_pos = exporter_text.find("    def _draw_numbering(")
if legacy_pos != -1:
    next_fn = exporter_text.find("\n    def ", legacy_pos + 10)
    if next_fn == -1:
        next_fn = len(exporter_text)

    segment = exporter_text[legacy_pos:next_fn]

    if old_numbering_rect in segment:
        segment = segment.replace(old_numbering_rect, new_numbering_rect, 1)
        exporter_text = exporter_text[:legacy_pos] + segment + exporter_text[next_fn:]
        print("[OK] Legacy sheet numbers moved to top margin")
    else:
        print("[SKIP] Legacy numbering block not changed")

EXPORTER.write_text(exporter_text, encoding="utf-8")

# ------------------------------------------------------------
# 4) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup, original_name in [
    (MAIN, main_backup, "main_window.py"),
    (EXPORTER, exporter_backup, "poster_exporter.py"),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_poster_print_cleanup_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {original_name}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 5) verification
# ------------------------------------------------------------
main_new = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_new = EXPORTER.read_text(encoding="utf-8", errors="replace")

checks = [
    ("main", "Poster Print Mode", "Poster Print Mode" in main_new),
    ("main", "Poster Print tab", "Poster Print" in main_new),
    ("exporter", "always tiling route", "Poster Print mode now always uses the scalable tiling engine" in exporter_new),
    ("exporter", "top margin numbering", "top margin, outside the main printable content" in exporter_new),
]

failed = [name for scope, name, ok in checks if not ok]

if failed:
    print("[WARN] Some checks failed:")
    for name in failed:
        print(f"  - {name}")
else:
    print("[OK] Verification checks passed")

print("")
print("Done.")
print("- A3 Split user-facing text renamed to Poster Print")
print("- Poster Print export now always uses scalable tiling")
print("- Estimated Sheets and actual output page count should now match")
print("- Sheet numbers moved to top margin outside the main content")
