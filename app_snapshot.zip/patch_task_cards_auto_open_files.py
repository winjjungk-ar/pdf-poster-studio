﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_task_auto_open_files_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

# ------------------------------------------------------------
# 1) Make Poster: auto-open files if no source exists
# ------------------------------------------------------------
new_task_make_poster = r'''    def task_make_poster(self) -> None:
        if not hasattr(self, "workspace_items") or not self.workspace_items:
            self.open_pdfs()

            if not hasattr(self, "workspace_items") or not self.workspace_items:
                return

        self._set_combo_by_data_if_exists("export_type_combo", "a3_split")

        dialog = QMessageBox(self)
        dialog.setWindowTitle("Make Poster")
        dialog.setIcon(QMessageBox.Icon.Question)
        dialog.setText("What area do you want to use for the poster?")
        dialog.setInformativeText(
            "Whole Page uses the full page or image.\n\n"
            "Selected Area uses only the area you select in the preview."
        )

        whole_button = dialog.addButton("Use Whole Page", QMessageBox.ButtonRole.AcceptRole)
        selected_button = dialog.addButton("Use Selected Area", QMessageBox.ButtonRole.ActionRole)
        cancel_button = dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        dialog.setDefaultButton(whole_button)
        dialog.exec()

        clicked = dialog.clickedButton()

        if clicked == cancel_button:
            return

        if clicked == whole_button:
            self._set_combo_by_data_if_exists("output_area_combo", "whole_page")
            area_message = (
                "Output Area set to Whole Page.\n\n"
                "Choose Poster Size Preset, check Tiling Preview, then click Poster PDF in the toolbar."
            )
        elif clicked == selected_button:
            self._set_combo_by_data_if_exists("output_area_combo", "selected_area")
            area_message = (
                "Output Area set to Selected Area.\n\n"
                "Drag to select an area or use Auto Select, then Build Print Order and click Poster PDF."
            )
        else:
            return

        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()

        if hasattr(self, "settings_tabs") and hasattr(self, "a3_split_group"):
            self.settings_tabs.setCurrentWidget(self.a3_split_group)

        QMessageBox.information(
            self,
            "Make Poster",
            area_message
        )

'''

try:
    text = replace_function(text, "task_make_poster", new_task_make_poster)
    print("[OK] Make Poster now opens files automatically if needed")
except Exception as exc:
    print(f"[ERROR] Failed to replace task_make_poster: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 2) Selected Area PDF: auto-open files if no source exists
# ------------------------------------------------------------
new_task_selected_area = r'''    def task_selected_area_pdf(self) -> None:
        if not hasattr(self, "workspace_items") or not self.workspace_items:
            self.open_pdfs()

            if not hasattr(self, "workspace_items") or not self.workspace_items:
                return

        self._set_combo_by_data_if_exists("output_area_combo", "selected_area")
        self._set_combo_by_data_if_exists("export_type_combo", "selection_only")
        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()

        dialog = QMessageBox(self)
        dialog.setWindowTitle("Selected Area PDF")
        dialog.setIcon(QMessageBox.Icon.Question)
        dialog.setText("How do you want to select the area?")
        dialog.setInformativeText(
            "Auto Select detects the content area on the current page.\n\n"
            "Select Manually lets you drag an area in the preview."
        )

        auto_button = dialog.addButton("Auto Select Current Page", QMessageBox.ButtonRole.AcceptRole)
        manual_button = dialog.addButton("Select Manually", QMessageBox.ButtonRole.ActionRole)
        cancel_button = dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        dialog.setDefaultButton(auto_button)
        dialog.exec()

        clicked = dialog.clickedButton()

        if clicked == cancel_button:
            return

        if hasattr(self, "settings_tabs") and hasattr(self, "selection_only_group"):
            self.settings_tabs.setCurrentWidget(self.selection_only_group)

        if clicked == auto_button:
            if self.page_count <= 0:
                QMessageBox.information(
                    self,
                    "Selected Area PDF",
                    "Please open a PDF or image first."
                )
                return

            self.auto_select_content()

            QMessageBox.information(
                self,
                "Selected Area PDF",
                "Auto Select completed for the current page.\n\n"
                "Click Build Print Order, then click Single Page PDF in the toolbar."
            )
            return

        if clicked == manual_button:
            QMessageBox.information(
                self,
                "Selected Area PDF",
                "Drag on the preview to select an area.\n\n"
                "Then click Build Print Order and click Single Page PDF in the toolbar."
            )

'''

try:
    text = replace_function(text, "task_selected_area_pdf", new_task_selected_area)
    print("[OK] Selected Area PDF now opens files automatically if needed")
except Exception as exc:
    print(f"[ERROR] Failed to replace task_selected_area_pdf: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 3) Optional: make Merge / Extract / Rotate also open directly instead of asking
# ------------------------------------------------------------
text = text.replace(
'''        if not hasattr(self, "workspace_items") or not self.workspace_items:
            result = QMessageBox.question(
                self,
                "Merge PDFs",
                "Merge PDFs combines full pages into one PDF.\\n\\n"
                "No source files are open yet.\\n\\n"
                "Open PDFs / Images now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result == QMessageBox.StandardButton.Yes:
                self.open_pdfs()

            return
''',
'''        if not hasattr(self, "workspace_items") or not self.workspace_items:
            self.open_pdfs()

            if not hasattr(self, "workspace_items") or not self.workspace_items:
                return
'''
)

text = text.replace(
'''        if not hasattr(self, "workspace_items") or not self.workspace_items:
            result = QMessageBox.question(
                self,
                "Extract Pages",
                "Extract Pages uses full pages from source files.\\n\\n"
                "No source files are open yet.\\n\\n"
                "Open PDFs / Images now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result == QMessageBox.StandardButton.Yes:
                self.open_pdfs()

            return
''',
'''        if not hasattr(self, "workspace_items") or not self.workspace_items:
            self.open_pdfs()

            if not hasattr(self, "workspace_items") or not self.workspace_items:
                return
'''
)

text = text.replace(
'''        if self.page_count <= 0:
            result = QMessageBox.question(
                self,
                "Rotate Pages",
                "No source file is open yet.\\n\\nOpen PDFs / Images now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if result == QMessageBox.StandardButton.Yes:
                self.open_pdfs()

            return
''',
'''        if self.page_count <= 0:
            self.open_pdfs()

            if self.page_count <= 0:
                return
'''
)

# ------------------------------------------------------------
# 4) Release Notes
# ------------------------------------------------------------
if "Task cards open files automatically" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Task cards open files automatically</b>: Home and startup task cards now open the file picker when no source files are loaded.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 5) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_task_auto_open_files_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Task cards open files automatically",
    "self.open_pdfs()",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Task cards now open the file picker automatically when no files are loaded")
print("- Startup task launcher should feel more direct")
