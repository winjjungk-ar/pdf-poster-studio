﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_toolbar_short_labels_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

replacements = [
    ('QAction("Auto Select Current Page", self)', 'QAction("Auto Current", self)'),
    ('QAction("Auto Select All Pages", self)', 'QAction("Auto All", self)'),
    ('QAction("Auto Select Page Range", self)', 'QAction("Auto Range", self)'),
    ('QAction("Clear All Selections", self)', 'QAction("Clear Selections", self)'),
    ('QAction("Create Poster PDF", self)', 'QAction("Poster PDF", self)'),
    ('QAction("Create Single Page PDF", self)', 'QAction("Single Page PDF", self)'),
    ('QAction("Open Exports Folder", self)', 'QAction("Exports Folder", self)'),
]

changed = 0

for old, new in replacements:
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        changed += count
        print(f"[OK] Replaced {count}: {old} -> {new}")

# Add/adjust tooltips if needed.
tooltip_replacements = [
    ('self.auto_current_action.setToolTip(enabled_tip_current if is_selected_area else disabled_tip)',
     'self.auto_current_action.setToolTip(enabled_tip_current if is_selected_area else disabled_tip)'),

    ('self.auto_all_action.setToolTip(enabled_tip_all if is_selected_area else disabled_tip)',
     'self.auto_all_action.setToolTip(enabled_tip_all if is_selected_area else disabled_tip)'),
]

# Explicit toolbar action tooltips for create buttons if markers exist.
text = text.replace(
    '''        create_poster_action = QAction("Poster PDF", self)
        create_poster_action.triggered.connect(self.create_poster_pdf)
        toolbar.addAction(create_poster_action)
''',
    '''        create_poster_action = QAction("Poster PDF", self)
        create_poster_action.setToolTip("Create a tiled poster PDF")
        create_poster_action.triggered.connect(self.create_poster_pdf)
        toolbar.addAction(create_poster_action)
''',
    1
)

text = text.replace(
    '''        create_single_page_action = QAction("Single Page PDF", self)
        create_single_page_action.triggered.connect(self.create_single_page_pdf)
        toolbar.addAction(create_single_page_action)
''',
    '''        create_single_page_action = QAction("Single Page PDF", self)
        create_single_page_action.setToolTip("Create clean single-page PDF output")
        create_single_page_action.triggered.connect(self.create_single_page_pdf)
        toolbar.addAction(create_single_page_action)
''',
    1
)

text = text.replace(
    '''        open_exports_folder_action = QAction("Exports Folder", self)
        open_exports_folder_action.triggered.connect(self.open_exports_folder)
        toolbar.addAction(open_exports_folder_action)
''',
    '''        open_exports_folder_action = QAction("Exports Folder", self)
        open_exports_folder_action.setToolTip("Open the exports folder")
        open_exports_folder_action.triggered.connect(self.open_exports_folder)
        toolbar.addAction(open_exports_folder_action)
''',
    1
)

# Release Notes
if "Toolbar labels shortened" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Toolbar labels shortened</b>: Main toolbar labels were shortened while keeping detailed tooltips.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_toolbar_short_labels_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    'QAction("Auto Current", self)',
    'QAction("Auto All", self)',
    'QAction("Auto Range", self)',
    'QAction("Poster PDF", self)',
    'QAction("Single Page PDF", self)',
    'Toolbar labels shortened',
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print(f"- Toolbar labels shortened, replacements applied: {changed}")
