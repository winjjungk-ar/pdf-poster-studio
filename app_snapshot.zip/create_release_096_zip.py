﻿from pathlib import Path
from datetime import datetime
import zipfile
import sys

ROOT = Path.cwd()
APP_NAME = "PDF Poster Studio"
VERSION = "0.9.6"

DIST_APP_DIR = ROOT / "dist" / APP_NAME
EXE_PATH = DIST_APP_DIR / f"{APP_NAME}.exe"
RELEASE_DIR = ROOT / "release"
ZIP_PATH = RELEASE_DIR / f"PDF_Poster_Studio_v{VERSION}_Beta_Windows.zip"

if not DIST_APP_DIR.exists():
    print(f"[ERROR] Dist folder not found: {DIST_APP_DIR}")
    print("You need to build the EXE first.")
    sys.exit(1)

if not EXE_PATH.exists():
    print(f"[ERROR] EXE not found: {EXE_PATH}")
    print("You need to build the EXE first.")
    sys.exit(1)

RELEASE_DIR.mkdir(parents=True, exist_ok=True)

readme = f"""PDF Poster Studio v{VERSION} Beta
====================================

PDF Poster Studio is a Windows desktop tool for creating print-ready PDFs from
PDF and image files.

Use cases:
- Print game maps across multiple pages
- Print TRPG / tabletop maps
- Create wall posters
- Print engineering drawings
- Make field work print packages
- Combine selected pages or areas from multiple PDFs/images

Supported input files:
- PDF
- PNG
- JPG / JPEG
- BMP
- WEBP

Main features:
- Open PDFs / Images
- Output Area:
  - Whole Page
  - Selected Area
- Home task launcher:
  - Merge PDFs
  - Extract Pages
  - Make Poster
  - Rotate Pages
  - Selected Area PDF
- Create Poster PDF
- Create Single Page PDF
- Output Files:
  - One PDF
  - Separate PDF per selected page
- A4 and US Letter output
- Poster presets:
  - Poster Small / Medium / Large / Huge
  - A3 / A2 / A1 / A0 from A4
  - ANSI B/C/D/E
  - Arch B/C/D/E
- Tiling Preview
- Auto Select Current Page
- Auto Select All Pages
- Auto Select Page Range
- Go to Page
- Find Text
- Page-specific rotation
- Project save/load
- Multilingual User Guide:
  - English
  - Korean
  - Japanese
  - Simplified Chinese

Quick start:
1. Run "PDF Poster Studio.exe"
2. Choose a task from the startup screen or Home tab
3. Open PDFs / Images
4. Build Print Order
5. Create Poster PDF or Single Page PDF

Output files:
- Generated PDFs are saved to the exports folder.
- Use "Open Exports Folder" in the toolbar.

Beta notes:
- This is a beta release for feedback.
- Large PDFs may take time to process.
- Use Auto Select Page Range for large PDFs.
- Image files are converted internally to temporary PDF pages.
- Original PDF/image files are not modified.
- Find Text works only with PDFs that already contain text.
  Scanned/image-only PDFs may require OCR in another tool.

Creator:
JI JEONG GEUN
"""

quick_start = f"""QUICK START - PDF Poster Studio v{VERSION} Beta
================================================

A. Make a poster
----------------
1. Choose "Make Poster".
2. Choose "Open One File" or "Use Current Source PDFs".
3. Choose Whole Page or Selected Area.
4. Choose paper size and poster preset.
5. Check Tiling Preview.
6. Build Print Order.
7. Click Poster PDF.

B. Merge PDFs
-------------
1. Choose "Merge PDFs".
2. Open PDFs / Images.
3. The app adds full pages to Print Order.
4. Click Single Page PDF.

C. Extract pages
----------------
1. Choose "Extract Pages".
2. Enter page range, e.g. all, 1-10, 1,3,5.
3. Choose Output Files mode.
4. Click Single Page PDF.

D. Rotate pages
---------------
1. Choose "Rotate Pages".
2. Choose Current Page, Checked Pages, or All Pages.
3. Choose Rotate Left / Rotate Right / Reset.
4. Click Single Page PDF to save rotated output.

E. Selected area PDF
--------------------
1. Choose "Selected Area PDF".
2. Auto select or manually select an area.
3. Build Print Order.
4. Click Single Page PDF.

F. Large PDFs
-------------
Use Auto Select Page Range instead of Auto Select All Pages.
Example: 1-20, 50-100, 1,3,5

G. Find output files
--------------------
Click Open Exports Folder.
"""

version_txt = f"""PDF Poster Studio
Version: {VERSION} Beta
Build date: {datetime.now().isoformat(timespec='seconds')}
Platform: Windows
Creator: JI JEONG GEUN

Release highlights:
- Task launcher startup screen
- Open PDFs and image files
- Whole Page / Selected Area
- Poster Print and Single Page output
- One PDF / Separate PDF output modes
- A4 / US Letter
- A-series / ANSI / Arch / Hobby poster presets
- Tiling Preview
- Auto Select Page Range
- Page-specific rotation
- Multilingual User Guide
"""

(DIST_APP_DIR / "README.txt").write_text(readme, encoding="utf-8")
(DIST_APP_DIR / "QUICK_START.txt").write_text(quick_start, encoding="utf-8")
(DIST_APP_DIR / "VERSION.txt").write_text(version_txt, encoding="utf-8")

for folder_name in ["data", "exports", "projects"]:
    folder = DIST_APP_DIR / folder_name
    folder.mkdir(parents=True, exist_ok=True)

if ZIP_PATH.exists():
    ZIP_PATH.unlink()

print(f"[INFO] Creating ZIP: {ZIP_PATH}")

with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for path in DIST_APP_DIR.rglob("*"):
        if path.is_file():
            arcname = Path(APP_NAME) / path.relative_to(DIST_APP_DIR)
            zf.write(path, arcname)

size_mb = ZIP_PATH.stat().st_size / (1024 * 1024)

print("[OK] Release ZIP created")
print(f"- path: {ZIP_PATH}")
print(f"- size: {size_mb:.1f} MB")
print("")
print("Next:")
print("1. Extract ZIP to a new folder")
print("2. Run PDF Poster Studio.exe")
print("3. Upload ZIP to GitHub Releases")
