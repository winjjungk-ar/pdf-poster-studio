﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_pretty_tiling_preview_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

# ------------------------------------------------------------
# 1) Make preview label suitable for rich HTML
# ------------------------------------------------------------
old = '''        self.tiling_preview_label = QLabel("-")
        self.tiling_preview_label.setWordWrap(True)
        self.tiling_preview_label.setMinimumHeight(70)
        self.tiling_preview_label.setStyleSheet("""
            QLabel {
                color: #395B64;
                background-color: #FFF8F0;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 8px;
                font-family: Consolas, 'Courier New', monospace;
            }
        """)
'''

new = '''        self.tiling_preview_label = QLabel("-")
        self.tiling_preview_label.setWordWrap(True)
        self.tiling_preview_label.setMinimumHeight(92)
        self.tiling_preview_label.setTextFormat(Qt.TextFormat.RichText)
        self.tiling_preview_label.setStyleSheet("""
            QLabel {
                color: #395B64;
                background-color: #FFF8F0;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 8px;
            }
        """)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Updated tiling preview label style for HTML")
else:
    if "setTextFormat(Qt.TextFormat.RichText)" in text:
        print("[SKIP] Tiling preview label already supports RichText")
    else:
        print("[WARN] Could not find old tiling preview label style block")

# ------------------------------------------------------------
# 2) Replace update_tiling_preview with pretty HTML table version
# ------------------------------------------------------------
new_update_tiling_preview = r'''    def update_tiling_preview(self, cols: int | None = None, rows: int | None = None) -> None:
        if not hasattr(self, "tiling_preview_label"):
            return

        if not cols or not rows or cols <= 0 or rows <= 0:
            self.tiling_preview_label.setText("-")
            return

        max_cells = 40
        total = cols * rows

        # Keep the preview compact for very large posters.
        display_cols = min(cols, 8)
        display_rows = min(rows, 6)

        html = []
        html.append(
            "<div style='font-family: Segoe UI, Arial; color:#395B64;'>"
            f"<div style='font-weight:700; margin-bottom:6px;'>"
            f"{cols} x {rows} = {total} sheets"
            "</div>"
        )

        html.append(
            "<table cellspacing='4' cellpadding='0' "
            "style='border-collapse:separate;'>"
        )

        sheet_no = 1

        for row in range(display_rows):
            html.append("<tr>")

            for col in range(display_cols):
                actual_sheet_no = row * cols + col + 1

                if actual_sheet_no > max_cells:
                    cell_text = "..."
                else:
                    cell_text = str(actual_sheet_no)

                html.append(
                    "<td style='"
                    "min-width:34px;"
                    "height:28px;"
                    "text-align:center;"
                    "vertical-align:middle;"
                    "background-color:#EAF7F7;"
                    "border:1px solid #9EDDE2;"
                    "border-radius:6px;"
                    "font-weight:700;"
                    "color:#395B64;"
                    "'>"
                    f"{cell_text}"
                    "</td>"
                )

                sheet_no += 1

            if cols > display_cols:
                html.append(
                    "<td style='"
                    "min-width:28px;"
                    "height:28px;"
                    "text-align:center;"
                    "vertical-align:middle;"
                    "color:#7A8D96;"
                    "font-weight:700;"
                    "'>...</td>"
                )

            html.append("</tr>")

        if rows > display_rows:
            html.append(
                "<tr><td colspan='99' style='"
                "text-align:center;"
                "color:#7A8D96;"
                "font-weight:700;"
                "padding-top:2px;"
                "'>...</td></tr>"
            )

        html.append("</table>")

        if total > max_cells:
            html.append(
                f"<div style='font-size:11px; color:#7A8D96; margin-top:4px;'>"
                f"Large layout preview is shortened. Total sheets: {total}."
                "</div>"
            )

        html.append("</div>")

        self.tiling_preview_label.setText("".join(html))
'''

try:
    text = replace_function(text, "update_tiling_preview", new_update_tiling_preview)
    print("[OK] Replaced update_tiling_preview with pretty HTML version")
except Exception as exc:
    print(f"[ERROR] Failed to replace update_tiling_preview: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_pretty_tiling_preview_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "setTextFormat(Qt.TextFormat.RichText)",
    "Large layout preview is shortened",
    "background-color:#EAF7F7",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Tiling Preview is now styled as pastel sheet cards")
print("- Large layouts are shortened visually but total sheet count remains shown")
