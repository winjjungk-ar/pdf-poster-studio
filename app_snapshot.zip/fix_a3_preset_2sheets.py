﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

main_backup = MAIN.with_name(f"main_window.py.bak_fix_a3_preset_2sheets_{timestamp}")
exporter_backup = EXPORTER.with_name(f"poster_exporter.py.bak_fix_a3_preset_2sheets_{timestamp}")

shutil.copy2(MAIN, main_backup)
shutil.copy2(EXPORTER, exporter_backup)

print(f"[OK] Backup created: {main_backup}")
print(f"[OK] Backup created: {exporter_backup}")

# ------------------------------------------------------------
# 1) exporter: A4 scale <= 141% uses classic 2-sheet split.
# ------------------------------------------------------------
exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace")
original_exporter = exporter_text

old = '''        if not (paper_size == "a4" and abs(poster_scale - 1.0) <= 0.000001):
            self._export_poster_tiling(src_doc, out_doc, selections, options)
            return

        sheet_total = len(selections) * 2
'''

new = '''        # A3 from A4 preset is 141% linear scale and should still be 2 A4 sheets.
        # Use the classic 2-sheet split for A4 up to A3 scale.
        if not (paper_size == "a4" and poster_scale <= 1.42):
            self._export_poster_tiling(src_doc, out_doc, selections, options)
            return

        sheet_total = len(selections) * 2
'''

if old in exporter_text:
    exporter_text = exporter_text.replace(old, new, 1)
    print("[OK] Exporter: A4 up to 141% now uses 2-sheet classic split")
elif "poster_scale <= 1.42" in exporter_text:
    print("[SKIP] Exporter already patched for A3 preset")
else:
    print("[ERROR] Could not find exporter route block")
    EXPORTER.write_text(original_exporter, encoding="utf-8")
    sys.exit(1)

EXPORTER.write_text(exporter_text, encoding="utf-8")

# ------------------------------------------------------------
# 2) main_window: estimate A4 100% and A4 141% as 2 sheets.
# ------------------------------------------------------------
main_text = MAIN.read_text(encoding="utf-8", errors="replace")
original_main = main_text

old = '''            # Classic base behavior:
            # A4 + 100% Poster Print means A3-sized poster output split into 2 A4 sheets.
            if paper == "a4" and scale_percent == 100:
                split_layout = self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else "left_right"

                if split_layout == "top_bottom":
                    layout_text = "1 x 2 = 2"
                    size_text = "Approx Poster Size: A3-like, 210 x 420 mm"
                else:
                    layout_text = "2 x 1 = 2"
                    size_text = "Approx Poster Size: A3, 420 x 297 mm"

                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text}\\n{size_text}"
                )
                return
'''

new = '''            # Classic A4 poster behavior:
            # A4 100% and A3 from A4 141% should both be 2 A4 sheets.
            if paper == "a4" and scale_percent <= 141:
                split_layout = self.split_layout_combo.currentData() if hasattr(self, "split_layout_combo") else "left_right"

                if split_layout == "top_bottom":
                    layout_text = "1 x 2 = 2"
                    size_text = "Approx Poster Size: A3-like, 210 x 420 mm"
                else:
                    layout_text = "2 x 1 = 2"
                    size_text = "Approx Poster Size: A3, 420 x 297 mm"

                self.poster_sheet_estimate_label.setText(
                    f"Estimated Sheets: {layout_text}\\n{size_text}"
                )
                return
'''

if old in main_text:
    main_text = main_text.replace(old, new, 1)
    print("[OK] Estimate: A4 up to A3 preset now shows 2 sheets")
elif "scale_percent <= 141" in main_text:
    print("[SKIP] Estimate already patched for A3 preset")
else:
    print("[ERROR] Could not find estimate classic A4 block")
    MAIN.write_text(original_main, encoding="utf-8")
    EXPORTER.write_text(original_exporter, encoding="utf-8")
    sys.exit(1)

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup in [
    (MAIN, main_backup),
    (EXPORTER, exporter_backup),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_fix_a3_preset_2sheets_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 4) verification
# ------------------------------------------------------------
main_new = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_new = EXPORTER.read_text(encoding="utf-8", errors="replace")

checks = [
    ("main scale_percent <= 141", "scale_percent <= 141" in main_new),
    ("exporter poster_scale <= 1.42", "poster_scale <= 1.42" in exporter_new),
]

for name, ok in checks:
    print(f"[CHECK] {name}: {'OK' if ok else 'MISSING'}")

print("")
print("Done.")
print("- A3 from A4 preset should now estimate 2 sheets")
print("- A3 from A4 preset should now export 2 sheets")
print("- A2/A1/A0 and US Letter presets still use scalable tiling")
