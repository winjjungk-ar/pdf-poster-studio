﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_release_notes_update_policy_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add reminder comment near show_release_notes
# ------------------------------------------------------------
if "# RELEASE NOTES UPDATE POLICY" not in text:
    marker = "    def show_release_notes(self) -> None:\n"
    pos = text.find(marker)

    if pos != -1:
        comment = '''    # RELEASE NOTES UPDATE POLICY:
    # Whenever user-facing features are changed, update this method and the welcome "What's new" text together.
'''
        text = text[:pos] + comment + text[pos:]
        print("[OK] Added release notes update policy comment")
    else:
        print("[WARN] show_release_notes not found for policy comment")
else:
    print("[SKIP] Release notes update policy comment already exists")

# ------------------------------------------------------------
# 2) Add release notes guidance to Welcome popup
# ------------------------------------------------------------
old = '''            "• One PDF or Separate PDF output modes\\n\\n"
            "New work:\\n"
'''

new = '''            "• One PDF or Separate PDF output modes\\n"
            "• See Help > Release Notes for details\\n\\n"
            "New work:\\n"
'''

if old in text and "See Help > Release Notes for details" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Welcome popup now points to Release Notes")
else:
    print("[SKIP] Welcome release notes hint already present or anchor not found")

# ------------------------------------------------------------
# 3) Add maintenance note inside release notes
# ------------------------------------------------------------
old = '''<h3>Version 0.9.1</h3>
<p>
This version focuses on making PDF Poster Studio easier to use for maps, posters,
game boards, engineering drawings, and print-ready PDF packages.
</p>
'''

new = '''<h3>Version 0.9.1</h3>
<p>
This version focuses on making PDF Poster Studio easier to use for maps, posters,
game boards, engineering drawings, and print-ready PDF packages.
</p>
<p>
Release notes are updated together with user-facing feature changes.
</p>
'''

if old in text and "Release notes are updated together" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Release Notes now mention update policy")
else:
    print("[SKIP] Release Notes update policy already present or anchor not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) Compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_release_notes_update_policy_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Release Notes update policy added")
print("- Welcome popup points users to Help > Release Notes")
