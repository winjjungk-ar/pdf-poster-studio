﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_hide_batch_output_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Ensure batch output default is Single PDF
# ------------------------------------------------------------
old = '''        self.batch_output_combo = QComboBox()
        self.batch_output_combo.addItem("Single PDF", "single_pdf")
        self.batch_output_combo.addItem("Separate PDF per checked page", "separate_pdf_per_page")
'''

new = '''        self.batch_output_combo = QComboBox()
        self.batch_output_combo.addItem("Single PDF", "single_pdf")
        self.batch_output_combo.addItem("Separate PDF per checked page", "separate_pdf_per_page")
        self.batch_output_combo.setCurrentIndex(0)
        # Kept internally for backward compatibility.
        # The app now uses Print Order and normally creates one print-ready PDF.
        self.batch_output_combo.setVisible(False)
'''

if old in text and "The app now uses Print Order" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Batch output combo hidden and defaulted to Single PDF")
else:
    print("[SKIP] Batch output combo already patched or block not found")

# ------------------------------------------------------------
# 2) Hide Batch Output label in active Export tab
# ------------------------------------------------------------
old = '''        export_layout.addWidget(QLabel("Batch Output"))
        export_layout.addWidget(self.batch_output_combo)
'''

new = '''        self.batch_output_label = QLabel("Batch Output")
        self.batch_output_label.setVisible(False)
        export_layout.addWidget(self.batch_output_label)
        export_layout.addWidget(self.batch_output_combo)
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Batch Output label hidden in active export tab")
else:
    if "self.batch_output_label" in text:
        print("[SKIP] Batch Output label already hidden")
    else:
        print("[WARN] Batch Output layout block not found")

# Patch duplicate/dead block harmlessly if it still exists.
if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Batch Output label hidden in duplicate block too")

# ------------------------------------------------------------
# 3) Force single_pdf at export start to avoid hidden old project setting causing surprise
# ------------------------------------------------------------
old = '''        if not self._prompt_export_type():
            return

        workspace_mode = self._workspace_has_multiple_pdfs()
'''

new = '''        if not self._prompt_export_type():
            return

        # Batch output UI is hidden. Use one print-ready PDF by default.
        if hasattr(self, "batch_output_combo"):
            self._apply_combo_data(self.batch_output_combo, "single_pdf")

        workspace_mode = self._workspace_has_multiple_pdfs()
'''

if old in text and "Batch output UI is hidden" not in text[text.find("def export_print_pdf"):text.find("def _create_temp_print_pdf")]:
    text = text.replace(old, new, 1)
    print("[OK] Export now forces Single PDF batch mode")
else:
    print("[SKIP] Export single_pdf force already present or block not found")

# ------------------------------------------------------------
# 4) Optional: reduce log confusion
# ------------------------------------------------------------
text = text.replace(
    '            self._log(f"Batch output: {self.batch_output_combo.currentData()}")',
    '            self._log("Batch output: single_pdf")'
)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_hide_batch_output_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "self.batch_output_combo.setVisible(False)",
    "self.batch_output_label.setVisible(False)",
    'self._apply_combo_data(self.batch_output_combo, "single_pdf")',
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Batch Output hidden from UI")
print("- Export defaults to Single PDF")
print("- Internal compatibility preserved")
