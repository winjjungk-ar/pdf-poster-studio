﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_output_files_help_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

old = '''        export_layout.addWidget(self.batch_output_label)
        export_layout.addWidget(self.batch_output_combo)

        export_layout.addWidget(QLabel("Print Quality"))
'''

new = '''        export_layout.addWidget(self.batch_output_label)
        export_layout.addWidget(self.batch_output_combo)

        self.output_files_help_label = QLabel(
            "One PDF combines selected pages into one file.\\n"
            "Separate creates one PDF for each selected page."
        )
        self.output_files_help_label.setWordWrap(True)
        self.output_files_help_label.setStyleSheet("color: #5F6F7A;")
        export_layout.addWidget(self.output_files_help_label)

        export_layout.addWidget(QLabel("Print Quality"))
'''

if old in text and "self.output_files_help_label" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Output Files help label")
else:
    if "self.output_files_help_label" in text:
        print("[SKIP] Output Files help label already exists")
    else:
        print("[WARN] Could not find Output Files layout block")
        print("        Trying fallback insertion after batch_output_combo widget.")

        fallback = '''        export_layout.addWidget(self.batch_output_combo)
'''
        fallback_insert = '''        export_layout.addWidget(self.batch_output_combo)

        self.output_files_help_label = QLabel(
            "One PDF combines selected pages into one file.\\n"
            "Separate creates one PDF for each selected page."
        )
        self.output_files_help_label.setWordWrap(True)
        self.output_files_help_label.setStyleSheet("color: #5F6F7A;")
        export_layout.addWidget(self.output_files_help_label)
'''

        if fallback in text and "self.output_files_help_label" not in text:
            text = text.replace(fallback, fallback_insert, 1)
            print("[OK] Added Output Files help label by fallback")
        else:
            print("[ERROR] Could not insert Output Files help label")
            MAIN.write_text(original, encoding="utf-8")
            sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_output_files_help_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

if "self.output_files_help_label" not in new_text:
    print("[WARN] Output Files help label marker not found after patch")
else:
    print("[OK] Output Files help label marker confirmed")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Output Files explanation added to Export tab")
