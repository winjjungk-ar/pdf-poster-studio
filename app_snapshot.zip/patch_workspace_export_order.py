﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_export_order_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add export order UI after workspace buttons
# ------------------------------------------------------------
old = """        workspace_button_layout.addWidget(add_workspace_button)
        workspace_button_layout.addWidget(remove_workspace_button)
        status_layout.addLayout(workspace_button_layout)

        status_layout.addWidget(QLabel("Pages for Export"))
"""

new = """        workspace_button_layout.addWidget(add_workspace_button)
        workspace_button_layout.addWidget(remove_workspace_button)
        status_layout.addLayout(workspace_button_layout)

        status_layout.addWidget(QLabel("Export Order"))

        self.export_order_list = QListWidget()
        self.export_order_list.setMinimumHeight(150)
        self.export_order_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.export_order_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.export_order_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        status_layout.addWidget(self.export_order_list)

        export_order_button_layout = QHBoxLayout()

        refresh_export_order_button = QPushButton("Refresh Order")
        refresh_export_order_button.clicked.connect(self.refresh_export_order_from_checked_pages)

        export_order_up_button = QPushButton("Move Up")
        export_order_up_button.clicked.connect(self.move_export_order_item_up)

        export_order_down_button = QPushButton("Move Down")
        export_order_down_button.clicked.connect(self.move_export_order_item_down)

        export_order_button_layout.addWidget(refresh_export_order_button)
        export_order_button_layout.addWidget(export_order_up_button)
        export_order_button_layout.addWidget(export_order_down_button)
        status_layout.addLayout(export_order_button_layout)

        status_layout.addWidget(QLabel("Pages for Export"))
"""

if old in text and "self.export_order_list = QListWidget()" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Export Order UI")
else:
    print("[SKIP] Export Order UI already present or target block not found")

# ------------------------------------------------------------
# 2) Add export order methods before _open_pdf_path
# ------------------------------------------------------------
methods = r'''
    def _export_order_item_text(self, workspace_index: int, page_index: int) -> str:
        item = self.workspace_items[workspace_index]
        pdf_name = Path(item.get("pdf_path", "")).name
        return f"{pdf_name}  -  Page {page_index + 1}"

    def _add_export_order_item(self, workspace_index: int, page_index: int) -> None:
        if not hasattr(self, "export_order_list"):
            return

        list_item = QListWidgetItem(self._export_order_item_text(workspace_index, page_index))
        list_item.setData(
            Qt.ItemDataRole.UserRole,
            {
                "workspace_index": workspace_index,
                "page_index": page_index,
            }
        )

        pdf_path = self.workspace_items[workspace_index].get("pdf_path", "")
        list_item.setToolTip(f"{pdf_path}\nPage {page_index + 1}")
        self.export_order_list.addItem(list_item)

    def refresh_export_order_from_checked_pages(self) -> None:
        if not hasattr(self, "export_order_list"):
            return

        if not hasattr(self, "workspace_items") or not self.workspace_items:
            QMessageBox.information(self, "Export Order", "Workspace is empty.")
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        self.export_order_list.clear()

        for workspace_index, item in enumerate(self.workspace_items):
            checked_pages = sorted(list(item.get("checked_pages", set())))

            for page_index in checked_pages:
                self._add_export_order_item(workspace_index, page_index)

        if self.export_order_list.count() <= 0:
            QMessageBox.information(
                self,
                "Export Order",
                "No checked pages found.\n\nSelect areas on pages first."
            )
            return

        self._log(f"Export order refreshed: {self.export_order_list.count()} pages")

    def _move_export_order_row(self, source_row: int, target_row: int) -> None:
        if not hasattr(self, "export_order_list"):
            return

        count = self.export_order_list.count()

        if source_row < 0 or source_row >= count:
            return

        if target_row < 0 or target_row >= count:
            return

        item = self.export_order_list.takeItem(source_row)
        self.export_order_list.insertItem(target_row, item)
        self.export_order_list.setCurrentRow(target_row)

    def move_export_order_item_up(self) -> None:
        if not hasattr(self, "export_order_list"):
            return

        row = self.export_order_list.currentRow()

        if row <= 0:
            return

        self._move_export_order_row(row, row - 1)

    def move_export_order_item_down(self) -> None:
        if not hasattr(self, "export_order_list"):
            return

        row = self.export_order_list.currentRow()

        if row < 0 or row >= self.export_order_list.count() - 1:
            return

        self._move_export_order_row(row, row + 1)

    def _get_export_order_entries(self) -> list[tuple[int, int]]:
        entries: list[tuple[int, int]] = []

        if not hasattr(self, "export_order_list"):
            return entries

        for row in range(self.export_order_list.count()):
            item = self.export_order_list.item(row)
            data = item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(data, dict):
                continue

            try:
                workspace_index = int(data.get("workspace_index"))
                page_index = int(data.get("page_index"))
            except Exception:
                continue

            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                continue

            entries.append((workspace_index, page_index))

        return entries

'''

if "def refresh_export_order_from_checked_pages" not in text:
    marker = "    def _open_pdf_path(self, file_path: str, clear_selections: bool = True) -> None:\n"
    if marker in text:
        text = text.replace(marker, methods + "\n" + marker, 1)
        print("[OK] Added Export Order methods")
    else:
        print("[ERROR] Could not find _open_pdf_path marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Export Order methods already present")

# ------------------------------------------------------------
# 3) Clear export order when opening normal PDF / new workspace
# ------------------------------------------------------------
old = """            if hasattr(self, "workspace_pdf_list"):
                self.workspace_pdf_list.clear()

        self._log(f"Opening PDF: {file_path}")
"""
new = """            if hasattr(self, "workspace_pdf_list"):
                self.workspace_pdf_list.clear()
            if hasattr(self, "export_order_list"):
                self.export_order_list.clear()

        self._log(f"Opening PDF: {file_path}")
"""

if old in text and "self.export_order_list.clear()" not in text[text.find("def _open_pdf_path"):text.find("def open_pdf")]:
    text = text.replace(old, new, 1)
    print("[OK] Clear Export Order on normal open")
else:
    print("[SKIP] Normal open clear patch skipped")

old = """        self.workspace_items = []
        self.current_workspace_index = None

        for pdf_path in file_paths:
"""
new = """        self.workspace_items = []
        self.current_workspace_index = None

        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        for pdf_path in file_paths:
"""

if old in text and "self.export_order_list.clear()" not in text[text.find("def open_multiple_pdfs_workspace"):text.find("def add_pdfs_to_workspace")]:
    text = text.replace(old, new, 1)
    print("[OK] Clear Export Order on workspace open")
else:
    print("[SKIP] Workspace open clear patch skipped")

# ------------------------------------------------------------
# 4) Replace _export_workspace_to_pdf with export-order-aware version
# ------------------------------------------------------------
start_marker = "    def _export_workspace_to_pdf(self, output_path: str, options: ExportOptions) -> None:\n"
start = text.find(start_marker)

if start == -1:
    print("[ERROR] _export_workspace_to_pdf not found")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

next_marker = "\n    def _open_pdf_path("
end = text.find(next_marker, start)

if end == -1:
    print("[ERROR] Could not find end of _export_workspace_to_pdf")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

new_func = r'''    def _export_workspace_to_pdf(self, output_path: str, options: ExportOptions) -> None:
        if not self.workspace_items:
            raise RuntimeError("Workspace is empty.")

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        # Export Order list has priority.
        export_order_entries = self._get_export_order_entries()

        # If user did not prepare Export Order, build it from checked pages automatically.
        if not export_order_entries:
            for workspace_index, item in enumerate(self.workspace_items):
                checked_pages = sorted(list(item.get("checked_pages", set())))
                for page_index in checked_pages:
                    export_order_entries.append((workspace_index, page_index))

        if not export_order_entries:
            raise RuntimeError("No pages are checked for export.")

        temp_dir = DATA_DIR / "workspace_export_temp"
        temp_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        temp_outputs = []
        exporter = PosterExporter()

        for order_index, entry in enumerate(export_order_entries):
            workspace_index, page_index = entry

            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                continue

            item = self.workspace_items[workspace_index]
            pdf_path = item.get("pdf_path")
            selections_qrect = item.get("page_selections", {})
            checked_pages = set(item.get("checked_pages", set()))

            if not pdf_path:
                continue

            if page_index not in checked_pages:
                continue

            rect = selections_qrect.get(page_index)

            if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                continue

            # Load correct PDF/page so coordinate conversion uses correct page data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path
            self.current_page_index = page_index
            self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)

            converted = {
                page_index: self._preview_rect_to_pdf_selection(rect)
            }

            part_path = temp_dir / f"workspace_order_{timestamp}_{order_index + 1:04d}.pdf"

            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(part_path),
                selections=converted,
                options=options,
            )

            temp_outputs.append(part_path)

        if not temp_outputs:
            raise RuntimeError("No valid selected pages were found for export.")

        merged = fitz.open()

        try:
            for part_path in temp_outputs:
                src = fitz.open(str(part_path))
                merged.insert_pdf(src)
                src.close()

            merged.save(output_path)
        finally:
            merged.close()

        self.last_exported_pdf_path = output_path
        self._log(f"Workspace export completed with custom page order: {output_path}")

'''

text = text[:start] + new_func + text[end:]
print("[OK] Replaced _export_workspace_to_pdf with Export Order version")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_export_order_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Export Order list added")
print("- Move Up / Move Down added")
print("- Workspace export now follows Export Order")
