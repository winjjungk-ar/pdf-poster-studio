﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_workspace_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Import QAbstractItemView if missing
# ------------------------------------------------------------
if "QAbstractItemView" not in text:
    text = text.replace(
        "    QTabWidget,\n",
        "    QTabWidget,\n    QAbstractItemView,\n",
        1
    )
    print("[OK] Added QAbstractItemView import")
else:
    print("[SKIP] QAbstractItemView already imported")

# ------------------------------------------------------------
# 2) Add workspace state in __init__
# ------------------------------------------------------------
old = """        self.page_selections: dict[int, QRect] = {}
        self.checked_pages: set[int] = set()
        self._updating_page_list = False
"""
new = """        self.page_selections: dict[int, QRect] = {}
        self.checked_pages: set[int] = set()
        self._updating_page_list = False

        # Multi-PDF workspace.
        # Each item keeps its own selected pages and selection rectangles.
        self.workspace_items: list[dict] = []
        self.current_workspace_index: int | None = None
        self._updating_workspace_list = False
"""
if old in text and "self.workspace_items: list[dict]" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added workspace state")
else:
    print("[SKIP] Workspace state already present or target not found")

# ------------------------------------------------------------
# 3) Add menu action
# ------------------------------------------------------------
old = """        open_pdf_action = self.file_menu.addAction("Open PDF", self.open_pdf)
        open_pdf_action.setShortcut(QKeySequence("Ctrl+O"))

        self.file_menu.addAction("Collect Pages from PDFs", self.open_page_collector_dialog)
"""
new = """        open_pdf_action = self.file_menu.addAction("Open PDF", self.open_pdf)
        open_pdf_action.setShortcut(QKeySequence("Ctrl+O"))

        open_workspace_action = self.file_menu.addAction("Open Multiple PDFs as Workspace", self.open_multiple_pdfs_workspace)
        open_workspace_action.setShortcut(QKeySequence("Ctrl+M"))

        self.file_menu.addAction("Collect Pages from PDFs", self.open_page_collector_dialog)
"""
if old in text and "Open Multiple PDFs as Workspace" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added workspace menu action")
else:
    print("[SKIP] Workspace menu action already present or target not found")

# ------------------------------------------------------------
# 4) Add workspace UI to Status tab
# ------------------------------------------------------------
old = """        status_layout.addWidget(self.checked_pages_label)
        status_layout.addWidget(QLabel("Pages for Export"))

        self.page_list_widget = QListWidget()
"""
new = """        status_layout.addWidget(self.checked_pages_label)

        status_layout.addWidget(QLabel("PDF Workspace"))

        self.workspace_pdf_list = QListWidget()
        self.workspace_pdf_list.setMinimumHeight(120)
        self.workspace_pdf_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.workspace_pdf_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.workspace_pdf_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.workspace_pdf_list.itemClicked.connect(self.on_workspace_pdf_clicked)
        self.workspace_pdf_list.model().rowsMoved.connect(self.on_workspace_rows_moved)
        status_layout.addWidget(self.workspace_pdf_list)

        workspace_button_layout = QHBoxLayout()
        add_workspace_button = QPushButton("Add PDFs")
        add_workspace_button.clicked.connect(self.add_pdfs_to_workspace)
        remove_workspace_button = QPushButton("Remove")
        remove_workspace_button.clicked.connect(self.remove_selected_workspace_pdf)
        workspace_button_layout.addWidget(add_workspace_button)
        workspace_button_layout.addWidget(remove_workspace_button)
        status_layout.addLayout(workspace_button_layout)

        status_layout.addWidget(QLabel("Pages for Export"))

        self.page_list_widget = QListWidget()
"""
if old in text and "self.workspace_pdf_list = QListWidget()" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added workspace UI")
else:
    print("[SKIP] Workspace UI already present or target not found")

# ------------------------------------------------------------
# 5) Save current workspace item in _open_pdf_path when opening non-workspace PDF
# ------------------------------------------------------------
old = """    def _open_pdf_path(self, file_path: str, clear_selections: bool = True) -> None:
        self._log(f"Opening PDF: {file_path}")
"""
new = """    def _open_pdf_path(self, file_path: str, clear_selections: bool = True) -> None:
        if clear_selections and hasattr(self, "workspace_items"):
            self.workspace_items.clear()
            self.current_workspace_index = None
            if hasattr(self, "workspace_pdf_list"):
                self.workspace_pdf_list.clear()

        self._log(f"Opening PDF: {file_path}")
"""
if old in text and "self.workspace_items.clear()" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched _open_pdf_path workspace reset")
else:
    print("[SKIP] _open_pdf_path already patched or target not found")

# ------------------------------------------------------------
# 6) Clear workspace on New Project
# ------------------------------------------------------------
old = """        self.page_selections.clear()
        self.checked_pages.clear()
"""
new = """        self.page_selections.clear()
        self.checked_pages.clear()

        if hasattr(self, "workspace_items"):
            self.workspace_items.clear()
            self.current_workspace_index = None
        if hasattr(self, "workspace_pdf_list"):
            self.workspace_pdf_list.clear()
"""
if old in text and "self.current_workspace_index = None" not in text[text.find("def new_project"):text.find("def _open_pdf_path")]:
    text = text.replace(old, new, 1)
    print("[OK] Patched new project workspace clear")
else:
    print("[SKIP] New project workspace clear already present or target not found")

# ------------------------------------------------------------
# 7) Add workspace methods before _open_pdf_path
# ------------------------------------------------------------
methods = r'''
    def _make_workspace_item(self, pdf_path: str) -> dict:
        page_count = 0
        try:
            doc = fitz.open(pdf_path)
            page_count = doc.page_count
            doc.close()
        except Exception:
            page_count = 0

        return {
            "pdf_path": pdf_path,
            "page_count": page_count,
            "current_page_index": 0,
            "page_selections": {},
            "checked_pages": set(),
        }

    def _save_current_workspace_state(self) -> None:
        if self.current_workspace_index is None:
            return

        if self.current_workspace_index < 0 or self.current_workspace_index >= len(self.workspace_items):
            return

        if self.page_count > 0:
            self._save_current_selection()

        item = self.workspace_items[self.current_workspace_index]
        item["current_page_index"] = self.current_page_index
        item["page_selections"] = {page: QRect(rect) for page, rect in self.page_selections.items()}
        item["checked_pages"] = set(self.checked_pages)

        self._refresh_workspace_list_text()

    def _load_workspace_index(self, index: int) -> None:
        if index < 0 or index >= len(self.workspace_items):
            return

        if self.current_workspace_index is not None and self.current_workspace_index != index:
            self._save_current_workspace_state()

        item = self.workspace_items[index]
        pdf_path = item["pdf_path"]

        self._log(f"Loading workspace PDF: {pdf_path}")

        self.page_count = self.pdf_renderer.open(pdf_path)
        self.current_pdf_path = pdf_path
        self.current_workspace_index = index

        self.page_selections = {
            int(page): QRect(rect)
            for page, rect in item.get("page_selections", {}).items()
        }
        self.checked_pages = set(item.get("checked_pages", set()))

        target_page = int(item.get("current_page_index", 0))
        self.current_page_index = max(0, min(target_page, self.page_count - 1))

        self.pdf_path_label.setText(f"PDF: {pdf_path}")
        self.pdf_info_label.setText(f"Pages: {self.page_count}")
        self.selection_info_label.setText("Selection: None")

        self._render_current_page()
        self._rebuild_page_list()
        self._refresh_workspace_list_text()

        if hasattr(self, "workspace_pdf_list"):
            self.workspace_pdf_list.blockSignals(True)
            self.workspace_pdf_list.setCurrentRow(index)
            self.workspace_pdf_list.blockSignals(False)

    def _workspace_item_text(self, index: int, item: dict) -> str:
        pdf_path = item.get("pdf_path", "")
        name = Path(pdf_path).name
        page_count = item.get("page_count", 0)
        checked_count = len(item.get("checked_pages", set()))
        prefix = "▶ " if index == self.current_workspace_index else ""
        return f"{prefix}{index + 1}. {name}  |  {page_count} pages  |  checked {checked_count}"

    def _refresh_workspace_list_text(self) -> None:
        if not hasattr(self, "workspace_pdf_list"):
            return

        self._updating_workspace_list = True

        current_row = self.workspace_pdf_list.currentRow()
        self.workspace_pdf_list.clear()

        for index, item in enumerate(self.workspace_items):
            list_item = QListWidgetItem(self._workspace_item_text(index, item))
            list_item.setData(Qt.ItemDataRole.UserRole, item.get("pdf_path", ""))
            list_item.setToolTip(item.get("pdf_path", ""))
            self.workspace_pdf_list.addItem(list_item)

        if self.current_workspace_index is not None and 0 <= self.current_workspace_index < self.workspace_pdf_list.count():
            self.workspace_pdf_list.setCurrentRow(self.current_workspace_index)
        elif 0 <= current_row < self.workspace_pdf_list.count():
            self.workspace_pdf_list.setCurrentRow(current_row)

        self._updating_workspace_list = False

    def open_multiple_pdfs_workspace(self) -> None:
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Open Multiple PDFs as Workspace",
            "",
            "PDF Files (*.pdf)"
        )

        if not file_paths:
            return

        self.workspace_items = []
        self.current_workspace_index = None

        for pdf_path in file_paths:
            self.workspace_items.append(self._make_workspace_item(pdf_path))

        self._refresh_workspace_list_text()

        if self.workspace_items:
            self._load_workspace_index(0)

        self.is_modified = True
        self._log(f"Workspace opened: {len(self.workspace_items)} PDFs")

    def add_pdfs_to_workspace(self) -> None:
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Add PDFs to Workspace",
            "",
            "PDF Files (*.pdf)"
        )

        if not file_paths:
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        existing = {item.get("pdf_path") for item in self.workspace_items}

        for pdf_path in file_paths:
            if pdf_path not in existing:
                self.workspace_items.append(self._make_workspace_item(pdf_path))

        self._refresh_workspace_list_text()

        if self.current_workspace_index is None and self.workspace_items:
            self._load_workspace_index(0)

        self.is_modified = True

    def remove_selected_workspace_pdf(self) -> None:
        if not hasattr(self, "workspace_pdf_list"):
            return

        row = self.workspace_pdf_list.currentRow()

        if row < 0 or row >= len(self.workspace_items):
            return

        del self.workspace_items[row]

        if not self.workspace_items:
            self.current_workspace_index = None
            self.current_pdf_path = None
            self.page_count = 0
            self.current_page_index = 0
            self.page_selections.clear()
            self.checked_pages.clear()
            self.preview_label.clear_preview()
            self.page_list_widget.clear()
            self.pdf_path_label.setText("PDF: Not selected")
            self.pdf_info_label.setText("Pages: -")
            self.selection_info_label.setText("Selection: None")
            self.checked_pages_label.setText("Checked pages: 0")
            self._refresh_workspace_list_text()
            return

        if self.current_workspace_index is not None:
            if row == self.current_workspace_index:
                self.current_workspace_index = None
                self._load_workspace_index(min(row, len(self.workspace_items) - 1))
            elif row < self.current_workspace_index:
                self.current_workspace_index -= 1

        self._refresh_workspace_list_text()
        self.is_modified = True

    def on_workspace_pdf_clicked(self, item: QListWidgetItem) -> None:
        if self._updating_workspace_list:
            return

        row = self.workspace_pdf_list.row(item)

        if row < 0:
            return

        self._load_workspace_index(row)

    def on_workspace_rows_moved(self, *args) -> None:
        if self._updating_workspace_list:
            return

        if not hasattr(self, "workspace_pdf_list"):
            return

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        old_items_by_path = {
            item.get("pdf_path"): item
            for item in self.workspace_items
        }

        new_items = []
        new_current_index = None

        for row in range(self.workspace_pdf_list.count()):
            list_item = self.workspace_pdf_list.item(row)
            pdf_path = list_item.data(Qt.ItemDataRole.UserRole)

            if pdf_path in old_items_by_path:
                new_items.append(old_items_by_path[pdf_path])

                if pdf_path == self.current_pdf_path:
                    new_current_index = row

        if len(new_items) == len(self.workspace_items):
            self.workspace_items = new_items
            self.current_workspace_index = new_current_index
            self._refresh_workspace_list_text()
            self.is_modified = True
            self._log("Workspace PDF order changed.")

    def _workspace_has_multiple_pdfs(self) -> bool:
        return hasattr(self, "workspace_items") and len(self.workspace_items) > 1

    def _export_workspace_to_pdf(self, output_path: str, options: ExportOptions) -> None:
        if not self.workspace_items:
            raise RuntimeError("Workspace is empty.")

        if self.current_workspace_index is not None:
            self._save_current_workspace_state()

        temp_dir = DATA_DIR / "workspace_export_temp"
        temp_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        temp_outputs = []
        exporter = PosterExporter()

        for index, item in enumerate(self.workspace_items):
            pdf_path = item.get("pdf_path")
            selections_qrect = item.get("page_selections", {})
            checked_pages = sorted(list(item.get("checked_pages", set())))

            if not pdf_path or not checked_pages:
                continue

            # Load this PDF temporarily so preview-to-PDF coordinate conversion uses correct page/render data.
            self.page_count = self.pdf_renderer.open(pdf_path)
            self.current_pdf_path = pdf_path

            converted = {}

            for page_index in checked_pages:
                rect = selections_qrect.get(page_index)

                if rect is None or rect.isNull() or rect.width() <= 0 or rect.height() <= 0:
                    continue

                self.current_page_index = page_index
                self.current_pixmap = self.pdf_renderer.render_page(page_index, zoom=self.render_zoom)
                converted[page_index] = self._preview_rect_to_pdf_selection(rect)

            if not converted:
                continue

            part_path = temp_dir / f"workspace_{timestamp}_{index + 1:03d}.pdf"
            exporter.export(
                source_pdf_path=pdf_path,
                output_pdf_path=str(part_path),
                selections=converted,
                options=options,
            )
            temp_outputs.append(part_path)

        if not temp_outputs:
            raise RuntimeError("No workspace pages are checked for export.")

        merged = fitz.open()

        try:
            for part_path in temp_outputs:
                src = fitz.open(str(part_path))
                merged.insert_pdf(src)
                src.close()

            merged.save(output_path)
        finally:
            merged.close()

        self.last_exported_pdf_path = output_path
        self._log(f"Workspace export completed: {output_path}")

'''

if "def open_multiple_pdfs_workspace" not in text:
    marker = "    def _open_pdf_path(self, file_path: str, clear_selections: bool = True) -> None:\n"
    if marker in text:
        text = text.replace(marker, methods + "\n" + marker, 1)
        print("[OK] Added workspace methods")
    else:
        print("[ERROR] Could not find _open_pdf_path marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Workspace methods already present")

# ------------------------------------------------------------
# 8) Patch export_print_pdf to use workspace export when multiple PDFs exist
# ------------------------------------------------------------
old = """    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        try:
            export_selections = self._build_export_selections()
        except Exception as exc:
            QMessageBox.warning(self, "No Selection", str(exc))
            return

        if self.export_type_combo.currentData() == "selection_only":
            default_name = Path(self.current_pdf_path).stem + "_selection_only_A4.pdf"
        else:
            default_name = Path(self.current_pdf_path).stem + "_A3_split_A4.pdf"
        default_path = EXPORTS_DIR / default_name
"""
new = """    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        workspace_mode = self._workspace_has_multiple_pdfs()

        if not workspace_mode:
            try:
                export_selections = self._build_export_selections()
            except Exception as exc:
                QMessageBox.warning(self, "No Selection", str(exc))
                return
        else:
            export_selections = {}

        if workspace_mode:
            default_name = "workspace_export_A4.pdf"
        elif self.export_type_combo.currentData() == "selection_only":
            default_name = Path(self.current_pdf_path).stem + "_selection_only_A4.pdf"
        else:
            default_name = Path(self.current_pdf_path).stem + "_A3_split_A4.pdf"
        default_path = EXPORTS_DIR / default_name
"""
if old in text and "workspace_mode = self._workspace_has_multiple_pdfs()" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched export_print_pdf header")
else:
    print("[SKIP] export_print_pdf header already patched or target not found")

old = """            exporter = PosterExporter()

            if self.batch_output_combo.currentData() == "separate_pdf_per_page":
"""
new = """            if workspace_mode:
                self._export_workspace_to_pdf(output_path, options)
                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Workspace output PDF was created:\\n\\n{output_path}"
                )
                return

            exporter = PosterExporter()

            if self.batch_output_combo.currentData() == "separate_pdf_per_page":
"""
if old in text and "Workspace output PDF was created" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Patched export_print_pdf workspace branch")
else:
    print("[SKIP] export_print_pdf workspace branch already present or target not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 9) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_workspace_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- File > Open Multiple PDFs as Workspace added")
print("- Status tab PDF Workspace list added")
print("- Drag/drop reorder enabled")
print("- Workspace export added")
