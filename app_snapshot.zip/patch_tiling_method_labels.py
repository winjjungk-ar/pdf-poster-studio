﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_tiling_method_labels_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

replacements = [
    ('self.output_mode_combo.addItem("No-Cut", "no_cut")',
     'self.output_mode_combo.addItem("Fit with Margins", "no_cut")'),

    ('self.output_mode_combo.addItem("Overlap", "overlap")',
     'self.output_mode_combo.addItem("Overlap for Taping", "overlap")'),

    ('self.output_mode_combo.addItem("True Size", "true_size")',
     'self.output_mode_combo.addItem("True Scale", "true_size")'),

    ('self.output_mode_title = QLabel("Output Mode")',
     'self.output_mode_title = QLabel("Tiling Method")'),

    ('self.numbering_check = QCheckBox("Add sheet numbers")',
     'self.numbering_check = QCheckBox("Show sheet numbers")'),

    ('self.cut_guides_check = QCheckBox("Add cut guide lines")',
     'self.cut_guides_check = QCheckBox("Show cut guide lines")'),
]

changed = 0

for old, new in replacements:
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        changed += count
        print(f"[OK] Replaced {count}: {old} -> {new}")

# Also update prompt/log text if present.
text = text.replace("Output mode:", "Tiling method:")
text = text.replace("Output Mode", "Tiling Method")
text = text.replace("Cut guides:", "Cut guide lines:")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_tiling_method_labels_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "Tiling Method",
    "Fit with Margins",
    "Overlap for Taping",
    "True Scale",
    "Show sheet numbers",
    "Show cut guide lines",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print(f"- replacements applied: {changed}")
print("- Poster Print tab labels are now more user-friendly")
print("- Internal option values are preserved")
