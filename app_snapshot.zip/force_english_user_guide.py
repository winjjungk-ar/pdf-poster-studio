﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_force_english_user_guide_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            targets.append(node)

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno

    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

new_show_user_guide = r'''    def show_user_guide(self) -> None:
        guides = {
            "English": """
<h2>PDF Poster Studio - User Guide</h2>

<p>
PDF Poster Studio helps you open one or more PDF files, select the area you need,
arrange the output order, and create print-ready PDF files for maps, posters,
game boards, and engineering drawings.
</p>

<hr>

<h3>1. Basic Workflow</h3>
<ol>
  <li><b>Open PDFs</b>: Open one or more source PDF files.</li>
  <li><b>Select Area</b>: Drag on the preview, or use Auto Select.</li>
  <li><b>Build Print Order</b>: Create the ordered list of selected pages/areas.</li>
  <li><b>Output Files</b>: Choose One PDF or Separate PDF per selected page.</li>
  <li>Click <b>Create Poster PDF</b> or <b>Create Single Page PDF</b>.</li>
</ol>

<hr>

<h3>2. Print a Game Map or Wall Poster</h3>
<ol>
  <li>Click <b>Open PDFs</b> and open your map or poster PDF.</li>
  <li>Select the map/poster area in the preview.</li>
  <li>Open the <b>Poster Print</b> tab.</li>
  <li>Choose <b>Output Paper Size</b>: A4 or US Letter.</li>
  <li>Choose <b>Poster Small</b>, <b>Poster Medium</b>, <b>Poster Large</b>, or <b>Poster Huge</b>.</li>
  <li>Check <b>Tiling Preview</b> to see how the sheets will be arranged.</li>
  <li>Click <b>Create Poster PDF</b>.</li>
</ol>

<p>
Hobby poster presets use the currently selected Output Paper Size.
For example, Poster Medium creates 4 sheets using either A4 or US Letter.
</p>

<hr>

<h3>3. Create a Poster PDF</h3>
<p>
Use <b>Create Poster PDF</b> to split a large selected area across multiple sheets.
</p>

<ol>
  <li>Open PDFs and select the area you want to print.</li>
  <li>Choose paper size, preset, or manual scale in the <b>Poster Print</b> tab.</li>
  <li>Check <b>Estimated Sheets</b> and <b>Tiling Preview</b>.</li>
  <li>Click <b>Build Print Order</b>.</li>
  <li>Click <b>Create Poster PDF</b>.</li>
</ol>

<hr>

<h3>4. Create a Single Page PDF</h3>
<p>
Use <b>Create Single Page PDF</b> when you want the selected area exported as clean single-page output.
</p>

<ul>
  <li><b>Fit Width</b>: Fit the selected area to page width.</li>
  <li><b>Fit Whole Area</b>: Fit the whole selected area without cropping.</li>
  <li><b>Fill Page Crop</b>: Fill the page; some edges may be cropped.</li>
  <li><b>Fit Height</b>: Fit the selected area to page height.</li>
</ul>

<hr>

<h3>5. One PDF / Separate PDFs</h3>
<ul>
  <li><b>One PDF</b>: Combine all selected pages in Print Order into one PDF file.</li>
  <li><b>Separate PDF per selected page</b>: Create one PDF file for each selected page/area.</li>
</ul>

<p>
You can also use this as a PDF combining workflow:
open multiple PDFs, select the pages/areas you need, build Print Order, choose One PDF, then export.
</p>

<hr>

<h3>6. Source PDFs and Print Order</h3>
<ul>
  <li><b>Source PDFs</b>: The PDF files loaded into the workspace.</li>
  <li><b>Print Order</b>: The final output order.</li>
  <li>Double-click a Print Order item to jump to that page in the preview.</li>
</ul>

<hr>

<h3>7. Auto Select</h3>
<ul>
  <li><b>Auto Select Current Page</b>: Detects the content area on the current page.</li>
  <li><b>Auto Select All Pages</b>: Detects content areas across all loaded source PDFs.</li>
  <li>Sensitivity can be changed in the View tab.</li>
</ul>

<hr>

<h3>8. Finding Exported Files</h3>
<p>
After export, the generated PDF opens automatically with the default Windows PDF viewer.
You can also click <b>Open Exports Folder</b>.
</p>

<hr>

<h3>9. Saving Projects</h3>
<p>
Use <b>File &gt; Save Project As</b> to save your workspace.
Source PDFs, selections, Print Order, Poster settings, and Output Files mode are saved.
</p>
""",

            "한국어": """
<h2>PDF Poster Studio - 사용 방법</h2>

<p>
PDF Poster Studio는 PDF 파일에서 필요한 영역을 선택하고, 큰 지도/포스터/게임맵/도면을
A4 또는 US Letter 여러 장으로 나누어 출력할 수 있게 도와주는 프로그램입니다.
</p>

<hr>

<h3>1. 기본 작업 순서</h3>
<ol>
  <li><b>Open PDFs</b>: 하나 이상의 원본 PDF 파일을 엽니다.</li>
  <li><b>영역 선택</b>: 미리보기 화면에서 드래그하거나 Auto Select를 사용합니다.</li>
  <li><b>Build Print Order</b>: 출력할 페이지/영역의 순서를 만듭니다.</li>
  <li><b>Output Files</b>: 하나의 PDF로 만들지, 선택 항목별로 따로 만들지 선택합니다.</li>
  <li><b>Create Poster PDF</b> 또는 <b>Create Single Page PDF</b>를 실행합니다.</li>
</ol>

<hr>

<h3>2. 게임 맵 / 벽 포스터 만들기</h3>
<ol>
  <li><b>Open PDFs</b>로 지도나 포스터 PDF를 엽니다.</li>
  <li>출력할 영역을 선택합니다.</li>
  <li><b>Poster Print</b> 탭에서 용지 크기(A4 또는 US Letter)를 선택합니다.</li>
  <li><b>Poster Small / Medium / Large / Huge</b> 같은 프리셋을 선택합니다.</li>
  <li><b>Tiling Preview</b>에서 몇 장으로 나뉘는지 확인합니다.</li>
  <li><b>Create Poster PDF</b>를 누릅니다.</li>
</ol>

<p>
Hobby preset은 현재 선택된 Output Paper Size를 따릅니다.
예: A4 + Poster Medium은 A4 4장, US Letter + Poster Medium은 Letter 4장입니다.
</p>

<hr>

<h3>3. One PDF / Separate PDF</h3>
<ul>
  <li><b>One PDF</b>: Print Order에 있는 모든 선택 항목을 하나의 PDF로 만듭니다.</li>
  <li><b>Separate PDF per selected page</b>: 선택한 페이지/영역마다 별도 PDF를 만듭니다.</li>
</ul>

<p>
여러 PDF에서 필요한 부분만 골라 <b>One PDF</b>로 만들면 PDF 합치기처럼 사용할 수 있습니다.
</p>
""",

            "日本語": """
<h2>PDF Poster Studio - 使い方</h2>
<p>PDF の必要な範囲を選択し、地図、ポスター、ゲームマップ、図面を A4 または US Letter の複数ページに分割して印刷用 PDF を作成できます。</p>

<hr>

<h3>基本の流れ</h3>
<ol>
<li><b>Open PDFs</b> で PDF を開きます。</li>
<li>プレビューで範囲を選択、または Auto Select を使います。</li>
<li><b>Build Print Order</b> で出力順を作成します。</li>
<li><b>Output Files</b> で One PDF または Separate PDF を選びます。</li>
<li><b>Create Poster PDF</b> または <b>Create Single Page PDF</b> を実行します。</li>
</ol>

<hr>

<h3>ゲームマップ / ポスター</h3>
<p>Poster Small / Medium / Large / Huge は現在選択中の Output Paper Size を使用します。</p>
<ul>
<li>A4 + Poster Medium = A4 4枚</li>
<li>US Letter + Poster Medium = Letter 4枚</li>
</ul>
""",

            "中文（简体）": """
<h2>PDF Poster Studio - 使用指南</h2>
<p>你可以从 PDF 中选择需要的区域，并把地图、海报、游戏地图、工程图纸分割到 A4 或 US Letter 多张纸上。</p>

<hr>

<h3>基本流程</h3>
<ol>
<li>点击 <b>Open PDFs</b> 打开 PDF。</li>
<li>在预览中选择区域，或使用 Auto Select。</li>
<li>点击 <b>Build Print Order</b> 建立输出顺序。</li>
<li>在 <b>Output Files</b> 中选择 One PDF 或 Separate PDF。</li>
<li>点击 <b>Create Poster PDF</b> 或 <b>Create Single Page PDF</b>。</li>
</ol>

<hr>

<h3>游戏地图 / 墙上海报</h3>
<p>Poster Small / Medium / Large / Huge 会使用当前选择的 Output Paper Size。</p>
<ul>
<li>A4 + Poster Medium = A4 4张</li>
<li>US Letter + Poster Medium = Letter 4张</li>
</ul>
"""
        }

        dialog = QDialog(self)
        dialog.setWindowTitle("User Guide / How to Use")
        dialog.setMinimumSize(800, 640)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        language_layout = QHBoxLayout()
        language_label = QLabel("Language")
        language_combo = QComboBox()
        language_combo.addItems(["English", "한국어", "日本語", "中文（简体）"])
        language_combo.setCurrentText("English")
        language_layout.addWidget(language_label)
        language_layout.addWidget(language_combo)
        language_layout.addStretch()

        guide_view = QTextEdit()
        guide_view.setReadOnly(True)
        guide_view.setHtml(guides["English"])
        guide_view.setStyleSheet("""
            QTextEdit {
                background-color: #FFFDF8;
                color: #2F4F5F;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 10px;
                font-family: Segoe UI, Arial;
                font-size: 10.5pt;
            }
        """)

        def change_language() -> None:
            guide_view.setHtml(guides.get(language_combo.currentText(), guides["English"]))

        language_combo.currentIndexChanged.connect(change_language)

        close_button = QPushButton("Close")
        close_button.clicked.connect(dialog.accept)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_button)

        layout.addLayout(language_layout)
        layout.addWidget(guide_view)
        layout.addLayout(button_layout)

        dialog.exec()
'''

try:
    text = replace_function(text, "show_user_guide", new_show_user_guide)
    print("[OK] Forced show_user_guide replacement with English included")
except Exception as exc:
    print(f"[ERROR] Failed to replace show_user_guide: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Version bump if still needed
text = text.replace("Version: 0.9.1", "Version: 0.9.2")
text = text.replace('"version": "0.9.1"', '"version": "0.9.2"')
text = text.replace("What's new in 0.9.1", "What's new in 0.9.2")
text = text.replace("Version 0.9.1", "Version 0.9.2")

# Welcome note
text = text.replace(
    "User Guide supports 한국어, 日本語, 中文（简体）",
    "User Guide supports English, 한국어, 日本語, 中文（简体）"
)

# Release notes note if possible
if "English User Guide restored" not in text and "Release Notes" in text:
    marker = "<h3>Version 0.9.2</h3>"
    if marker in text:
        text = text.replace(
            marker,
            marker + """
<ul>
  <li><b>English User Guide restored</b>: User Guide now supports English, 한국어, 日本語, 中文（简体）.</li>
</ul>
<hr>
""",
            1
        )

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_force_english_user_guide_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    '"English"',
    'language_combo.addItems(["English", "한국어", "日本語", "中文（简体）"])',
    'guide_view.setHtml(guides["English"])',
    "Version: 0.9.2",
    '"version": "0.9.2"',
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- English added to User Guide language dropdown")
print("- Default language set to English")
print("- Version updated to 0.9.2 if not already")
