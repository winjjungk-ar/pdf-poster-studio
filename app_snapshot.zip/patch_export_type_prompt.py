﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_export_type_prompt_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add export type prompt method before export_print_pdf
# ------------------------------------------------------------
method = r'''
    def _prompt_export_type(self) -> bool:
        dialog = QMessageBox(self)
        dialog.setWindowTitle("Choose Export Type")
        dialog.setIcon(QMessageBox.Icon.Question)
        dialog.setText("How do you want to export?")
        dialog.setInformativeText(
            "A3 Split Mode: split the selected area into A4 pages for poster printing.\n\n"
            "Selection Only Mode: export only the selected area as clean A4 page(s)."
        )

        a3_button = dialog.addButton("A3 Split Mode", QMessageBox.ButtonRole.AcceptRole)
        selection_button = dialog.addButton("Selection Only Mode", QMessageBox.ButtonRole.ActionRole)
        cancel_button = dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        dialog.setDefaultButton(a3_button)
        dialog.exec()

        clicked = dialog.clickedButton()

        if clicked == cancel_button:
            return False

        if clicked == a3_button:
            self._apply_combo_data(self.export_type_combo, "a3_split")
            self.update_export_option_states()
            self._log("Export type selected from prompt: A3 Split Mode")
            return True

        if clicked == selection_button:
            self._apply_combo_data(self.export_type_combo, "selection_only")
            self.update_export_option_states()
            self._log("Export type selected from prompt: Selection Only Mode")
            return True

        return False

'''

if "def _prompt_export_type" not in text:
    marker = "    def export_print_pdf(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find export_print_pdf marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added export type prompt method")
else:
    print("[SKIP] Export type prompt method already exists")

# ------------------------------------------------------------
# 2) Call prompt at start of export_print_pdf
# ------------------------------------------------------------
old = '''    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        workspace_mode = self._workspace_has_multiple_pdfs()
'''

new = '''    def export_print_pdf(self) -> None:
        if not self.current_pdf_path:
            QMessageBox.warning(self, "No PDF", "Please open a PDF file first.")
            return

        if not self._prompt_export_type():
            return

        workspace_mode = self._workspace_has_multiple_pdfs()
'''

if old in text and "if not self._prompt_export_type():" not in text[text.find("def export_print_pdf"):text.find("def _create_temp_print_pdf")]:
    text = text.replace(old, new, 1)
    print("[OK] Added export type prompt call")
else:
    print("[SKIP] Export type prompt call already present or target block not found")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_export_type_prompt_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "def _prompt_export_type",
    "A3 Split Mode",
    "Selection Only Mode",
    "self._prompt_export_type()",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Export PDF now asks A3 Split Mode / Selection Only Mode before exporting")
