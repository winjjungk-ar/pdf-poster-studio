﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_single_page_tab_labels_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Rename Selection tab to Single Page
# ------------------------------------------------------------
text = text.replace(
    'self.settings_tabs.addTab(self.selection_only_group, "Selection")',
    'self.settings_tabs.addTab(self.selection_only_group, "Single Page")'
)

# ------------------------------------------------------------
# 2) Rename labels
# ------------------------------------------------------------
text = text.replace(
    'self.selection_fit_mode_title = QLabel("Selection Fit Mode")',
    'self.selection_fit_mode_title = QLabel("Single Page Fit Mode")'
)

# ------------------------------------------------------------
# 3) Add explanatory label to selection_only_group layout
# ------------------------------------------------------------
old = '''        self.selection_only_group = QWidget()
        selection_layout = QVBoxLayout(self.selection_only_group)
        self.selection_fit_mode_title = QLabel("Single Page Fit Mode")
        self.page_orientation_title = QLabel("Page Orientation")
        selection_layout.addWidget(self.selection_fit_mode_title)
'''

new = '''        self.selection_only_group = QWidget()
        selection_layout = QVBoxLayout(self.selection_only_group)

        self.single_page_help_label = QLabel(
            "Used only for Selection Only Mode.\\n"
            "Exports the selected area as clean single-page output."
        )
        self.single_page_help_label.setWordWrap(True)
        self.single_page_help_label.setStyleSheet("color: #5F6F7A;")

        self.selection_fit_mode_title = QLabel("Single Page Fit Mode")
        self.page_orientation_title = QLabel("Page Orientation")

        selection_layout.addWidget(self.single_page_help_label)
        selection_layout.addWidget(self.selection_fit_mode_title)
'''

if old in text and "self.single_page_help_label" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Single Page help label")
else:
    if "self.single_page_help_label" in text:
        print("[SKIP] Single Page help label already exists")
    else:
        print("[WARN] Could not add help label; target block not found")

# Patch duplicate/dead block if present harmlessly.
if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Added Single Page help label to duplicate block too")

# ------------------------------------------------------------
# 4) Improve export prompt wording
# ------------------------------------------------------------
text = text.replace(
    "Selection Only Mode: export only the selected area as clean A4 page(s).",
    "Selection Only Mode: export the selected area as clean single-page output."
)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_single_page_tab_labels_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    '"Single Page"',
    "Single Page Fit Mode",
    "Used only for Selection Only Mode",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Selection tab renamed to Single Page")
print("- Help text added to explain it only applies to Selection Only Mode")
print("- Fit mode label clarified")
