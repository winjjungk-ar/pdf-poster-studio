﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_zoom_sync_remove_view_tab_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1
    end = node.end_lineno

    return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

def insert_before_function(source: str, func_name: str, code: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    start = node.lineno - 1

    return "".join(lines[:start]) + code + "\n" + "".join(lines[start:])

# ------------------------------------------------------------
# 1) Add zoom sync helper
# ------------------------------------------------------------
helper = r'''
    def _sync_zoom_factor_from_current_display(self) -> None:
        """When leaving Fit Page mode, sync zoom factor to the current displayed size.

        Without this, the first Zoom Out from Fit Page can look like Zoom In,
        because internal zoom may still be 100% while the fitted page is much smaller.
        """
        try:
            base_w = max(1, int(getattr(self, "current_display_base_width", 1)))
            base_h = max(1, int(getattr(self, "current_display_base_height", 1)))

            display_w, display_h = self._get_preview_display_size_tuple()

            factor_w = display_w / base_w
            factor_h = display_h / base_h
            factor = min(factor_w, factor_h)

            if factor > 0:
                self.preview_zoom_factor = max(
                    self.preview_zoom_min,
                    min(factor, self.preview_zoom_max),
                )

        except Exception as exc:
            self._log(f"Zoom sync skipped: {exc}")

'''

if "def _sync_zoom_factor_from_current_display" not in text:
    try:
        text = insert_before_function(text, "zoom_in", helper)
        print("[OK] Added _sync_zoom_factor_from_current_display")
    except Exception as exc:
        print(f"[ERROR] Could not insert zoom sync helper: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Zoom sync helper already exists")

# ------------------------------------------------------------
# 2) Replace zoom_in / zoom_out
# ------------------------------------------------------------
new_zoom_in = r'''    def zoom_in(self) -> None:
        if self.page_count <= 0:
            return

        self._save_current_selection()

        if self.fit_to_page_enabled:
            self._sync_zoom_factor_from_current_display()

        self.fit_to_page_enabled = False
        self.preview_zoom_factor = min(
            self.preview_zoom_factor * self.preview_zoom_step,
            self.preview_zoom_max,
        )

        self._render_current_page()
        self._log(f"Zoom In applied: {int(self.preview_zoom_factor * 100)}%.")
'''

new_zoom_out = r'''    def zoom_out(self) -> None:
        if self.page_count <= 0:
            return

        self._save_current_selection()

        if self.fit_to_page_enabled:
            self._sync_zoom_factor_from_current_display()

        self.fit_to_page_enabled = False
        self.preview_zoom_factor = max(
            self.preview_zoom_factor / self.preview_zoom_step,
            self.preview_zoom_min,
        )

        self._render_current_page()
        self._log(f"Zoom Out applied: {int(self.preview_zoom_factor * 100)}%.")
'''

try:
    text = replace_function(text, "zoom_in", new_zoom_in)
    print("[OK] Replaced zoom_in")
except Exception as exc:
    print(f"[ERROR] Could not replace zoom_in: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

try:
    text = replace_function(text, "zoom_out", new_zoom_out)
    print("[OK] Replaced zoom_out")
except Exception as exc:
    print(f"[ERROR] Could not replace zoom_out: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# ------------------------------------------------------------
# 3) Remove View tab from Basic Settings tabs
# ------------------------------------------------------------
removed = 0
for old in [
    '        self.settings_tabs.addTab(view_tab, "View")\n',
    '        self.settings_tabs.addTab(view_tab, "View")\r\n',
]:
    if old in text:
        text = text.replace(old, '        # View tab removed: view controls are available in the preview floating toolbar.\n', 1)
        removed += 1

if removed:
    print(f"[OK] Removed View tab from settings tabs: {removed}")
else:
    print("[SKIP] View tab addTab line not found or already removed")

# ------------------------------------------------------------
# 4) Release Notes update
# ------------------------------------------------------------
if "Zoom sync from Fit Page" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Zoom sync from Fit Page</b>: Zoom Out no longer appears to zoom in on the first click after Fit Page.</li>
  <li><b>View tab cleanup</b>: View controls are now handled by the preview floating toolbar.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

# ------------------------------------------------------------
# 5) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_zoom_sync_remove_view_tab_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "def _sync_zoom_factor_from_current_display",
    "Zoom sync from Fit Page",
    "View tab removed",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- First Zoom Out from Fit Page should no longer look like Zoom In")
print("- View tab removed from Basic Settings")
print("- Preview floating toolbar remains the main view control")
