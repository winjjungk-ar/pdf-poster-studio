﻿from pathlib import Path
import re
import ast
import sys
from datetime import datetime

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"
OUT = ROOT / "preset_validation_report.txt"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

main_text = MAIN.read_text(encoding="utf-8", errors="replace")
exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace")

expected = [
    ("A3 from A4", 141, "a4", 2, "A-series fixed"),
    ("A2 from A4", 200, "a4", 4, "A-series fixed"),
    ("A1 from A4", 283, "a4", 8, "A-series fixed"),
    ("A0 from A4", 400, "a4", 16, "A-series fixed"),
    ("ANSI B / Tabloid", 141, "letter", 2, "ANSI expected"),
    ("ANSI C", 200, "letter", 4, "ANSI expected"),
    ("ANSI D", 283, "letter", 8, "ANSI expected"),
    ("ANSI E", 400, "letter", 16, "ANSI expected"),
    ("Arch B", 152, "letter", 2, "Arch expected"),
    ("Arch C", 215, "letter", 4, "Arch expected"),
    ("Arch D", 304, "letter", 8, "Arch expected"),
    ("Arch E", 430, "letter", 16, "Arch expected"),
]

report = []
report.append("# Preset Validation Report")
report.append("")
report.append(f"- generated_at: {datetime.now().isoformat(timespec='seconds')}")
report.append(f"- root: {ROOT}")
report.append("")

report.append("## 1. Syntax")
for name, text in [("main_window.py", main_text), ("poster_exporter.py", exporter_text)]:
    try:
        ast.parse(text)
        report.append(f"- [OK] {name}")
    except SyntaxError as exc:
        report.append(f"- [FAILED] {name}: {exc}")
report.append("")

report.append("## 2. Preset definitions in main_window.py")
for label, scale, paper, expected_sheets, note in expected:
    marker = f'self.poster_size_preset_combo.addItem("{label}'
    found = marker in main_text
    scale_found = f'"scale": {scale}' in main_text
    paper_found = f'"paper_size": "{paper}"' in main_text

    status = "OK" if found and scale_found and paper_found else "WARN"
    report.append(
        f"- [{status}] {label}: scale={scale}, paper={paper}, expected={expected_sheets} sheets"
    )
    if not found:
        report.append(f"  - missing label marker: {marker}")
    if not scale_found:
        report.append(f"  - missing scale marker: {scale}")
    if not paper_found:
        report.append(f"  - missing paper marker: {paper}")
report.append("")

report.append("## 3. Fixed grid logic check")
checks = [
    ("A-series helper exists", "def _get_fixed_a_series_tile_grid" in main_text),
    ("A3 <=141 handled", "scale_percent <= 141" in main_text),
    ("A2 <=200 handled", "scale_percent <= 200" in main_text),
    ("A1 <=283 handled", "scale_percent <= 283" in main_text),
    ("A0 <=400 handled", "scale_percent <= 400" in main_text),
    ("Exporter tile_cols field", "tile_cols: int | None" in exporter_text),
    ("Exporter forced grid branch", "forced_cols = getattr(options, \"tile_cols\", None)" in exporter_text),
]

for label, ok in checks:
    report.append(f"- [{'OK' if ok else 'WARN'}] {label}")
report.append("")

report.append("## 4. Missing fixed grid for ANSI/Arch?")
ansi_arch_fixed = (
    "def _get_fixed_letter_series_tile_grid" in main_text
    or "ANSI B" in main_text and "tile_cols" in main_text and "paper == \"letter\"" in main_text
)

if ansi_arch_fixed:
    report.append("- [OK] Letter/ANSI/Arch fixed grid logic seems present.")
else:
    report.append("- [WARN] Letter/ANSI/Arch fixed grid logic not detected.")
    report.append("  - ANSI/Arch presets may still use automatic tiling and produce unexpected sheet counts.")
report.append("")

report.append("## 5. Recommendation")
report.append("- A4 A-series presets should be fixed-grid: A3=2, A2=4, A1=8, A0=16.")
report.append("- ANSI presets should likely follow the same fixed-grid counts: B=2, C=4, D=8, E=16.")
report.append("- Arch presets should also be fixed-grid by user expectation: B=2, C=4, D=8, E=16.")
report.append("- If report warns about Letter/ANSI/Arch, patch fixed grid helper to support letter presets too.")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Wrote: {OUT}")
print("Paste preset_validation_report.txt here.")
