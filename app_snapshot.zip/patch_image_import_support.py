﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_image_import_support_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Version bump 0.9.2 -> 0.9.3
# ------------------------------------------------------------
version_replacements = [
    ("Version: 0.9.2", "Version: 0.9.3"),
    ('"version": "0.9.2"', '"version": "0.9.3"'),
    ("Version 0.9.2", "Version 0.9.3"),
    ("What's new in 0.9.2", "What's new in 0.9.3"),
    ("0.9.2", "0.9.3"),
]

for old, new in version_replacements:
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        print(f"[OK] Version replace {count}: {old} -> {new}")

# ------------------------------------------------------------
# Helper to insert method
# ------------------------------------------------------------
def insert_before_function(source: str, marker_func: str, new_code: str) -> str:
    marker = f"    def {marker_func}"
    pos = source.find(marker)
    if pos == -1:
        raise RuntimeError(f"Could not find function marker: {marker_func}")
    return source[:pos] + new_code + "\n" + source[pos:]

# ------------------------------------------------------------
# 2) Add image import helper methods
# ------------------------------------------------------------
methods = r'''
    def _is_supported_image_path(self, file_path: str) -> bool:
        suffix = Path(file_path).suffix.lower()
        return suffix in {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

    def _prepare_source_file_for_workspace(self, file_path: str) -> str:
        """Return a PDF path usable by the existing PDF renderer/exporter.

        PDF files are returned as-is.
        Image files are converted to a temporary single-page PDF.
        """
        if not self._is_supported_image_path(file_path):
            return file_path

        return self._convert_image_to_temp_pdf(file_path)

    def _convert_image_to_temp_pdf(self, image_path: str) -> str:
        image_file = Path(image_path)

        if not image_file.exists():
            raise RuntimeError(f"Image file not found: {image_path}")

        temp_dir = DATA_DIR / "image_imports"
        temp_dir.mkdir(parents=True, exist_ok=True)

        safe_stem = "".join(ch if ch not in '<>:"/\\\\|?*' else "_" for ch in image_file.stem)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        output_pdf = temp_dir / f"{safe_stem}_{timestamp}.pdf"

        doc = fitz.open()

        try:
            img_doc = fitz.open(str(image_file))
            rect = img_doc[0].rect

            if rect.width <= 0 or rect.height <= 0:
                raise RuntimeError("Invalid image size.")

            page = doc.new_page(width=rect.width, height=rect.height)
            page.insert_image(page.rect, filename=str(image_file))

            doc.save(str(output_pdf), garbage=4, deflate=True)

        finally:
            doc.close()
            try:
                img_doc.close()
            except Exception:
                pass

        self._log(f"Image converted to temporary PDF: {image_file} -> {output_pdf}")
        return str(output_pdf)

'''

if "def _convert_image_to_temp_pdf" not in text:
    try:
        text = insert_before_function(text, "open_pdfs", methods)
        print("[OK] Added image import helper methods")
    except Exception as exc:
        print(f"[ERROR] Could not insert image helper methods: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Image import helper methods already exist")

# ------------------------------------------------------------
# 3) Update file dialog filters
# ------------------------------------------------------------
old_filter = '"PDF Files (*.pdf)"'
new_filter = '"PDF and Image Files (*.pdf *.png *.jpg *.jpeg *.bmp *.webp);;PDF Files (*.pdf);;Image Files (*.png *.jpg *.jpeg *.bmp *.webp)"'

filter_count = text.count(old_filter)
if filter_count:
    text = text.replace(old_filter, new_filter)
    print(f"[OK] Updated file dialog filters: {filter_count} occurrence(s)")
else:
    print("[WARN] No simple PDF file dialog filter found")

# ------------------------------------------------------------
# 4) Patch open_pdfs loop to convert images before adding workspace item
# ------------------------------------------------------------
old = '''            for pdf_path in file_paths:
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

new = '''            for source_path in file_paths:
                pdf_path = self._prepare_source_file_for_workspace(source_path)
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] open_pdfs now prepares image files")
else:
    print("[WARN] open_pdfs loop block not found or already changed")

# ------------------------------------------------------------
# 5) Patch add_pdfs_to_workspace loop if present
# ------------------------------------------------------------
old = '''        for pdf_path in file_paths:
            if pdf_path not in existing:
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

new = '''        for source_path in file_paths:
            pdf_path = self._prepare_source_file_for_workspace(source_path)

            if pdf_path not in existing:
                self.workspace_items.append(self._make_workspace_item(pdf_path))
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] add_pdfs_to_workspace now prepares image files")
else:
    print("[SKIP] add_pdfs_to_workspace loop block not found or already changed")

# ------------------------------------------------------------
# 6) Update Welcome text to mention images
# ------------------------------------------------------------
text = text.replace(
    "Print large maps, posters, game boards, and engineering drawings from normal PDF files.",
    "Print large maps, posters, game boards, and engineering drawings from PDF or image files."
)

text = text.replace(
    "1. Open one or more source PDF files.",
    "1. Open one or more source PDF or image files."
)

text = text.replace(
    "• User Guide supports English, 한국어, 日本語, 中文（简体）",
    "• Open PDFs now supports PDF and image files\\n"
    "• User Guide supports English, 한국어, 日本語, 中文（简体）"
)

# ------------------------------------------------------------
# 7) Update User Guide wording lightly
# ------------------------------------------------------------
text = text.replace(
    "Open one or more source PDF files.",
    "Open one or more source PDF or image files."
)

text = text.replace(
    "open your map or poster PDF",
    "open your map, poster PDF, or image file"
)

text = text.replace(
    "지도나 포스터 PDF를 엽니다.",
    "지도, 포스터 PDF 또는 이미지 파일을 엽니다."
)

text = text.replace(
    "地図やポスター PDF を開きます。",
    "地図、ポスター PDF、または画像ファイルを開きます。"
)

text = text.replace(
    "打开地图或海报 PDF",
    "打开地图、海报 PDF 或图片文件"
)

# ------------------------------------------------------------
# 8) Update Release Notes
# ------------------------------------------------------------
release_insert_anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
release_section = """
<h3>Version 0.9.3</h3>
<ul>
  <li><b>Image import support</b>: Open PDFs now supports PNG, JPG, JPEG, BMP, and WEBP image files.</li>
  <li>Images are converted internally to temporary PDF pages so Poster Print and Single Page workflows can be used.</li>
</ul>
<hr>
"""

if "Version 0.9.3" not in text and release_insert_anchor in text:
    text = text.replace(release_insert_anchor, release_insert_anchor + "\n" + release_section, 1)
    print("[OK] Added Release Notes section for 0.9.3")
elif "Image import support" not in text and release_insert_anchor in text:
    text = text.replace(release_insert_anchor, release_insert_anchor + "\n" + release_section, 1)
    print("[OK] Added image import Release Notes")
else:
    print("[SKIP] Release Notes already mention image import or anchor not found")

# ------------------------------------------------------------
# 9) Compile check
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_image_import_support_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "def _convert_image_to_temp_pdf",
    "*.png *.jpg *.jpeg *.bmp *.webp",
    "_prepare_source_file_for_workspace",
    "Version: 0.9.3",
    '"version": "0.9.3"',
    "Image import support",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Open PDFs now accepts PDF and image files")
print("- Supported images: PNG, JPG, JPEG, BMP, WEBP")
print("- Images are converted to temporary PDFs under data/image_imports")
print("- Version bumped to 0.9.3")
print("- Release Notes updated")
