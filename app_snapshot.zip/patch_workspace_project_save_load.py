﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_workspace_project_save_load_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add project serialization helper methods before _collect_project_data
# ------------------------------------------------------------
helpers = r'''
    def _rect_to_project_data(self, rect: QRect) -> dict:
        return {
            "x": rect.x(),
            "y": rect.y(),
            "width": rect.width(),
            "height": rect.height(),
        }

    def _rect_from_project_data(self, rect_data: dict) -> QRect:
        return QRect(
            int(rect_data.get("x", 0)),
            int(rect_data.get("y", 0)),
            int(rect_data.get("width", 0)),
            int(rect_data.get("height", 0)),
        )

    def _serialize_workspace_items(self) -> list[dict]:
        if hasattr(self, "workspace_items") and self.current_workspace_index is not None:
            self._save_current_workspace_state()

        result = []

        for item in getattr(self, "workspace_items", []):
            selections = {}

            for page_index, rect in item.get("page_selections", {}).items():
                selections[str(int(page_index))] = self._rect_to_project_data(rect)

            result.append(
                {
                    "pdf_path": item.get("pdf_path"),
                    "page_count": int(item.get("page_count", 0) or 0),
                    "current_page_index": int(item.get("current_page_index", 0) or 0),
                    "checked_pages": sorted([int(x) for x in item.get("checked_pages", set())]),
                    "selections": selections,
                }
            )

        return result

    def _serialize_export_order(self) -> list[dict]:
        result = []

        if not hasattr(self, "export_order_list"):
            return result

        for row in range(self.export_order_list.count()):
            list_item = self.export_order_list.item(row)
            data = list_item.data(Qt.ItemDataRole.UserRole)

            if not isinstance(data, dict):
                continue

            try:
                result.append(
                    {
                        "workspace_index": int(data.get("workspace_index")),
                        "page_index": int(data.get("page_index")),
                    }
                )
            except Exception:
                continue

        return result

    def _restore_export_order_from_project(self, export_order: list[dict]) -> None:
        if not hasattr(self, "export_order_list"):
            return

        self.export_order_list.clear()

        for entry in export_order or []:
            try:
                workspace_index = int(entry.get("workspace_index"))
                page_index = int(entry.get("page_index"))
            except Exception:
                continue

            if workspace_index < 0 or workspace_index >= len(self.workspace_items):
                continue

            self._add_export_order_item(workspace_index, page_index)

    def _restore_workspace_items_from_project(self, workspace_items: list[dict]) -> None:
        self.workspace_items = []
        self.current_workspace_index = None

        if hasattr(self, "workspace_pdf_list"):
            self.workspace_pdf_list.clear()
        if hasattr(self, "export_order_list"):
            self.export_order_list.clear()

        for saved_item in workspace_items or []:
            pdf_path = saved_item.get("pdf_path")

            if not pdf_path:
                continue

            item = {
                "pdf_path": pdf_path,
                "page_count": int(saved_item.get("page_count", 0) or 0),
                "current_page_index": int(saved_item.get("current_page_index", 0) or 0),
                "page_selections": {},
                "checked_pages": set(),
            }

            # Refresh page count from actual file when possible.
            try:
                probe = self._make_workspace_item(pdf_path)
                if int(probe.get("page_count", 0) or 0) > 0:
                    item["page_count"] = int(probe.get("page_count", 0))
            except Exception:
                pass

            for page_index in saved_item.get("checked_pages", []):
                try:
                    item["checked_pages"].add(int(page_index))
                except Exception:
                    continue

            selections = saved_item.get("selections", {})
            for page_key, rect_data in selections.items():
                try:
                    item["page_selections"][int(page_key)] = self._rect_from_project_data(rect_data)
                except Exception:
                    continue

            self.workspace_items.append(item)

        self._refresh_workspace_list_text()

'''

if "def _serialize_workspace_items" not in text:
    marker = "    def _collect_project_data(self) -> dict:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find _collect_project_data marker")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + helpers + "\n" + text[pos:]
    print("[OK] Added workspace project serialization helpers")
else:
    print("[SKIP] Workspace serialization helpers already exist")

# ------------------------------------------------------------
# 2) Replace _collect_project_data
# ------------------------------------------------------------
start_marker = "    def _collect_project_data(self) -> dict:\n"
start = text.find(start_marker)

if start == -1:
    print("[ERROR] _collect_project_data not found")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

end_marker = "\n    def _apply_project_data"
end = text.find(end_marker, start)

if end == -1:
    print("[ERROR] Could not find end of _collect_project_data")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

new_collect = r'''    def _collect_project_data(self) -> dict:
        # Keep current page selection before saving.
        if self.page_count > 0:
            self._save_current_selection()

        selections = {}
        for page_index, rect in self.page_selections.items():
            selections[str(page_index)] = self._rect_to_project_data(rect)

        workspace_items = self._serialize_workspace_items()
        export_order = self._serialize_export_order()

        return {
            "app": "PDF Poster Studio",
            "version": "0.9.0-workspace",
            "saved_at": datetime.now().isoformat(timespec="seconds"),

            # Legacy/single-PDF compatibility fields.
            "pdf_path": self.current_pdf_path,
            "last_exported_pdf_path": self.last_exported_pdf_path,
            "current_page_index": self.current_page_index,
            "page_count": self.page_count,
            "selections": selections,
            "checked_pages": sorted(list(self.checked_pages)),

            # Workspace project fields.
            "workspace": {
                "items": workspace_items,
                "current_workspace_index": self.current_workspace_index,
                "export_order": export_order,
            },

            "settings": {
                "export_type": self.export_type_combo.currentData(),
                "selection_fit_mode": self.selection_fit_mode_combo.currentData(),
                "page_orientation": self.page_orientation_combo.currentData(),
                "export_quality": self.export_quality_combo.currentData(),
                "batch_output": self.batch_output_combo.currentData(),
                "print_quality_dpi": self.print_quality_combo.currentData(),
                "auto_select_sensitivity": self.auto_select_sensitivity_combo.currentData(),
                "output_mode": self.output_mode_combo.currentData(),
                "split_layout": self.split_layout_combo.currentData(),
                "add_numbers": self.numbering_check.isChecked(),
                "add_cut_guides": self.cut_guides_check.isChecked(),
                "rotation_degrees": self.rotation_degrees,
                "preview_zoom_factor": self.preview_zoom_factor,
                "fit_to_page_enabled": self.fit_to_page_enabled,
            },
        }
'''

text = text[:start] + new_collect + text[end:]
print("[OK] Replaced _collect_project_data with workspace-aware version")

# ------------------------------------------------------------
# 3) Replace _apply_project_data
# ------------------------------------------------------------
start_marker = "    def _apply_project_data(self, data: dict) -> None:\n"
start = text.find(start_marker)

if start == -1:
    print("[ERROR] _apply_project_data not found")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# End before next function after apply_project_data.
# In current file, _confirm_discard_changes likely follows later, but use next "\n    def ".
next_def = text.find("\n    def ", start + len(start_marker))
if next_def == -1:
    print("[ERROR] Could not find end of _apply_project_data")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

new_apply = r'''    def _apply_project_data(self, data: dict) -> None:
        self.last_exported_pdf_path = data.get("last_exported_pdf_path")

        settings = data.get("settings", {})
        self._apply_combo_data(self.export_type_combo, settings.get("export_type"))
        self._apply_combo_data(self.selection_fit_mode_combo, settings.get("selection_fit_mode"))
        self._apply_combo_data(self.page_orientation_combo, settings.get("page_orientation"))
        self._apply_combo_data(self.export_quality_combo, settings.get("export_quality"))
        self._apply_combo_data(self.batch_output_combo, settings.get("batch_output"))
        self._apply_combo_data(self.print_quality_combo, settings.get("print_quality_dpi"))
        self._apply_combo_data(self.auto_select_sensitivity_combo, settings.get("auto_select_sensitivity"))
        self._apply_combo_data(self.output_mode_combo, settings.get("output_mode"))
        self._apply_combo_data(self.split_layout_combo, settings.get("split_layout"))
        self.update_export_option_states()

        self.numbering_check.setChecked(bool(settings.get("add_numbers", True)))
        self.cut_guides_check.setChecked(bool(settings.get("add_cut_guides", True)))

        self.rotation_degrees = int(settings.get("rotation_degrees", 0)) % 360
        self.preview_zoom_factor = float(settings.get("preview_zoom_factor", 1.0))
        self.fit_to_page_enabled = bool(settings.get("fit_to_page_enabled", True))

        workspace = data.get("workspace", {})
        workspace_items = workspace.get("items", [])

        if workspace_items:
            self._restore_workspace_items_from_project(workspace_items)

            target_workspace_index = workspace.get("current_workspace_index")
            try:
                target_workspace_index = int(target_workspace_index)
            except Exception:
                target_workspace_index = 0

            if self.workspace_items:
                target_workspace_index = max(0, min(target_workspace_index, len(self.workspace_items) - 1))
                self._load_workspace_index(target_workspace_index)

            self._restore_export_order_from_project(workspace.get("export_order", []))

        else:
            # Legacy single-PDF project support.
            pdf_path = data.get("pdf_path")
            if pdf_path:
                self._open_pdf_path(pdf_path, clear_selections=False)

            self.checked_pages = set()
            for page_index in data.get("checked_pages", []):
                try:
                    self.checked_pages.add(int(page_index))
                except Exception:
                    continue

            self.page_selections.clear()
            selections = data.get("selections", {})

            for page_key, rect_data in selections.items():
                try:
                    self.page_selections[int(page_key)] = self._rect_from_project_data(rect_data)
                except Exception:
                    continue

            target_page = int(data.get("current_page_index", 0))
            if self.page_count > 0:
                self.current_page_index = max(0, min(target_page, self.page_count - 1))
                self._render_current_page()
                self._rebuild_page_list()

        self._refresh_workspace_list_text()
        self._refresh_current_page_check_state()
        self._refresh_page_list_all_text()
        self._update_checked_pages_label()

        self.is_modified = False
'''

text = text[:start] + new_apply + text[next_def:]
print("[OK] Replaced _apply_project_data with workspace-aware version")

# ------------------------------------------------------------
# 4) Patch snapshot history methods if old _collect_current_state/_restore_state exist
#    Keep them as-is if not found. Project save/load is main target.
# ------------------------------------------------------------

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 5) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_workspace_project_save_load_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
required = [
    "def _serialize_workspace_items",
    "def _restore_workspace_items_from_project",
    '"workspace":',
    '"export_order": export_order',
    "0.9.0-workspace",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Project save/load now supports Workspace PDF list")
print("- Per-PDF selections and checked pages are saved")
print("- Export Order is saved/restored")
print("- Legacy single-PDF project loading is preserved")
