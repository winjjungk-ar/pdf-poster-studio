﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_make_poster_choice_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

new_task_make_poster = r'''    def task_make_poster(self) -> None:
        self._set_combo_by_data_if_exists("export_type_combo", "a3_split")

        dialog = QMessageBox(self)
        dialog.setWindowTitle("Make Poster")
        dialog.setIcon(QMessageBox.Icon.Question)
        dialog.setText("What area do you want to use for the poster?")
        dialog.setInformativeText(
            "Whole Page uses the full page or image.\n\n"
            "Selected Area uses only the area you select in the preview."
        )

        whole_button = dialog.addButton("Use Whole Page", QMessageBox.ButtonRole.AcceptRole)
        selected_button = dialog.addButton("Use Selected Area", QMessageBox.ButtonRole.ActionRole)
        cancel_button = dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)

        dialog.setDefaultButton(whole_button)
        dialog.exec()

        clicked = dialog.clickedButton()

        if clicked == cancel_button:
            return

        if clicked == whole_button:
            self._set_combo_by_data_if_exists("output_area_combo", "whole_page")
            area_message = (
                "Output Area set to Whole Page.\n\n"
                "Choose Poster Size Preset, check Tiling Preview, then click Poster PDF in the toolbar."
            )
        elif clicked == selected_button:
            self._set_combo_by_data_if_exists("output_area_combo", "selected_area")
            area_message = (
                "Output Area set to Selected Area.\n\n"
                "Drag to select an area or use Auto Select, then Build Print Order and click Poster PDF."
            )
        else:
            return

        self.update_export_option_states()
        self.update_output_area_states()
        self.update_action_summary()

        if hasattr(self, "settings_tabs") and hasattr(self, "a3_split_group"):
            self.settings_tabs.setCurrentWidget(self.a3_split_group)

        QMessageBox.information(
            self,
            "Make Poster",
            area_message
        )

'''

try:
    text = replace_function(text, "task_make_poster", new_task_make_poster)
    print("[OK] Make Poster now asks Whole Page / Selected Area")
except Exception as exc:
    print(f"[ERROR] Failed to replace task_make_poster: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

# Release Notes
if "Make Poster area choice" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Make Poster area choice</b>: Home > Make Poster now asks whether to use Whole Page or Selected Area.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_make_poster_choice_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "What area do you want to use for the poster?",
    "Use Whole Page",
    "Use Selected Area",
    "Make Poster area choice",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Home > Make Poster now asks Whole Page or Selected Area")
print("- Poster Print tab opens after selection")
