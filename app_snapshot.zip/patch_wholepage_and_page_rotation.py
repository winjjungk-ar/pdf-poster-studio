﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_wholepage_rotation_per_page_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)
    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]
    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")
    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

def insert_before_function(source: str, func_name: str, code: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)
    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]
    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")
    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + code + "\n" + "".join(lines[node.lineno - 1:])

# ------------------------------------------------------------
# 1) Add per-page rotation state in __init__
# ------------------------------------------------------------
old = '''        self.rotation_degrees = 0
        self.current_display_base_width = 1
        self.current_display_base_height = 1
'''

new = '''        self.rotation_degrees = 0
        # Page-specific rotation. This prevents rotating one page from rotating all pages.
        self.page_rotations: dict[int, int] = {}
        self.current_display_base_width = 1
        self.current_display_base_height = 1
'''

if old in text and "self.page_rotations" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added page_rotations state")
elif "self.page_rotations" in text:
    print("[SKIP] page_rotations already exists")
else:
    print("[WARN] Could not find rotation init block")

# ------------------------------------------------------------
# 2) Add rotation helper methods
# ------------------------------------------------------------
helpers = r'''
    def _get_current_rotation_degrees(self) -> int:
        return int(self.page_rotations.get(self.current_page_index, self.rotation_degrees)) % 360

    def _set_current_rotation_degrees(self, degrees: int) -> None:
        self.page_rotations[self.current_page_index] = int(degrees) % 360
        self.rotation_degrees = self.page_rotations[self.current_page_index]

    def _get_page_rotation_degrees(self, page_index: int) -> int:
        return int(self.page_rotations.get(page_index, 0)) % 360

'''

if "def _get_current_rotation_degrees" not in text:
    try:
        text = insert_before_function(text, "_render_current_page", helpers)
        print("[OK] Added per-page rotation helpers")
    except Exception as exc:
        print(f"[ERROR] Could not insert rotation helpers: {exc}")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] Rotation helpers already exist")

# ------------------------------------------------------------
# 3) Replace global rotation reads in display code
# ------------------------------------------------------------
text = text.replace(
    "angle = self.rotation_degrees % 360",
    "angle = self._get_current_rotation_degrees() % 360"
)

text = text.replace(
    'self.rotation_info_label.setText(f"Rotation: {self.rotation_degrees % 360}°")',
    'self.rotation_info_label.setText(f"Rotation: {self._get_current_rotation_degrees() % 360}°")'
)

# ------------------------------------------------------------
# 4) Replace rotate/reset functions
# ------------------------------------------------------------
new_rotate_left = r'''    def rotate_left(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        new_degrees = (self._get_current_rotation_degrees() - 90) % 360
        self._set_current_rotation_degrees(new_degrees)
        self._show_pixmap()
        self._log(f"Rotate Left applied on page {self.current_page_index + 1}: {new_degrees} degrees.")
'''

new_rotate_right = r'''    def rotate_right(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        new_degrees = (self._get_current_rotation_degrees() + 90) % 360
        self._set_current_rotation_degrees(new_degrees)
        self._show_pixmap()
        self._log(f"Rotate Right applied on page {self.current_page_index + 1}: {new_degrees} degrees.")
'''

new_reset_rotation = r'''    def reset_rotation(self) -> None:
        self._push_undo_state()
        if self.current_pixmap is None:
            return

        self._save_current_selection()
        self._set_current_rotation_degrees(0)
        self._show_pixmap()
        self._log(f"Rotation reset on page {self.current_page_index + 1}.")
'''

new_reset_view = r'''    def reset_view(self) -> None:
        """Reset preview view state for current page: rotation + zoom + fit page."""
        if self.page_count <= 0:
            return

        self._save_current_selection()

        self._set_current_rotation_degrees(0)
        self.preview_zoom_factor = 1.0
        self.fit_to_page_enabled = True

        self._render_current_page()

        if hasattr(self, "rotation_info_label"):
            self.rotation_info_label.setText("Rotation: 0°")

        if hasattr(self, "zoom_info_label"):
            self.zoom_info_label.setText("Zoom: Fit Page")

        self._log("View reset for current page: rotation=0°, zoom=Fit Page.")
'''

for fn, code in [
    ("rotate_left", new_rotate_left),
    ("rotate_right", new_rotate_right),
    ("reset_rotation", new_reset_rotation),
    ("reset_view", new_reset_view),
]:
    try:
        text = replace_function(text, fn, code)
        print(f"[OK] Replaced {fn}")
    except Exception as exc:
        print(f"[WARN] Could not replace {fn}: {exc}")

# ------------------------------------------------------------
# 5) Save/load page rotations in workspace state
# ------------------------------------------------------------
old = '''        item["current_page_index"] = self.current_page_index
        item["page_selections"] = {page: QRect(rect) for page, rect in self.page_selections.items()}
        item["checked_pages"] = set(self.checked_pages)
'''

new = '''        item["current_page_index"] = self.current_page_index
        item["page_selections"] = {page: QRect(rect) for page, rect in self.page_selections.items()}
        item["checked_pages"] = set(self.checked_pages)
        item["page_rotations"] = {int(page): int(deg) % 360 for page, deg in self.page_rotations.items()}
'''

if old in text and 'item["page_rotations"]' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Workspace state now saves page_rotations")
else:
    print("[SKIP] Workspace rotation save already exists or anchor not found")

old = '''        self.page_selections = {
            int(page): QRect(rect)
            for page, rect in item.get("page_selections", {}).items()
        }
        self.checked_pages = set(item.get("checked_pages", set()))
'''

new = '''        self.page_selections = {
            int(page): QRect(rect)
            for page, rect in item.get("page_selections", {}).items()
        }
        self.checked_pages = set(item.get("checked_pages", set()))
        self.page_rotations = {
            int(page): int(deg) % 360
            for page, deg in item.get("page_rotations", {}).items()
        }
        self.rotation_degrees = self._get_current_rotation_degrees()
'''

if old in text and "item.get(\"page_rotations\"" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Workspace load now restores page_rotations")
else:
    print("[SKIP] Workspace rotation load already exists or anchor not found")

# serialize project
old = '''                    "checked_pages": sorted([int(x) for x in item.get("checked_pages", set())]),
                    "selections": selections,
'''

new = '''                    "checked_pages": sorted([int(x) for x in item.get("checked_pages", set())]),
                    "page_rotations": {str(int(page)): int(deg) % 360 for page, deg in item.get("page_rotations", {}).items()},
                    "selections": selections,
'''

if old in text and '"page_rotations"' not in text[text.find("def _serialize_workspace_items"):text.find("def _serialize_export_order")]:
    text = text.replace(old, new, 1)
    print("[OK] Project save now includes page_rotations")
else:
    print("[SKIP] Project rotation save already exists or anchor not found")

# restore project
old = '''                "page_selections": {},
                "checked_pages": set(),
            }
'''

new = '''                "page_selections": {},
                "checked_pages": set(),
                "page_rotations": {},
            }
'''

if old in text and '"page_rotations": {}' not in text[text.find("def _restore_workspace_items_from_project"):text.find("self.workspace_items.append")]:
    text = text.replace(old, new, 1)
    print("[OK] Project restore item includes page_rotations")
else:
    print("[SKIP] Project restore page_rotations dict already exists or anchor not found")

old = '''            selections = saved_item.get("selections", {})
            for page_key, rect_data in selections.items():
'''

new = '''            for page_key, degrees in saved_item.get("page_rotations", {}).items():
                try:
                    item["page_rotations"][int(page_key)] = int(degrees) % 360
                except Exception:
                    continue

            selections = saved_item.get("selections", {})
            for page_key, rect_data in selections.items():
'''

if old in text and 'saved_item.get("page_rotations"' not in text:
    text = text.replace(old, new, 1)
    print("[OK] Project restore now loads page_rotations")
else:
    print("[SKIP] Project rotation restore already exists or anchor not found")

# ------------------------------------------------------------
# 6) Print Order thumbnail should reflect page rotation
# ------------------------------------------------------------
old = '''            pixmap = renderer.render_page(page_index, zoom=0.35)

            if pixmap.isNull():
                return QIcon()
'''

new = '''            pixmap = renderer.render_page(page_index, zoom=0.35)

            page_rotation = 0
            try:
                page_rotation = int(item.get("page_rotations", {}).get(page_index, 0)) % 360
            except Exception:
                page_rotation = 0

            if page_rotation:
                transform = QTransform()
                transform.rotate(page_rotation)
                pixmap = pixmap.transformed(
                    transform,
                    Qt.TransformationMode.SmoothTransformation,
                )

            if pixmap.isNull():
                return QIcon()
'''

if old in text and "page_rotation = 0" not in text[text.find("def _create_export_order_thumbnail"):text.find("canvas = QPixmap", text.find("def _create_export_order_thumbnail"))]:
    text = text.replace(old, new, 1)
    print("[OK] Print Order thumbnail now reflects page rotation")
else:
    print("[SKIP] Thumbnail rotation already exists or anchor not found")

# ------------------------------------------------------------
# 7) Whole Page + no checked pages: export current page automatically
# ------------------------------------------------------------
old = '''        if not self.checked_pages:
            raise RuntimeError("No checked pages exist. Please select an area and check pages for export.")
'''

new = '''        if not self.checked_pages:
            if self._is_whole_page_output_area() and self.page_count > 0:
                self.checked_pages.add(self.current_page_index)
            else:
                raise RuntimeError("No checked pages exist. Please select an area and check pages for export.")
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Whole Page export now auto-uses current page if none checked")
else:
    print("[WARN] Could not find no checked pages block")

# ------------------------------------------------------------
# 8) New project / clear all should clear rotations
# ------------------------------------------------------------
text = text.replace(
    "self.page_selections.clear()\n        self.page_selection_display_sizes.clear()\n        self.checked_pages.clear()",
    "self.page_selections.clear()\n        self.page_selection_display_sizes.clear()\n        self.page_rotations.clear()\n        self.checked_pages.clear()"
)

text = text.replace(
    "self.page_selections.clear()\n            self.page_selection_display_sizes.clear()\n            self.checked_pages.clear()",
    "self.page_selections.clear()\n            self.page_selection_display_sizes.clear()\n            self.page_rotations.clear()\n            self.checked_pages.clear()"
)

# ------------------------------------------------------------
# 9) Release Notes
# ------------------------------------------------------------
if "Page-specific rotation" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Page-specific rotation</b>: Rotating one page no longer rotates every page in the same PDF.</li>
  <li><b>Print Order thumbnails</b>: Thumbnails now reflect page rotation.</li>
  <li><b>Whole Page export fix</b>: Create Single Page PDF can use the current full page without requiring a selection.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")

# ------------------------------------------------------------
# 10) Compile
# ------------------------------------------------------------
MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_wholepage_rotation_per_page_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)
    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "page_rotations",
    "def _get_current_rotation_degrees",
    "Page-specific rotation",
    "Print Order thumbnail now reflects page rotation",
    "Whole Page export now auto-uses current page",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Whole Page + Create Single Page PDF no longer requires manual selection")
print("- Rotation is now page-specific")
print("- Print Order thumbnails reflect page rotation")
