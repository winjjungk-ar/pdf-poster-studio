﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_rename_open_pdfs_images_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")

# User-facing rename only.
# Keep function names like open_pdfs unchanged.
replacements = [
    ('QPushButton("Open PDFs")', 'QPushButton("Open PDFs / Images")'),
    ('QAction("Open PDFs", self)', 'QAction("Open PDFs / Images", self)'),
    ('addAction("Open PDFs", self.open_pdfs)', 'addAction("Open PDFs / Images", self.open_pdfs)'),

    ('<b>Open PDFs</b>', '<b>Open PDFs / Images</b>'),
    ('Click <b>Open PDFs</b>', 'Click <b>Open PDFs / Images</b>'),
    ('<li><b>Open PDFs</b>:', '<li><b>Open PDFs / Images</b>:'),

    ('"Open PDFs"', '"Open PDFs / Images"'),
]

changed = 0
for old, new in replacements:
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        changed += count
        print(f"[OK] Replaced {count}: {old} -> {new}")

# Avoid changing dialog title "Open PDFs or Images" into weird form if global replacement touched it.
text = text.replace('"Open PDFs / Images or Images"', '"Open PDFs or Images"')
text = text.replace('"Open PDFs / Images Error"', '"Open PDFs or Images Error"')

# Improve welcome/source wording if present.
text = text.replace(
    "Open one or more source PDF files.",
    "Open one or more source PDF or image files."
)
text = text.replace(
    "Open one or more source PDF file",
    "Open one or more source PDF or image file"
)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_rename_open_pdfs_images_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Open PDFs / Images",
    "Open PDFs or Images",
    "PDF and Image Files",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print(f"- user-facing replacements: {changed}")
print("- Toolbar/File/Welcome/User Guide should now say Open PDFs / Images")
