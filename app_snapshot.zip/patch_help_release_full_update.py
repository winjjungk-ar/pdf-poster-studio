﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_help_release_full_update_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

new_user_guide = r'''    def show_user_guide(self) -> None:
        guides = {
            "English": """
<h2>PDF Poster Studio - User Guide</h2>

<p>
PDF Poster Studio helps you create print-ready PDFs from PDF and image files.
You can merge PDFs, extract pages, make tiled posters, rotate pages, or export selected areas.
</p>

<hr>

<h3>1. Home Task Launcher</h3>
<p>
The Home tab and startup launcher provide guided workflows:
</p>
<ul>
  <li><b>Merge PDFs</b>: Combine full pages into one PDF.</li>
  <li><b>Extract Pages</b>: Export only chosen page ranges.</li>
  <li><b>Make Poster</b>: Create tiled prints for maps, posters, images, and drawings.</li>
  <li><b>Rotate Pages</b>: Rotate current, checked, or all pages and save a new PDF.</li>
  <li><b>Selected Area PDF</b>: Export only a selected area.</li>
</ul>

<hr>

<h3>2. Make Poster</h3>
<p>
Make Poster is the main workflow for large maps, game boards, wall posters, and engineering drawings.
</p>
<ol>
  <li>Choose <b>Make Poster</b>.</li>
  <li>Select <b>Open One File</b> for a single map/poster/drawing, or <b>Use Current Source PDFs</b> for advanced multi-file workflows.</li>
  <li>Choose <b>Whole Page</b> or <b>Selected Area</b>.</li>
  <li>Choose Output Paper Size: A4 or US Letter.</li>
  <li>Choose a preset: Poster Small/Medium/Large/Huge, A-series, ANSI, or Arch.</li>
  <li>Check <b>Tiling Preview</b>.</li>
  <li>Click <b>Build Print Order</b>.</li>
  <li>Click <b>Poster PDF</b> in the toolbar.</li>
</ol>

<hr>

<h3>3. Whole Page vs Selected Area</h3>
<ul>
  <li><b>Whole Page</b>: Uses the full page or full image. Good for PDF merging and full-map posters.</li>
  <li><b>Selected Area</b>: Uses only the area you select. Good for zooming in on part of a page.</li>
</ul>
<p>
If you manually drag a selection, Output Area automatically changes to Selected Area.
</p>

<hr>

<h3>4. Merge PDFs</h3>
<ol>
  <li>Choose <b>Merge PDFs</b>.</li>
  <li>Open PDF/image files if needed.</li>
  <li>The app sets Output Area to Whole Page, Output Files to One PDF, and Single Page Mode.</li>
  <li>All source pages are added to Print Order.</li>
  <li>Click <b>Single Page PDF</b> in the toolbar.</li>
</ol>

<hr>

<h3>5. Extract Pages</h3>
<ol>
  <li>Choose <b>Extract Pages</b>.</li>
  <li>Enter a page range such as <b>all</b>, <b>1-10</b>, <b>1,3,5</b>, or <b>10-20,35</b>.</li>
  <li>The app uses Whole Page and defaults to Separate PDF per selected page.</li>
  <li>Click <b>Single Page PDF</b> to export.</li>
</ol>

<hr>

<h3>6. Rotate Pages</h3>
<ol>
  <li>Choose <b>Rotate Pages</b>.</li>
  <li>Select Current Page, Checked Pages, or All Pages.</li>
  <li>Choose Rotate Left, Rotate Right, or Reset Rotation.</li>
  <li>The app prepares Print Order using Whole Page mode.</li>
  <li>Click <b>Single Page PDF</b> to save the rotated output.</li>
</ol>

<hr>

<h3>7. Single Page PDF</h3>
<p>
Use <b>Single Page PDF</b> to export pages or selected areas as clean non-tiled PDF output.
</p>
<ul>
  <li><b>Fit Width</b>: Fit the selected area to page width.</li>
  <li><b>Fit Whole Area</b>: Fit the whole selected area without cropping.</li>
  <li><b>Fill Page Crop</b>: Fill the page; edges may be cropped.</li>
  <li><b>Fit Height</b>: Fit the selected area to page height.</li>
</ul>

<hr>

<h3>8. Output Files</h3>
<ul>
  <li><b>One PDF</b>: Combine all Print Order items into one PDF.</li>
  <li><b>Separate PDF per selected page</b>: Create one PDF for each Print Order item.</li>
</ul>

<hr>

<h3>9. Auto Select</h3>
<ul>
  <li><b>Auto Current</b>: Auto-select content on the current page.</li>
  <li><b>Auto All</b>: Auto-select content on all pages.</li>
  <li><b>Auto Range</b>: Auto-select only a page range such as 1-20.</li>
</ul>
<p>
Auto Select is available when Output Area is Selected Area.
</p>

<hr>

<h3>10. Text Search and OCR</h3>
<p>
Find Text works only with PDFs that already contain text.
Scanned PDFs or image-only PDFs may require OCR in another tool before searching.
</p>

<hr>

<h3>11. Exported Files and Projects</h3>
<ul>
  <li>Generated PDFs are saved to the exports folder.</li>
  <li>Use <b>Open Exports Folder</b> to find output files.</li>
  <li>Use <b>Save Project As</b> to save Source PDFs, selections, Print Order, and settings.</li>
</ul>
""",

            "한국어": """
<h2>PDF Poster Studio - 사용 방법</h2>

<p>
PDF Poster Studio는 PDF와 이미지 파일을 이용해 출력용 PDF를 만드는 프로그램입니다.
PDF 합치기, 페이지 추출, 포스터 분할 출력, 페이지 회전 저장, 선택 영역 출력이 가능합니다.
</p>

<hr>

<h3>1. Home 작업 메뉴</h3>
<ul>
  <li><b>Merge PDFs</b>: 전체 페이지를 하나의 PDF로 합칩니다.</li>
  <li><b>Extract Pages</b>: 원하는 페이지 범위만 추출합니다.</li>
  <li><b>Make Poster</b>: 지도, 포스터, 이미지, 도면을 여러 장으로 나누어 출력합니다.</li>
  <li><b>Rotate Pages</b>: 현재/체크/전체 페이지를 회전하고 새 PDF로 저장합니다.</li>
  <li><b>Selected Area PDF</b>: 선택한 영역만 PDF로 출력합니다.</li>
</ul>

<hr>

<h3>2. 포스터 만들기</h3>
<ol>
  <li><b>Make Poster</b>를 선택합니다.</li>
  <li>한 파일만 사용할 경우 <b>Open One File</b>을 선택합니다.</li>
  <li>이미 불러온 여러 파일을 사용할 경우 <b>Use Current Source PDFs</b>를 선택합니다.</li>
  <li><b>Whole Page</b> 또는 <b>Selected Area</b>를 선택합니다.</li>
  <li>A4 또는 US Letter를 선택합니다.</li>
  <li>Poster Small/Medium/Large/Huge, A-series, ANSI, Arch 프리셋을 선택합니다.</li>
  <li><b>Tiling Preview</b>를 확인합니다.</li>
  <li><b>Build Print Order</b> 후 툴바의 <b>Poster PDF</b>를 누릅니다.</li>
</ol>

<hr>

<h3>3. Whole Page / Selected Area</h3>
<ul>
  <li><b>Whole Page</b>: 전체 페이지 또는 전체 이미지를 사용합니다. PDF 합치기나 전체 지도 출력에 좋습니다.</li>
  <li><b>Selected Area</b>: 선택한 영역만 사용합니다. 도면/지도 일부 확대에 좋습니다.</li>
</ul>
<p>
마우스로 영역을 선택하면 Output Area가 자동으로 Selected Area로 바뀝니다.
</p>

<hr>

<h3>4. PDF 합치기</h3>
<ol>
  <li><b>Merge PDFs</b>를 선택합니다.</li>
  <li>필요하면 PDF/이미지를 엽니다.</li>
  <li>앱이 Whole Page, One PDF, Single Page Mode로 자동 설정합니다.</li>
  <li>모든 Source 페이지가 Print Order에 추가됩니다.</li>
  <li>툴바의 <b>Single Page PDF</b>를 누릅니다.</li>
</ol>

<hr>

<h3>5. 페이지 추출</h3>
<ol>
  <li><b>Extract Pages</b>를 선택합니다.</li>
  <li><b>all</b>, <b>1-10</b>, <b>1,3,5</b>, <b>10-20,35</b> 같은 페이지 범위를 입력합니다.</li>
  <li>기본적으로 Separate PDF per selected page로 설정됩니다.</li>
  <li><b>Single Page PDF</b>를 눌러 출력합니다.</li>
</ol>

<hr>

<h3>6. 페이지 회전 저장</h3>
<ol>
  <li><b>Rotate Pages</b>를 선택합니다.</li>
  <li>Current Page, Checked Pages, All Pages 중 하나를 선택합니다.</li>
  <li>Rotate Left, Rotate Right, Reset Rotation을 선택합니다.</li>
  <li>앱이 Whole Page 기준으로 Print Order를 준비합니다.</li>
  <li><b>Single Page PDF</b>를 눌러 회전된 PDF를 저장합니다.</li>
</ol>

<hr>

<h3>7. Output Files</h3>
<ul>
  <li><b>One PDF</b>: Print Order 항목을 하나의 PDF로 만듭니다.</li>
  <li><b>Separate PDF per selected page</b>: 각 항목을 별도 PDF로 만듭니다.</li>
</ul>

<hr>

<h3>8. Auto Select</h3>
<ul>
  <li><b>Auto Current</b>: 현재 페이지 내용 영역을 자동 선택합니다.</li>
  <li><b>Auto All</b>: 모든 페이지를 자동 선택합니다.</li>
  <li><b>Auto Range</b>: 1-20 같은 특정 범위만 자동 선택합니다.</li>
</ul>

<hr>

<h3>9. 텍스트 검색과 OCR</h3>
<p>
Find Text는 PDF 안에 텍스트 정보가 있을 때만 동작합니다.
스캔 PDF나 이미지 PDF는 다른 도구에서 OCR 처리를 해야 검색될 수 있습니다.
</p>
""",

            "日本語": """
<h2>PDF Poster Studio - 使い方</h2>
<p>PDF と画像から、結合、ページ抽出、ポスター分割、回転保存、選択範囲出力ができます。</p>

<hr>
<h3>Home タスク</h3>
<ul>
<li><b>Merge PDFs</b>: ページ全体を1つの PDF にまとめます。</li>
<li><b>Extract Pages</b>: 指定したページ範囲だけを抽出します。</li>
<li><b>Make Poster</b>: 地図、ポスター、画像、図面を複数ページに分割します。</li>
<li><b>Rotate Pages</b>: ページを回転して新しい PDF として保存します。</li>
<li><b>Selected Area PDF</b>: 選択範囲だけを出力します。</li>
</ul>

<hr>
<h3>Make Poster</h3>
<p><b>Open One File</b> は1つの地図/画像/図面に最適です。複数ファイルを使う場合は <b>Use Current Source PDFs</b> を選びます。</p>
<p>Whole Page はページ全体、Selected Area は選択範囲のみを使います。</p>

<hr>
<h3>Extract Pages</h3>
<p>all、1-10、1,3,5、10-20,35 のようにページ範囲を入力できます。</p>

<hr>
<h3>Rotate Pages</h3>
<p>Current Page、Checked Pages、All Pages を選び、回転後に Single Page PDF で保存します。</p>

<hr>
<h3>OCR 注意</h3>
<p>Find Text はテキスト情報を含む PDF のみ検索できます。スキャン PDF や画像 PDF は OCR が必要な場合があります。</p>
""",

            "中文（简体）": """
<h2>PDF Poster Studio - 使用指南</h2>
<p>本程序可以从 PDF 和图片创建可打印 PDF，支持合并、页面提取、海报分割、页面旋转和选区输出。</p>

<hr>
<h3>Home 任务</h3>
<ul>
<li><b>Merge PDFs</b>：把完整页面合并为一个 PDF。</li>
<li><b>Extract Pages</b>：只提取指定页面范围。</li>
<li><b>Make Poster</b>：把地图、海报、图片、图纸分割到多张纸上。</li>
<li><b>Rotate Pages</b>：旋转页面并保存为新 PDF。</li>
<li><b>Selected Area PDF</b>：只输出选择区域。</li>
</ul>

<hr>
<h3>Make Poster</h3>
<p><b>Open One File</b> 适合单个地图、图片或图纸。多个文件时请选择 <b>Use Current Source PDFs</b>。</p>
<p>Whole Page 使用整个页面，Selected Area 只使用选择区域。</p>

<hr>
<h3>Extract Pages</h3>
<p>可以输入 all、1-10、1,3,5、10-20,35 等页面范围。</p>

<hr>
<h3>Rotate Pages</h3>
<p>选择 Current Page、Checked Pages 或 All Pages，旋转后用 Single Page PDF 保存。</p>

<hr>
<h3>OCR 说明</h3>
<p>Find Text 只能搜索包含文本层的 PDF。扫描 PDF 或纯图片 PDF 可能需要先使用 OCR 工具处理。</p>
"""
        }

        dialog = QDialog(self)
        dialog.setWindowTitle("User Guide / How to Use")
        dialog.setMinimumSize(820, 660)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        language_layout = QHBoxLayout()
        language_label = QLabel("Language")
        language_combo = QComboBox()
        language_combo.addItems(["English", "한국어", "日本語", "中文（简体）"])
        language_combo.setCurrentText("English")
        language_layout.addWidget(language_label)
        language_layout.addWidget(language_combo)
        language_layout.addStretch()

        guide_view = QTextEdit()
        guide_view.setReadOnly(True)
        guide_view.setHtml(guides["English"])
        guide_view.setStyleSheet("""
            QTextEdit {
                background-color: #FFFDF8;
                color: #2F4F5F;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 10px;
                font-family: Segoe UI, Arial;
                font-size: 10.5pt;
            }
        """)

        def change_language() -> None:
            guide_view.setHtml(guides.get(language_combo.currentText(), guides["English"]))

        language_combo.currentIndexChanged.connect(change_language)

        close_button = QPushButton("Close")
        close_button.clicked.connect(dialog.accept)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_button)

        layout.addLayout(language_layout)
        layout.addWidget(guide_view)
        layout.addLayout(button_layout)

        dialog.exec()
'''

new_release_notes = r'''    def show_release_notes(self) -> None:
        notes = """
<h2>PDF Poster Studio - Release Notes</h2>

<h3>Version 0.9.6</h3>
<ul>
  <li><b>Task Launcher welcome screen</b>: Startup popup now shows large workflow cards.</li>
  <li><b>Home task cards</b>: Merge PDFs, Extract Pages, Make Poster, Rotate Pages, and Selected Area PDF workflows.</li>
  <li><b>Make Poster source choice</b>: Choose Open One File or Use Current Source PDFs.</li>
  <li><b>Make Poster area choice</b>: Choose Whole Page or Selected Area.</li>
  <li><b>Selected Area PDF task choice</b>: Choose Auto Select Current Page or Select Manually.</li>
  <li><b>Merge PDFs automation</b>: Adds all source pages to Print Order using Whole Page and One PDF.</li>
  <li><b>Extract Pages page ranges</b>: Supports all, 1-10, 1,3,5, and mixed ranges.</li>
  <li><b>Rotate Pages workflow</b>: Rotate current, checked, or all pages and prepare Print Order.</li>
  <li><b>Output Area</b>: Whole Page or Selected Area.</li>
  <li><b>Auto Select Page Range</b>: Process only selected page ranges for large PDFs.</li>
  <li><b>Preview floating toolbar</b>: Collapsible view controls over the preview.</li>
  <li><b>Zoom and Reset View improvements</b>: Better zoom behavior and reset handling.</li>
  <li><b>Page-specific rotation</b>: Rotating one page no longer rotates every page.</li>
  <li><b>Export respects rotation</b>: Output PDF now follows the rotation shown in preview.</li>
  <li><b>Print Order thumbnail refresh</b>: Thumbnails update after rotation.</li>
  <li><b>Image import support</b>: PNG, JPG, JPEG, BMP, and WEBP files are supported.</li>
  <li><b>Multilingual User Guide</b>: English, 한국어, 日本語, 中文（简体）.</li>
</ul>

<hr>

<h3>Version 0.9.5 and earlier highlights</h3>
<ul>
  <li>Poster Print and Single Page workflows.</li>
  <li>One PDF and Separate PDF output modes.</li>
  <li>A4 and US Letter support.</li>
  <li>A-series, ANSI, Arch, and Hobby poster presets.</li>
  <li>Tiling Preview.</li>
  <li>Project save/load.</li>
  <li>Vector PDF quality preservation where possible.</li>
</ul>

<hr>

<h3>Known Notes</h3>
<ul>
  <li>This is still a beta version.</li>
  <li>Large PDFs may take time to process.</li>
  <li>Image files are converted internally to temporary PDF pages.</li>
  <li>Find Text works only with PDFs that already contain text. Scanned PDFs may require OCR in another tool.</li>
</ul>
"""

        dialog = QDialog(self)
        dialog.setWindowTitle("Release Notes")
        dialog.setMinimumSize(760, 620)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        notes_view = QTextEdit()
        notes_view.setReadOnly(True)
        notes_view.setHtml(notes)
        notes_view.setStyleSheet("""
            QTextEdit {
                background-color: #FFFDF8;
                color: #2F4F5F;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 10px;
                font-family: Segoe UI, Arial;
                font-size: 10.5pt;
            }
        """)

        close_button = QPushButton("Close")
        close_button.clicked.connect(dialog.accept)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_button)

        layout.addWidget(notes_view)
        layout.addLayout(button_layout)

        dialog.exec()
'''

try:
    text = replace_function(text, "show_user_guide", new_user_guide)
    print("[OK] User Guide fully updated")
except Exception as exc:
    print(f"[ERROR] Failed to replace show_user_guide: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

try:
    text = replace_function(text, "show_release_notes", new_release_notes)
    print("[OK] Release Notes fully updated")
except Exception as exc:
    print(f"[ERROR] Failed to replace show_release_notes: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_help_release_full_update_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")
print("[INFO] Marker check:")
for marker in [
    "Home Task Launcher",
    "Make Poster",
    "Extract Pages",
    "Rotate Pages workflow",
    "Output Area",
    "Auto Select Page Range",
    "Version 0.9.6",
    "Multilingual User Guide",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- User Guide updated in English/Korean/Japanese/Chinese")
print("- Release Notes consolidated and updated")
