﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_rename_workspace_print_order_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")

# ------------------------------------------------------------
# User-facing label replacements
# ------------------------------------------------------------
replacements = {
    # Main panel labels
    'QLabel("PDF Workspace")': 'QLabel("Source PDFs")',
    'QLabel("Export Order")': 'QLabel("Print Order")',

    # Buttons
    'QPushButton("Build Export Order")': 'QPushButton("Build Print Order")',
    'QPushButton("Refresh Order")': 'QPushButton("Build Print Order")',

    # Dialog titles/messages
    '"Export Order"': '"Print Order"',
    '"Export order refreshed:': '"Print order refreshed:',
    '"No checked pages found.\\n\\nSelect areas on pages first."': '"No selected pages found.\\n\\nSelect areas on pages first."',

    # Log/message wording
    'f"Export order refreshed: {self.export_order_list.count()} pages"': 'f"Print order refreshed: {self.export_order_list.count()} pages"',
    'f"Jumped from Export Order to workspace {workspace_index + 1}, "': 'f"Jumped from Print Order to source PDF {workspace_index + 1}, "',
    'self._log(f"Export Order jump failed: {exc}")': 'self._log(f"Print Order jump failed: {exc}")',

    # Welcome guidance
    '"Start a new print workspace from PDFs, or continue an existing project."':
        '"Open one or more PDFs as source files, or continue an existing project."',

    '"1. Click “Open PDFs” and choose one or more PDF files.\\n"':
        '"1. Click “Open PDFs” and choose one or more source PDF files.\\n"',

    '"2. Select areas, build the export order, then export.\\n\\n"':
        '"2. Select areas, build the print order, then export.\\n\\n"',
}

changed = 0
for old, new in replacements.items():
    count = text.count(old)
    if count:
        text = text.replace(old, new)
        changed += count
        print(f"[OK] Replaced {count} occurrence(s): {old[:60]}")

# More broad but safe user-facing text replacements
broad_replacements = {
    "Export Order": "Print Order",
    "export order": "print order",
    "Export order": "Print order",
    "Build Export Order": "Build Print Order",
    "PDF Workspace": "Source PDFs",
}

# Avoid renaming internal variable names like export_order_list.
# These broad replacements affect strings/comments only by targeting quoted text-ish common phrases.
for old, new in broad_replacements.items():
    # Replace only simple quoted/user text leftovers.
    for quote in ['"', "'"]:
        old_q = quote + old + quote
        new_q = quote + new + quote
        if old_q in text:
            count = text.count(old_q)
            text = text.replace(old_q, new_q)
            changed += count
            print(f"[OK] Broad quoted replace {count}: {old} -> {new}")

# Comments are okay either way, but change visible confirmation message text if present.
text = text.replace(
    "Export the selected pages in this order?",
    "Create the print PDF using this page order?"
)

# Keep internal method/variable names unchanged for safety:
# export_order_list, refresh_export_order_from_checked_pages, etc. are not renamed.

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_rename_workspace_print_order_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "Source PDFs",
    "Print Order",
    "Build Print Order",
    "source PDF files",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Some expected user-facing text was not found:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print(f"- user-facing replacements applied: {changed}")
print("- Internal variable/method names were kept unchanged for safety")
print("- Open PDFs remains unchanged")
