﻿from pathlib import Path
import re
import ast
import sys

ROOT = Path.cwd()
OUT = ROOT / "handover_extract.txt"

CANDIDATES = [
    ROOT / "main_window.py",
    ROOT / "src" / "main_window.py",
    ROOT / "app" / "main_window.py",
    ROOT / "ui" / "main_window.py",
]

main_path = None
for p in CANDIDATES:
    if p.exists():
        main_path = p
        break

if main_path is None:
    found = list(ROOT.rglob("main_window.py"))
    if found:
        main_path = found[0]

if main_path is None:
    OUT.write_text(
        "ERROR: main_window.py not found.\n"
        f"ROOT={ROOT}\n"
        "Please run this script from the project root folder.\n",
        encoding="utf-8"
    )
    print(f"[ERROR] main_window.py not found. Wrote: {OUT}")
    sys.exit(1)

text = main_path.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines()

def line_no_from_pos(pos):
    return text.count("\n", 0, pos) + 1

def extract_function_block(source, func_name):
    pattern = re.compile(rf"^([ \t]*)def {re.escape(func_name)}\s*\(", re.M)
    m = pattern.search(source)
    if not m:
        return None

    indent = m.group(1)
    start = m.start()
    start_line = line_no_from_pos(start)

    next_pattern = re.compile(rf"^(?!{re.escape(indent)}[ \t]){re.escape(indent)}def\s+|\n{re.escape(indent)}def\s+", re.M)
    # safer manual scan
    source_lines = source.splitlines(True)
    acc_pos = 0
    start_idx = None
    for i, ln in enumerate(source_lines):
        if acc_pos == start:
            start_idx = i
            break
        acc_pos += len(ln)

    if start_idx is None:
        return None

    base_indent_len = len(indent)
    end_idx = len(source_lines)

    for j in range(start_idx + 1, len(source_lines)):
        raw = source_lines[j]
        stripped = raw.strip()

        if not stripped:
            continue

        current_indent_len = len(raw) - len(raw.lstrip(" \t"))

        # same or lower indentation with def/class means function block ended
        if current_indent_len <= base_indent_len and (
            raw.lstrip().startswith("def ") or raw.lstrip().startswith("class ")
        ):
            end_idx = j
            break

    block = "".join(source_lines[start_idx:end_idx])
    end_line = start_line + block.count("\n")
    return start_line, end_line, block

def find_context(keyword, radius=25):
    result = []
    lowered = text.lower()
    key = keyword.lower()
    for i, ln in enumerate(lines):
        if key in ln.lower():
            s = max(0, i - radius)
            e = min(len(lines), i + radius + 1)
            result.append((i + 1, s + 1, e, "\n".join(f"{n+1:05d}: {lines[n]}" for n in range(s, e))))
    return result

def grep_many(patterns):
    rows = []
    for idx, ln in enumerate(lines, 1):
        for pat in patterns:
            if re.search(pat, ln):
                rows.append(f"{idx:05d}: {ln}")
                break
    return "\n".join(rows)

functions_to_extract = [
    "_create_central_ui",
    "_create_log_panel",
    "_create_status_tab",
    "_create_view_tab",
    "_create_export_tab",
    "_create_a3_split_tab",
    "_create_selection_tab",
    "_update_preview",
    "_fit_page",
    "_actual_size",
]

patterns = [
    r"QSplitter",
    r"settings_area",
    r"settings_scroll",
    r"preview_area",
    r"scroll_area",
    r"preview",
    r"setFixedWidth",
    r"setMinimumWidth",
    r"setMaximumWidth",
    r"setStretch",
    r"addWidget",
    r"QHBoxLayout",
    r"QVBoxLayout",
    r"setCentralWidget",
]

report = []
report.append("# handover_extract.txt")
report.append("")
report.append("## Environment")
report.append(f"- root: {ROOT}")
report.append(f"- main_window.py: {main_path}")
report.append(f"- main_window.py size: {len(text)} chars / {len(lines)} lines")
report.append("")

report.append("## Python syntax check via ast")
try:
    ast.parse(text)
    report.append("- ast.parse: OK")
except SyntaxError as e:
    report.append("- ast.parse: FAILED")
    report.append(f"  - {e}")
report.append("")

report.append("## Imports related to Qt layout/widgets")
imports = []
for idx, ln in enumerate(lines, 1):
    if "PyQt6" in ln or "QSplitter" in ln or "QScrollArea" in ln or "QHBoxLayout" in ln or "QVBoxLayout" in ln:
        imports.append(f"{idx:05d}: {ln}")
report.append("\n".join(imports) if imports else "(none)")
report.append("")

report.append("## Key layout/widget references")
refs = grep_many(patterns)
report.append(refs if refs else "(none)")
report.append("")

for fn in functions_to_extract:
    report.append(f"## Function block: {fn}")
    block = extract_function_block(text, fn)
    if block is None:
        report.append("(not found)")
    else:
        start_line, end_line, code = block
        report.append(f"- lines: {start_line}-{end_line}")
        report.append("```python")
        report.append(code.rstrip())
        report.append("```")
    report.append("")

for keyword in ["settings_area", "settings_scroll", "preview_area", "setFixedWidth", "setMaximumWidth", "QSplitter"]:
    report.append(f"## Context around `{keyword}`")
    contexts = find_context(keyword, radius=18)
    if not contexts:
        report.append("(not found)")
    else:
        for hit_line, s, e, ctx in contexts[:8]:
            report.append(f"### hit line {hit_line}, context {s}-{e}")
            report.append("```text")
            report.append(ctx)
            report.append("```")
    report.append("")

OUT.write_text("\n".join(report), encoding="utf-8")
print(f"[OK] Extracted info to: {OUT}")
print("")
print("Please open handover_extract.txt and paste its contents here.")
