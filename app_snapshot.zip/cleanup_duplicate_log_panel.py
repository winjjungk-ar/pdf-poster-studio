﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_remove_duplicate_log_panel_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
lines = text.splitlines(True)

try:
    tree = ast.parse(text)
except SyntaxError as exc:
    print(f"[ERROR] Syntax error before patch: {exc}")
    sys.exit(1)

targets = []
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef) and node.name == "_create_log_panel":
        targets.append((node.lineno, node.end_lineno))

targets.sort()

print(f"[INFO] Found _create_log_panel definitions: {len(targets)}")
for start, end in targets:
    print(f"  - lines {start}-{end} ({end - start + 1} lines)")

if len(targets) <= 1:
    print("[SKIP] No duplicate _create_log_panel found.")
    sys.exit(0)

# Keep the last definition, remove previous duplicate definitions.
remove_ranges = targets[:-1]

for start, end in sorted(remove_ranges, reverse=True):
    removed = "".join(lines[start - 1:end])

    suspicious_markers = [
        "QTabWidget",
        "root_layout",
        "open_pdf_button",
        "settings_area",
        "preview_area",
        "self.main_splitter",
    ]

    if any(marker in removed for marker in suspicious_markers):
        print(f"[OK] Removing suspicious duplicate _create_log_panel lines {start}-{end}")
    else:
        print(f"[OK] Removing duplicate _create_log_panel lines {start}-{end}")

    del lines[start - 1:end]

new_text = "".join(lines)
MAIN.write_text(new_text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_remove_duplicate_log_panel_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

# Verify after cleanup.
new_tree = ast.parse(MAIN.read_text(encoding="utf-8", errors="replace"))
remaining = []

for node in ast.walk(new_tree):
    if isinstance(node, ast.FunctionDef) and node.name == "_create_log_panel":
        remaining.append((node.lineno, node.end_lineno))

print(f"[INFO] Remaining _create_log_panel definitions: {len(remaining)}")
for start, end in remaining:
    print(f"  - lines {start}-{end} ({end - start + 1} lines)")

if len(remaining) != 1:
    print("[ERROR] Expected exactly one _create_log_panel after cleanup.")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Duplicate/dead _create_log_panel removed")
print("- Normal short log panel function remains")
