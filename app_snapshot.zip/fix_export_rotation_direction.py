﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
EXPORTER = ROOT / "app" / "pdf" / "poster_exporter.py"
MAIN = ROOT / "app" / "main_window.py"

if not EXPORTER.exists():
    print(f"[ERROR] Not found: {EXPORTER}")
    sys.exit(1)

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
exporter_backup = EXPORTER.with_name(f"poster_exporter.py.bak_fix_export_rotation_direction_{timestamp}")
main_backup = MAIN.with_name(f"main_window.py.bak_fix_export_rotation_direction_{timestamp}")

shutil.copy2(EXPORTER, exporter_backup)
shutil.copy2(MAIN, main_backup)

print(f"[OK] Backup created: {exporter_backup}")
print(f"[OK] Backup created: {main_backup}")

exporter_text = EXPORTER.read_text(encoding="utf-8", errors="replace")
main_text = MAIN.read_text(encoding="utf-8", errors="replace")

# ------------------------------------------------------------
# 1) Replace _get_page_rotation in poster_exporter.py
# ------------------------------------------------------------
def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    targets = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == func_name
    ]

    if not targets:
        raise RuntimeError(f"Function not found: {func_name}")

    node = sorted(targets, key=lambda n: n.lineno)[0]
    return "".join(lines[:node.lineno - 1]) + new_func + "\n" + "".join(lines[node.end_lineno:])

new_get_page_rotation = r'''    def _get_page_rotation(self, page_index: int, options: ExportOptions) -> int:
        try:
            rotations = getattr(options, "page_rotations", None) or {}
            preview_rotation = int(rotations.get(page_index, 0)) % 360

            # PyQt preview rotation and PyMuPDF show_pdf_page rotation use opposite visual direction.
            # Invert the angle so exported PDF matches the preview.
            return (-preview_rotation) % 360

        except Exception:
            return 0
'''

try:
    exporter_text = replace_function(exporter_text, "_get_page_rotation", new_get_page_rotation)
    print("[OK] Export rotation direction corrected")
except Exception as exc:
    print(f"[ERROR] Could not replace _get_page_rotation: {exc}")
    EXPORTER.write_text(exporter_text, encoding="utf-8")
    sys.exit(1)

EXPORTER.write_text(exporter_text, encoding="utf-8")

# ------------------------------------------------------------
# 2) Release Notes update
# ------------------------------------------------------------
if "Export rotation direction fix" not in main_text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.6</h3>
<ul>
  <li><b>Export rotation direction fix</b>: Exported PDFs now match the rotation direction shown in Preview.</li>
</ul>
<hr>
"""
    if anchor in main_text:
        main_text = main_text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated")
    else:
        print("[WARN] Release Notes anchor not found")

MAIN.write_text(main_text, encoding="utf-8")

# ------------------------------------------------------------
# 3) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")

for path, backup in [
    (EXPORTER, exporter_backup),
    (MAIN, main_backup),
]:
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
    )

    if result.returncode != 0:
        failed = path.with_name(f"{path.name}.failed_fix_export_rotation_direction_{timestamp}")
        shutil.copy2(path, failed)
        shutil.copy2(backup, path)

        print(f"[ERROR] py_compile failed: {path}")
        print(result.stdout)
        print(result.stderr)
        print(f"[RESTORED] Restored: {backup}")
        print(f"[INFO] Failed file saved: {failed}")
        sys.exit(result.returncode)

print("[OK] py_compile passed")

# ------------------------------------------------------------
# 4) Marker check
# ------------------------------------------------------------
exporter_new = EXPORTER.read_text(encoding="utf-8", errors="replace")
main_new = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker, source in [
    ("return (-preview_rotation) % 360", exporter_new),
    ("opposite visual direction", exporter_new),
    ("Export rotation direction fix", main_new),
]:
    print(f"  - {marker}: {marker in source}")

print("")
print("Done.")
print("- Export rotation direction is now inverted to match Preview")
print("- Test with Rotate Left / Rotate Right and export again")
print("- If testing EXE, rebuild EXE first")
