﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_toolbar_exports_folder_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add open_exports_folder method if missing
# ------------------------------------------------------------
method = r'''
    def open_exports_folder(self) -> None:
        try:
            EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
            os.startfile(str(EXPORTS_DIR))
            self._log(f"Opened exports folder: {EXPORTS_DIR}")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Open Exports Folder",
                f"Failed to open exports folder.\n\n{exc}"
            )
            self._log(f"Open exports folder error: {exc}")

'''

if "def open_exports_folder(self) -> None:" not in text:
    marker_candidates = [
        "    def open_last_exported_pdf(self) -> None:\n",
        "    def export_print_pdf(self) -> None:\n",
        "    def print_pdf(self) -> None:\n",
    ]

    inserted = False

    for marker in marker_candidates:
        pos = text.find(marker)
        if pos != -1:
            text = text[:pos] + method + "\n" + text[pos:]
            inserted = True
            print(f"[OK] Added open_exports_folder before {marker.strip()}")
            break

    if not inserted:
        print("[ERROR] Could not find insertion point for open_exports_folder")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)
else:
    print("[SKIP] open_exports_folder already exists")

# ------------------------------------------------------------
# 2) Add toolbar action right after Export PDF
# ------------------------------------------------------------
old = '''        export_action = QAction("Export PDF", self)
        export_action.triggered.connect(self.export_print_pdf)
        toolbar.addAction(export_action)
'''

new = '''        export_action = QAction("Export PDF", self)
        export_action.triggered.connect(self.export_print_pdf)
        toolbar.addAction(export_action)

        open_exports_folder_action = QAction("Open Exports Folder", self)
        open_exports_folder_action.triggered.connect(self.open_exports_folder)
        toolbar.addAction(open_exports_folder_action)
'''

toolbar_start = text.find("    def _create_quick_toolbar")
toolbar_end = text.find("\n    def ", toolbar_start + 10) if toolbar_start != -1 else -1

if toolbar_start == -1:
    print("[ERROR] _create_quick_toolbar not found")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

toolbar_segment = text[toolbar_start:toolbar_end if toolbar_end != -1 else len(text)]

if "Open Exports Folder" in toolbar_segment:
    print("[SKIP] Open Exports Folder already exists in toolbar")
else:
    if old in toolbar_segment:
        toolbar_segment = toolbar_segment.replace(old, new, 1)
        text = text[:toolbar_start] + toolbar_segment + text[toolbar_end if toolbar_end != -1 else len(text):]
        print("[OK] Added Open Exports Folder next to Export PDF in toolbar")
    else:
        print("[ERROR] Could not find Export PDF toolbar action block")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 3) py_compile
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_toolbar_exports_folder_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "def open_exports_folder",
    'QAction("Open Exports Folder", self)',
    "self.open_exports_folder",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[ERROR] Missing expected code:")
    for x in missing:
        print(f"  - {x}")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Toolbar button added: Open Exports Folder")
print("- It is placed next to Export PDF")
