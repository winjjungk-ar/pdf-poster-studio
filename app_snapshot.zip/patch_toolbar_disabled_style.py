﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_toolbar_disabled_style_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

old = '''            QToolButton:pressed {
                background-color: #CDECEF;
            }
'''

new = '''            QToolButton:pressed {
                background-color: #CDECEF;
            }
            QToolButton:disabled {
                color: #9AA6AD;
                background-color: #ECEFF1;
                border: 1px solid #D0D7DC;
            }
'''

if old in text and "QToolButton:disabled" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Added disabled style for toolbar buttons")
elif "QToolButton:disabled" in text:
    print("[SKIP] Disabled toolbar style already exists")
else:
    print("[ERROR] Could not find toolbar pressed style block")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_toolbar_disabled_style_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Disabled toolbar buttons now have gray background/text")
print("- Active toolbar buttons keep pastel mint style")
