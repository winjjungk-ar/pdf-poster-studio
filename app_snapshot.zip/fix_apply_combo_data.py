﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_fix_apply_combo_data_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

new_method = r'''    def _apply_combo_data(self, combo, target_data) -> bool:
        """Select combo item by itemData with tolerant type matching."""
        if combo is None:
            return False

        if target_data is None:
            return False

        # 1) Exact match first.
        for index in range(combo.count()):
            if combo.itemData(index) == target_data:
                combo.setCurrentIndex(index)
                return True

        # 2) String-normalized match.
        target_text = str(target_data)

        for index in range(combo.count()):
            data = combo.itemData(index)
            if str(data) == target_text:
                combo.setCurrentIndex(index)
                return True

        # 3) Numeric tolerant match.
        try:
            target_float = float(target_data)

            for index in range(combo.count()):
                data = combo.itemData(index)
                try:
                    if abs(float(data) - target_float) < 0.000001:
                        combo.setCurrentIndex(index)
                        return True
                except Exception:
                    continue
        except Exception:
            pass

        # 4) Text match fallback.
        for index in range(combo.count()):
            if combo.itemText(index) == target_text:
                combo.setCurrentIndex(index)
                return True

        self._log(f"Combo data not found: {target_data}")
        return False

'''

# Replace existing _apply_combo_data if present.
pattern = re.compile(
    r"^    def _apply_combo_data\(self, combo, target_data\).*?(?=^    def |\Z)",
    re.M | re.S
)

if pattern.search(text):
    text = pattern.sub(new_method + "\n", text, count=1)
    print("[OK] Replaced existing _apply_combo_data")
else:
    # Insert before project apply/collect area.
    markers = [
        "    def _apply_project_data(self, data: dict) -> None:\n",
        "    def _collect_project_data(self) -> dict:\n",
        "    def _create_central_ui(self) -> None:\n",
    ]

    inserted = False
    for marker in markers:
        pos = text.find(marker)
        if pos != -1:
            text = text[:pos] + new_method + "\n" + text[pos:]
            inserted = True
            print(f"[OK] Added _apply_combo_data before {marker.strip()}")
            break

    if not inserted:
        print("[ERROR] Could not find insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_fix_apply_combo_data_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

if "def _apply_combo_data" not in new_text:
    print("[ERROR] _apply_combo_data still missing")
    shutil.copy2(backup, MAIN)
    print("[RESTORED] Backup restored.")
    sys.exit(1)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- _apply_combo_data fixed/added with tolerant matching")
print("- Now run: python main.py")
