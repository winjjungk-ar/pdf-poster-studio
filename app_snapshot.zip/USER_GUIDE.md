# User Guide

## Quick Start

1. Open the program.
2. Click `Open PDF`.
3. Select a PDF file.
4. Choose output settings.
5. Export split-print PDF.
6. Print the exported PDF with an A4 printer.

## Notes

The first version is a development skeleton. PDF preview and split export will be added in later patches.