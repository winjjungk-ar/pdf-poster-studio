﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import re

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_add_qgridlayout_import_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

if "QGridLayout" in text.split("from app.", 1)[0]:
    print("[SKIP] QGridLayout already imported")
else:
    # Preferred: add after QHBoxLayout
    if "    QHBoxLayout,\n" in text:
        text = text.replace(
            "    QHBoxLayout,\n",
            "    QHBoxLayout,\n    QGridLayout,\n",
            1
        )
        print("[OK] Added QGridLayout after QHBoxLayout")
    elif "    QVBoxLayout,\n" in text:
        text = text.replace(
            "    QVBoxLayout,\n",
            "    QVBoxLayout,\n    QGridLayout,\n",
            1
        )
        print("[OK] Added QGridLayout after QVBoxLayout")
    else:
        print("[ERROR] Could not find layout import anchor")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_add_qgridlayout_import_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

print("[OK] py_compile passed")
print("")
print("Done.")
print("- QGridLayout import added")
print("- Run: py main.py")
