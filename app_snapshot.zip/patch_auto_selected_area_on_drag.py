﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_auto_selected_area_on_drag_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

old = '''            else:
                self.page_selections[self.current_page_index] = QRect(rect)
                self.checked_pages.add(self.current_page_index)
                self._refresh_current_page_check_state()
                self._refresh_page_list_item(self.current_page_index)
                self._log(
                    f"Selection changed on page {self.current_page_index + 1}: "
                    f"x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
                )
'''

new = '''            else:
                if hasattr(self, "output_area_combo") and self.output_area_combo.currentData() != "selected_area":
                    self._apply_combo_data(self.output_area_combo, "selected_area")
                    self.update_output_area_states()
                    self._log("Output Area automatically changed to Selected Area.")

                self.page_selections[self.current_page_index] = QRect(rect)
                self.checked_pages.add(self.current_page_index)
                self._refresh_current_page_check_state()
                self._refresh_page_list_item(self.current_page_index)
                self._log(
                    f"Selection changed on page {self.current_page_index + 1}: "
                    f"x={rect.x()}, y={rect.y()}, w={rect.width()}, h={rect.height()}"
                )
'''

if old in text and "Output Area automatically changed to Selected Area" not in text:
    text = text.replace(old, new, 1)
    print("[OK] Selection drag now switches Output Area to Selected Area")
else:
    if "Output Area automatically changed to Selected Area" in text:
        print("[SKIP] Auto switch already present")
    else:
        print("[ERROR] Could not find on_selection_changed selection block")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

# Release Notes update
if "Dragging a selection switches Output Area to Selected Area" not in text:
    anchor = "<h2>PDF Poster Studio - Release Notes</h2>"
    section = """
<h3>Version 0.9.5</h3>
<ul>
  <li><b>Output Area smart switching</b>: Dragging a selection switches Output Area to Selected Area automatically.</li>
  <li>Whole Page mode remains unchanged when a selection is cleared.</li>
</ul>
<hr>
"""
    if anchor in text:
        text = text.replace(anchor, anchor + "\n" + section, 1)
        print("[OK] Release Notes updated for smart Output Area switching")
    else:
        print("[WARN] Release Notes anchor not found")

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_auto_selected_area_on_drag_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

print("[INFO] Marker check:")
for marker in [
    "Output Area automatically changed to Selected Area",
    "Dragging a selection switches Output Area to Selected Area",
]:
    print(f"  - {marker}: {marker in new_text}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Dragging a valid selection now switches Output Area to Selected Area")
print("- Clearing selection does not force Whole Page")
