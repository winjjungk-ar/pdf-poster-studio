﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_release_notes_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

# ------------------------------------------------------------
# 1) Add Help > Release Notes menu
# ------------------------------------------------------------
old = '''        # Help
        help_menu.addAction("User Guide / How to Use", self.show_user_guide)
        help_menu.addSeparator()
        help_menu.addAction("About Program", self.show_about)
'''

new = '''        # Help
        help_menu.addAction("User Guide / How to Use", self.show_user_guide)
        help_menu.addAction("Release Notes", self.show_release_notes)
        help_menu.addSeparator()
        help_menu.addAction("About Program", self.show_about)
'''

if old in text and "Release Notes" not in text[text.find("def _create_menus"):text.find("def _create_app_icon") if "def _create_app_icon" in text else text.find("def _create_quick_toolbar")]:
    text = text.replace(old, new, 1)
    print("[OK] Added Help > Release Notes")
elif "Release Notes" in text:
    print("[SKIP] Release Notes already exists somewhere")
else:
    print("[WARN] Could not find Help menu block")

# ------------------------------------------------------------
# 2) Add short What's New to welcome popup
# ------------------------------------------------------------
old = '''        steps = QLabel(
            "New work:\\n"
            "1. Open one or more source PDF files.\\n"
            "2. Select an area manually or use Auto Select.\\n"
            "3. Build Print Order and choose Output Files.\\n"
            "4. Create Poster PDF for tiled prints, or Single Page PDF for clean page output.\\n\\n"
            "Examples:\\n"
            "• Game maps and wall posters\\n"
            "• TRPG / board game maps\\n"
            "• Engineering drawings and field work packages\\n\\n"
            "Existing work:\\n"
            "• Open Project to continue a saved workspace."
        )
'''

new = '''        steps = QLabel(
            "New work:\\n"
            "1. Open one or more source PDF files.\\n"
            "2. Select an area manually or use Auto Select.\\n"
            "3. Build Print Order and choose Output Files.\\n"
            "4. Create Poster PDF for tiled prints, or Single Page PDF for clean page output.\\n\\n"
            "Examples:\\n"
            "• Game maps and wall posters\\n"
            "• TRPG / board game maps\\n"
            "• Engineering drawings and field work packages\\n\\n"
            "What's new in 0.9.1:\\n"
            "• Poster presets for A-series, ANSI, Arch, and hobby posters\\n"
            "• Tiling Preview for poster layouts\\n"
            "• One PDF or Separate PDF output modes\\n\\n"
            "Existing work:\\n"
            "• Open Project to continue a saved workspace."
        )
'''

if old in text:
    text = text.replace(old, new, 1)
    print("[OK] Added short What's New to welcome popup")
else:
    print("[WARN] Welcome steps block not found. Skipped welcome update.")

# ------------------------------------------------------------
# 3) Add show_release_notes method before show_about
# ------------------------------------------------------------
method = r'''    def show_release_notes(self) -> None:
        notes = """
<h2>PDF Poster Studio - Release Notes</h2>

<h3>Version 0.9.1</h3>
<p>
This version focuses on making PDF Poster Studio easier to use for maps, posters,
game boards, engineering drawings, and print-ready PDF packages.
</p>

<hr>

<h3>Major New Features</h3>
<ul>
  <li><b>Open PDFs</b>: Open one or more source PDF files in one workspace.</li>
  <li><b>Source PDFs</b>: Manage loaded source PDF files.</li>
  <li><b>Print Order</b>: Build and arrange the final output order.</li>
  <li><b>Double-click Print Order items</b>: Jump directly to the related page preview.</li>
  <li><b>Create Poster PDF</b>: Create tiled poster output from selected areas.</li>
  <li><b>Create Single Page PDF</b>: Export selected areas as clean single-page output.</li>
  <li><b>Output Files</b>: Choose One PDF or Separate PDF per selected page.</li>
</ul>

<hr>

<h3>Poster Print Improvements</h3>
<ul>
  <li><b>A4 and US Letter</b> output paper support.</li>
  <li><b>A-series presets</b>: A3, A2, A1, A0 from A4.</li>
  <li><b>ANSI presets</b>: ANSI B, C, D, E for US Letter workflows.</li>
  <li><b>Arch presets</b>: Arch B, C, D, E for US Letter workflows.</li>
  <li><b>Hobby poster presets</b>: Poster Small, Medium, Large, Huge.</li>
  <li><b>Manual Poster Scale</b>: Adjust scale percentage manually.</li>
  <li><b>Tiling Preview</b>: See how sheets are arranged before export.</li>
  <li><b>Sheet numbers</b>: Short labels such as 1/4, 2/4.</li>
  <li><b>Cut guide lines</b>: Optional guide lines for trimming and taping.</li>
</ul>

<hr>

<h3>Quality Improvements</h3>
<ul>
  <li>Poster output now preserves PDF vector quality where possible.</li>
  <li>Text and line drawings should remain sharper than image-based poster output.</li>
  <li>Exported PDF files open automatically with the default Windows PDF viewer.</li>
</ul>

<hr>

<h3>Project Save / Load</h3>
<ul>
  <li>Source PDFs are saved in project files.</li>
  <li>Selections and checked pages are saved per source PDF.</li>
  <li>Print Order is saved and restored.</li>
  <li>Poster settings, presets, scale, and Output Files mode are saved.</li>
</ul>

<hr>

<h3>Use Cases</h3>
<ul>
  <li>Print game maps or TRPG battle maps across multiple pages.</li>
  <li>Create wall posters from PDF files.</li>
  <li>Print engineering drawings, P&amp;ID sections, loop sheets, and pipe drawings.</li>
  <li>Combine selected areas from multiple PDFs into one output PDF.</li>
  <li>Create separate PDF files for each selected page or drawing area.</li>
</ul>

<hr>

<h3>Known Notes</h3>
<ul>
  <li>This is still a pre-1.0 version.</li>
  <li>Some internal names may still use legacy terms for project compatibility.</li>
  <li>For best quality, use vector PDF sources when possible.</li>
</ul>
"""

        dialog = QDialog(self)
        dialog.setWindowTitle("Release Notes")
        dialog.setMinimumSize(720, 560)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        notes_view = QTextEdit()
        notes_view.setReadOnly(True)
        notes_view.setHtml(notes)
        notes_view.setStyleSheet("""
            QTextEdit {
                background-color: #FFFDF8;
                color: #2F4F5F;
                border: 1px solid #EADBC8;
                border-radius: 8px;
                padding: 10px;
                font-family: Segoe UI, Arial;
                font-size: 10.5pt;
            }
        """)

        close_button = QPushButton("Close")
        close_button.clicked.connect(dialog.accept)

        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_button)

        layout.addWidget(notes_view)
        layout.addLayout(button_layout)

        dialog.exec()

'''

if "def show_release_notes" not in text:
    marker = "    def show_about(self) -> None:\n"
    pos = text.find(marker)

    if pos == -1:
        print("[ERROR] Could not find show_about insertion point")
        MAIN.write_text(original, encoding="utf-8")
        sys.exit(1)

    text = text[:pos] + method + "\n" + text[pos:]
    print("[OK] Added show_release_notes method")
else:
    print("[SKIP] show_release_notes already exists")

MAIN.write_text(text, encoding="utf-8")

# ------------------------------------------------------------
# 4) Compile check
# ------------------------------------------------------------
print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_release_notes_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "def show_release_notes",
    "Release Notes",
    "Version 0.9.1",
    "Hobby poster presets",
    "What's new in 0.9.1",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Help > Release Notes added")
print("- Welcome popup includes What's new in 0.9.1")
