﻿from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys
import ast

ROOT = Path.cwd()
MAIN = ROOT / "app" / "main_window.py"

if not MAIN.exists():
    print(f"[ERROR] Not found: {MAIN}")
    sys.exit(1)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = MAIN.with_name(f"main_window.py.bak_welcome_broadened_{timestamp}")
shutil.copy2(MAIN, backup)
print(f"[OK] Backup created: {backup}")

text = MAIN.read_text(encoding="utf-8", errors="replace")
original = text

def replace_function(source: str, func_name: str, new_func: str) -> str:
    tree = ast.parse(source)
    lines = source.splitlines(True)

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = node.end_lineno
            return "".join(lines[:start]) + new_func + "\n" + "".join(lines[end:])

    raise RuntimeError(f"Function not found: {func_name}")

new_show_welcome = r'''    def _show_welcome_dialog(self) -> None:
        if hasattr(self, "workspace_items") and self.workspace_items:
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Welcome to PDF Poster Studio")
        dialog.setModal(True)
        dialog.setMinimumWidth(560)
        dialog.setWindowIcon(self.windowIcon())

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(26, 24, 26, 24)
        layout.setSpacing(14)

        dialog.setStyleSheet("""
            QDialog {
                background-color: #FFF8F0;
            }
            QLabel#welcomeTitle {
                color: #395B64;
                font-size: 22px;
                font-weight: 800;
            }
            QLabel#welcomeSubtitle {
                color: #4F6F8F;
                font-size: 13px;
                line-height: 1.4;
            }
            QLabel#welcomeSteps {
                color: #395B64;
                background-color: #EAF7F7;
                border: 1px solid #BFE8E8;
                border-radius: 10px;
                padding: 14px;
                font-size: 13px;
            }
            QPushButton#openPdfsButton {
                color: white;
                background-color: #6AA6FF;
                border: 1px solid #4C8FE8;
                border-radius: 8px;
                padding: 10px 18px;
                font-size: 15px;
                font-weight: 800;
            }
            QPushButton#openPdfsButton:hover {
                background-color: #5A98F0;
            }
            QPushButton#openProjectButton {
                color: #395B64;
                background-color: #DDF3D5;
                border: 1px solid #B7DFAE;
                border-radius: 8px;
                padding: 9px 16px;
                font-weight: 800;
            }
            QPushButton#openProjectButton:hover {
                background-color: #CFECC5;
            }
            QPushButton#closeWelcomeButton {
                color: #395B64;
                background-color: #F6E7CB;
                border: 1px solid #E4CFA8;
                border-radius: 8px;
                padding: 9px 16px;
                font-weight: 700;
            }
            QPushButton#closeWelcomeButton:hover {
                background-color: #EFDDBA;
            }
        """)

        title = QLabel("PDF Poster Studio")
        title.setObjectName("welcomeTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel(
            "Print large maps, posters, game boards, and engineering drawings "
            "from normal PDF files."
        )
        subtitle.setObjectName("welcomeSubtitle")
        subtitle.setWordWrap(True)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        steps = QLabel(
            "New work:\\n"
            "1. Open one or more source PDF files.\\n"
            "2. Select an area manually or use Auto Select.\\n"
            "3. Build Print Order and choose Output Files.\\n"
            "4. Create Poster PDF for tiled prints, or Single Page PDF for clean page output.\\n\\n"
            "Examples:\\n"
            "• Game maps and wall posters\\n"
            "• TRPG / board game maps\\n"
            "• Engineering drawings and field work packages\\n\\n"
            "Existing work:\\n"
            "• Open Project to continue a saved workspace."
        )
        steps.setObjectName("welcomeSteps")
        steps.setWordWrap(True)
        layout.addWidget(steps)

        button_layout = QHBoxLayout()
        button_layout.addStretch()

        open_button = QPushButton("Open PDFs")
        open_button.setObjectName("openPdfsButton")

        open_project_button = QPushButton("Open Project")
        open_project_button.setObjectName("openProjectButton")

        close_button = QPushButton("Continue")
        close_button.setObjectName("closeWelcomeButton")

        button_layout.addWidget(open_button)
        button_layout.addWidget(open_project_button)
        button_layout.addWidget(close_button)
        button_layout.addStretch()
        layout.addLayout(button_layout)

        def open_pdfs_and_close() -> None:
            dialog.accept()
            self.open_pdfs()

        def open_project_and_close() -> None:
            dialog.accept()
            self.open_project()

        open_button.clicked.connect(open_pdfs_and_close)
        open_project_button.clicked.connect(open_project_and_close)
        close_button.clicked.connect(dialog.reject)

        dialog.exec()
'''

try:
    text = replace_function(text, "_show_welcome_dialog", new_show_welcome)
    print("[OK] Welcome dialog updated for maps/posters/drawings")
except Exception as exc:
    print(f"[ERROR] Could not replace _show_welcome_dialog: {exc}")
    MAIN.write_text(original, encoding="utf-8")
    sys.exit(1)

MAIN.write_text(text, encoding="utf-8")

print("[INFO] Running py_compile...")
result = subprocess.run(
    [sys.executable, "-m", "py_compile", str(MAIN)],
    cwd=str(ROOT),
    text=True,
    capture_output=True,
)

if result.returncode != 0:
    failed = MAIN.with_name(f"main_window.py.failed_welcome_broadened_{timestamp}")
    shutil.copy2(MAIN, failed)
    shutil.copy2(backup, MAIN)

    print("[ERROR] py_compile failed. Restored backup.")
    print(result.stdout)
    print(result.stderr)
    print(f"[INFO] Failed file saved: {failed}")
    sys.exit(result.returncode)

new_text = MAIN.read_text(encoding="utf-8", errors="replace")

required = [
    "game boards",
    "TRPG / board game maps",
    "Create Poster PDF for tiled prints",
    "Engineering drawings and field work packages",
]

missing = [x for x in required if x not in new_text]

if missing:
    print("[WARN] Missing expected markers:")
    for x in missing:
        print(f"  - {x}")

print("[OK] py_compile passed")
print("")
print("Done.")
print("- Welcome popup now explains maps, posters, game boards, and engineering drawings")
print("- Workflow mentions Create Poster PDF / Create Single Page PDF / Output Files")
